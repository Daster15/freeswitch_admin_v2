# -*- coding: utf-8 -*-
import base64
import logging

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

CDR_STATUS = [
    ('ringing',       'Dzwoni'),
    ('completed',     'Odebrane'),
    ('answered',      'Odebrane (krótkie)'),
    ('no_answer',     'Nieodebrane'),
    ('cancelled',     'Porzucone'),
    ('busy',          'Zajęte'),
    ('failed',        'Błąd'),
    ('fifo_timeout',  'Timeout kolejki'),
]

CDR_DIRECTION = [
    ('inbound',  'Przychodzące'),
    ('outbound', 'Wychodzące'),
]


class FreeSwitchCDR(models.Model):
    _name        = 'freeswitch.cdr'
    _description = 'FreeSWITCH — Historia połączeń (CDR)'
    _inherit     = ['freeswitch.db.mixin', 'mail.thread']
    _order       = 'start_time desc'
    _rec_name    = 'caller_id_num'

    # Klucz — UUID z FreeSWITCH
    fs_uuid          = fields.Char('UUID połączenia', required=False, index=True, readonly=True)
    caller_id_name   = fields.Char('Nazwa dzwoniącego', readonly=True)
    caller_id_num    = fields.Char('Numer dzwoniącego',  required=True, readonly=True, index=True)
    destination_num  = fields.Char('Numer docelowy',     required=True, readonly=True, index=True)
    direction        = fields.Selection(CDR_DIRECTION, string='Kierunek',
                                        default='inbound', readonly=True)
    status           = fields.Selection(CDR_STATUS, string='Status',
                                        default='ringing', readonly=True)

    # Czasy
    start_time       = fields.Datetime('Czas połączenia',  readonly=True, index=True)
    answer_time      = fields.Datetime('Czas odebrania',   readonly=True)
    end_time         = fields.Datetime('Czas zakończenia', readonly=True)
    duration_sec     = fields.Integer('Czas trwania (s)', readonly=True, default=0)
    billsec          = fields.Integer('Czas billingu (s)', readonly=True, default=0)
    wait_time_sec    = fields.Integer('Czas oczekiwania (s)', readonly=True, default=0)
    hangup_cause     = fields.Char('Przyczyna rozłączenia', readonly=True)

    # Routing
    route_type       = fields.Char('Typ routingu',  readonly=True)
    route_target     = fields.Char('Cel routingu',  readonly=True)
    queue_name       = fields.Char('Kolejka',        readonly=True, index=True)
    agent_id         = fields.Char('Agent',          readonly=True, index=True)
    ivr_name         = fields.Char('IVR',            readonly=True)
    ivr_selections   = fields.Char('Wybory IVR',     readonly=True,
                                   help='Historia wyborów DTMF, np. [1, 2]')
    placowka         = fields.Char('Placówka',       readonly=True)

    # Nagranie
    recording_path   = fields.Char('Ścieżka nagrania', readonly=True)
    recording_url    = fields.Char('URL nagrania',     compute='_compute_recording_url')
    has_recording    = fields.Boolean('Ma nagranie',
                                      compute='_compute_has_recording', store=True)
    has_attachment   = fields.Boolean('Ma załącznik audio',
                                      compute='_compute_has_attachment', store=True)

    # Computed — czytelne czasy
    duration_human   = fields.Char('Czas trwania', compute='_compute_human_times')
    wait_human       = fields.Char('Czas oczekiwania', compute='_compute_human_times')

    @api.depends('recording_path')
    def _compute_recording_url(self):
        ICP = self.env['ir.config_parameter'].sudo()
        base = ICP.get_param('freeswitch.recordings_url', '').rstrip('/')
        for rec in self:
            if rec.recording_path and rec.fs_uuid:
                rec.recording_url = f'{base}/{rec.fs_uuid}'
            else:
                rec.recording_url = False

    @api.depends('recording_path')
    def _compute_has_recording(self):
        for rec in self:
            rec.has_recording = bool(rec.recording_path)

    def _compute_has_attachment(self):
        for rec in self:
            if not rec.id:
                rec.has_attachment = False
                continue
            rec.has_attachment = bool(
                self.env['ir.attachment'].search([
                    ('res_model', '=', 'freeswitch.cdr'),
                    ('res_id',    '=', rec.id),
                    ('mimetype',  'in', ['audio/wav', 'audio/x-wav',
                                         'audio/mpeg', 'audio/mp3']),
                ], limit=1)
            )

    def create_recording_attachment(self, filename, mimetype, datas_b64):
        """
        Tworzy ir.attachment z danymi nagrania.
        Wywoływane przez kontroler /freeswitch/recording/attach.

        :param filename:   nazwa pliku, np. 'nagranie_<uuid>.wav'
        :param mimetype:   'audio/wav' lub 'audio/mpeg'
        :param datas_b64:  zawartość pliku zakodowana w base64
        :returns:          rekord ir.attachment
        """
        self.ensure_one()

        # Usuń stary załącznik audio jeśli istnieje (nadpisz)
        old = self.env['ir.attachment'].search([
            ('res_model', '=', 'freeswitch.cdr'),
            ('res_id',    '=', self.id),
            ('mimetype',  'in', ['audio/wav', 'audio/x-wav',
                                  'audio/mpeg', 'audio/mp3']),
        ])
        if old:
            old.unlink()

        att = self.env['ir.attachment'].sudo().create({
            'name':        filename,
            'type':        'binary',
            'datas':       datas_b64,
            'mimetype':    mimetype,
            'res_model':   'freeswitch.cdr',
            'res_id':      self.id,
            'description': (
                f'Nagranie: {self.caller_id_num} → {self.destination_num}'
                f' | {self.start_time}'
            ),
        })
        self.has_attachment = True
        _logger.info('CDR %s: załącznik nagrania id=%d (%s)',
                     self.fs_uuid, att.id, filename)
        return att

    @api.depends('duration_sec', 'wait_time_sec')
    def _compute_human_times(self):
        def fmt(s):
            if not s:
                return '–'
            m, sec = divmod(int(s), 60)
            return f'{m}:{sec:02d}'
        for rec in self:
            rec.duration_human = fmt(rec.duration_sec)
            rec.wait_human     = fmt(rec.wait_time_sec)

    # ── Akcje ────────────────────────────────────────────────────────────
    def action_play_recording(self):
        """Odtwórz nagranie: załącznik Odoo (priorytet) lub zewnętrzny URL."""
        self.ensure_one()
        att = self.env['ir.attachment'].search([
            ('res_model', '=', 'freeswitch.cdr'),
            ('res_id',    '=', self.id),
            ('mimetype',  'in', ['audio/wav', 'audio/x-wav',
                                  'audio/mpeg', 'audio/mp3']),
        ], limit=1, order='id desc')
        if att:
            return {
                'type':   'ir.actions.act_url',
                'url':    f'/web/content/{att.id}?download=false',
                'target': 'new',
            }
        if self.recording_url:
            return {
                'type':   'ir.actions.act_url',
                'url':    self.recording_url,
                'target': 'new',
            }
        raise UserError(_('Brak nagrania dla tego połączenia.'))

    def action_sync_from_fs(self, limit=500, date_from=None):
        """Importuj CDR z PostgreSQL FreeSWITCH do Odoo."""
        where = "WHERE 1=1"
        params = []
        if date_from:
            where += " AND start_time >= %s"
            params.append(date_from)

        sql = f"""
            SELECT id, caller_id_name, caller_id_num, destination_num,
                   direction, status, start_time, answer_time, end_time,
                   duration_sec, billsec, wait_time_sec, hangup_cause,
                   recording_path, route_type, route_target,
                   queue_name, agent_id, ivr_name,
                   ivr_selections::text, placowka
            FROM   call_records
            {where}
            ORDER  BY start_time DESC
            LIMIT  %s
        """
        params.append(limit)
        rows = self._fs_query(sql, params)

        created = updated = 0
        for row in rows:
            uid   = row.get('id', '')
            start = row.get('start_time')
            ans   = row.get('answer_time')
            end   = row.get('end_time')

            vals = {
                'fs_uuid':        uid,
                'caller_id_name': row.get('caller_id_name') or '',
                'caller_id_num':  row.get('caller_id_num', ''),
                'destination_num':row.get('destination_num', ''),
                'direction':      row.get('direction', 'inbound'),
                'status':         row.get('status', 'ringing'),
                'start_time':     start,
                'answer_time':    ans,
                'end_time':       end,
                'duration_sec':   row.get('duration_sec', 0) or 0,
                'billsec':        row.get('billsec', 0) or 0,
                'wait_time_sec':  row.get('wait_time_sec', 0) or 0,
                'hangup_cause':   row.get('hangup_cause') or '',
                'recording_path': row.get('recording_path') or '',
                'route_type':     row.get('route_type') or '',
                'route_target':   row.get('route_target') or '',
                'queue_name':     row.get('queue_name') or '',
                'agent_id':       row.get('agent_id') or '',
                'ivr_name':       row.get('ivr_name') or '',
                'ivr_selections': row.get('ivr_selections') or '',
                'placowka':       row.get('placowka') or '',
            }

            existing = self.search([('fs_uuid', '=', uid)], limit=1)
            if existing:
                existing.write(vals); updated += 1
            else:
                self.create(vals);   created += 1

        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title':   _('Import CDR'),
                'message': _('Zaimportowano: %d nowych, %d zaktualizowanych') % (created, updated),
                'type':    'success',
            }
        }