# -*- coding: utf-8 -*-
"""
controllers/recording_controller.py
====================================
Endpoint przyjmujący nagranie WAV z cdr_writer.lua i dołączający je
jako ir.attachment do rekordu freeswitch.cdr.

Wywołanie z cdr_writer.lua (przez curl):
    POST /freeswitch/recording/attach
    Content-Type: application/json
    {
        "uuid":     "<fs_uuid>",
        "filename": "nagranie_<uuid>.wav",
        "mimetype": "audio/wav",
        "datas":    "<base64>"
    }

Odpowiedź:
    {"status": "ok",    "attachment_id": 42}   — sukces
    {"status": "error", "message": "..."}       — błąd
"""
import logging

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)

# Zaufane IP — te same co dla xml_curl i webhooka CDR
_ALLOWED_IPS = {
    '127.0.0.1',
    '::1',
    '192.168.0.58',   # IP serwera FreeSWITCH — dostosuj do swojej sieci
}


class RecordingAttachController(http.Controller):

    @http.route(
        '/freeswitch/recording/attach',
        type='json',
        auth='none',
        methods=['POST'],
        csrf=False,
    )
    def attach_recording(self, **kwargs):
        """
        Przyjmuje base64 pliku WAV z FreeSWITCH i tworzy ir.attachment
        powiązany z rekordem freeswitch.cdr (szukamy po fs_uuid).
        """
        # ── Weryfikacja IP źródłowego ─────────────────────────────────────────
        remote_ip = request.httprequest.remote_addr or ''
        if remote_ip not in _ALLOWED_IPS:
            _logger.warning('recording/attach: odrzucono IP=%s', remote_ip)
            return {'status': 'error', 'message': 'forbidden'}

        # ── Pobierz dane z JSON body ──────────────────────────────────────────
        data = request.get_json_data() if hasattr(request, 'get_json_data') \
               else (request.jsonrequest or {})

        uuid     = (data.get('uuid')     or '').strip()
        filename = (data.get('filename') or '').strip()
        mimetype = (data.get('mimetype') or 'audio/wav').strip()
        datas    = (data.get('datas')    or '').strip()

        if not uuid:
            return {'status': 'error', 'message': 'missing uuid'}
        if not datas:
            return {'status': 'error', 'message': 'missing datas'}
        if not filename:
            filename = f'nagranie_{uuid}.wav'

        _logger.info('recording/attach: uuid=%s plik=%s rozmiar_b64=%d',
                     uuid, filename, len(datas))

        # ── Znajdź rekord CDR ─────────────────────────────────────────────────
        CDR = request.env['freeswitch.cdr'].sudo()
        cdr = CDR.search([('fs_uuid', '=', uuid)], limit=1)

        if not cdr:
            # CDR może jeszcze nie istnieć gdy cdr_writer wysyła nagranie
            # przed zapisem CDR — zrób 3 próby z krótkim czekaniem
            import time
            for attempt in range(3):
                time.sleep(1)
                cdr = CDR.search([('fs_uuid', '=', uuid)], limit=1)
                if cdr:
                    break

        if not cdr:
            _logger.warning('recording/attach: brak CDR dla uuid=%s', uuid)
            return {'status': 'error', 'message': f'CDR not found: {uuid}'}

        # ── Utwórz załącznik ──────────────────────────────────────────────────
        try:
            att = cdr.create_recording_attachment(filename, mimetype, datas)
        except Exception as e:
            _logger.error('recording/attach: błąd tworzenia załącznika uuid=%s: %s',
                          uuid, e)
            return {'status': 'error', 'message': str(e)}

        return {
            'status':        'ok',
            'attachment_id': att.id,
            'uuid':          uuid,
            'filename':      filename,
        }