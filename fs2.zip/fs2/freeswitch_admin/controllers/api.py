# -*- coding: utf-8 -*-
"""
controllers/api.py
==================
REST API FreeSWITCH Admin — endpoint HTTP w Odoo.

Uwierzytelnienie: nagłówek  X-API-Key: <klucz z freeswitch.company.config>
Firma identyfikowana na podstawie klucza API.

Bazowy URL:  /freeswitch/api/v1/

Endpointy
---------
Trasy DID
  GET    /freeswitch/api/v1/routes
  GET    /freeswitch/api/v1/routes/<id>
  POST   /freeswitch/api/v1/routes
  PUT    /freeswitch/api/v1/routes/<id>
  DELETE /freeswitch/api/v1/routes/<id>

Użytkownicy SIP
  GET    /freeswitch/api/v1/sip_users
  GET    /freeswitch/api/v1/sip_users/<id>
  POST   /freeswitch/api/v1/sip_users
  PUT    /freeswitch/api/v1/sip_users/<id>
  DELETE /freeswitch/api/v1/sip_users/<id>

Konfiguracje IVR
  GET    /freeswitch/api/v1/ivr
  GET    /freeswitch/api/v1/ivr/<id>
  POST   /freeswitch/api/v1/ivr
  PUT    /freeswitch/api/v1/ivr/<id>
  DELETE /freeswitch/api/v1/ivr/<id>

Kolejki CallCenter
  GET    /freeswitch/api/v1/cc_queues
  GET    /freeswitch/api/v1/cc_queues/<id>
  POST   /freeswitch/api/v1/cc_queues
  PUT    /freeswitch/api/v1/cc_queues/<id>
  DELETE /freeswitch/api/v1/cc_queues/<id>

Dialplan
  POST   /freeswitch/api/v1/dialplan/reload

Statusy
  GET    /freeswitch/api/v1/health
  GET    /freeswitch/api/v1/cc_queues/<id>/stats

Dokumentacja
  GET    /freeswitch/api/v1/openapi.json  — specyfikacja OpenAPI 3.0
  GET    /freeswitch/api/v1/docs          — Swagger UI
"""

import base64
import json
import logging
import time

from odoo import http, _
from odoo.http import request, Response

_logger = logging.getLogger(__name__)

# ── Stałe ────────────────────────────────────────────────────────────────────
API_BASE = '/freeswitch/api/v1'


# ── Helpery ───────────────────────────────────────────────────────────────────

def _json_response(data, status=200):
    return Response(
        json.dumps(data, default=str, ensure_ascii=False),
        status=status,
        headers={'Content-Type': 'application/json; charset=utf-8'},
    )


def _error(message, status=400, code=None):
    return _json_response(
        {'error': message, 'code': code or str(status)},
        status=status,
    )


def _authenticate(func):
    """
    Dekorator sprawdzający nagłówek X-API-Key.
    Wstrzykuje obiekt `company_config` do kwargs wywoływanej metody.
    """
    def wrapper(self, *args, **kwargs):
        api_key = request.httprequest.headers.get('X-API-Key', '').strip()
        if not api_key:
            return _error('Brak nagłówka X-API-Key', 401, 'missing_key')

        cfg = request.env['freeswitch.company.config'].sudo().search(
            [('odoo_api_key', '=', api_key)], limit=1
        )
        if not cfg:
            return _error('Nieprawidłowy klucz API', 401, 'invalid_key')

        kwargs['_company_cfg'] = cfg
        # Pracuj w kontekście firmy powiązanej z kluczem
        request.env = request.env(context=dict(
            request.env.context,
            allowed_company_ids=[cfg.company_id.id],
            force_company=cfg.company_id.id,
        ))
        return func(self, *args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper


def _parse_body():
    """Parsuj JSON body z żądania."""
    try:
        data = request.httprequest.get_data(as_text=True)
        return json.loads(data) if data else {}
    except json.JSONDecodeError:
        return None


# ── Kontroler ─────────────────────────────────────────────────────────────────

class FreeSwitchApiController(http.Controller):

    # ══ HEALTH ══════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/health', type='http', auth='none', methods=['GET'], csrf=False)
    def health(self, **kw):
        return _json_response({'status': 'ok', 'module': 'freeswitch_admin'})

    # ══ WHOAMI ══════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/me', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def whoami(self, _company_cfg=None, **kw):
        """Zwróć informacje o kliencie powiązanym z kluczem API."""
        company = _company_cfg.company_id
        return _json_response({
            'company_id':    company.id,
            'company_name':  company.name,
            'company_vat':   company.vat or '',
            'company_email': company.email or '',
            'sip_domain':    _company_cfg.sip_domain or '',
            'gateway':       _company_cfg.gateway or '',
            'api_url':       _company_cfg.api_url or '',
        })

    # ══ TRASY DID ═══════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/routes', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def routes_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        # Opcjonalne filtry query string
        if kw.get('active'):
            domain.append(('active', '=', kw['active'].lower() == 'true'))
        if kw.get('name'):
            domain.append(('name', 'ilike', kw['name']))

        routes = request.env['freeswitch.route'].sudo().search(domain)
        return _json_response({'count': len(routes), 'results': [
            _route_to_dict(r) for r in routes
        ]})

    @http.route(f'{API_BASE}/routes/<int:route_id>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def routes_get(self, route_id, _company_cfg=None, **kw):
        route = _get_record('freeswitch.route', route_id, _company_cfg.company_id.id)
        if not route:
            return _error('Trasa nie znaleziona', 404)
        return _json_response(_route_to_dict(route, full=True))

    @http.route(f'{API_BASE}/routes', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def routes_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            route = request.env['freeswitch.route'].sudo().create(body)
            return _json_response(_route_to_dict(route), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/routes/<int:route_id>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def routes_update(self, route_id, _company_cfg=None, **kw):
        route = _get_record('freeswitch.route', route_id, _company_cfg.company_id.id)
        if not route:
            return _error('Trasa nie znaleziona', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)   # company_id nie można zmieniać
        try:
            route.sudo().write(body)
            return _json_response(_route_to_dict(route))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/routes/<int:route_id>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def routes_delete(self, route_id, _company_cfg=None, **kw):
        route = _get_record('freeswitch.route', route_id, _company_cfg.company_id.id)
        if not route:
            return _error('Trasa nie znaleziona', 404)
        route.sudo().unlink()
        return _json_response({'deleted': True, 'id': route_id})

    # ══ UŻYTKOWNICY SIP ═════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/sip_users', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sip_users_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        if kw.get('active'):
            domain.append(('active', '=', kw['active'].lower() == 'true'))
        if kw.get('extension'):
            domain.append(('extension', '=', kw['extension']))

        users = request.env['freeswitch.sip.user'].sudo().search(domain)
        return _json_response({'count': len(users), 'results': [
            _sip_user_to_dict(u) for u in users
        ]})

    @http.route(f'{API_BASE}/sip_users/<int:uid>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sip_users_get(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        return _json_response(_sip_user_to_dict(user))

    @http.route(f'{API_BASE}/sip_users', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def sip_users_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            user = request.env['freeswitch.sip.user'].sudo().create(body)
            return _json_response(_sip_user_to_dict(user), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sip_users/<int:uid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def sip_users_update(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)
        try:
            user.sudo().write(body)
            return _json_response(_sip_user_to_dict(user))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sip_users/<int:uid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def sip_users_delete(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        user.sudo().unlink()
        return _json_response({'deleted': True, 'id': uid})

    # ══ IVR ════════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/ivr', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def ivr_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        if kw.get('active'):
            domain.append(('active', '=', kw['active'].lower() == 'true'))

        ivrs = request.env['freeswitch.ivr'].sudo().search(domain)
        return _json_response({'count': len(ivrs), 'results': [
            _ivr_to_dict(i) for i in ivrs
        ]})

    @http.route(f'{API_BASE}/ivr/<int:ivr_id>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def ivr_get(self, ivr_id, _company_cfg=None, **kw):
        ivr = _get_record('freeswitch.ivr', ivr_id, _company_cfg.company_id.id)
        if not ivr:
            return _error('IVR nie znaleziony', 404)
        return _json_response(_ivr_to_dict(ivr, full=True))

    @http.route(f'{API_BASE}/ivr', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def ivr_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            ivr = request.env['freeswitch.ivr'].sudo().create(body)
            return _json_response(_ivr_to_dict(ivr), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/ivr/<int:ivr_id>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def ivr_update(self, ivr_id, _company_cfg=None, **kw):
        ivr = _get_record('freeswitch.ivr', ivr_id, _company_cfg.company_id.id)
        if not ivr:
            return _error('IVR nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)
        try:
            ivr.sudo().write(body)
            return _json_response(_ivr_to_dict(ivr))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/ivr/<int:ivr_id>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def ivr_delete(self, ivr_id, _company_cfg=None, **kw):
        ivr = _get_record('freeswitch.ivr', ivr_id, _company_cfg.company_id.id)
        if not ivr:
            return _error('IVR nie znaleziony', 404)
        ivr.sudo().unlink()
        return _json_response({'deleted': True, 'id': ivr_id})

    # ══ KOLEJKI CALLCENTER ══════════════════════════════════════════════════

    @http.route(f'{API_BASE}/cc_queues', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_queues_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        queues = request.env['freeswitch.cc.queue'].sudo().search(domain)
        return _json_response({'count': len(queues), 'results': [
            _cc_queue_to_dict(q) for q in queues
        ]})

    @http.route(f'{API_BASE}/cc_queues/<int:qid>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_queues_get(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        return _json_response(_cc_queue_to_dict(queue, full=True))

    @http.route(f'{API_BASE}/cc_queues', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def cc_queues_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            queue = request.env['freeswitch.cc.queue'].sudo().create(body)
            return _json_response(_cc_queue_to_dict(queue), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/cc_queues/<int:qid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def cc_queues_update(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)
        try:
            queue.sudo().write(body)
            return _json_response(_cc_queue_to_dict(queue))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/cc_queues/<int:qid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def cc_queues_delete(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        queue.sudo().unlink()
        return _json_response({'deleted': True, 'id': qid})

    @http.route(f'{API_BASE}/cc_queues/<int:qid>/stats', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_queues_stats(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        return _json_response({
            'id':               queue.id,
            'name':             queue.name,
            'callers_waiting':  queue.callers_waiting,
            'agents_available': queue.agents_available,
            'calls_today':      queue.calls_today,
        })


    # ══ AGENCI CALLCENTER ═══════════════════════════════════════════════════

    @http.route(f'{API_BASE}/cc_agents', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_agents_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        if kw.get('active'):
            domain.append(('active', '=', kw['active'].lower() == 'true'))
        if kw.get('status'):
            domain.append(('status', '=', kw['status']))
        agents = request.env['freeswitch.cc.agent'].sudo().search(domain, order='name')
        return _json_response({'count': len(agents), 'results': [
            _cc_agent_to_dict(a) for a in agents
        ]})

    @http.route(f'{API_BASE}/cc_agents/<int:aid>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_agents_get(self, aid, _company_cfg=None, **kw):
        agent = _get_record('freeswitch.cc.agent', aid, _company_cfg.company_id.id)
        if not agent:
            return _error('Agent nie znaleziony', 404)
        return _json_response(_cc_agent_to_dict(agent))

    @http.route(f'{API_BASE}/cc_agents', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def cc_agents_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            agent = request.env['freeswitch.cc.agent'].sudo().create(body)
            return _json_response(_cc_agent_to_dict(agent), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/cc_agents/<int:aid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def cc_agents_update(self, aid, _company_cfg=None, **kw):
        agent = _get_record('freeswitch.cc.agent', aid, _company_cfg.company_id.id)
        if not agent:
            return _error('Agent nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)
        try:
            agent.sudo().write(body)
            return _json_response(_cc_agent_to_dict(agent))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/cc_agents/<int:aid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def cc_agents_delete(self, aid, _company_cfg=None, **kw):
        agent = _get_record('freeswitch.cc.agent', aid, _company_cfg.company_id.id)
        if not agent:
            return _error('Agent nie znaleziony', 404)
        agent.sudo().unlink()
        return _json_response({'deleted': True, 'id': aid})

    # ══ REGUŁY CZASOWE TRAS DID ══════════════════════════════════════════════

    @http.route(f'{API_BASE}/routes/<int:route_id>/time_rules', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def time_rules_list(self, route_id, _company_cfg=None, **kw):
        route = _get_record('freeswitch.route', route_id, _company_cfg.company_id.id)
        if not route:
            return _error('Trasa nie znaleziona', 404)
        return _json_response({'count': len(route.time_rule_ids), 'results': [
            _time_rule_to_dict(t) for t in route.time_rule_ids
        ]})

    @http.route(f'{API_BASE}/routes/<int:route_id>/time_rules', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def time_rules_create(self, route_id, _company_cfg=None, **kw):
        route = _get_record('freeswitch.route', route_id, _company_cfg.company_id.id)
        if not route:
            return _error('Trasa nie znaleziona', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['route_id'] = route_id
        try:
            t = request.env['freeswitch.route.time_rule'].sudo().create(body)
            return _json_response(_time_rule_to_dict(t), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/time_rules/<int:tid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def time_rules_update(self, tid, _company_cfg=None, **kw):
        t = request.env['freeswitch.route.time_rule'].sudo().browse(tid)
        if not t.exists() or t.route_id.company_id.id != _company_cfg.company_id.id:
            return _error('Reguła nie znaleziona', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('route_id', None)
        try:
            t.write(body)
            return _json_response(_time_rule_to_dict(t))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/time_rules/<int:tid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def time_rules_delete(self, tid, _company_cfg=None, **kw):
        t = request.env['freeswitch.route.time_rule'].sudo().browse(tid)
        if not t.exists() or t.route_id.company_id.id != _company_cfg.company_id.id:
            return _error('Reguła nie znaleziona', 404)
        t.unlink()
        return _json_response({'deleted': True, 'id': tid})

    # ══ POZYCJE MENU IVR ═════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/ivr/<int:ivr_id>/items', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def ivr_items_list(self, ivr_id, _company_cfg=None, **kw):
        ivr = _get_record('freeswitch.ivr', ivr_id, _company_cfg.company_id.id)
        if not ivr:
            return _error('IVR nie znaleziony', 404)
        return _json_response({'count': len(ivr.menu_item_ids), 'results': [
            _ivr_item_to_dict(item) for item in ivr.menu_item_ids
        ]})

    @http.route(f'{API_BASE}/ivr/<int:ivr_id>/items', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def ivr_items_create(self, ivr_id, _company_cfg=None, **kw):
        ivr = _get_record('freeswitch.ivr', ivr_id, _company_cfg.company_id.id)
        if not ivr:
            return _error('IVR nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['ivr_id'] = ivr_id
        try:
            item = request.env['freeswitch.ivr.item'].sudo().create(body)
            return _json_response(_ivr_item_to_dict(item), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/ivr_items/<int:iid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def ivr_items_update(self, iid, _company_cfg=None, **kw):
        item = request.env['freeswitch.ivr.item'].sudo().browse(iid)
        if not item.exists() or item.ivr_id.company_id.id != _company_cfg.company_id.id:
            return _error('Pozycja IVR nie znaleziona', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('ivr_id', None)
        try:
            item.write(body)
            return _json_response(_ivr_item_to_dict(item))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/ivr_items/<int:iid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def ivr_items_delete(self, iid, _company_cfg=None, **kw):
        item = request.env['freeswitch.ivr.item'].sudo().browse(iid)
        if not item.exists() or item.ivr_id.company_id.id != _company_cfg.company_id.id:
            return _error('Pozycja IVR nie znaleziona', 404)
        item.unlink()
        return _json_response({'deleted': True, 'id': iid})

    # ══ TIERY AGENTÓW CC ════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/cc_queues/<int:qid>/tiers', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_tiers_list(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        return _json_response({'count': len(queue.tier_ids), 'results': [
            _cc_tier_to_dict(t) for t in queue.tier_ids
        ]})

    @http.route(f'{API_BASE}/cc_queues/<int:qid>/tiers', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def cc_tiers_create(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['queue_id'] = qid
        try:
            t = request.env['freeswitch.cc.tier'].sudo().create(body)
            return _json_response(_cc_tier_to_dict(t), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/cc_tiers/<int:tid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def cc_tiers_update(self, tid, _company_cfg=None, **kw):
        t = request.env['freeswitch.cc.tier'].sudo().browse(tid)
        if not t.exists() or t.queue_id.company_id.id != _company_cfg.company_id.id:
            return _error('Tier nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('queue_id', None)
        try:
            t.write(body)
            return _json_response(_cc_tier_to_dict(t))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/cc_tiers/<int:tid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def cc_tiers_delete(self, tid, _company_cfg=None, **kw):
        t = request.env['freeswitch.cc.tier'].sudo().browse(tid)
        if not t.exists() or t.queue_id.company_id.id != _company_cfg.company_id.id:
            return _error('Tier nie znaleziony', 404)
        t.unlink()
        return _json_response({'deleted': True, 'id': tid})

    # ══ URZĄDZENIA SIP ══════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/sip_users/<int:uid>/devices', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sip_devices_list(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        return _json_response({'count': len(user.device_ids), 'results': [
            _sip_device_to_dict(d) for d in user.device_ids
        ]})

    @http.route(f'{API_BASE}/sip_users/<int:uid>/devices', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def sip_devices_create(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['user_id'] = uid
        try:
            d = request.env['freeswitch.sip.device'].sudo().create(body)
            return _json_response(_sip_device_to_dict(d), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sip_devices/<int:did>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def sip_devices_update(self, did, _company_cfg=None, **kw):
        d = request.env['freeswitch.sip.device'].sudo().browse(did)
        if not d.exists() or d.user_id.company_id.id != _company_cfg.company_id.id:
            return _error('Urządzenie nie znalezione', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('user_id', None)
        try:
            d.write(body)
            return _json_response(_sip_device_to_dict(d))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sip_devices/<int:did>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def sip_devices_delete(self, did, _company_cfg=None, **kw):
        d = request.env['freeswitch.sip.device'].sudo().browse(did)
        if not d.exists() or d.user_id.company_id.id != _company_cfg.company_id.id:
            return _error('Urządzenie nie znalezione', 404)
        d.unlink()
        return _json_response({'deleted': True, 'id': did})

    # ══ HARMONOGRAMY SIP (godziny pracy) ═══════════════════════════════════════

    @http.route(f'{API_BASE}/sip_users/<int:uid>/calendar', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sip_calendar_list(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        return _json_response({'count': len(user.calendar_ids), 'results': [
            _calendar_to_dict(c) for c in user.calendar_ids
        ]})

    @http.route(f'{API_BASE}/sip_users/<int:uid>/calendar', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def sip_calendar_create(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['user_id'] = uid
        try:
            cal = request.env['freeswitch.sip.calendar'].sudo().create(body)
            return _json_response(_calendar_to_dict(cal), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sip_calendar/<int:cid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def sip_calendar_update(self, cid, _company_cfg=None, **kw):
        cal = request.env['freeswitch.sip.calendar'].sudo().browse(cid)
        if not cal.exists():
            return _error('Wpis kalendarza nie znaleziony', 404)
        # Sprawdź przynależność do firmy przez user_id
        if cal.user_id.company_id.id != _company_cfg.company_id.id:
            return _error('Wpis kalendarza nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('user_id', None)
        try:
            cal.write(body)
            return _json_response(_calendar_to_dict(cal))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sip_calendar/<int:cid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def sip_calendar_delete(self, cid, _company_cfg=None, **kw):
        cal = request.env['freeswitch.sip.calendar'].sudo().browse(cid)
        if not cal.exists():
            return _error('Wpis kalendarza nie znaleziony', 404)
        if cal.user_id.company_id.id != _company_cfg.company_id.id:
            return _error('Wpis kalendarza nie znaleziony', 404)
        cal.unlink()
        return _json_response({'deleted': True, 'id': cid})

    # ══ DNI WOLNE ════════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/holidays', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def holidays_list(self, _company_cfg=None, **kw):
        domain = [('active', '=', True)]
        if kw.get('country_code'):
            domain.append(('country_code', '=', kw['country_code']))
        if kw.get('date'):
            domain.append(('date', '=', kw['date']))
        holidays = request.env['freeswitch.public.holiday'].sudo().search(
            domain, order='country_code, date'
        )
        return _json_response({'count': len(holidays), 'results': [
            _holiday_to_dict(h) for h in holidays
        ]})

    @http.route(f'{API_BASE}/holidays/<int:hid>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def holidays_get(self, hid, _company_cfg=None, **kw):
        h = request.env['freeswitch.public.holiday'].sudo().browse(hid)
        if not h.exists() or not h.active:
            return _error('Dzień wolny nie znaleziony', 404)
        return _json_response(_holiday_to_dict(h))

    @http.route(f'{API_BASE}/holidays', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def holidays_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        try:
            h = request.env['freeswitch.public.holiday'].sudo().create(body)
            return _json_response(_holiday_to_dict(h), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/holidays/<int:hid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def holidays_update(self, hid, _company_cfg=None, **kw):
        h = request.env['freeswitch.public.holiday'].sudo().browse(hid)
        if not h.exists():
            return _error('Dzień wolny nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        try:
            h.write(body)
            return _json_response(_holiday_to_dict(h))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/holidays/<int:hid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def holidays_delete(self, hid, _company_cfg=None, **kw):
        h = request.env['freeswitch.public.holiday'].sudo().browse(hid)
        if not h.exists():
            return _error('Dzień wolny nie znaleziony', 404)
        h.unlink()
        return _json_response({'deleted': True, 'id': hid})

    # ══ BIBLIOTEKA DŹWIĘKÓW ═════════════════════════════════════════════════

    @http.route(f'{API_BASE}/sounds', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sounds_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        if kw.get('active'):
            domain.append(('active', '=', kw['active'].lower() == 'true'))
        if kw.get('category'):
            domain.append(('category', '=', kw['category']))
        if kw.get('name'):
            domain.append(('name', 'ilike', kw['name']))
        sounds = request.env['freeswitch.sound'].sudo().search(domain, order='category, name')
        return _json_response({'count': len(sounds), 'results': [
            _sound_to_dict(s) for s in sounds
        ]})

    @http.route(f'{API_BASE}/sounds/<int:sid>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sounds_get(self, sid, _company_cfg=None, **kw):
        sound = _get_record('freeswitch.sound', sid, _company_cfg.company_id.id)
        if not sound:
            return _error('Dźwięk nie znaleziony', 404)
        include_data = kw.get('include_data', '').lower() == 'true'
        return _json_response(_sound_to_dict(sound, include_data=include_data))

    @http.route(f'{API_BASE}/sounds', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def sounds_create(self, _company_cfg=None, **kw):
        """Utwórz rekord dźwięku (bez pliku audio — użyj PUT /sounds/<id>/upload)."""
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        body.pop('audio_data', None)   # audio tylko przez /upload
        try:
            sound = request.env['freeswitch.sound'].sudo().create(body)
            return _json_response(_sound_to_dict(sound), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sounds/<int:sid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def sounds_update(self, sid, _company_cfg=None, **kw):
        sound = _get_record('freeswitch.sound', sid, _company_cfg.company_id.id)
        if not sound:
            return _error('Dźwięk nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)
        body.pop('audio_data', None)   # audio tylko przez /upload
        try:
            sound.sudo().write(body)
            return _json_response(_sound_to_dict(sound))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sounds/<int:sid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def sounds_delete(self, sid, _company_cfg=None, **kw):
        sound = _get_record('freeswitch.sound', sid, _company_cfg.company_id.id)
        if not sound:
            return _error('Dźwięk nie znaleziony', 404)
        sound.sudo().unlink()
        return _json_response({'deleted': True, 'id': sid})

    @http.route(f'{API_BASE}/sounds/<int:sid>/upload', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def sounds_upload(self, sid, _company_cfg=None, **kw):
        """
        Upload pliku audio (multipart/form-data).
        Pole: file (binary)
        Opcjonalnie: fs_path (string)
        """
        sound = _get_record('freeswitch.sound', sid, _company_cfg.company_id.id)
        if not sound:
            return _error('Dźwięk nie znaleziony', 404)
        file_obj = request.httprequest.files.get('file')
        if not file_obj:
            return _error('Brak pola "file" w żądaniu multipart', 400)
        try:
            audio_bytes = file_obj.read()
            audio_b64   = base64.b64encode(audio_bytes).decode()
            vals = {
                'audio_data':  audio_b64,
                'audio_fname': file_obj.filename or 'sound.wav',
            }
            if kw.get('fs_path'):
                vals['fs_path'] = kw['fs_path']
            sound.sudo().write(vals)
            return _json_response(_sound_to_dict(sound))
        except Exception as e:
            return _error(str(e), 500)

    @http.route(f'{API_BASE}/sounds/<int:sid>/download', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sounds_download(self, sid, _company_cfg=None, **kw):
        """Pobierz plik audio jako binarny response."""
        sound = _get_record('freeswitch.sound', sid, _company_cfg.company_id.id)
        if not sound:
            return _error('Dźwięk nie znaleziony', 404)
        if not sound.audio_data:
            return _error('Brak pliku audio', 404)
        audio_bytes = base64.b64decode(sound.audio_data)
        from odoo.http import Response
        return Response(
            audio_bytes,
            status=200,
            headers={
                'Content-Type':        sound.audio_mime or 'audio/wav',
                'Content-Disposition': f'attachment; filename="{sound.audio_fname or "audio.wav"}"',
                'Content-Length':      str(len(audio_bytes)),
            }
        )

    # ══ CC MONITOR — live dane kolejek i agentów ═════════════════════════════

    @http.route(f'{API_BASE}/cc_monitor', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_monitor(self, _company_cfg=None, **kw):
        """
        Live dane CallCenter — kolejki z callerami + agenci ze statusem.
        Analogicznie do /freeswitch/cc_dashboard (wewnętrzny endpoint OWL),
        ale dostępny przez X-API-Key dla integracji zewnętrznych.
        """
        try:
            return _json_response(self._build_cc_monitor_data(_company_cfg, kw))
        except Exception as e:
            _logger.error('CC monitor API error: %s', e, exc_info=True)
            return _error(str(e), 500)

    def _build_cc_monitor_data(self, company_cfg, kw=None):
        env        = request.env
        company_id = company_cfg.company_id.id
        cfg        = env['freeswitch.company.config'].sudo()._get_for_company(company_cfg.company_id)
        sip_domain = cfg.sip_domain or 'localhost'
        now        = int(time.time())

        queues_odoo = env['freeswitch.cc.queue'].sudo().search([
            ('active',     '=', True),
            ('company_id', '=', company_id),
        ])
        agents_odoo = env['freeswitch.cc.agent'].sudo().search([
            ('active',     '=', True),
            ('company_id', '=', company_id),
        ])

        # Opcjonalny filtr po kolejce
        queue_filter = (kw or {}).get('queue')
        if queue_filter:
            queues_odoo = queues_odoo.filtered(lambda q: q.name == queue_filter)

        # ── Live data z bazy PostgreSQL FreeSWITCH ────────────────────────
        fs_agents  = {}
        fs_members = []
        db_ok      = False

        if queues_odoo:
            try:
                test = queues_odoo[0]._fs_query("SELECT 1 AS ok")
                if test:
                    db_ok = True
            except Exception as e:
                _logger.warning('CC monitor: brak połączenia z bazą FS: %s', e)

        if db_ok:
            try:
                rows = queues_odoo[0]._fs_query("""
                    SELECT name, status, state,
                           last_bridge_start, last_bridge_end,
                           calls_answered, talk_time, no_answer_count,
                           wrap_up_time, ready_time
                    FROM agents ORDER BY name
                """)
                for r in (rows or []):
                    n = r.get('name')
                    if n:
                        fs_agents[n] = r
            except Exception as e:
                _logger.warning('CC monitor agents query: %s', e)

            try:
                fs_members = queues_odoo[0]._fs_query("""
                    SELECT queue, uuid, cid_number, cid_name,
                           joined_epoch, bridge_epoch, state, serving_agent
                    FROM members
                    WHERE state NOT IN ('Abandoned')
                    ORDER BY joined_epoch
                """) or []
            except Exception as e:
                _logger.warning('CC monitor members query: %s', e)

        # ── Kolejki ───────────────────────────────────────────────────────
        queues_data = []
        for q in queues_odoo:
            fs_name = f'{q.name}@{sip_domain}'
            callers = []
            for m in fs_members:
                if m.get('queue', '') != fs_name:
                    continue
                joined   = int(m.get('joined_epoch') or 0)
                wait_sec = max(0, now - joined) if joined > 0 else 0
                callers.append({
                    'uuid':          m.get('uuid', ''),
                    'cid_number':    m.get('cid_number') or '',
                    'cid_name':      m.get('cid_name')   or '',
                    'state':         m.get('state')       or '',
                    'serving_agent': m.get('serving_agent') or '',
                    'wait_sec':      wait_sec,
                    'wait_fmt':      _fmt_duration(wait_sec),
                })

            queue_agent_names = [
                t.agent_id.name for t in q.tier_ids
                if t.agent_id and t.agent_id.active
            ]
            agents_available = sum(
                1 for aname in queue_agent_names
                if (fs_agents.get(aname) or {}).get('status') == 'Available'
            )

            queues_data.append({
                'id':               q.id,
                'name':             q.name,
                'fs_name':          fs_name,
                'description':      q.description   or '',
                'strategy':         q.strategy       or '',
                'max_wait_time':    q.max_wait_time,
                'agents_total':     len(queue_agent_names),
                'agents_available': agents_available,
                'callers_waiting':  len([c for c in callers if c['state'] == 'Waiting']),
                'callers_trying':   len([c for c in callers if c['state'] == 'Trying']),
                'callers_answered': len([c for c in callers if c['state'] == 'Answered']),
                'callers':          callers,
            })

        # ── Agenci ────────────────────────────────────────────────────────
        agents_data = []
        for a in agents_odoo:
            fs  = fs_agents.get(a.name, {})
            status          = fs.get('status') or a.status or 'Logged Out'
            state           = fs.get('state')  or a.state  or 'Waiting'
            last_bridge_end = int(fs.get('last_bridge_end') or 0)
            talk_time       = int(fs.get('talk_time')       or 0)
            calls_answered  = int(fs.get('calls_answered')  or 0)
            idle_sec        = (now - last_bridge_end) if last_bridge_end > 0 else None

            agent_queues = [
                t.queue_id.name for t in a.tier_ids
                if t.queue_id and t.queue_id.active
            ]

            agents_data.append({
                'id':             a.id,
                'name':           a.name,
                'display_name':   a.display_name_field or a.name,
                'extension':      a.extension or '',
                'status':         status,
                'state':          state,
                'talk_time':      talk_time,
                'talk_time_fmt':  _fmt_duration(talk_time),
                'calls_answered': calls_answered,
                'idle_sec':       idle_sec,
                'idle_fmt':       _fmt_duration(idle_sec) if idle_sec is not None else '—',
                'queues':         agent_queues,
                'live_data':      db_ok,
            })

        # ── Podsumowanie ──────────────────────────────────────────────────
        summary = {
            'available':      sum(1 for a in agents_data if a['status'] == 'Available'),
            'in_call':        sum(1 for a in agents_data if a['state'] in ('In a queue call', 'Receiving')),
            'on_break':       sum(1 for a in agents_data if a['status'] == 'On Break'),
            'logged_out':     sum(1 for a in agents_data if a['status'] == 'Logged Out'),
            'callers_waiting': sum(q['callers_waiting'] for q in queues_data),
            'total_queues':   len(queues_data),
        }

        return {
            'ts':       now,
            'db_ok':    db_ok,
            'company':  company_cfg.company_id.name,
            'summary':  summary,
            'queues':   queues_data,
            'agents':   agents_data,
        }

    # ══ SWAGGER / OpenAPI ═══════════════════════════════════════════════════

    @http.route(f'{API_BASE}/openapi.json', type='http', auth='none', methods=['GET'], csrf=False)
    def openapi_spec(self, **kw):
        """Zwróć specyfikację OpenAPI 3.0 w formacie JSON."""
        return _json_response(_build_openapi_spec())

    @http.route(f'{API_BASE}/docs', type='http', auth='none', methods=['GET'], csrf=False)
    def swagger_ui(self, **kw):
        """Zwróć interaktywny Swagger UI."""
        html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeSWITCH Admin API — Dokumentacja</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css">
  <style>
    body {{ margin: 0; background: #fafafa; }}
    .topbar {{ display: none !important; }}

    /* ── Okienko autoryzacji wyśrodkowane na ekranie ── */
    .swagger-ui .dialog-ux .modal-ux {{
      position: fixed !important;
      top: 50% !important;
      left: 50% !important;
      transform: translate(-50%, -50%) !important;
      margin: 0 !important;
      max-height: 90vh;
      overflow-y: auto;
      z-index: 9999;
    }}
    .swagger-ui .dialog-ux .backdrop-ux {{
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      z-index: 9998;
    }}
  </style>
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    SwaggerUIBundle({{
      url: '{API_BASE}/openapi.json',
      dom_id: '#swagger-ui',
      deepLinking: true,
      persistAuthorization: true,
      presets: [
        SwaggerUIBundle.presets.apis,
        SwaggerUIBundle.SwaggerUIStandalonePreset
      ],
      layout: 'BaseLayout',
    }});
  </script>
</body>
</html>"""
        return Response(html, status=200, headers={'Content-Type': 'text/html; charset=utf-8'})

    # ══ DIALPLAN ════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/dialplan/reload', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def dialplan_reload(self, _company_cfg=None, **kw):
        try:
            mixin = request.env['freeswitch.db.mixin'].with_company(
                _company_cfg.company_id
            )
            result = mixin._fs_api_call('POST', '/routing/dialplan/reload')
            return _json_response({
                'status':  'ok',
                'company': _company_cfg.company_id.name,
                'result':  result,
            })
        except Exception as e:
            return _error(str(e), 502, 'dialplan_reload_failed')


# ── Funkcje serializujące modele do dict ─────────────────────────────────────

def _get_record(model, record_id, company_id):
    """Pobierz rekord sprawdzając przynależność do firmy."""
    rec = request.env[model].sudo().browse(record_id)
    if not rec.exists():
        return None
    if hasattr(rec, 'company_id') and rec.company_id.id != company_id:
        return None
    return rec


def _route_to_dict(r, full=False):
    data = {
        'id':                    r.id,
        'fs_uuid':               r.fs_uuid,
        'name':                  r.name,
        'description':           r.description or '',
        'route_type':            r.route_type,
        'route_target':          r.route_target or '',
        'active':                r.active,
        'use_time_rules':        r.use_time_rules,
        'fallback_type':         r.fallback_type or '',
        'fallback_target':       r.fallback_target or '',
        'use_holidays':          r.use_holidays,
        'holiday_country_code':  r.holiday_country_code or '',
        'holiday_action_type':   r.holiday_action_type or '',
        'holiday_action_target': r.holiday_action_target or '',
        'company_id':            r.company_id.id,
        'company_name':          r.company_id.name,
        'time_rule_count':       len(r.time_rule_ids),
    }
    if full:
        data['time_rules'] = [_time_rule_to_dict(t) for t in r.time_rule_ids]
    return data


def _time_rule_to_dict(t):
    return {
        'id':         t.id,
        'route_id':   t.route_id.id,
        'sequence':   t.sequence,
        'name':       t.name or '',
        'day_mon':    t.day_mon,
        'day_tue':    t.day_tue,
        'day_wed':    t.day_wed,
        'day_thu':    t.day_thu,
        'day_fri':    t.day_fri,
        'day_sat':    t.day_sat,
        'day_sun':    t.day_sun,
        'time_start': t.time_start or '',
        'time_end':   t.time_end or '',
        'timezone':   t.timezone or 'Europe/Warsaw',
    }


def _sip_user_to_dict(u):
    return {
        'id':                    u.id,
        'fs_uuid':               u.fs_uuid,
        'name':                  u.name,
        'first_name':            u.first_name or '',
        'extension':             u.extension,
        'sip_password':          u.sip_password,
        'vm_password':           u.vm_password or '',
        'status':                u.status,
        'active':                u.active,
        'department':            u.department or '',
        'company_id':            u.company_id.id,
        'company_name':          u.company_id.name,
        'email':                 u.email or '',
        'outbound_caller_id':    u.outbound_caller_id or '',
        # Kalendarz godzin pracy
        'use_calendar':          u.use_calendar,
        'calendar_off_action':   u.calendar_off_action or '',
        'calendar_off_target':   u.calendar_off_target or '',
        # Dni wolne
        'use_holidays':          u.use_holidays,
        'holiday_country_code':  u.holiday_country_code or '',
        'holiday_action':        u.holiday_action or '',
        'holiday_target':        u.holiday_target or '',
        # Harmonogram — wpisy (tylko IDs, pełne dane przez /sip_users/{id}/calendar)
        'calendar_count':        len(u.calendar_ids),
    }


def _ivr_to_dict(i, full=False):
    data = {
        'id':             i.id,
        'fs_uuid':        i.fs_uuid,
        'name':           i.name,
        'description':    i.description or '',
        'active':         i.active,
        'timeout_sec':    i.timeout_sec,
        'max_failures':   i.max_failures,
        'greeting_id':    i.greeting_id.id if i.greeting_id else None,
        'greeting_name':  i.greeting_id.name if i.greeting_id else '',
        'default_action': i.default_action or '',
        'default_target': i.default_target or '',
        'default_pstn':   i.default_pstn or '',
        'company_id':     i.company_id.id,
        'company_name':   i.company_id.name,
        'item_count':     i.item_count,
    }
    if full:
        data['menu_items'] = [_ivr_item_to_dict(item) for item in i.menu_item_ids]
    return data


def _ivr_item_to_dict(item):
    return {
        'id':          item.id,
        'ivr_id':      item.ivr_id.id,
        'sequence':    item.sequence,
        'digit':       item.digit,
        'description': item.description or '',
        'action':      item.action,
        'target':      item.target or '',
    }


def _cc_queue_to_dict(q, full=False):
    data = {
        'id':               q.id,
        'fs_uuid':          q.fs_uuid,
        'name':             q.name,
        'description':      q.description or '',
        'strategy':         q.strategy,
        'max_wait_time':    q.max_wait_time,
        'max_wait_no_agent': q.max_wait_no_agent,
        'time_base_score':  q.time_base_score,
        'tier_rules_apply': q.tier_rules_apply,
        'abandoned_resume': q.abandoned_resume,
        'active':           q.active,
        'company_id':       q.company_id.id,
        'company_name':     q.company_id.name,
        'callers_waiting':  q.callers_waiting,
        'agents_available': q.agents_available,
        'calls_today':      q.calls_today,
    }
    if full:
        data['tiers'] = [
            {
                'id':       t.id,
                'agent_id': t.agent_id.id,
                'agent':    t.agent_id.name,
                'level':    t.level,
                'position': t.position,
            }
            for t in q.tier_ids
        ]
    return data




def _holiday_to_dict(h):
    return {
        'id':           h.id,
        'name':         h.name,
        'country_code': h.country_code,
        'date':         str(h.date) if h.date else '',
        'month_day':    h.month_day or '',
        'recurring':    h.recurring,
        'active':       h.active,
        'note':         h.note or '',
    }


def _calendar_to_dict(c):
    return {
        'id':             c.id,
        'user_id':        c.user_id.id,
        'sequence':       c.sequence,
        'name':           c.name or '',
        'day_mon':        c.day_mon,
        'day_tue':        c.day_tue,
        'day_wed':        c.day_wed,
        'day_thu':        c.day_thu,
        'day_fri':        c.day_fri,
        'day_sat':        c.day_sat,
        'day_sun':        c.day_sun,
        'time_start':     c.time_start or '',
        'time_end':       c.time_end or '',
        'timezone':       c.timezone or 'Europe/Warsaw',
        'is_exception':   c.is_exception,
        'exception_date': str(c.exception_date) if c.exception_date else '',
        'exception_type': c.exception_type or '',
    }



def _sip_device_to_dict(d):
    return {
        'id':              d.id,
        'user_id':         d.user_id.id,
        'fs_uuid':         d.fs_uuid or '',
        'sequence':        d.sequence,
        'device_type':     d.device_type,
        'label':           d.label or '',
        'active':          d.active,
        'linked_user_id':  d.linked_user_id.id if d.linked_user_id else None,
        'linked_user_name': d.linked_user_id.name if d.linked_user_id else '',
        'sip_domain':      d.sip_domain or '',
        'codec_string':    d.codec_string or '',
        'dtmf_mode':       d.dtmf_mode or 'rfc2833',
        'nat_traverse':    d.nat_traverse,
        'transport':       d.transport or 'udp',
        'mobile_number':   d.mobile_number or '',
        'mobile_gateway':  d.mobile_gateway or '',
        'ring_strategy':   d.ring_strategy or 'simultaneous',
    }


def _cc_tier_to_dict(t):
    return {
        'id':         t.id,
        'queue_id':   t.queue_id.id,
        'queue_name': t.queue_id.name,
        'agent_id':   t.agent_id.id,
        'agent_name': t.agent_id.name,
        'level':      t.level,
        'position':   t.position,
    }



def _cc_agent_to_dict(a):
    return {
        'id':                  a.id,
        'name':                a.name,
        'display_name':        a.display_name_field or a.name,
        'extension':           a.extension or '',
        'contact':             a.contact or '',
        'status':              a.status or '',
        'active':              a.active,
        'wrap_up_time':        a.wrap_up_time,
        'no_answer_delay_time': a.no_answer_delay_time,
        'sip_user_id':         a.sip_user_id.id if a.sip_user_id else None,
        'sip_user_name':       a.sip_user_id.name if a.sip_user_id else '',
        'company_id':          a.company_id.id,
        'company_name':        a.company_id.name,
        'queues': [
            {'queue_id': t.queue_id.id, 'queue_name': t.queue_id.name,
             'level': t.level, 'position': t.position}
            for t in a.tier_ids if t.queue_id
        ],
    }


def _fmt_duration(sec):
    """Formatuj sekundy jako H:MM:SS lub MM:SS."""
    if sec is None or sec < 0:
        return '—'
    sec = int(sec)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    if h > 0:
        return f'{h}:{m:02d}:{s:02d}'
    return f'{m:02d}:{s:02d}'


def _sound_to_dict(s, include_data=False):
    data = {
        'id':           s.id,
        'name':         s.name,
        'description':  s.description or '',
        'category':     s.category,
        'active':       s.active,
        'audio_fname':  s.audio_fname or '',
        'audio_mime':   s.audio_mime  or '',
        'fs_path':      s.fs_path     or '',
        'has_audio':    bool(s.audio_data),
        'company_id':   s.company_id.id,
        'company_name': s.company_id.name,
        'audio_url':    (
            f'/web/content?model=freeswitch.sound&id={s.id}'
            f'&field=audio_data&filename={s.audio_fname or "audio.wav"}&download=false'
        ) if s.audio_data and s.id else '',
    }
    if include_data and s.audio_data:
        data['audio_data_base64'] = s.audio_data.decode() if isinstance(s.audio_data, bytes) else s.audio_data
    return data


# ── Specyfikacja OpenAPI 3.0 ──────────────────────────────────────────────────

def _build_openapi_spec():
    """Zwróć słownik zgodny z OpenAPI 3.0.3 opisujący wszystkie endpointy API."""

    def _resp(description, schema_ref=None):
        r = {'description': description}
        if schema_ref:
            r['content'] = {'application/json': {'schema': {'$ref': f'#/components/schemas/{schema_ref}'}}}
        return r

    return {
        'openapi': '3.0.3',
        'info': {
            'title':       'FreeSWITCH Admin REST API',
            'version':     '1.0.0',
            'description': (
                'REST API modułu **freeswitch_admin** w Odoo.\n\n'
                '**Uwierzytelnienie:** nagłówek `X-API-Key` z kluczem '
                'wygenerowanym w *FreeSWITCH → Konfiguracja → Ustawienia per firma*.'
            ),
        },
        'servers': [{'url': API_BASE, 'description': 'Odoo FreeSWITCH API'}],
        'security': [{'ApiKeyAuth': []}],
        'components': {
            'securitySchemes': {
                'ApiKeyAuth': {
                    'type': 'apiKey',
                    'in':   'header',
                    'name': 'X-API-Key',
                    'description': 'Klucz API z konfiguracji firmy FreeSWITCH w Odoo.',
                }
            },
            'schemas': {
                'Error': {
                    'type': 'object',
                    'properties': {
                        'error': {'type': 'string', 'example': 'Nie znaleziono'},
                        'code':  {'type': 'string', 'example': '404'},
                    }
                },
                'ListMeta': {
                    'type': 'object',
                    'properties': {
                        'count':   {'type': 'integer'},
                        'results': {'type': 'array', 'items': {}},
                    }
                },
                'Deleted': {
                    'type': 'object',
                    'properties': {
                        'deleted': {'type': 'boolean', 'example': True},
                        'id':      {'type': 'integer'},
                    }
                },
                'RouteTimeRule': {
                    'type': 'object',
                    'required': ['time_start', 'time_end'],
                    'properties': {
                        'id':         {'type': 'integer', 'readOnly': True},
                        'route_id':   {'type': 'integer', 'readOnly': True},
                        'sequence':   {'type': 'integer', 'default': 10},
                        'name':       {'type': 'string', 'example': 'Godziny pracy'},
                        'day_mon':    {'type': 'boolean', 'default': True},
                        'day_tue':    {'type': 'boolean', 'default': True},
                        'day_wed':    {'type': 'boolean', 'default': True},
                        'day_thu':    {'type': 'boolean', 'default': True},
                        'day_fri':    {'type': 'boolean', 'default': True},
                        'day_sat':    {'type': 'boolean', 'default': False},
                        'day_sun':    {'type': 'boolean', 'default': False},
                        'time_start': {'type': 'string', 'pattern': '^\\d{2}:\\d{2}$', 'example': '08:00'},
                        'time_end':   {'type': 'string', 'pattern': '^\\d{2}:\\d{2}$', 'example': '17:00'},
                        'timezone':   {'type': 'string', 'default': 'Europe/Warsaw'},
                    }
                },
                'IVRItem': {
                    'type': 'object',
                    'required': ['digit', 'action'],
                    'properties': {
                        'id':          {'type': 'integer', 'readOnly': True},
                        'ivr_id':      {'type': 'integer', 'readOnly': True},
                        'sequence':    {'type': 'integer', 'default': 10},
                        'digit':       {'type': 'string', 'enum': ['0','1','2','3','4','5','6','7','8','9','*','#']},
                        'description': {'type': 'string'},
                        'action':      {'type': 'string', 'enum': ['ivr','callcenter','user','pstn','playback','voicemail','hangup','repeat']},
                        'target':      {'type': 'string', 'description': 'Klucz celu (nazwa IVR, nazwa kolejki CC, login SIP, numer PSTN itp.)'},
                    }
                },
                'CCTier': {
                    'type': 'object',
                    'required': ['agent_id'],
                    'properties': {
                        'id':         {'type': 'integer', 'readOnly': True},
                        'queue_id':   {'type': 'integer', 'readOnly': True},
                        'queue_name': {'type': 'string', 'readOnly': True},
                        'agent_id':   {'type': 'integer', 'description': 'ID agenta CC'},
                        'agent_name': {'type': 'string', 'readOnly': True},
                        'level':      {'type': 'integer', 'default': 1, 'description': '1 = najwyższy priorytet'},
                        'position':   {'type': 'integer', 'default': 1},
                    }
                },
                'SipDevice': {
                    'type': 'object',
                    'required': ['device_type'],
                    'properties': {
                        'id':               {'type': 'integer', 'readOnly': True},
                        'user_id':          {'type': 'integer', 'readOnly': True},
                        'fs_uuid':          {'type': 'string', 'readOnly': True},
                        'sequence':         {'type': 'integer', 'default': 10},
                        'device_type':      {'type': 'string', 'enum': ['sip','mobile','webrtc','softphone']},
                        'label':            {'type': 'string', 'example': 'Biuro'},
                        'active':           {'type': 'boolean', 'default': True},
                        'linked_user_id':   {'type': 'integer', 'nullable': True, 'description': 'ID innego użytkownika SIP (konto SIP)'},
                        'linked_user_name': {'type': 'string', 'readOnly': True},
                        'sip_domain':       {'type': 'string'},
                        'codec_string':     {'type': 'string', 'enum': ['PCMU','PCMA','G722','G729','opus','PCMU,PCMA','G722,PCMU,PCMA'], 'default': 'G722,PCMU,PCMA'},
                        'dtmf_mode':        {'type': 'string', 'enum': ['rfc2833','info','inband'], 'default': 'rfc2833'},
                        'nat_traverse':     {'type': 'boolean', 'default': False},
                        'transport':        {'type': 'string', 'enum': ['udp','tcp','tls'], 'default': 'udp'},
                        'mobile_number':    {'type': 'string', 'example': '+48501234567'},
                        'mobile_gateway':   {'type': 'string'},
                        'ring_strategy':    {'type': 'string', 'enum': ['simultaneous','sequential','exclusive'], 'default': 'simultaneous'},
                    }
                },
                'Route': {
                    'type': 'object',
                    'required': ['name', 'route_type'],
                    'properties': {
                        'id':                    {'type': 'integer', 'readOnly': True},
                        'fs_uuid':               {'type': 'string', 'format': 'uuid', 'readOnly': True},
                        'name':                  {'type': 'string', 'example': 'DID-Warszawa'},
                        'description':           {'type': 'string'},
                        'route_type':            {'type': 'string', 'enum': ['ivr','callcenter','user','fifo','pstn','voicemail','hangup','playback']},
                        'route_target':          {'type': 'string'},
                        'active':                {'type': 'boolean', 'default': True},
                        'use_time_rules':        {'type': 'boolean', 'default': False},
                        'fallback_type':         {'type': 'string', 'enum': ['ivr','callcenter','user','fifo','pstn','voicemail','hangup'], 'description': 'Akcja fallback poza godzinami (gdy use_time_rules=true)'},
                        'fallback_target':       {'type': 'string'},
                        'use_holidays':          {'type': 'boolean', 'default': False},
                        'holiday_country_code':  {'type': 'string', 'enum': ['PL','DE','GB','FR','US','CZ','SK','UA','OTHER'], 'default': 'PL'},
                        'holiday_action_type':   {'type': 'string', 'enum': ['ivr','callcenter','user','pstn','voicemail','hangup']},
                        'holiday_action_target': {'type': 'string'},
                        'time_rule_count':       {'type': 'integer', 'readOnly': True},
                        'time_rules':            {'type': 'array', 'readOnly': True, 'description': 'Dostępne tylko w GET /routes/{id}', 'items': {'$ref': '#/components/schemas/RouteTimeRule'}},
                        'company_id':            {'type': 'integer', 'readOnly': True},
                        'company_name':          {'type': 'string', 'readOnly': True},
                    }
                },
                'SipUser': {
                    'type': 'object',
                    'required': ['name', 'first_name', 'extension'],
                    'properties': {
                        'id':                   {'type': 'integer', 'readOnly': True},
                        'fs_uuid':              {'type': 'string', 'format': 'uuid', 'readOnly': True},
                        'name':                 {'type': 'string', 'description': 'Login SIP (unikalny, np. 1001)'},
                        'first_name':           {'type': 'string'},
                        'extension':            {'type': 'string', 'example': '1001'},
                        'sip_password':         {'type': 'string'},
                        'vm_password':          {'type': 'string', 'example': '1234'},
                        'status':               {'type': 'string', 'enum': ['active', 'suspended', 'vacation', 'inactive'], 'default': 'active'},
                        'active':               {'type': 'boolean', 'default': True},
                        'department':           {'type': 'string'},
                        'email':                {'type': 'string', 'format': 'email'},
                        'outbound_caller_id':   {'type': 'string', 'example': '+48221234567'},
                        'company_id':           {'type': 'integer', 'readOnly': True},
                        'company_name':         {'type': 'string', 'readOnly': True},
                    }
                },
                'SipCalendar': {
                    'type': 'object',
                    'required': ['time_start', 'time_end'],
                    'properties': {
                        'id':             {'type': 'integer', 'readOnly': True},
                        'user_id':        {'type': 'integer', 'readOnly': True},
                        'sequence':       {'type': 'integer', 'default': 10},
                        'name':           {'type': 'string', 'example': 'Poniedziałek–Piątek'},
                        'day_mon':        {'type': 'boolean', 'default': True},
                        'day_tue':        {'type': 'boolean', 'default': True},
                        'day_wed':        {'type': 'boolean', 'default': True},
                        'day_thu':        {'type': 'boolean', 'default': True},
                        'day_fri':        {'type': 'boolean', 'default': True},
                        'day_sat':        {'type': 'boolean', 'default': False},
                        'day_sun':        {'type': 'boolean', 'default': False},
                        'time_start':     {'type': 'string', 'pattern': '^\\d{2}:\\d{2}$', 'example': '08:00'},
                        'time_end':       {'type': 'string', 'pattern': '^\\d{2}:\\d{2}$', 'example': '17:00'},
                        'timezone':       {'type': 'string', 'default': 'Europe/Warsaw', 'example': 'Europe/Warsaw'},
                        'is_exception':   {'type': 'boolean', 'default': False, 'description': 'Wyjątek dla konkretnej daty'},
                        'exception_date': {'type': 'string', 'format': 'date', 'nullable': True, 'example': '2026-12-24'},
                        'exception_type': {'type': 'string', 'enum': ['available', 'unavailable'], 'nullable': True},
                    }
                },
                'PublicHoliday': {
                    'type': 'object',
                    'required': ['name', 'country_code', 'date'],
                    'properties': {
                        'id':           {'type': 'integer', 'readOnly': True},
                        'name':         {'type': 'string', 'example': 'Boże Narodzenie'},
                        'country_code': {'type': 'string', 'enum': ['PL', 'DE', 'GB', 'FR', 'US', 'CZ', 'SK', 'UA', 'OTHER'], 'default': 'PL'},
                        'date':         {'type': 'string', 'format': 'date', 'example': '2026-12-25'},
                        'month_day':    {'type': 'string', 'readOnly': True, 'example': '12-25'},
                        'recurring':    {'type': 'boolean', 'default': True, 'description': 'Powtarza się co roku (rok w dacie ignorowany)'},
                        'active':       {'type': 'boolean', 'default': True},
                        'note':         {'type': 'string'},
                    }
                },
                'IVR': {
                    'type': 'object',
                    'required': ['name', 'description'],
                    'properties': {
                        'id':             {'type': 'integer', 'readOnly': True},
                        'fs_uuid':        {'type': 'string', 'format': 'uuid', 'readOnly': True},
                        'name':           {'type': 'string', 'description': 'Klucz IVR (unikalny, np. ivr-glowne)'},
                        'description':    {'type': 'string'},
                        'active':         {'type': 'boolean', 'default': True},
                        'timeout_sec':    {'type': 'integer', 'default': 7},
                        'max_failures':   {'type': 'integer', 'default': 3},
                        'greeting_id':    {'type': 'integer', 'nullable': True, 'description': 'ID dźwięku powitalnego (freeswitch.sound)'},
                        'greeting_name':  {'type': 'string', 'readOnly': True},
                        'default_action': {'type': 'string', 'enum': ['ivr','callcenter','user','pstn','playback','voicemail','hangup','repeat'], 'description': 'Akcja po max_failures błędach'},
                        'default_target': {'type': 'string', 'readOnly': True},
                        'default_pstn':   {'type': 'string', 'example': '+48221234567'},
                        'item_count':     {'type': 'integer', 'readOnly': True},
                        'company_id':     {'type': 'integer', 'readOnly': True},
                        'company_name':   {'type': 'string', 'readOnly': True},
                        'menu_items':     {'type': 'array', 'readOnly': True, 'description': 'Dostępne tylko w GET /ivr/{id}', 'items': {'$ref': '#/components/schemas/IVRItem'}},
                    }
                },
                'CCQueue': {
                    'type': 'object',
                    'required': ['name'],
                    'properties': {
                        'id':                {'type': 'integer', 'readOnly': True},
                        'fs_uuid':           {'type': 'string', 'format': 'uuid', 'readOnly': True},
                        'name':              {'type': 'string', 'description': 'Klucz kolejki — tylko litery, cyfry, myślnik, podkreślnik, kropka. Bez spacji.', 'example': 'cc-sprzedaz'},
                        'description':       {'type': 'string'},
                        'strategy':          {'type': 'string', 'enum': ['longest-idle-agent', 'round-robin', 'top-down', 'agent-with-fewest-calls', 'agent-with-least-talk-time', 'random', 'ring-all'], 'default': 'longest-idle-agent'},
                        'max_wait_time':     {'type': 'integer', 'default': 0, 'description': 'Maks. czas oczekiwania (s), 0 = bez limitu'},
                        'max_wait_no_agent': {'type': 'integer', 'default': 120, 'description': 'Maks. oczekiwanie gdy brak agentów (s)'},
                        'time_base_score':   {'type': 'string', 'enum': ['queue', 'system'], 'default': 'queue'},
                        'tier_rules_apply':  {'type': 'boolean', 'default': False},
                        'abandoned_resume':  {'type': 'boolean', 'default': False},
                        'active':            {'type': 'boolean', 'default': True},
                        'company_id':        {'type': 'integer', 'readOnly': True},
                        'company_name':      {'type': 'string', 'readOnly': True},
                        'callers_waiting':   {'type': 'integer', 'readOnly': True},
                        'agents_available':  {'type': 'integer', 'readOnly': True},
                        'calls_today':       {'type': 'integer', 'readOnly': True},
                        'tiers': {
                            'type': 'array',
                            'readOnly': True,
                            'description': 'Dostępne tylko w GET /cc_queues/{id}',
                            'items': {
                                'type': 'object',
                                'properties': {
                                    'id':       {'type': 'integer'},
                                    'agent_id': {'type': 'integer'},
                                    'agent':    {'type': 'string'},
                                    'level':    {'type': 'integer'},
                                    'position': {'type': 'integer'},
                                }
                            }
                        },
                    }
                },
                'CCAgent': {
                    'type': 'object',
                    'required': ['name', 'extension', 'contact'],
                    'properties': {
                        'id':                   {'type': 'integer', 'readOnly': True},
                        'name':                 {'type': 'string', 'description': 'Klucz agenta w mod_callcenter (unikalny)', 'example': 'jan.kowalski'},
                        'display_name':         {'type': 'string', 'example': 'Jan Kowalski'},
                        'extension':            {'type': 'string', 'example': '1001'},
                        'contact':              {'type': 'string', 'example': 'sofia/internal/1001@sip.firma.pl'},
                        'status':               {'type': 'string', 'enum': ['Available', 'Available (On Demand)', 'On Break', 'Logged Out'], 'default': 'Available'},
                        'active':               {'type': 'boolean', 'default': True},
                        'wrap_up_time':         {'type': 'integer', 'default': 0, 'description': 'Czas wrap-up po rozmowie (s)'},
                        'no_answer_delay_time': {'type': 'integer', 'default': 0, 'description': 'Opóźnienie po braku odpowiedzi (s)'},
                        'sip_user_id':          {'type': 'integer', 'nullable': True},
                        'sip_user_name':        {'type': 'string', 'readOnly': True},
                        'company_id':           {'type': 'integer', 'readOnly': True},
                        'company_name':         {'type': 'string', 'readOnly': True},
                        'queues': {
                            'type': 'array',
                            'readOnly': True,
                            'description': 'Kolejki do których agent jest przypisany (tiery)',
                            'items': {
                                'type': 'object',
                                'properties': {
                                    'queue_id':   {'type': 'integer'},
                                    'queue_name': {'type': 'string'},
                                    'level':      {'type': 'integer'},
                                    'position':   {'type': 'integer'},
                                }
                            }
                        },
                    }
                },
                'Sound': {
                    'type': 'object',
                    'required': ['name', 'category'],
                    'properties': {
                        'id':           {'type': 'integer', 'readOnly': True},
                        'name':         {'type': 'string', 'example': 'powitanie-firmowe'},
                        'description':  {'type': 'string'},
                        'category':     {'type': 'string', 'enum': ['greeting', 'ivr', 'hold', 'queue', 'voicemail', 'playback', 'other'], 'default': 'ivr'},
                        'active':       {'type': 'boolean', 'default': True},
                        'audio_fname':  {'type': 'string', 'example': 'powitanie.wav', 'readOnly': True},
                        'audio_mime':   {'type': 'string', 'example': 'audio/wav', 'readOnly': True},
                        'fs_path':      {'type': 'string', 'example': '/etc/freeswitch/sounds/pl/powitanie.wav'},
                        'has_audio':    {'type': 'boolean', 'readOnly': True},
                        'audio_url':    {'type': 'string', 'description': 'URL do odtworzenia/pobrania pliku audio przez Odoo', 'readOnly': True},
                        'company_id':   {'type': 'integer', 'readOnly': True},
                        'company_name': {'type': 'string', 'readOnly': True},
                    }
                },
                'CCMonitorCaller': {
                    'type': 'object',
                    'properties': {
                        'uuid':          {'type': 'string', 'format': 'uuid'},
                        'cid_number':    {'type': 'string', 'example': '+48221234567'},
                        'cid_name':      {'type': 'string'},
                        'state':         {'type': 'string', 'enum': ['Waiting', 'Trying', 'Answered'], 'description': 'Stan rozmówcy w kolejce'},
                        'serving_agent': {'type': 'string', 'description': 'Nazwa agenta obsługującego (jeśli Answered)'},
                        'wait_sec':      {'type': 'integer', 'description': 'Czas oczekiwania w sekundach'},
                        'wait_fmt':      {'type': 'string', 'example': '02:15'},
                    }
                },
                'CCMonitorQueue': {
                    'type': 'object',
                    'properties': {
                        'id':               {'type': 'integer'},
                        'name':             {'type': 'string'},
                        'fs_name':          {'type': 'string', 'example': 'cc-sprzedaz@sip.firma.pl'},
                        'description':      {'type': 'string'},
                        'strategy':         {'type': 'string'},
                        'max_wait_time':    {'type': 'integer'},
                        'agents_total':     {'type': 'integer'},
                        'agents_available': {'type': 'integer'},
                        'callers_waiting':  {'type': 'integer'},
                        'callers_trying':   {'type': 'integer'},
                        'callers_answered': {'type': 'integer'},
                        'callers': {
                            'type': 'array',
                            'items': {'$ref': '#/components/schemas/CCMonitorCaller'}
                        },
                    }
                },
                'CCMonitorAgent': {
                    'type': 'object',
                    'properties': {
                        'id':             {'type': 'integer'},
                        'name':           {'type': 'string', 'description': 'Login agenta w mod_callcenter'},
                        'display_name':   {'type': 'string'},
                        'extension':      {'type': 'string'},
                        'status':         {'type': 'string', 'enum': ['Available', 'Available (On Demand)', 'On Break', 'Logged Out'], 'description': 'Status agenta w mod_callcenter'},
                        'state':          {'type': 'string', 'enum': ['Waiting', 'Receiving', 'In a queue call', 'Idle'], 'description': 'Stan agenta'},
                        'talk_time':      {'type': 'integer', 'description': 'Łączny czas rozmów (s)'},
                        'talk_time_fmt':  {'type': 'string', 'example': '01:23:45'},
                        'calls_answered': {'type': 'integer'},
                        'idle_sec':       {'type': 'integer', 'nullable': True, 'description': 'Sekundy bezczynności od ostatniej rozmowy'},
                        'idle_fmt':       {'type': 'string', 'example': '05:12'},
                        'queues':         {'type': 'array', 'items': {'type': 'string'}, 'description': 'Nazwy kolejek do których jest przypisany'},
                        'live_data':      {'type': 'boolean', 'description': 'true = dane z bazy PostgreSQL FS, false = dane tylko z Odoo'},
                    }
                },
                'CCMonitorSummary': {
                    'type': 'object',
                    'properties': {
                        'available':       {'type': 'integer', 'description': 'Agenci dostępni'},
                        'in_call':         {'type': 'integer', 'description': 'Agenci w rozmowie'},
                        'on_break':        {'type': 'integer', 'description': 'Agenci na przerwie'},
                        'logged_out':      {'type': 'integer', 'description': 'Agenci wylogowani'},
                        'callers_waiting': {'type': 'integer', 'description': 'Łączna liczba oczekujących we wszystkich kolejkach'},
                        'total_queues':    {'type': 'integer'},
                    }
                },
                'CCMonitorResponse': {
                    'type': 'object',
                    'properties': {
                        'ts':      {'type': 'integer', 'description': 'Unix timestamp odpowiedzi'},
                        'db_ok':   {'type': 'boolean', 'description': 'Czy połączenie z bazą PostgreSQL FreeSWITCH jest aktywne'},
                        'company': {'type': 'string'},
                        'summary': {'$ref': '#/components/schemas/CCMonitorSummary'},
                        'queues':  {'type': 'array', 'items': {'$ref': '#/components/schemas/CCMonitorQueue'}},
                        'agents':  {'type': 'array', 'items': {'$ref': '#/components/schemas/CCMonitorAgent'}},
                    }
                },
            }
        },
        'paths': {
            # ── Health ────────────────────────────────────────────────────
            '/health': {
                'get': {
                    'tags':       ['Status'],
                    'summary':    'Status serwisu',
                    'security':   [],
                    'operationId': 'health_get',
                    'responses': {
                        '200': {
                            'description': 'Serwis działa',
                            'content': {'application/json': {'schema': {
                                'type': 'object',
                                'properties': {
                                    'status': {'type': 'string', 'example': 'ok'},
                                    'module': {'type': 'string', 'example': 'freeswitch_admin'},
                                }
                            }}}
                        }
                    }
                }
            },
            # ── Whoami ────────────────────────────────────────────────────
            '/me': {
                'get': {
                    'tags':        ['Klient'],
                    'summary':     'Informacje o kliencie (firma powiązana z kluczem API)',
                    'operationId': 'whoami',
                    'responses': {
                        '200': {
                            'description': 'Dane klienta',
                            'content': {'application/json': {'schema': {
                                'type': 'object',
                                'properties': {
                                    'company_id':    {'type': 'integer', 'example': 1},
                                    'company_name':  {'type': 'string',  'example': 'Moja Firma Sp. z o.o.'},
                                    'company_vat':   {'type': 'string',  'example': 'PL1234567890'},
                                    'company_email': {'type': 'string',  'example': 'biuro@firma.pl'},
                                    'sip_domain':    {'type': 'string',  'example': 'sip.firma.pl'},
                                    'gateway':       {'type': 'string',  'example': 'default'},
                                    'api_url':       {'type': 'string',  'example': 'http://127.0.0.1:8000/api/v1'},
                                }
                            }}}
                        },
                        '401': _resp('Brak/nieprawidłowy klucz API', 'Error'),
                    }
                }
            },
            # ── Trasy DID ─────────────────────────────────────────────────
            '/routes': {
                'get': {
                    'tags':        ['Trasy DID'],
                    'summary':     'Lista tras DID',
                    'operationId': 'routes_list',
                    'parameters': [
                        {'name': 'active', 'in': 'query', 'description': 'Filtr: aktywne/nieaktywne', 'schema': {'type': 'boolean'}},
                        {'name': 'name',   'in': 'query', 'description': 'Filtr: szukaj po nazwie (ilike)', 'schema': {'type': 'string'}},
                    ],
                    'responses': {
                        '200': {'description': 'Lista tras', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}},
                        '401': _resp('Brak autoryzacji', 'Error'),
                    }
                },
                'post': {
                    'tags':        ['Trasy DID'],
                    'summary':     'Utwórz trasę DID',
                    'operationId': 'routes_create',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}},
                    'responses': {
                        '201': {'description': 'Trasa utworzona', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}},
                        '400': _resp('Nieprawidłowy JSON', 'Error'),
                        '422': _resp('Błąd walidacji', 'Error'),
                    }
                },
            },
            '/routes/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}, 'description': 'ID trasy'}],
                'get':    {'tags': ['Trasy DID'], 'summary': 'Pobierz trasę DID', 'operationId': 'routes_get',
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['Trasy DID'], 'summary': 'Zaktualizuj trasę DID', 'operationId': 'routes_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}},
                           'responses': {'200': {'description': 'Zaktualizowano', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}}, '404': _resp('Nie znaleziono', 'Error'), '422': _resp('Błąd walidacji', 'Error')}},
                'delete': {'tags': ['Trasy DID'], 'summary': 'Usuń trasę DID', 'operationId': 'routes_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── Route Time Rules ─────────────────────────────────────────
            '/routes/{id}/time_rules': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}, 'description': 'ID trasy DID'}],
                'get':  {'tags': ['Trasy DID'], 'summary': 'Lista reguł czasowych trasy', 'operationId': 'time_rules_list',
                         'responses': {'200': {'description': 'Lista reguł', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}, '404': _resp('Trasa nie znaleziona', 'Error')}},
                'post': {'tags': ['Trasy DID'], 'summary': 'Dodaj regułę czasową', 'operationId': 'time_rules_create',
                         'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/RouteTimeRule'}}}},
                         'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/RouteTimeRule'}}}}, '404': _resp('Trasa nie znaleziona', 'Error'), '422': _resp('Błąd walidacji', 'Error')}},
            },
            '/time_rules/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'put':    {'tags': ['Trasy DID'], 'summary': 'Zaktualizuj regułę czasową', 'operationId': 'time_rules_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/RouteTimeRule'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/RouteTimeRule'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Trasy DID'], 'summary': 'Usuń regułę czasową', 'operationId': 'time_rules_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── SIP Users ─────────────────────────────────────────────────
            '/sip_users': {
                'get': {
                    'tags': ['Użytkownicy SIP'], 'summary': 'Lista użytkowników SIP', 'operationId': 'sip_users_list',
                    'parameters': [
                        {'name': 'active',    'in': 'query', 'schema': {'type': 'boolean'}},
                        {'name': 'extension', 'in': 'query', 'schema': {'type': 'string'}, 'description': 'Numer wewnętrzny (exact match)'},
                    ],
                    'responses': {'200': {'description': 'Lista użytkowników', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}, '401': _resp('Brak autoryzacji', 'Error')}
                },
                'post': {
                    'tags': ['Użytkownicy SIP'], 'summary': 'Utwórz użytkownika SIP', 'operationId': 'sip_users_create',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}},
                    'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}}, '422': _resp('Błąd walidacji', 'Error')}
                },
            },
            '/sip_users/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['Użytkownicy SIP'], 'summary': 'Pobierz użytkownika SIP', 'operationId': 'sip_users_get',
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['Użytkownicy SIP'], 'summary': 'Zaktualizuj użytkownika SIP', 'operationId': 'sip_users_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Użytkownicy SIP'], 'summary': 'Usuń użytkownika SIP', 'operationId': 'sip_users_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── SIP Devices ──────────────────────────────────────────────
            '/sip_users/{id}/devices': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}, 'description': 'ID użytkownika SIP'}],
                'get':  {'tags': ['Użytkownicy SIP'], 'summary': 'Lista urządzeń użytkownika SIP', 'operationId': 'sip_devices_list',
                         'responses': {'200': {'description': 'Lista urządzeń', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}, '404': _resp('Użytkownik nie znaleziony', 'Error')}},
                'post': {'tags': ['Użytkownicy SIP'], 'summary': 'Dodaj urządzenie SIP', 'operationId': 'sip_devices_create',
                         'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipDevice'}}}},
                         'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipDevice'}}}}, '422': _resp('Błąd walidacji', 'Error')}},
            },
            '/sip_devices/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'put':    {'tags': ['Użytkownicy SIP'], 'summary': 'Zaktualizuj urządzenie SIP', 'operationId': 'sip_devices_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipDevice'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipDevice'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Użytkownicy SIP'], 'summary': 'Usuń urządzenie SIP', 'operationId': 'sip_devices_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── SIP Calendar ─────────────────────────────────────────────
            '/sip_users/{id}/calendar': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}, 'description': 'ID użytkownika SIP'}],
                'get': {
                    'tags': ['Harmonogramy SIP'], 'summary': 'Lista wpisów harmonogramu użytkownika', 'operationId': 'sip_calendar_list',
                    'responses': {'200': {'description': 'Lista wpisów', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}, '404': _resp('Użytkownik nie znaleziony', 'Error')}
                },
                'post': {
                    'tags': ['Harmonogramy SIP'], 'summary': 'Dodaj wpis harmonogramu', 'operationId': 'sip_calendar_create',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipCalendar'}}}},
                    'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipCalendar'}}}}, '404': _resp('Użytkownik nie znaleziony', 'Error'), '422': _resp('Błąd walidacji', 'Error')}
                },
            },
            '/sip_calendar/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}, 'description': 'ID wpisu harmonogramu'}],
                'put': {
                    'tags': ['Harmonogramy SIP'], 'summary': 'Zaktualizuj wpis harmonogramu', 'operationId': 'sip_calendar_update',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipCalendar'}}}},
                    'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipCalendar'}}}}, '404': _resp('Nie znaleziono', 'Error')}
                },
                'delete': {
                    'tags': ['Harmonogramy SIP'], 'summary': 'Usuń wpis harmonogramu', 'operationId': 'sip_calendar_delete',
                    'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}
                },
            },
            # ── Public Holidays ───────────────────────────────────────────
            '/holidays': {
                'get': {
                    'tags': ['Dni wolne'], 'summary': 'Lista dni wolnych', 'operationId': 'holidays_list',
                    'parameters': [
                        {'name': 'country_code', 'in': 'query', 'schema': {'type': 'string', 'enum': ['PL', 'DE', 'GB', 'FR', 'US', 'CZ', 'SK', 'UA', 'OTHER']}, 'description': 'Filtr po kraju'},
                        {'name': 'date',         'in': 'query', 'schema': {'type': 'string', 'format': 'date'}, 'description': 'Filtr po konkretnej dacie (YYYY-MM-DD)'},
                    ],
                    'responses': {'200': {'description': 'Lista dni wolnych', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}}
                },
                'post': {
                    'tags': ['Dni wolne'], 'summary': 'Dodaj dzień wolny', 'operationId': 'holidays_create',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/PublicHoliday'}}}},
                    'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/PublicHoliday'}}}}, '422': _resp('Błąd walidacji', 'Error')}
                },
            },
            '/holidays/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['Dni wolne'], 'summary': 'Pobierz dzień wolny', 'operationId': 'holidays_get',
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/PublicHoliday'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['Dni wolne'], 'summary': 'Zaktualizuj dzień wolny', 'operationId': 'holidays_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/PublicHoliday'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/PublicHoliday'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Dni wolne'], 'summary': 'Usuń dzień wolny', 'operationId': 'holidays_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── IVR ───────────────────────────────────────────────────────
            '/ivr': {
                'get':  {'tags': ['IVR'], 'summary': 'Lista konfiguracji IVR', 'operationId': 'ivr_list',
                         'parameters': [{'name': 'active', 'in': 'query', 'schema': {'type': 'boolean'}}],
                         'responses': {'200': {'description': 'Lista IVR', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}}},
                'post': {'tags': ['IVR'], 'summary': 'Utwórz konfigurację IVR', 'operationId': 'ivr_create',
                         'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}},
                         'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}}, '422': _resp('Błąd walidacji', 'Error')}},
            },
            '/ivr/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['IVR'], 'summary': 'Pobierz IVR (z pozycjami menu)', 'operationId': 'ivr_get',
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['IVR'], 'summary': 'Zaktualizuj IVR', 'operationId': 'ivr_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['IVR'], 'summary': 'Usuń IVR', 'operationId': 'ivr_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── IVR Items ────────────────────────────────────────────────
            '/ivr/{id}/items': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}, 'description': 'ID IVR'}],
                'get':  {'tags': ['IVR'], 'summary': 'Lista pozycji menu IVR', 'operationId': 'ivr_items_list',
                         'responses': {'200': {'description': 'Lista pozycji', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}, '404': _resp('IVR nie znaleziony', 'Error')}},
                'post': {'tags': ['IVR'], 'summary': 'Dodaj pozycję menu IVR', 'operationId': 'ivr_items_create',
                         'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVRItem'}}}},
                         'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVRItem'}}}}, '422': _resp('Błąd walidacji', 'Error')}},
            },
            '/ivr_items/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'put':    {'tags': ['IVR'], 'summary': 'Zaktualizuj pozycję menu IVR', 'operationId': 'ivr_items_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVRItem'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVRItem'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['IVR'], 'summary': 'Usuń pozycję menu IVR', 'operationId': 'ivr_items_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── CC Queues ─────────────────────────────────────────────────
            '/cc_queues': {
                'get':  {'tags': ['Kolejki CallCenter'], 'summary': 'Lista kolejek CC', 'operationId': 'cc_queues_list',
                         'parameters': [{'name': 'active', 'in': 'query', 'schema': {'type': 'boolean'}}],
                         'responses': {'200': {'description': 'Lista kolejek', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}}},
                'post': {'tags': ['Kolejki CallCenter'], 'summary': 'Utwórz kolejkę CC', 'operationId': 'cc_queues_create',
                         'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}},
                         'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}}, '422': _resp('Błąd walidacji', 'Error')}},
            },
            '/cc_queues/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['Kolejki CallCenter'], 'summary': 'Pobierz kolejkę CC (z tierami)', 'operationId': 'cc_queues_get',
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['Kolejki CallCenter'], 'summary': 'Zaktualizuj kolejkę CC', 'operationId': 'cc_queues_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Kolejki CallCenter'], 'summary': 'Usuń kolejkę CC', 'operationId': 'cc_queues_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            '/cc_queues/{id}/stats': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get': {
                    'tags': ['Kolejki CallCenter'], 'summary': 'Statystyki live kolejki CC', 'operationId': 'cc_queues_stats',
                    'responses': {'200': {'description': 'Statystyki', 'content': {'application/json': {'schema': {
                        'type': 'object',
                        'properties': {
                            'id':               {'type': 'integer'},
                            'name':             {'type': 'string'},
                            'callers_waiting':  {'type': 'integer'},
                            'agents_available': {'type': 'integer'},
                            'calls_today':      {'type': 'integer'},
                        }
                    }}}}, '404': _resp('Nie znaleziono', 'Error')}
                }
            },
            # ── CC Tiers ─────────────────────────────────────────────────
            '/cc_queues/{id}/tiers': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}, 'description': 'ID kolejki CC'}],
                'get':  {'tags': ['Kolejki CallCenter'], 'summary': 'Lista tierów (agent↔kolejka)', 'operationId': 'cc_tiers_list',
                         'responses': {'200': {'description': 'Lista tierów', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}, '404': _resp('Kolejka nie znaleziona', 'Error')}},
                'post': {'tags': ['Kolejki CallCenter'], 'summary': 'Przypisz agenta do kolejki', 'operationId': 'cc_tiers_create',
                         'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCTier'}}}},
                         'responses': {'201': {'description': 'Tier utworzony', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCTier'}}}}, '422': _resp('Błąd walidacji', 'Error')}},
            },
            '/cc_tiers/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'put':    {'tags': ['Kolejki CallCenter'], 'summary': 'Zaktualizuj tier (level/position)', 'operationId': 'cc_tiers_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCTier'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCTier'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Kolejki CallCenter'], 'summary': 'Odepnij agenta od kolejki', 'operationId': 'cc_tiers_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── CC Agents ────────────────────────────────────────────────
            '/cc_agents': {
                'get': {
                    'tags': ['Agenci CallCenter'], 'summary': 'Lista agentów CC', 'operationId': 'cc_agents_list',
                    'parameters': [
                        {'name': 'active', 'in': 'query', 'schema': {'type': 'boolean'}},
                        {'name': 'status', 'in': 'query', 'schema': {'type': 'string', 'enum': ['Available', 'Available (On Demand)', 'On Break', 'Logged Out']}, 'description': 'Filtr po statusie'},
                    ],
                    'responses': {'200': {'description': 'Lista agentów', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}}
                },
                'post': {
                    'tags': ['Agenci CallCenter'], 'summary': 'Utwórz agenta CC', 'operationId': 'cc_agents_create',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCAgent'}}}},
                    'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCAgent'}}}}, '422': _resp('Błąd walidacji', 'Error')},
                },
            },
            '/cc_agents/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['Agenci CallCenter'], 'summary': 'Pobierz agenta CC', 'operationId': 'cc_agents_get',
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCAgent'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['Agenci CallCenter'], 'summary': 'Zaktualizuj agenta CC', 'operationId': 'cc_agents_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCAgent'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCAgent'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Agenci CallCenter'], 'summary': 'Usuń agenta CC', 'operationId': 'cc_agents_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── Sounds ───────────────────────────────────────────────────
            '/sounds': {
                'get': {
                    'tags': ['Dźwięki'], 'summary': 'Lista dźwięków', 'operationId': 'sounds_list',
                    'parameters': [
                        {'name': 'active',   'in': 'query', 'schema': {'type': 'boolean'}},
                        {'name': 'category', 'in': 'query', 'schema': {'type': 'string', 'enum': ['greeting', 'ivr', 'hold', 'queue', 'voicemail', 'playback', 'other']}, 'description': 'Filtr po kategorii'},
                        {'name': 'name',     'in': 'query', 'schema': {'type': 'string'}, 'description': 'Szukaj po nazwie (ilike)'},
                    ],
                    'responses': {'200': {'description': 'Lista dźwięków', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}}
                },
                'post': {
                    'tags': ['Dźwięki'], 'summary': 'Utwórz rekord dźwięku', 'operationId': 'sounds_create',
                    'description': 'Tworzy rekord bez pliku audio. Plik wgraj przez POST /sounds/{id}/upload.',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Sound'}}}},
                    'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Sound'}}}}, '422': _resp('Błąd walidacji', 'Error')},
                },
            },
            '/sounds/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['Dźwięki'], 'summary': 'Pobierz dźwięk', 'operationId': 'sounds_get',
                           'parameters': [{'name': 'include_data', 'in': 'query', 'schema': {'type': 'boolean'}, 'description': 'Dołącz audio_data_base64 w odpowiedzi'}],
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Sound'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['Dźwięki'], 'summary': 'Zaktualizuj metadane dźwięku', 'operationId': 'sounds_update',
                           'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Sound'}}}},
                           'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Sound'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Dźwięki'], 'summary': 'Usuń dźwięk', 'operationId': 'sounds_delete',
                           'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            '/sounds/{id}/upload': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'post': {
                    'tags': ['Dźwięki'], 'summary': 'Wgraj plik audio', 'operationId': 'sounds_upload',
                    'description': 'Upload pliku audio (multipart/form-data). Plik zostanie automatycznie skonwertowany do WAV 8kHz mono jeśli dostępny SoX lub ffmpeg.',
                    'requestBody': {
                        'required': True,
                        'content': {'multipart/form-data': {'schema': {
                            'type': 'object',
                            'required': ['file'],
                            'properties': {
                                'file':    {'type': 'string', 'format': 'binary', 'description': 'Plik audio (WAV/MP3/OGG)'},
                                'fs_path': {'type': 'string', 'description': 'Opcjonalnie: zaktualizuj ścieżkę na serwerze FS'},
                            }
                        }}}
                    },
                    'responses': {'200': {'description': 'Plik wgrany', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Sound'}}}}, '400': _resp('Brak pola file', 'Error'), '404': _resp('Dźwięk nie znaleziony', 'Error')},
                }
            },
            '/sounds/{id}/download': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get': {
                    'tags': ['Dźwięki'], 'summary': 'Pobierz plik audio (binary)', 'operationId': 'sounds_download',
                    'responses': {
                        '200': {'description': 'Plik audio', 'content': {'audio/wav': {'schema': {'type': 'string', 'format': 'binary'}}, 'audio/mpeg': {'schema': {'type': 'string', 'format': 'binary'}}}},
                        '404': _resp('Dźwięk lub plik nie znaleziony', 'Error'),
                    }
                }
            },
            # ── CC Monitor ────────────────────────────────────────────────
            '/cc_monitor': {
                'get': {
                    'tags':        ['CC Monitor'],
                    'summary':     'Live dane CallCenter — kolejki + agenci',
                    'operationId': 'cc_monitor',
                    'description': (
                        'Zwraca kompletny snapshot stanu CallCenter w czasie rzeczywistym. '
                        'Dane agentów i callerów pochodzą bezpośrednio z bazy PostgreSQL FreeSWITCH '
                        '(gdy db_ok=true) lub z Odoo jako fallback. '
                        'Identyczna struktura danych jak wewnętrzny dashboard Monitor CC.'
                    ),
                    'parameters': [
                        {'name': 'queue', 'in': 'query', 'schema': {'type': 'string'}, 'description': 'Filtr: pokaż tylko dane dla podanej kolejki (nazwa bez domeny)'},
                    ],
                    'responses': {
                        '200': {'description': 'Dane CC', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCMonitorResponse'}}}},
                        '401': _resp('Brak autoryzacji', 'Error'),
                        '500': _resp('Błąd serwera', 'Error'),
                    }
                }
            },
        },
        'tags': [
            {'name': 'Status',             'description': 'Sprawdzenie stanu serwisu'},
            {'name': 'Klient',             'description': 'Informacje o kliencie powiązanym z kluczem API'},
            {'name': 'Trasy DID',          'description': 'Zarządzanie trasami DID / inbound routes'},
            {'name': 'Użytkownicy SIP',    'description': 'Zarządzanie użytkownikami SIP'},
            {'name': 'Harmonogramy SIP',   'description': 'Godziny pracy użytkowników SIP — wpisy kalendarza dostępności'},
            {'name': 'Dni wolne',           'description': 'Globalna lista dni wolnych od pracy (święta) per kraj'},
            {'name': 'IVR',               'description': 'Konfiguracje Interactive Voice Response'},
            {'name': 'Kolejki CallCenter', 'description': 'Kolejki CallCenter (mod_callcenter) z agentami i tierami'},
            {'name': 'Agenci CallCenter',  'description': 'Agenci mod_callcenter — konfiguracja i przypisania do kolejek'},
            {'name': 'Dźwięki',            'description': 'Biblioteka dźwięków — zarządzanie plikami audio'},
            {'name': 'CC Monitor',          'description': 'Live dane CallCenter: kolejki, callerzy, agenci'},
        ],
    }