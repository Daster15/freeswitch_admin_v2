-- =============================================================================
-- Moduł wewnętrzny: zbieranie prób agentów po zakończeniu kolejki callcenter.
-- Wywoływany przez action_callcenter.lua zaraz po session:execute("callcenter").
--
-- Dane są pobierane z tabel mod_callcenter (members / members_session_end)
-- przez ESL API i zapisywane do zmiennej sesji odoo_agent_attempts (JSON).
-- cdr_writer.lua odczytuje tę zmienną i wysyła do Odoo przez webhook lub INSERT.
--
-- Użycie:
--   require("action_callcenter_attempts").collect(queue_name, caller_uuid, log)
-- =============================================================================

local M = {}

-- ── Mapowanie hangup_cause FS → reason Odoo ──────────────────────────────────

local CAUSE_TO_REASON = {
    NO_ANSWER            = "no_answer_timeout",
    PROGRESS_TIMEOUT     = "no_answer_timeout",
    USER_BUSY            = "agent_busy",
    CALL_REJECTED        = "rejected_manually",
    SUBSCRIBER_ABSENT    = "not_registered",
    USER_NOT_REGISTERED  = "not_registered",
    NO_ROUTE_DESTINATION = "not_registered",
    NORMAL_CLEARING      = "unknown",
}

-- Mapowanie cc_member_leaving_reason (natywne mod_callcenter) → reason Odoo
local CC_LEAVING_TO_REASON = {
    ["1"]  = "no_answer_timeout",   -- TIMEOUT
    ["2"]  = "agent_busy",          -- AGENT_BUSY
    ["3"]  = "rejected_manually",   -- REJECT
    ["4"]  = "no_answer_timeout",   -- NO_ANSWER
    ["5"]  = "agent_logged_out",    -- AGENT_NOT_LOGGED_IN
    ["6"]  = "max_no_answer",       -- MAX_NO_ANSWER
    ["7"]  = "wrap_up",             -- WRAP_UP
}

local function cause_to_reason(cause)
    return CAUSE_TO_REASON[cause] or "unknown"
end

local function leaving_to_reason(code)
    return CC_LEAVING_TO_REASON[tostring(code)] or "unknown"
end

-- ── Prosta serializacja do JSON (bez zewnętrznych bibliotek) ─────────────────

local function json_str(s)
    if s == nil then return "null" end
    s = tostring(s)
    s = s:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n'):gsub('\r', '')
    return '"' .. s .. '"'
end

local function attempt_to_json(a)
    return string.format(
        '{"agent_name":%s,"agent_ext":%s,"attempt_time":%s,' ..
        '"duration_sec":%d,"result":%s,"reason":%s,"hangup_cause":%s}',
        json_str(a.agent_name),
        json_str(a.agent_ext or ""),
        json_str(a.attempt_time or ""),
        tonumber(a.duration_sec) or 0,
        json_str(a.result),
        json_str(a.reason),
        json_str(a.hangup_cause or "")
    )
end

local function attempts_to_json(list)
    if #list == 0 then return "[]" end
    local parts = {}
    for _, a in ipairs(list) do
        table.insert(parts, attempt_to_json(a))
    end
    return "[" .. table.concat(parts, ",") .. "]"
end

-- ── ESL helper ───────────────────────────────────────────────────────────────

local function esl_get(cmd_app, cmd_args)
    local api   = freeswitch.API()
    local reply = api:execute(cmd_app, cmd_args) or ""
    reply = reply:match("^%s*(.-)%s*$")
    if reply:match("^%-ERR") or reply == "" then return nil end
    return reply
end

-- ── Odczyt prób z ESL callcenter_config member list ──────────────────────────
-- Tabela members w FS zawiera historię sesji BIEŻĄCEGO połączenia.
-- Aby odczytać próby zakończonego połączenia używamy member uuid (caller_uuid).

local function collect_from_esl(queue_name, caller_uuid, log)
    local attempts = {}

    -- Metoda 1: callcenter_config member list — zwraca wszystkie aktywne/ostatnie wpisy
    -- Format linii: uuid|system|joined_epoch|leaving_epoch|state|agent|cid_name|cid_num|last_agent|pos
    local member_data = esl_get("callcenter_config",
        "member list " .. queue_name .. "@" .. (require("odoo_db").company_config().sip_domain or ""))

    if member_data then
        for line in member_data:gmatch("[^\n]+") do
            -- Szukamy linii pasującej do naszego caller_uuid
            local parts = {}
            for p in line:gmatch("([^|]+)") do
                table.insert(parts, p:match("^%s*(.-)%s*$"))
            end

            if #parts >= 6 then
                local m_uuid   = parts[1]
                local joined   = tonumber(parts[3]) or 0
                local leaving  = tonumber(parts[4]) or 0
                local state    = parts[5] or ""
                local agent    = parts[6] or ""
                local leaving_r = parts[9] or "0"

                if m_uuid == caller_uuid and agent ~= "" and agent ~= "N/A" then
                    local duration = (leaving > 0 and joined > 0) and (leaving - joined) or 0
                    local result   = (state == "Answered" or state == "CS_BRIDGE") and "answered" or "no_answer"
                    local reason   = leaving_to_reason(leaving_r)
                    local agent_short = agent:match("^([^@]+)") or agent

                    table.insert(attempts, {
                        agent_name   = agent_short,
                        agent_ext    = agent_short,
                        attempt_time = joined > 0 and os.date("%Y-%m-%d %H:%M:%S", joined) or "",
                        duration_sec = duration,
                        result       = result,
                        reason       = reason,
                        hangup_cause = "",
                    })
                    log("INFO", string.format(
                        "  attempt[ESL]: agent=%s result=%s reason=%s dur=%ds",
                        agent_short, result, reason, duration))
                end
            end
        end
    end

    return attempts
end

-- ── Metoda 2: zmienne sesji ustawione przez mod_callcenter ───────────────────
-- Gdy ESL nie zwraca danych (połączenie już zakończone), fallback na zmienne sesji.

local function collect_from_session(cc_cause, cc_agent, log)
    local attempts = {}

    -- cc_agent zawiera ostatniego agenta który próbował odebrać
    local agent = cc_agent and cc_agent:match("^([^@]+)") or ""
    if agent == "" or agent == "false" then
        log("DEBUG", "  collect_from_session: brak cc_agent")
        return attempts
    end

    local result = "no_answer"
    local reason = "unknown"

    if cc_cause == "answered" or cc_cause == "success" then
        result = "answered"
        reason = "unknown"
    elseif cc_cause == "no-agents-available" then
        result = "no_answer"
        reason = "agent_logged_out"
    elseif cc_cause == "timeout" then
        result = "timeout"
        reason = "no_answer_timeout"
    else
        result = "no_answer"
        reason = cause_to_reason(cc_cause or "")
    end

    -- Czas rozmowy z sesji (cc_talk_time) jako duration dla odebrane
    local talk_time = tonumber(session:getVariable("cc_talk_time") or "0") or 0
    local wait_time = tonumber(session:getVariable("cc_wait_time") or "0") or 0

    table.insert(attempts, {
        agent_name   = agent,
        agent_ext    = agent,
        attempt_time = "",  -- brak precyzyjnego czasu w zmiennych sesji
        duration_sec = result == "answered" and talk_time or
                       tonumber(session:getVariable("call_timeout") or "20") or 20,
        result       = result,
        reason       = reason,
        hangup_cause = session:getVariable("hangup_cause") or "",
    })

    log("INFO", string.format(
        "  attempt[session]: agent=%s result=%s reason=%s",
        agent, result, reason))

    return attempts
end

-- ── Buduj ścieżkę połączenia ─────────────────────────────────────────────────

local function build_call_path(queue_name, attempts, log)
    local ivr_name   = session:getVariable("odoo_ivr_name")   or ""
    local route_type = session:getVariable("odoo_route_type") or ""
    local parts = {}

    if ivr_name ~= "" then
        local ivr_sel = session:getVariable("odoo_ivr_selections") or ""
        local sel_str = ivr_sel ~= "" and (" [" .. ivr_sel .. "]") or ""
        table.insert(parts, "IVR:" .. ivr_name .. sel_str)
    end

    if route_type == "callcenter" and queue_name ~= "" then
        table.insert(parts, "CC:" .. queue_name)
    elseif route_type == "fifo" and queue_name ~= "" then
        table.insert(parts, "FIFO:" .. queue_name)
    end

    -- Ostatni agent który odebrał lub próbował
    for i = #attempts, 1, -1 do
        local a = attempts[i]
        if a.result == "answered" then
            table.insert(parts, "agent:" .. a.agent_name)
            break
        end
    end

    local path = table.concat(parts, " → ")
    log("INFO", "  call_path: " .. (path ~= "" and path or "(brak)"))
    return path
end

-- ── Główna funkcja ────────────────────────────────────────────────────────────

function M.collect(queue_name, caller_uuid, log)
    log = log or function(l, m) freeswitch.consoleLog(l, "[cc_attempts] " .. m) end
    log("INFO", string.format("collect_attempts: queue=%s uuid=%s", queue_name, caller_uuid))

    local cc_cause = session:getVariable("cc_cause") or ""
    local cc_agent = session:getVariable("cc_agent") or ""

    -- Próbuj najpierw przez ESL, fallback na zmienne sesji
    local attempts = collect_from_esl(queue_name, caller_uuid, log)

    if #attempts == 0 then
        log("INFO", "  ESL nie zwrócił prób — fallback na zmienne sesji")
        attempts = collect_from_session(cc_cause, cc_agent, log)
    end

    log("INFO", string.format("  zebrano %d prób", #attempts))

    -- Zapisz JSON prób do zmiennej sesji (odczyta cdr_writer.lua)
    local json = attempts_to_json(attempts)
    session:setVariable("odoo_agent_attempts", json)

    -- Buduj i zapisz ścieżkę połączenia
    local call_path = build_call_path(queue_name, attempts, log)
    session:setVariable("odoo_call_path", call_path)

    -- Ustaw odoo_answered / odoo_agent_name na podstawie prób
    for _, a in ipairs(attempts) do
        if a.result == "answered" then
            session:setVariable("odoo_answered",   "true")
            session:setVariable("odoo_agent_name", a.agent_name)
            session:setVariable("odoo_talk_sec",   tostring(a.duration_sec))
            break
        end
    end

    return attempts
end

return M
