-- =============================================================================
-- fifo_position.lua
-- Periodic queue position announcement for FIFO queue.
--
-- Called by sched_api from action_fifo.lua every N seconds:
--   sched_api +20 <uuid> lua fifo_position.lua <queue_name> <caller_uuid>
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local queue_name  = argv[1] or ""
local caller_uuid = argv[2] or ""

-- Ten log ZAWSZE pojawia sie na konsoli FS gdy skrypt sie uruchamia
freeswitch.consoleLog("NOTICE", string.format(
    "[fifo_position] START queue=%s uuid=%s\n", queue_name, caller_uuid))

if queue_name == "" or caller_uuid == "" then
    freeswitch.consoleLog("WARN", "[fifo_position] missing argv queue=" .. queue_name
                                   .. " uuid=" .. caller_uuid .. "\n")
    return
end

local function log(level, msg)
    freeswitch.consoleLog(level, string.format("[fifo_pos:%s] %s\n", queue_name, msg))
end

local api = freeswitch.API()

-- Check if channel still exists
local uuid_exists = api:execute("uuid_exists", caller_uuid) or "false"
uuid_exists = uuid_exists:match("^%s*(.-)%s*$")
if uuid_exists ~= "true" then
    log("INFO", "channel " .. caller_uuid .. " gone -- skip")
    return
end

-- Check FIFO channel variable -- if fifo_state is set it may have been answered
local fifo_state = api:execute("uuid_getvar", caller_uuid .. " fifo_state") or ""
fifo_state = fifo_state:match("^%s*(.-)%s*$")
-- FreeSWITCH zwraca "_undef_" gdy zmienna nie istnieje
if fifo_state == "answering" or fifo_state == "answered" then
    log("INFO", "fifo_state=" .. fifo_state .. " -- call handled, skip")
    return
end

-- Get sip domain
local db  = require("odoo_db")
local cfg = db.company_config()
local qkey = queue_name .. "@" .. cfg.sip_domain

-- Get position in FIFO queue
-- fifo_member_count returns total callers in queue
-- fifo_queue_position is the caller's position (set by mod_fifo as channel var)
local position = 0
local total    = 0

-- Try channel variable first (mod_fifo sets fifo_queue_position)
local pos_var = api:execute("uuid_getvar", caller_uuid .. " fifo_queue_position") or ""
pos_var = pos_var:match("^%s*(.-)%s*$")
if pos_var ~= "" and pos_var ~= "false" and pos_var ~= "_undef_" and tonumber(pos_var) then
    position = tonumber(pos_var)
    log("NOTICE", "  position from channel var fifo_queue_position: " .. tostring(position))
end

-- Parsuj XML z fifo list_verbose
-- Format: <caller uuid="..." status="WAITING" ...>
-- Liczymy tylko elementy <caller> (nie consumers, nie bridges)
-- i sprawdzamy czy uuid calera pojawia sie w atrybucie uuid elementu caller

local fifo_xml = api:execute("fifo", "list_verbose " .. qkey) or ""

-- Wytnij tylko sekcje <callers>...</callers>
local callers_section = fifo_xml:match("<callers>(.-)</callers>") or ""

-- Pobierz waiting_count z atrybutu fifo (szybszy niz parsowanie)
local waiting_count = fifo_xml:match('waiting_count="(%d+)"')
total = tonumber(waiting_count) or 0

-- Znajdz pozycje callera wsrod <caller uuid="..."> elementow
local pos = 0
local idx = 0
for uuid_attr in callers_section:gmatch('<caller uuid="([^"]+)"') do
    idx = idx + 1
    if uuid_attr == caller_uuid then
        pos = idx
        break
    end
end
position = pos

log("NOTICE", string.format(
    "  XML parse: waiting_count=%d caller_idx=%d (searched %d callers)",
    total, position, idx))

log("NOTICE", string.format("position=%d/%d caller=%s", position, total, caller_uuid))

-- Play announcement via uuid_broadcast
local sounds_base = "/usr/local/freeswitch/sounds/en/us/callie"
local digits_dir  = sounds_base .. "/digits/8000"

local function file_exists(path)
    local f = io.open(path, "r")
    if f then f:close(); return true end
    return false
end

local function broadcast(file)
    log("NOTICE", ">>> BROADCAST: " .. file)
    if not file_exists(file) then
        log("WARN", "    PLIK NIE ISTNIEJE: " .. file)
        return
    end
    local r = api:execute("uuid_broadcast", caller_uuid .. " " .. file .. " aleg")
    r = (r or ""):match("^%s*(.-)%s*$")
    log("NOTICE", "    uuid_broadcast reply: " .. tostring(r))
    api:execute("sleep", "500")
end

local function play_number(n)
    if n <= 0 then return end
    if n <= 20 then
        broadcast(digits_dir .. "/" .. tostring(n) .. ".wav")
    elseif n < 100 then
        local tens  = math.floor(n / 10) * 10
        local units = n % 10
        broadcast(digits_dir .. "/" .. tostring(tens) .. ".wav")
        if units > 0 then broadcast(digits_dir .. "/" .. tostring(units) .. ".wav") end
    elseif n < 1000 then
        local hundreds = math.floor(n / 100)
        local rest     = n % 100
        broadcast(digits_dir .. "/" .. tostring(hundreds) .. ".wav")
        broadcast(digits_dir .. "/hundred.wav")
        if rest > 0 then play_number(rest) end
    else
        broadcast(digits_dir .. "/thousand.wav")
    end
end

log("NOTICE", string.format("=== FIFO_POSITION ANNOUNCEMENT: position=%d/%d ===", position, total))

if position == 0 then
    log("WARN", "Klient NIE ZNALEZIONY w kolejce FIFO -- brak ogłoszenia")
else
    -- EWT z CDR
    local avg_talk    = 0
    local agents_avail = 0
    local ewt_min     = 0
    local db = require("odoo_db")
    local cfg = db.company_config()

    local ok1 = pcall(function()
        local row = db.query_one(string.format([[
            SELECT COALESCE(AVG(billsec), 0)::int AS avg_talk, COUNT(*)::int AS cnt
            FROM (
                SELECT billsec FROM freeswitch_cdr
                WHERE  queue_name = %s AND status = 'completed' AND billsec > 0
                ORDER  BY start_time DESC LIMIT 50
            ) sub
        ]], db.esc(queue_name)))
        if row then
            avg_talk = tonumber(row.avg_talk) or 0
            log("NOTICE", string.format("  EWT CDR: avg_talk=%ds z %s pol.", avg_talk, tostring(row.cnt)))
        end
    end)
    if not ok1 then log("WARN", "  EWT CDR blad pcall") end

    local ok2 = pcall(function()
        local arow = db.query_one(string.format([[
            SELECT COUNT(*)::int AS cnt
            FROM   freeswitch_fifo_agent a
            JOIN   freeswitch_fifo f ON f.id = a.fifo_id
            JOIN   freeswitch_cc_agent ca ON ca.id = a.cc_agent_id
            WHERE  f.name       = %s
              AND  f.company_id = %d
              AND  ca.status    = 'Available'
              AND  a.active     = true
        ]], db.esc(queue_name), cfg.company_id))
        if arow then agents_avail = tonumber(arow.cnt) or 0 end
        log("NOTICE", string.format("  EWT agenci dostepni=%d", agents_avail))
    end)
    if not ok2 then log("WARN", "  EWT agenci blad pcall") end

    if avg_talk > 0 and position > 1 then
        local divisor = math.max(agents_avail, 1)
        local ewt_sec = math.ceil((position - 1) * avg_talk / divisor)
        ewt_min = math.ceil(ewt_sec / 60)
        log("NOTICE", string.format("  EWT: (pos=%d-1)*%ds/%d=%ds=%dmin",
            position, avg_talk, divisor, ewt_sec, ewt_min))
    end

    log("NOTICE", string.format("ODTWARZAM: pozycja=%d EWT=%dmin", position, ewt_min))
    play_number(position)
    if ewt_min > 0 then
        api:execute("sleep", "300")
        broadcast(digits_dir .. "/dot.wav")
        play_number(ewt_min)
    end
end

-- Schedule next announcement
local still_alive = api:execute("uuid_exists", caller_uuid) or "false"
still_alive = still_alive:match("^%s*(.-)%s*$")

local interval_str = api:execute("uuid_getvar", caller_uuid .. " fifo_announce_interval") or "20"
interval_str = interval_str:match("^%s*(.-)%s*$")
local interval = tonumber(interval_str) or 20

if still_alive == "true" and position > 0 then
    local sched_cmd = string.format("+%d %s lua fifo_position.lua %s %s",
        interval, caller_uuid, queue_name, caller_uuid)
    local sched_reply = api:execute("sched_api", sched_cmd) or ""
    log("INFO", string.format("next in %ds sched=%s", interval, sched_reply))
else
    log("INFO", "no next announcement (channel gone or not in queue)")
end
