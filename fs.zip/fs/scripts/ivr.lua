-- =============================================================================
-- ivr.lua
-- Obsługa menu IVR — odczyt z tabel Odoo:
--   freeswitch_ivr       (model freeswitch.ivr)
--   freeswitch_ivr_item  (model freeswitch.ivr.item)
--   freeswitch_sound     (model freeswitch.sound)
--
-- Użycie jako moduł (z router.lua):
--   require("ivr").run("nazwa_ivr")
--
-- Użycie z dialplanu (bezpośrednio):
--   <action application="lua" data="ivr.lua nazwa_ivr"/>
--
-- Historia wyborów DTMF zapisywana jest w zmiennej sesji:
--   odoo_ivr_selections
-- Format: "menu-glowne:2 → menu-sprzedaz:1 → cc-rejestracja"
-- Każdy wpis: "<nazwa_ivr>:<cyfra>" lub "<nazwa_ivr>:timeout/<akcja_domyslna>"
-- =============================================================================
local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db    = require("odoo_db")
local sound = require("sound")
local cfg = db.company_config()

local M = {}

-- ── Helper: dopisz krok do historii przebiegu połączenia ─────────────────────
-- Każde wywołanie dodaje jeden wpis do odoo_ivr_selections.
-- Format wpisu: "nazwa_ivr:cyfra"  lub  "nazwa_ivr:timeout"
local function track(ivr_name, digit)
    local current = session:getVariable("odoo_ivr_selections") or ""
    local entry   = ivr_name .. ":" .. tostring(digit)
    if current == "" then
        session:setVariable("odoo_ivr_selections", entry)
    else
        session:setVariable("odoo_ivr_selections", current .. " → " .. entry)
    end
    freeswitch.consoleLog("INFO",
        "[ivr.lua] ivr_selections=" ..
        (session:getVariable("odoo_ivr_selections") or ""))
end


function M.run(ivr_name)
    ivr_name = (ivr_name or ""):gsub("^odoo_ivr_", "")
    freeswitch.consoleLog("INFO", "[ivr.lua] START name=" .. ivr_name)

    -- Pobierz konfigurację IVR
    local ivr = db.query_one(string.format([[
        SELECT id, name, timeout_sec, max_failures,
               greeting_id, default_action, default_target
        FROM   freeswitch_ivr
        WHERE  name       = %s
          AND  company_id = %d
          AND  active     = true
        LIMIT  1
    ]], db.esc(ivr_name), cfg.company_id))

    if not ivr then
        freeswitch.consoleLog("ERR", "[ivr.lua] Nie znaleziono IVR: " .. ivr_name)
        session:execute("hangup", "NO_ROUTE_DESTINATION")
        return
    end

    -- Ustaw aktualny IVR (ostatni aktywny)
    session:setVariable("odoo_ivr_name", ivr_name)

    -- Pobierz opcje menu
    local items = db.query_all(string.format([[
        SELECT digit, action, target,
               target_sound_id,
               playback_after,
               playback_after_ivr_id,
               playback_after_fifo_id,
               playback_after_cc_id,
               playback_after_pstn
        FROM   freeswitch_ivr_item
        WHERE  ivr_id = %d
        ORDER  BY sequence, digit
    ]], tonumber(ivr.id)))

    local menu = {}
    for _, item in ipairs(items) do
        menu[tostring(item.digit)] = item
    end

    freeswitch.consoleLog("INFO", "[ivr.lua] greeting_id=" .. tostring(ivr.greeting_id))
    local greeting   = sound.resolve(ivr.greeting_id)
    freeswitch.consoleLog("INFO", "[ivr.lua] greeting_path=" .. tostring(greeting))
    local timeout_ms = (tonumber(ivr.timeout_sec) or 7) * 1000
    local max_fail   = tonumber(ivr.max_failures) or 3

    freeswitch.consoleLog("INFO",
        "[ivr.lua] Załadowano IVR=" .. ivr_name ..
        " opcje=" .. #items .. " timeout=" .. timeout_ms .. "ms")

    -- Pętla menu
    -- Używamy playAndGetDigits z pustym greeting gdy plik MP3,
    -- bo mod_shout nie działa w playAndGetDigits.
    -- Rozwiązanie: ustawiamy zmienną playback_terminators aby DTMF przerywało playback,
    -- następnie odtwarzamy przez playback i zbieramy przez getDigits.
    local failures = 0
    while session:ready() and failures < max_fail do

        session:flushDigits()

        -- Ustaw aby dowolna cyfra przerywała odtwarzanie
        session:setVariable("playback_terminators", "0123456789*#")
        session:setVariable("playback_terminator_used", "")

        -- Odtwórz greeting (działa z WAV i MP3 przez mod_shout)
        if greeting ~= "" then
            session:execute("playback", greeting)
        end

        -- Sprawdź czy cyfra została wciśnięta podczas odtwarzania
        local digit = session:getVariable("playback_terminator_used") or ""

        -- Jeśli nie wciśnięto podczas odtwarzania — czekaj na DTMF przez timeout
        if digit == "" then
            digit = session:getDigits(1, "#", timeout_ms)
        end

        -- Wyczyść terminator
        session:setVariable("playback_terminators", "none")

        if not digit or digit == "" then
            failures = failures + 1
            freeswitch.consoleLog("WARN", "[ivr.lua] Brak wyboru #" .. failures)
            -- Zapisz timeout w historii (tylko przy pierwszym timeout w tej pętli)
            if failures == 1 then
                track(ivr_name, "timeout")
            end
        else
            local item = menu[digit]
            if not item then
                failures = failures + 1
                freeswitch.consoleLog("WARN", "[ivr.lua] Nieznana cyfra: " .. digit)
                track(ivr_name, digit .. "?")   -- nieznana cyfra oznaczona "?"
            else
                local action = item.action or "hangup"
                local target = item.target or ""
                freeswitch.consoleLog("INFO",
                    "[ivr.lua] Cyfra=" .. digit .. " action=" .. action .. " target=" .. target)

                -- Zapisz wybór DTMF w historii PRZED wykonaniem akcji
                track(ivr_name, digit)

                if action == "repeat" then
                    -- wróć do pętli, nie inkrementuj failures

                elseif action == "hangup" then
                    return

                elseif action == "user" then
                    -- Deleguj do action_user który obsługuje unreg/noanswer/busy fallback
                    require("action_user").run(target, function(lvl, msg)
                        freeswitch.consoleLog(lvl, "[ivr→user] " .. msg)
                    end)
                    return

                elseif action == "ivr" then
                    M.run(target)
                    return

                elseif action == "fifo" then
                    -- POPRAWKA: action_fifo.run() zamiast session:execute
                    -- Ustawia odoo_agent_name, odoo_wait_sec, odoo_talk_sec po wyjsciu z kolejki
                    require("action_fifo").run(target, function(lvl, msg)
                        freeswitch.consoleLog(lvl, "[ivr→fifo] " .. msg)
                    end)
                    return

                elseif action == "callcenter" then
                    -- POPRAWKA: action_callcenter.run() zamiast session:execute
                    -- Po wyjsciu z kolejki zapisuje cc_agent, wait_sec, talk_sec do sesji
                    require("action_callcenter").run(target, function(lvl, msg)
                        freeswitch.consoleLog(lvl, "[ivr→cc] " .. msg)
                    end)
                    return

                elseif action == "pstn" then
                    require("action_pstn").run(target, function(lvl, msg)
                        freeswitch.consoleLog(lvl, "[ivr→pstn] " .. msg)
                    end)
                    return

                elseif action == "voicemail" then
                    session:execute("voicemail",
                        "default " .. cfg.sip_domain .. " " .. target)
                    return

                elseif action == "playback" then
                    local sf = sound.resolve(item.target_sound_id)
                    if sf ~= "" then session:execute("playback", sf) end

                    local pb_after = item.playback_after or "hangup"
                    if pb_after == "hangup" then
                        return
                    elseif pb_after == "repeat" then
                        -- wróć do pętli menu
                    elseif pb_after == "ivr" and item.playback_after_ivr_id then
                        local r = db.query_one("SELECT name FROM freeswitch_ivr WHERE id = " .. tostring(item.playback_after_ivr_id) .. " LIMIT 1")
                        if r then M.run(r.name) end
                        return
                    elseif pb_after == "fifo" and item.playback_after_fifo_id then
                        local r = db.query_one("SELECT name FROM freeswitch_fifo WHERE id = " .. tostring(item.playback_after_fifo_id) .. " LIMIT 1")
                        if r then
                            require("action_fifo").run(r.name, function(lvl, msg)
                                freeswitch.consoleLog(lvl, "[ivr→fifo] " .. msg)
                            end)
                        end
                        return
                    elseif pb_after == "callcenter" and item.playback_after_cc_id then
                        local r = db.query_one("SELECT name FROM freeswitch_cc_queue WHERE id = " .. tostring(item.playback_after_cc_id) .. " LIMIT 1")
                        if r then
                            require("action_callcenter").run(r.name, function(lvl, msg)
                                freeswitch.consoleLog(lvl, "[ivr→cc] " .. msg)
                            end)
                        end
                        return
                    elseif pb_after == "pstn" then
                        local pstn = item.playback_after_pstn or ""
                        if pstn ~= "" then
                            require("action_pstn").run(pstn, function(lvl, msg)
                                freeswitch.consoleLog(lvl, "[ivr→pstn] " .. msg)
                            end)
                        end
                        return
                    end
                end
            end
        end
    end

    -- Przekroczono max_failures → akcja domyślna
    local def  = ivr.default_action or "hangup"
    local dtgt = ivr.default_target or ""
    freeswitch.consoleLog("WARN",
        "[ivr.lua] max_failures → default_action=" .. def)

    -- Odnotuj w historii że poszło do akcji domyślnej
    track(ivr_name, "default:" .. def)

    if def == "ivr" then
        M.run(dtgt)
    elseif def == "fifo" then
        require("action_fifo").run(dtgt, function(lvl, msg)
            freeswitch.consoleLog(lvl, "[ivr→fifo] " .. msg)
        end)
    elseif def == "callcenter" then
        require("action_callcenter").run(dtgt, function(lvl, msg)
            freeswitch.consoleLog(lvl, "[ivr→cc] " .. msg)
        end)
    elseif def == "user" then
        -- Deleguj do action_user który obsługuje unreg/noanswer/busy fallback
        require("action_user").run(dtgt, function(lvl, msg)
            freeswitch.consoleLog(lvl, "[ivr→user] " .. msg)
        end)
    elseif def == "pstn" then
        require("action_pstn").run(dtgt, function(lvl, msg)
            freeswitch.consoleLog(lvl, "[ivr→pstn] " .. msg)
        end)
    end
    -- hangup → dialplan obsłuży
end

-- Obsługa wywołania bezpośrednio z dialplanu
if argv and argv[1] then
    M.run(argv[1])
end

return M
