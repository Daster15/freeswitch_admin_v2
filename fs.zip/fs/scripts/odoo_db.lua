-- =============================================================================
-- odoo_db.lua
-- Moduł bazowy: połączenie z PostgreSQL Odoo + helpery query/execute.
-- Wszystkie inne skrypty Lua robią require("odoo_db").
--
-- Zależności (luarocks):
--   luarocks install luasql-postgres PGSQL_INCDIR=/usr/include/postgresql
-- =============================================================================

-- ── Ścieżka do skryptów FreeSWITCH ───────────────────────────────────────────
-- Wszystkie moduły Lua (ivr.lua, cdr_writer.lua itd.) leżą w tym katalogu.
-- Dzięki temu require("ivr"), require("odoo_db") itd. zawsze działają
-- niezależnie od systemowej ścieżki Lua.
local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local M = {}

-- ── Konfiguracja połączenia z bazą Odoo ──────────────────────────────────────
-- Wpisz tu dane raz podczas instalacji na serwerze FreeSWITCH.
M.pg = {
    host     = "127.0.0.1",
    port     = "5432",
    dbname   = "ltech_dev",
    user     = "odoo17",
    password = "odoo",
}

-- ID firmy w Odoo (res.company)
M.company_id = 1

-- Włącz szczegółowe logi
M.debug = false

-- ── Wewnętrzne ────────────────────────────────────────────────────────────────
local _env  = nil
local _conn = nil

local function get_conn()
    if _conn then return _conn end
    if not _env then
        local luasql = require("luasql.postgres")
        _env = luasql.postgres()
    end
    local conn, err = _env:connect(
        "dbname="    .. M.pg.dbname ..
        " host="     .. M.pg.host   ..
        " port="     .. M.pg.port   ..
        " user="     .. M.pg.user   ..
        " password=" .. M.pg.password
    )
    if not conn then
        error("[odoo_db] Błąd połączenia z PostgreSQL: " .. tostring(err))
    end
    _conn = conn
    return conn
end

-- ── API publiczne ─────────────────────────────────────────────────────────────

-- SELECT — zwraca pierwszy wiersz jako {kolumna=wartość} lub nil
function M.query_one(sql)
    if M.debug then freeswitch.consoleLog("DEBUG", "[odoo_db] " .. sql) end
    local conn = get_conn()
    local cur, err = conn:execute(sql)
    if not cur then
        freeswitch.consoleLog("ERR", "[odoo_db] Błąd zapytania: " .. tostring(err) .. " | SQL: " .. sql)
        return nil
    end
    local row = cur:fetch({}, "a")
    cur:close()
    return row
end

-- SELECT — zwraca wszystkie wiersze jako tablicę
function M.query_all(sql)
    if M.debug then freeswitch.consoleLog("DEBUG", "[odoo_db] " .. sql) end
    local conn = get_conn()
    local cur, err = conn:execute(sql)
    if not cur then
        freeswitch.consoleLog("ERR", "[odoo_db] Błąd zapytania: " .. tostring(err) .. " | SQL: " .. sql)
        return {}
    end
    local rows = {}
    local row = cur:fetch({}, "a")
    while row do
        table.insert(rows, row)
        row = cur:fetch({}, "a")
    end
    cur:close()
    return rows
end

-- INSERT / UPDATE / DELETE — nie zwraca wierszy
function M.execute(sql)
    if M.debug then freeswitch.consoleLog("DEBUG", "[odoo_db] " .. sql) end
    local conn = get_conn()
    local res, err = conn:execute(sql)
    if not res then
        freeswitch.consoleLog("ERR", "[odoo_db] Błąd wykonania: " .. tostring(err) .. " | SQL: " .. sql)
        return false
    end
    return true
end

-- Ucieczka apostrofów
function M.esc(s)
    if s == nil then return "NULL" end
    return "'" .. tostring(s):gsub("'", "''") .. "'"
end

-- ── Konfiguracja firmy (cache per wywołanie skryptu) ─────────────────────────
local _company_cfg = nil

function M.company_config()
    if _company_cfg then return _company_cfg end

    local row = M.query_one(string.format([[
        SELECT
            c.sip_domain,
            c.gateway,
            c.sounds_dir,
            c.company_id,
            p.value AS odoo_base_url
        FROM  freeswitch_company_config c
        LEFT  JOIN ir_config_parameter p ON p.key = 'web.base.url'
        WHERE c.company_id = %d
        LIMIT 1
    ]], M.company_id))

    if not row then
        error("[odoo_db] Brak konfiguracji FreeSWITCH dla company_id=" .. M.company_id)
    end

    _company_cfg = {
        sip_domain  = row.sip_domain   or "sip.example.pl",
        gateway     = row.gateway      or "default",
        sounds_dir  = row.sounds_dir   or "/etc/freeswitch/sounds/pl",
        company_id  = row.company_id   or M.company_id,
        odoo_base_url = (row.odoo_base_url or "http://127.0.0.1:8069"):gsub("/$", ""),
    }
    return _company_cfg
end

return M

