-- =============================================================================
-- sound.lua
-- Rozwiązuje ścieżkę do pliku audio dla FreeSWITCH.
-- Czyta załącznik bezpośrednio z ir_attachment (Odoo filestore lub db_datas).
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db = require("odoo_db")

local M = {}

-- ── Konfiguracja ──────────────────────────────────────────────────────────────
-- Ścieżka do filestore Odoo: <data_dir>/filestore/<nazwa_bazy>

--local ODOO_FILESTORE = "/home/arek/Downloads/ltech-prod-11517204_2026-04-29_130144_test_fs/filestore"
local ODOO_FILESTORE = "/home/arek/.local/share/Odoo/filestore/" .. db.pg.dbname

-- Katalog dźwięków FreeSWITCH — per firma: /etc/freeswitch/sounds/<company_id>/
-- Tworzony automatycznie przy pierwszym użyciu
local function get_sounds_dir(company_id)
    local dir = "/etc/freeswitch/sounds/" .. tostring(company_id)
    os.execute("mkdir -p " .. dir)
    return dir
end

-- ── Pomocnicze ────────────────────────────────────────────────────────────────

local function log(level, msg)
    freeswitch.consoleLog(level, "[sound] " .. msg)
end

local function file_exists(path)
    local f = io.open(path, "r")
    if f then f:close(); return true end
    return false
end

local function extension(fname)
    return (fname or ""):lower():match("%.([^%.]+)$") or ""
end

local function convert_to_wav(src, dest)
    log("INFO", string.format("  konwersja: %s → %s", src, dest))
    local cmd = string.format('ffmpeg -y -i "%s" -ar 8000 -ac 1 -f wav "%s" 2>/dev/null', src, dest)
    if os.execute(cmd) == 0 then
        log("INFO", "  konwersja ffmpeg OK")
        return true
    end
    cmd = string.format('sox "%s" -r 8000 -c 1 "%s" 2>/dev/null', src, dest)
    if os.execute(cmd) == 0 then
        log("INFO", "  konwersja sox OK")
        return true
    end
    log("ERR", "  konwersja nieudana — brak ffmpeg i sox")
    return false
end

-- ── Główna funkcja ────────────────────────────────────────────────────────────

function M.resolve(sound_id)
    if not sound_id or tostring(sound_id) == "" then
        log("WARN", "resolve() wywołane z pustym sound_id")
        return ""
    end

    local sid = tostring(sound_id)
    log("INFO", "━━━ resolve sound_id=" .. sid .. " ━━━")
    log("INFO", "  ODOO_FILESTORE=" .. ODOO_FILESTORE)

    -- Pobierz rekord dźwięku + załącznik z ir_attachment
    local row = db.query_one(string.format([[
        SELECT
            s.id,
            s.fs_path,
            s.audio_fname,
            s.company_id,
            a.store_fname,
            (a.db_datas IS NOT NULL) AS has_db_datas
        FROM  freeswitch_sound s
        LEFT  JOIN ir_attachment a
               ON  a.res_model = 'freeswitch.sound'
               AND a.res_id    = s.id
               AND a.res_field = 'audio_data'
        WHERE s.id = %s
          AND s.active = true
        LIMIT 1
    ]], sid))

    if not row then
        log("WARN", "  Nie znaleziono rekordu freeswitch_sound id=" .. sid)
        return ""
    end

    log("INFO", string.format(
        "  rekord: fname=%s  fs_path=%s  store_fname=%s  has_db=%s",
        row.audio_fname or "NULL",
        row.fs_path     or "NULL",
        row.store_fname or "NULL",
        tostring(row.has_db_datas)))

    local fname      = row.audio_fname or ("sound_" .. sid .. ".wav")
    local ext        = extension(fname)
    local sounds_dir = get_sounds_dir(row.company_id or db.company_id)
    local dest_file  = sounds_dir .. "/" .. fname

    -- Cache hit — plik już skopiowany pod dest_file
    if file_exists(dest_file) then
        log("INFO", "  ✓ cache hit — zwracam: " .. dest_file)
        return dest_file
    end
    log("INFO", "  dest_file (cache)=" .. dest_file)
    log("INFO", "  brak cache, szukam źródła...")

    -- ── Strategia 1: ir_attachment.store_fname (Odoo filestore) ─────────────
    -- Główna ścieżka — plik wgrany przez Odoo do filestore.
    if row.store_fname and row.store_fname ~= "" then
        local full_path = ODOO_FILESTORE .. "/" .. row.store_fname
        log("INFO", "  [1] filestore: " .. full_path)
        local exists = file_exists(full_path)
        if not exists then
            -- io.open może nie mieć uprawnień — sprawdź przez shell
            local check = io.popen('test -f "' .. full_path .. '" && echo YES || echo NO')
            if check then
                local result = (check:read("*l") or ""):match("^%s*(.-)%s*$")
                check:close()
                log("INFO", "      shell test -f: " .. tostring(result))
                exists = (result == "YES")
            end
        end
        log("INFO", "      plik " .. (exists and "istnieje ✓" or "NIE istnieje ✗"))
        if exists then
            -- Pliki w filestore Odoo nie mają rozszerzenia — kopiujemy z właściwym ext.
            local cp_cmd = string.format('cp "%s" "%s"', full_path, dest_file)
            log("INFO", "      cp: " .. cp_cmd)
            local ok = os.execute(cp_cmd)
            log("INFO", "      cp result=" .. tostring(ok))
            if ok == 0 or ok == true then
                log("INFO", "      ✓ skopiowano: " .. dest_file)
                return dest_file
            else
                log("ERR", "      błąd cp — spróbuję konwersją")
                if convert_to_wav(full_path, dest_file) then
                    return dest_file
                end
            end
        else
            log("WARN", "      plik nie znaleziony w filestore: " .. full_path)
            log("WARN", "      ODOO_FILESTORE=" .. ODOO_FILESTORE)
        end
    else
        log("INFO", "  [1] store_fname pusty — brak pliku w filestore")
    end

    -- ── Strategia 2: db_datas — plik binarny bezpośrednio w bazie ────────────
    if row.has_db_datas == "t" or row.has_db_datas == true then
        log("INFO", "  [2] pobieranie db_datas z bazy...")
        local data_row = db.query_one(string.format([[
            SELECT encode(db_datas, 'escape') AS raw
            FROM   ir_attachment
            WHERE  res_model = 'freeswitch.sound'
              AND  res_id    = %s
              AND  res_field = 'audio_data'
            LIMIT 1
        ]], sid))
        if data_row and data_row.raw and data_row.raw ~= "" then
            log("INFO", "      zapisuję do: " .. dest_file)
            local f = io.open(dest_file, "wb")
            if f then
                f:write(data_row.raw)
                f:close()
                log("INFO", "      ✓ zapisano: " .. dest_file)
                return dest_file
            else
                log("ERR", "      nie można zapisać: " .. dest_file)
            end
        else
            log("WARN", "      db_datas puste")
        end
    else
        log("INFO", "  [2] brak db_datas")
    end

    -- ── Strategia 3: fs_path — fallback na plik bezpośrednio na dysku FS ─────
    -- Używane tylko gdy brak załącznika w Odoo (stare rekordy / pliki systemowe).
    if row.fs_path and row.fs_path ~= "" then
        log("INFO", "  [3] fallback fs_path: " .. row.fs_path)
        local exists = file_exists(row.fs_path)
        if not exists then
            local check = io.popen('test -f "' .. row.fs_path .. '" && echo YES || echo NO')
            if check then
                local result = (check:read("*l") or ""):match("^%s*(.-)%s*$")
                check:close()
                log("INFO", "      shell test -f: " .. tostring(result))
                exists = (result == "YES")
            end
        end
        if exists then
            log("INFO", "      ✓ zwracam fs_path bezpośrednio: " .. row.fs_path)
            return row.fs_path
        else
            log("WARN", "      fs_path nie istnieje: " .. row.fs_path)
        end
    else
        log("INFO", "  [3] fs_path pusty")
    end

    log("ERR", "  ✗ Nie udało się uzyskać pliku dla sound_id=" .. sid)
    return ""
end

-- Wyczyść cache dla dźwięku (np. po zmianie pliku w Odoo)
function M.invalidate(sound_id)
    -- Usuń plik z katalogu dźwięków (wymusi ponowne skopiowanie z filestore)
    local row = db.query_one("SELECT company_id, audio_fname FROM freeswitch_sound WHERE id = " .. tostring(sound_id) .. " LIMIT 1")
    if row then
        local sounds_dir = get_sounds_dir(row.company_id or db.company_id)
        local fname = row.audio_fname or ("sound_" .. tostring(sound_id) .. ".wav")
        local path = sounds_dir .. "/" .. fname
        os.remove(path)
        log("INFO", "usunięto: " .. path)
    end
end

return M
