-- =============================================================================
-- router.lua
-- Gwny router pocze przychodzcych.
--
-- Odpowiedzialno:
--   1. Odczyt trasy DID z bazy Odoo (reguy czasowe + wita + normalna)
--   2. Przekazanie do moduu akcji (action_user / action_fifo / action_callcenter
--      / action_playback / ivr)
--
-- Wywoanie z dialplanu:
--   <action application="lua" data="router.lua"/>
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db  = require("odoo_db")
local cfg = db.company_config()

--  Logowanie 

local uuid   = session:getVariable("uuid")   or "no-uuid"
local did    = session:getVariable("destination_number") or ""
local caller = session:getVariable("caller_id_number")   or "unknown"

local function log(level, msg)
    freeswitch.consoleLog(level, string.format("[router] [%s] %s", uuid, msg))
end

log("INFO", "")
log("INFO", string.format("POCZENIE  caller=%s  DID=%s", caller, did))
log("INFO", "")

--  Reguy czasowe 

local function within_time_rules(route_id)
    local rules = db.query_all(string.format([[
        SELECT day_mon, day_tue, day_wed, day_thu, day_fri, day_sat, day_sun,
               time_start, time_end, name
        FROM   freeswitch_route_time_rule
        WHERE  route_id = %d
        ORDER  BY sequence, id
    ]], route_id))

    if #rules == 0 then
        log("INFO", "  reguy czasowe: brak  zawsze aktywna")
        return true
    end

    local t          = os.date("*t")
    local cur        = t.hour * 60 + t.min
    local day_cols   = {"day_sun","day_mon","day_tue","day_wed","day_thu","day_fri","day_sat"}
    local day_names  = {"nd","pn","wt","r","cz","pt","sob"}
    local today_col  = day_cols[t.wday]
    local today_name = day_names[t.wday]

    log("INFO", string.format("  reguy czasowe: %s %02d:%02d  regu=%d",
        today_name, t.hour, t.min, #rules))

    local function tmin(ts)
        local h, m = (ts or "00:00"):match("^(%d+):(%d+)")
        return (tonumber(h) or 0) * 60 + (tonumber(m) or 0)
    end

    for _, r in ipairs(rules) do
        local day_ok = (r[today_col] == "t" or r[today_col] == true)
        local t_ok   = (cur >= tmin(r.time_start) and cur <= tmin(r.time_end))
        local match  = day_ok and t_ok
        log("INFO", string.format("    '%s': dzie=%s czas=%s(%s-%s)  %s",
            r.name or "?",
            day_ok and "TAK" or "NIE",
            t_ok   and "TAK" or "NIE",
            r.time_start or "?", r.time_end or "?",
            match and "PASUJE " or "nie pasuje"))
        if match then return true end
    end
    return false
end

--  wita 

local function is_holiday(country_code)
    local today = os.date("%Y-%m-%d")
    local row = db.query_one(string.format([[
        SELECT name FROM freeswitch_public_holiday
        WHERE  date = %s
          AND  (country_code = %s OR country_code IS NULL)
          AND  active = true
        LIMIT  1
    ]], db.esc(today), db.esc(country_code or "PL")))
    if row then
        log("INFO", "  wito: " .. (row.name or ""))
        return true
    end
    return false
end

--  Pobierz tras 

log("INFO", "KROK 1: trasa DID...")

local route = db.query_one(string.format([[
    SELECT
        r.id,
        r.description,
        r.route_type,              r.route_target,
        r.route_sound_id,          r.route_sound_after,
        r.route_sound_after_pstn,
        r.use_time_rules,
        r.fallback_type,           r.fallback_target,
        r.fallback_sound_id,       r.fallback_sound_after,
        r.fallback_sound_after_pstn,
        r.use_holidays,
        r.holiday_country_code,
        r.holiday_action_type,     r.holiday_action_target,
        r.holiday_sound_id
    FROM  freeswitch_route r
    WHERE r.name       = %s
      AND r.company_id = %d
      AND r.active     = true
    LIMIT 1
]], db.esc(did), cfg.company_id))

if not route then
    log("WARN", string.format("BRAK TRASY  DID=%s  hangup", did))
    session:setVariable("odoo_route_type", "hangup")
    return
end

log("INFO", string.format("  id=%s  '%s'", route.id, route.description or ""))
log("INFO", string.format("  normalna:  %-12s  %s", route.route_type or "?",   route.route_target or ""))
log("INFO", string.format("  fallback:  %-12s  %s", route.fallback_type or "-", route.fallback_target or "-"))
log("INFO", string.format("  flagi: time_rules=%s  holidays=%s  country=%s",
    tostring(route.use_time_rules), tostring(route.use_holidays),
    route.holiday_country_code or "-"))

--  Wybierz aktywn tras 

log("INFO", "KROK 2: wybr trasy...")

local rtype, rtarget, rsound_id, rafter, rafter_pstn
local reason = "normalna"

-- 1. wita (najwyszy priorytet)
if route.use_holidays == "t" or route.use_holidays == true then
    if is_holiday(route.holiday_country_code) then
        rtype       = route.holiday_action_type
        rtarget     = route.holiday_action_target
        rsound_id   = route.holiday_sound_id
        rafter      = "hangup"
        rafter_pstn = ""
        reason      = "DZIE WOLNY"
    end
end

-- 2. Reguy czasowe
if not rtype and (route.use_time_rules == "t" or route.use_time_rules == true) then
    if not within_time_rules(tonumber(route.id)) then
        rtype       = route.fallback_type
        rtarget     = route.fallback_target
        rsound_id   = route.fallback_sound_id
        rafter      = route.fallback_sound_after or "hangup"
        rafter_pstn = route.fallback_sound_after_pstn or ""
        reason      = "FALLBACK (poza godzinami)"
    end
end

-- 3. Normalna
if not rtype then
    rtype       = route.route_type
    rtarget     = route.route_target
    rsound_id   = route.route_sound_id
    rafter      = route.route_sound_after or "hangup"
    rafter_pstn = route.route_sound_after_pstn or ""
end

rtype   = rtype   or "hangup"
rtarget = rtarget or ""

log("INFO", "")
log("INFO", string.format("ROUTING: %s", reason))
log("INFO", string.format("  typ = %-12s  cel = %s", rtype, rtarget))
log("INFO", "")

-- Zmienne dla cdr_writer.lua
session:setVariable("odoo_route_type",   rtype)
session:setVariable("odoo_route_target", rtarget)
session:setVariable("odoo_ivr_name",     rtype == "ivr" and rtarget or "")

--  Globalne nagrywanie wszystkich pocze 
-- Nagrywanie startuje PRZED akcj  nagrywany jest cay przebieg poczenia
-- (IVR + kolejka + rozmowa z agentem).
-- Plik: /nagrania/YYYY-MM-DD/<uuid>.wav
-- Zmienne FS: recording_file (do CDR), recording_started

log("INFO", "KROK 3: nagrywanie globalne...")

local rec_dir      = "/nagrania"
local rec_date_dir = os.date("%Y-%m-%d")
local rec_path     = string.format("%s/%s/%s.wav", rec_dir, rec_date_dir, uuid)

-- Utwrz katalog jeli nie istnieje (przez os.execute  FS musi mie uprawnienia)
os.execute("mkdir -p " .. rec_dir .. "/" .. rec_date_dir)

session:setVariable("recording_file",    rec_path)
session:setVariable("recording_started", "true")

-- record_session nagrywa na kanale callera od razu, asynchronicznie
-- (nie blokuje  nagrywanie trwa do rozczenia)
session:execute("record_session", rec_path)
log("INFO", "  nagrywanie START: " .. rec_path)

--  Dispatcher 

log("INFO", "KROK 4: wykonuj akcj...")

if rtype == "ivr" then
    session:execute("answer")
    require("ivr").run(rtarget)

elseif rtype == "user" then
    require("action_user").run(rtarget, log)

elseif rtype == "fifo" then
    require("action_fifo").run(rtarget, log)

elseif rtype == "callcenter" then
    require("action_callcenter").run(rtarget, log)

elseif rtype == "pstn" then
    require("action_pstn").run(rtarget, log)

elseif rtype == "playback" then
    require("action_playback").run(rsound_id, rafter, rafter_pstn, route.id, log)

else
    log("WARN", "AKCJA: HANGUP (typ=" .. rtype .. ")")
end

log("INFO", string.format("KONIEC  caller=%s  DID=%s  typ=%s  cel=%s",
    caller, did, rtype, rtarget))
