-- =============================================================================
-- fs_db.lua
-- Połączenie z bazą PostgreSQL FreeSWITCH (mod_callcenter).
-- Osobna baza od Odoo — tabele: queues, agents, tiers, members.
--
-- Użycie:
--   local fsdb = require("fs_db")
--   local row  = fsdb.query_one("SELECT status FROM agents WHERE name = 'agent-jan'")
--   fsdb.execute("UPDATE agents SET status = 'Available' WHERE name = 'agent-jan'")
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local M = {}

-- ── Konfiguracja połączenia z bazą FreeSWITCH ────────────────────────────────
M.pg = {
    host     = "localhost",
    port     = "5432",
    dbname   = "freeswitch",
    user     = "fsuser",
    password = "silnehaslo",
}

M.debug = false

-- ── Wewnętrzne ────────────────────────────────────────────────────────────────
local _env  = nil
local _conn = nil

local function get_conn()
    -- Sprawdź czy połączenie jest jeszcze żywe (luasql nie ma ping, więc próbujemy)
    if _conn then
        local ok, cur = pcall(function() return _conn:execute("SELECT 1") end)
        if ok and cur then
            cur:close()
            return _conn
        end
        -- Połączenie martwe — wyczyść i otwórz nowe
        pcall(function() _conn:close() end)
        _conn = nil
    end

    if not _env then
        local luasql = require("luasql.postgres")
        _env = luasql.postgres()
    end

    local conn, err = _env:connect(
        "dbname="    .. M.pg.dbname  ..
        " host="     .. M.pg.host    ..
        " port="     .. M.pg.port    ..
        " user="     .. M.pg.user    ..
        " password=" .. M.pg.password
    )
    if not conn then
        error("[fs_db] Błąd połączenia z bazą FreeSWITCH: " .. tostring(err))
    end
    _conn = conn
    return conn
end

-- ── Ucieczka apostrofów ───────────────────────────────────────────────────────
function M.esc(s)
    if s == nil then return "NULL" end
    return "'" .. tostring(s):gsub("'", "''") .. "'"
end

-- ── SELECT — pierwszy wiersz jako {kolumna=wartość} lub nil ──────────────────
function M.query_one(sql)
    if M.debug then freeswitch.consoleLog("DEBUG", "[fs_db] " .. sql .. "\n") end
    local ok, conn = pcall(get_conn)
    if not ok then
        freeswitch.consoleLog("ERR", "[fs_db] Brak połączenia: " .. tostring(conn) .. "\n")
        return nil
    end
    local cur, err = conn:execute(sql)
    if not cur then
        freeswitch.consoleLog("ERR", "[fs_db] Błąd zapytania: " .. tostring(err) .. " | SQL: " .. sql .. "\n")
        return nil
    end
    local row = cur:fetch({}, "a")
    cur:close()
    return row
end

-- ── SELECT — wszystkie wiersze jako tablica ───────────────────────────────────
function M.query_all(sql)
    if M.debug then freeswitch.consoleLog("DEBUG", "[fs_db] " .. sql .. "\n") end
    local ok, conn = pcall(get_conn)
    if not ok then
        freeswitch.consoleLog("ERR", "[fs_db] Brak połączenia: " .. tostring(conn) .. "\n")
        return {}
    end
    local cur, err = conn:execute(sql)
    if not cur then
        freeswitch.consoleLog("ERR", "[fs_db] Błąd zapytania: " .. tostring(err) .. " | SQL: " .. sql .. "\n")
        return {}
    end
    local rows = {}
    local row = cur:fetch({}, "a")
    while row do
        table.insert(rows, row)
        row = cur:fetch({}, "a")
    end
    cur:close()
    return rows
end

-- ── INSERT / UPDATE / DELETE ──────────────────────────────────────────────────
function M.execute(sql)
    if M.debug then freeswitch.consoleLog("DEBUG", "[fs_db] " .. sql .. "\n") end
    local ok, conn = pcall(get_conn)
    if not ok then
        freeswitch.consoleLog("ERR", "[fs_db] Brak połączenia: " .. tostring(conn) .. "\n")
        return false
    end
    local res, err = conn:execute(sql)
    if not res then
        freeswitch.consoleLog("ERR", "[fs_db] Błąd wykonania: " .. tostring(err) .. " | SQL: " .. sql .. "\n")
        return false
    end
    return true
end

-- ── Helpery dla mod_callcenter ────────────────────────────────────────────────

-- Pobierz status i stan agenta
function M.get_agent(agent_name)
    return M.query_one(string.format(
        "SELECT name, type, contact, status, state, wrap_up_time FROM agents WHERE name = %s LIMIT 1",
        M.esc(agent_name)
    ))
end

-- Ustaw status agenta
function M.set_agent_status(agent_name, status)
    return M.execute(string.format(
        "UPDATE agents SET status = %s WHERE name = %s",
        M.esc(status), M.esc(agent_name)
    ))
end

-- Pobierz tiery kolejki
function M.get_queue_tiers(queue_name)
    return M.query_all(string.format(
        "SELECT agent, level, position, state FROM tiers WHERE queue = %s ORDER BY level, position",
        M.esc(queue_name)
    ))
end

-- Pobierz oczekujących w kolejce
function M.get_queue_members(queue_name)
    return M.query_all(string.format([[
        SELECT uuid, cid_number, cid_name, state,
               joined_epoch, serving_agent
        FROM   members
        WHERE  queue = %s
          AND  state NOT IN ('Answered', 'Abandoned')
        ORDER  BY joined_epoch
    ]], M.esc(queue_name)))
end

return M
