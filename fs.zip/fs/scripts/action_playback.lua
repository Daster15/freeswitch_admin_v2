-- =============================================================================
-- action_playback.lua
-- Odtwarzanie pliku audio + akcja po odtworzeniu.
--
-- Użycie:
--   require("action_playback").run(sound_id, after, after_pstn, route_id, log_fn)
--
-- sound_id   — ID rekordu freeswitch_sound (rozwiązywany przez sound.lua)
-- after      — akcja po odtworzeniu: hangup/repeat/ivr/fifo/callcenter/user/pstn
-- after_pstn — numer PSTN gdy after="pstn"
-- route_id   — ID trasy freeswitch_route (do odczytu celu after_*)
-- =============================================================================
local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db  = require("odoo_db")
local cfg = db.company_config()

local M = {}

-- ── Helper: pobierz cel akcji after z trasy ───────────────────────────────────
-- route_id może być nil gdy wywołanie z IVR (wtedy after_target przekazany wprost)

local function get_after_target(route_id, col_name)
    if not route_id or tonumber(route_id) == 0 then return nil end
    local row = db.query_one(string.format([[
        SELECT t.name AS target_name
        FROM   freeswitch_route r
        JOIN   %s t ON t.id = r.%s
        WHERE  r.id = %d
        LIMIT  1
    ]], col_name:match("^(.-)_id$") or col_name, col_name, tonumber(route_id)))
    return row and row.target_name or nil
end

-- ── Główna funkcja ────────────────────────────────────────────────────────────

function M.run(sound_id, after, after_pstn, route_id, log)
    log = log or function(l, m) freeswitch.consoleLog(l, "[action_playback] " .. m) end

    -- Rozwiąż ścieżkę pliku przez sound.lua (filestore Odoo → db_datas → fs_path)
    local sound = require("sound")
    local sf    = sound.resolve(sound_id)

    log("INFO", string.format("AKCJA: PLAYBACK  sound_id=%s  plik=%s",
        tostring(sound_id), sf))

    if sf == "" then
        log("WARN", "  brak pliku audio → hangup")
        return
    end

    session:execute("answer")
    session:execute("playback", sf)

    -- ── Akcja po odtworzeniu ──────────────────────────────────────────────────
    after      = after      or "hangup"
    after_pstn = after_pstn or ""
    log("INFO", string.format("  po odtworzeniu: after=%s  route_id=%s",
        after, tostring(route_id)))

    if after == "hangup" or after == "" then
        return

    elseif after == "repeat" then
        log("INFO", "  → powtórz")
        local sf2 = sound.resolve(sound_id)
        if sf2 ~= "" then session:execute("playback", sf2) end

    elseif after == "ivr" then
        local target = nil  -- after_pstn NIE jest celem IVR
        if not target and route_id then
            local row = db.query_one(string.format([[
                SELECT fi.name
                FROM   freeswitch_route r
                JOIN   freeswitch_ivr fi
                       ON fi.id = COALESCE(r.route_sound_after_ivr_id,
                                           r.fallback_sound_after_ivr_id)
                WHERE  r.id = %d
                LIMIT  1
            ]], tonumber(route_id)))
            target = row and row.name or nil
        end
        if target then
            log("INFO", "  → IVR: " .. target)
            session:setVariable("odoo_ivr_name", target)
            require("ivr").run(target)
        else
            log("WARN", "  → IVR: brak celu — hangup")
        end

    elseif after == "fifo" then
        local target = nil  -- after_pstn NIE jest celem FIFO
        if not target and route_id then
            local row = db.query_one(string.format([[
                SELECT ff.name
                FROM   freeswitch_route r
                JOIN   freeswitch_fifo ff
                       ON ff.id = COALESCE(r.route_sound_after_fifo_id,
                                           r.fallback_sound_after_fifo_id)
                WHERE  r.id = %d
                LIMIT  1
            ]], tonumber(route_id)))
            target = row and row.name or nil
        end
        if target then
            log("INFO", "  → FIFO: " .. target)
            session:setVariable("odoo_route_type",   "fifo")
            session:setVariable("odoo_route_target", target)
            session:execute("fifo",
                target .. "@" .. cfg.sip_domain ..
                " in /usr/share/freeswitch/sounds/en/us/callie/ivr/8000/ivr-hold_connect_call.wav")
        else
            log("WARN", "  → FIFO: brak celu — hangup")
        end

    elseif after == "callcenter" then
        local target = nil  -- after_pstn NIE jest celem CC
        if not target and route_id then
            local row = db.query_one(string.format([[
                SELECT fq.name
                FROM   freeswitch_route r
                JOIN   freeswitch_cc_queue fq
                       ON fq.id = COALESCE(r.route_sound_after_cc_id,
                                           r.fallback_sound_after_cc_id)
                WHERE  r.id = %d
                LIMIT  1
            ]], tonumber(route_id)))
            target = row and row.name or nil
        end
        if target then
            log("INFO", "  → CallCenter: " .. target)
            session:setVariable("odoo_route_type",   "callcenter")
            session:setVariable("odoo_route_target", target)
            session:execute("callcenter", target .. "@" .. cfg.sip_domain)
        else
            log("WARN", "  → CallCenter: brak celu — hangup")
        end

    elseif after == "user" then
        local target = nil  -- after_pstn NIE jest celem User
        if not target and route_id then
            local row = db.query_one(string.format([[
                SELECT su.name
                FROM   freeswitch_route r
                JOIN   freeswitch_sip_user su
                       ON su.id = COALESCE(r.route_sound_after_user_id,
                                           r.fallback_sound_after_user_id)
                WHERE  r.id = %d
                LIMIT  1
            ]], tonumber(route_id)))
            target = row and row.name or nil
        end
        if target then
            log("INFO", "  → Użytkownik SIP: " .. target)
            require("action_user").run(target, log)
        else
            log("WARN", "  → User: brak celu — hangup")
        end

    elseif after == "pstn" then
        local target = after_pstn ~= "" and after_pstn or nil
        if not target and route_id then
            local row = db.query_one(string.format([[
                SELECT COALESCE(r.route_sound_after_pstn,
                                r.fallback_sound_after_pstn) AS pstn_num
                FROM   freeswitch_route r
                WHERE  r.id = %d
                LIMIT  1
            ]], tonumber(route_id)))
            target = row and row.pstn_num or nil
        end
        if target and target ~= "" then
            log("INFO", "  → PSTN: " .. target)
            require("action_pstn").run(target, log)
        else
            log("WARN", "  → PSTN: brak numeru — hangup")
        end
    end
end

return M
