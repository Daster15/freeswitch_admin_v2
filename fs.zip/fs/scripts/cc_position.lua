-- =============================================================================
-- cc_position.lua
-- Periodic queue position announcement for CallCenter.
--
-- Called by sched_api from action_callcenter.lua every N seconds:
--   sched_api +20 <uuid> lua cc_position.lua <queue_name> <caller_uuid>
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local queue_name  = argv[1] or ""
local caller_uuid = argv[2] or ""

-- Ten log ZAWSZE pojawia sie na konsoli FS gdy skrypt sie uruchamia
freeswitch.consoleLog("NOTICE", string.format(
    "[cc_position] START queue=%s uuid=%s\n", queue_name, caller_uuid))

if queue_name == "" or caller_uuid == "" then
    freeswitch.consoleLog("WARN", "[cc_position] missing argv queue=" .. queue_name
                                   .. " uuid=" .. caller_uuid .. "\n")
    return
end

local function log(level, msg)
    freeswitch.consoleLog(level, string.format("[cc_pos:%s] %s\n", queue_name, msg))
end

local api = freeswitch.API()

-- Check if channel still exists
local uuid_exists = api:execute("uuid_exists", caller_uuid) or "false"
uuid_exists = uuid_exists:match("^%s*(.-)%s*$")
if uuid_exists ~= "true" then
    log("INFO", "channel " .. caller_uuid .. " gone -- skip")
    return
end

-- Check if already answered (cc_cause set = left queue)
local cc_cause = api:execute("uuid_getvar", caller_uuid .. " cc_cause") or ""
cc_cause = cc_cause:match("^%s*(.-)%s*$")
-- FreeSWITCH zwraca "_undef_" gdy zmienna nie istnieje w sesji
if cc_cause ~= "" and cc_cause ~= "false" and cc_cause ~= "_undef_" then
    log("INFO", "cc_cause=" .. cc_cause .. " -- call handled, skip")
    return
end

-- Get sip domain
local db  = require("odoo_db")
local cfg = db.company_config()
local qkey = queue_name .. "@" .. cfg.sip_domain

-- Get position in queue
local reply    = api:execute("callcenter_config", "queue list members " .. qkey) or ""
local position = 0
local total    = 0

-- Format odpowiedzi (pipe-separated):
-- queue|instance_id|uuid|session_uuid|cid_number|cid_name|...|state|score
-- UUID klienta jest w kolumnie 4 (session_uuid), nie w kolumnie 1!
for line in reply:gmatch("[^\n]+") do
    -- Pomin naglowek, linie +OK i puste
    if line:match("^queue|") or line:match("^%+OK") or line:match("^%s*$") then
        goto next_line
    end

    -- Wytnij kolumny przez pipe
    local cols = {}
    for col in (line .. "|"):gmatch("([^|]*)|") do
        table.insert(cols, col)
    end

    -- session_uuid to kolumna 4 (index 4)
    local session_uuid = cols[4] or ""
    session_uuid = session_uuid:match("^%s*(.-)%s*$")

    if session_uuid ~= "" then
        total = total + 1
        log("DEBUG", string.format("  member %d: session_uuid=%s state=%s",
            total, session_uuid, cols[16] or "?"))
        if session_uuid == caller_uuid then
            position = total
        end
    end
    ::next_line::
end

log("INFO", string.format("position=%d/%d caller=%s", position, total, caller_uuid))

-- Play announcement via uuid_broadcast
-- UWAZNE: uuid_broadcast wymaga ze kanal jest w stanie "answered" i nie jest bridged.
-- W mod_callcenter kanal callera jest answered ale bridged z kolejka (hold music),
-- wiec uuid_broadcast z "aleg" powinien dzialac i przerywac MOH.
local sounds_base = "/usr/local/freeswitch/sounds/en/us/callie"
local digits_dir  = sounds_base .. "/digits/8000"

local function file_exists(path)
    local f = io.open(path, "r")
    if f then f:close(); return true end
    return false
end

local function broadcast(file)
    -- Loguj ZAWSZE probe odtworzenia (widoczne na konsoli FS)
    log("NOTICE", ">>> BROADCAST: " .. file)

    -- Sprawdz czy plik istnieje przed broadcastem
    if not file_exists(file) then
        log("WARN", "    PLIK NIE ISTNIEJE: " .. file)
        -- Sprobuj znalezc alternatywna sciezke (np. /var/lib/freeswitch/sounds/)
        local alt = file:gsub("/usr/share/freeswitch", "/var/lib/freeswitch")
        if file_exists(alt) then
            log("NOTICE", "    Uzywam alternatywnej sciezki: " .. alt)
            file = alt
        else
            log("WARN", "    Rowniez nie znaleziono: " .. alt .. " -- pomijam")
            return
        end
    end

    local r = api:execute("uuid_broadcast", caller_uuid .. " " .. file .. " aleg")
    r = (r or ""):match("^%s*(.-)%s*$")
    log("NOTICE", "    uuid_broadcast reply: " .. tostring(r))

    -- Krotkie czekanie zeby dzwiek zdazyl sie odtworzyc przed nastepnym
    api:execute("sleep", "500")
end

-- Odtwarza liczbe uzywajac plikow z digits/8000.
-- Dostepne pliki: 0-20, 30, 40, 50, 60, 70, 80, 90 (pelne), reszta = dziesiatki + jednostki
local function play_number(n)
    if n <= 0 then return end

    if n <= 20 then
        -- 1..20 — bezposredni plik
        broadcast(digits_dir .. "/" .. tostring(n) .. ".wav")
    elseif n < 100 then
        -- 21..99 — dziesiatka + jednostka
        local tens  = math.floor(n / 10) * 10
        local units = n % 10
        broadcast(digits_dir .. "/" .. tostring(tens) .. ".wav")
        if units > 0 then
            broadcast(digits_dir .. "/" .. tostring(units) .. ".wav")
        end
    elseif n < 1000 then
        -- 100..999 — setki + reszta
        local hundreds = math.floor(n / 100)
        local rest     = n % 100
        broadcast(digits_dir .. "/" .. tostring(hundreds) .. ".wav")
        broadcast(digits_dir .. "/hundred.wav")
        if rest > 0 then play_number(rest) end
    else
        -- Powyzej 999 — zagraj tylko samą liczbe jako tys (edge case)
        broadcast(digits_dir .. "/thousand.wav")
    end
end

log("NOTICE", string.format("=== CC_POSITION ANNOUNCEMENT: position=%d/%d caller=%s ===",
    position, total, caller_uuid))

if position == 0 then
    log("WARN", "Klient NIE ZNALEZIONY w kolejce -- brak ogłoszenia")
    log("WARN", "  queue=" .. qkey .. "  total_members=" .. total)
else
    -- ── Wylicz EWT z historii CDR ─────────────────────────────────────────
    local avg_talk    = 0
    local agents_avail = 0
    local ewt_min     = 0

    -- Krok 1: sredni czas rozmowy z ostatnich 50 polaczen tej kolejki
    log("NOTICE", "  EWT krok 1: pobieranie avg_talk z CDR...")
    local cdr_row, cdr_err = nil, nil
    local ok1 = pcall(function()
        cdr_row = db.query_one(string.format([[
            SELECT COALESCE(AVG(billsec), 0)::int AS avg_talk,
                   COUNT(*)::int                   AS cnt
            FROM (
                SELECT billsec
                FROM   freeswitch_cdr
                WHERE  queue_name = %s
                  AND  status     = 'completed'
                  AND  billsec    > 0
                ORDER  BY start_time DESC
                LIMIT  50
            ) sub
        ]], db.esc(queue_name)))
    end)

    if not ok1 then
        log("WARN", "  EWT krok 1 BLAD: pcall zlapal wyjatek -- sprawdz polaczenie z DB")
    elseif not cdr_row then
        log("WARN", "  EWT krok 1: brak wynikow z CDR (nowa kolejka?)")
    else
        avg_talk = tonumber(cdr_row.avg_talk) or 0
        log("NOTICE", string.format("  EWT krok 1 OK: avg_talk=%ds z %s polaczen",
            avg_talk, tostring(cdr_row.cnt)))
    end

    -- Krok 2: liczba dostepnych agentow z Odoo
    log("NOTICE", "  EWT krok 2: pobieranie liczby agentow...")
    local ok2 = pcall(function()
        local arow = db.query_one(string.format([[
            SELECT COUNT(*)::int AS cnt
            FROM   freeswitch_cc_agent a
            JOIN   freeswitch_cc_tier  t ON t.agent_id = a.id
            JOIN   freeswitch_cc_queue q ON q.id = t.queue_id
            WHERE  q.name       = %s
              AND  q.company_id = %d
              AND  a.status     = 'Available'
              AND  a.active     = true
        ]], db.esc(queue_name), cfg.company_id))
        if arow then
            agents_avail = tonumber(arow.cnt) or 0
        end
    end)

    if not ok2 then
        log("WARN", "  EWT krok 2 BLAD: pcall zlapal wyjatek")
        agents_avail = 1  -- fallback
    else
        log("NOTICE", string.format("  EWT krok 2 OK: agents_avail=%d", agents_avail))
    end

    -- Krok 3: wylicz EWT
    if avg_talk > 0 and position > 1 then
        local divisor = math.max(agents_avail, 1)
        local ewt_sec = math.ceil((position - 1) * avg_talk / divisor)
        ewt_min = math.ceil(ewt_sec / 60)
        log("NOTICE", string.format(
            "  EWT krok 3: (pos=%d-1)*%ds/%d = %ds = %d min",
            position, avg_talk, divisor, ewt_sec, ewt_min))
    else
        log("NOTICE", string.format(
            "  EWT krok 3: brak EWT (avg_talk=%d position=%d)", avg_talk, position))
    end

    -- ── Odtwórz ogłoszenie ────────────────────────────────────────────────
    log("NOTICE", string.format("  ODTWARZAM: pozycja=%d  EWT=%d min", position, ewt_min))

    play_number(position)

    if ewt_min > 0 then
        api:execute("sleep", "300")
        broadcast(digits_dir .. "/dot.wav")
        play_number(ewt_min)
    end
end

-- Schedule next announcement if channel still alive and still waiting
local still_alive = api:execute("uuid_exists", caller_uuid) or "false"
still_alive = still_alive:match("^%s*(.-)%s*$")

local interval_str = api:execute("uuid_getvar", caller_uuid .. " cc_announce_interval") or "20"
interval_str = interval_str:match("^%s*(.-)%s*$")
local interval = tonumber(interval_str) or 20

if still_alive == "true" and position > 0 then
    local sched_cmd = string.format("+%d %s lua cc_position.lua %s %s",
        interval, caller_uuid, queue_name, caller_uuid)
    local sched_reply = api:execute("sched_api", sched_cmd) or ""
    log("INFO", string.format("next in %ds sched=%s", interval, sched_reply))
else
    log("INFO", "no next announcement (channel gone or not in queue)")
end
