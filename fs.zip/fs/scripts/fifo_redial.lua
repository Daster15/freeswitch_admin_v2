-- =============================================================================
-- fifo_redial.lua
-- Ponowne dzwonienie do agentow FIFO gdy pierwszy attempt nie zostal odebrany.
--
-- Wywolywany przez sched_api z action_fifo.lua:
--   sched_api +<delay> <caller_uuid> lua fifo_redial.lua <queue_name> <caller_uuid>
--
-- Sprawdza czy caller nadal jest w kolejce i ponownie dzwoni do agentow.
-- Planuje kolejne ponowienie jesli nadal nikt nie odebral.
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local queue_name  = argv[1] or ""
local caller_uuid = argv[2] or ""

freeswitch.consoleLog("NOTICE", string.format(
    "[fifo_redial] START queue=%s caller_uuid=%s\n", queue_name, caller_uuid))

if queue_name == "" or caller_uuid == "" then
    freeswitch.consoleLog("WARN", "[fifo_redial] brak argumentow -- pomijam\n")
    return
end

local api = freeswitch.API()

-- Sprawdz czy caller nadal istnieje
local exists = (api:execute("uuid_exists", caller_uuid) or ""):match("^%s*(.-)%s*$")
if exists ~= "true" then
    freeswitch.consoleLog("NOTICE",
        "[fifo_redial] caller gone -- brak ponownego dzwonienia\n")
    return
end

-- Sprawdz czy caller nadal czeka (fifo_status = WAITING lub nie ustawione)
local fifo_status = (api:execute("uuid_getvar", caller_uuid .. " fifo_status") or "")
    :match("^%s*(.-)%s*$")

freeswitch.consoleLog("NOTICE", string.format(
    "[fifo_redial] fifo_status=%q\n", fifo_status))

if fifo_status == "DONE" or fifo_status == "answered" or fifo_status == "ABORTED" then
    freeswitch.consoleLog("NOTICE",
        "[fifo_redial] caller juz obsluzony (status=" .. fifo_status .. ") -- stop\n")
    return
end

-- Pobierz timeout agenta z sesji callera
local agent_timeout_str = (api:execute("uuid_getvar",
    caller_uuid .. " odoo_fifo_agent_timeout") or ""):match("^%s*(.-)%s*$")
local agent_timeout = tonumber(agent_timeout_str) or 30

-- Pobierz konfiguracje z Odoo
local db  = require("odoo_db")
local cfg = db.company_config()
local sound = require("sound")

local function log(level, msg)
    freeswitch.consoleLog(level, string.format("[fifo_redial:%s] %s\n", queue_name, msg))
end

-- Pobierz agentow kolejki
local agents = db.query_all(string.format([[
    SELECT
        a.extension,
        a.contact,
        a.member_wait,
        a.pop_order,
        a.group_confirm_key,
        a.wrapup_key,
        COALESCE(NULLIF(a.call_timeout, 0), ca.call_timeout, 30) AS call_timeout,
        ca.status,
        ca.name AS agent_name,
        COALESCE(sgc.fs_path, sgc.audio_fname, '') AS group_confirm_file,
        COALESCE(swu.fs_path, swu.audio_fname, '') AS wrapup_sound,
        COALESCE(
            (SELECT d.mobile_number FROM freeswitch_sip_device d
             JOIN fifo_agent_sip_device_rel r ON r.device_id = d.id
             WHERE r.fifo_agent_id = a.id AND d.mobile_number IS NOT NULL
               AND d.mobile_number <> '' AND d.active = true
             ORDER BY d.sequence LIMIT 1),
            (SELECT d.mobile_number FROM freeswitch_sip_device d
             WHERE d.user_id = su.id AND d.mobile_number IS NOT NULL
               AND d.mobile_number <> '' AND d.active = true
             ORDER BY d.sequence LIMIT 1)
        ) AS mobile_number,
        COALESCE(
            (SELECT d.mobile_gateway FROM freeswitch_sip_device d
             JOIN fifo_agent_sip_device_rel r ON r.device_id = d.id
             WHERE r.fifo_agent_id = a.id AND d.mobile_number IS NOT NULL
               AND d.mobile_number <> '' AND d.active = true
             ORDER BY d.sequence LIMIT 1),
            (SELECT d.mobile_gateway FROM freeswitch_sip_device d
             WHERE d.user_id = su.id AND d.mobile_number IS NOT NULL
               AND d.mobile_number <> '' AND d.active = true
             ORDER BY d.sequence LIMIT 1)
        ) AS mobile_gateway
    FROM  freeswitch_fifo_agent a
    LEFT  JOIN freeswitch_fifo       f   ON f.id  = a.fifo_id
    LEFT  JOIN freeswitch_cc_agent   ca  ON ca.id = a.cc_agent_id
    LEFT  JOIN freeswitch_sip_user   su  ON su.id = ca.sip_user_id
    LEFT  JOIN freeswitch_sound      sgc ON sgc.id = a.group_confirm_file
    LEFT  JOIN freeswitch_sound      swu ON swu.id = a.wrapup_sound_id
    WHERE f.name      = %s
      AND f.company_id = %d
      AND a.active    = true
    ORDER BY a.sequence
]], db.esc(queue_name), cfg.company_id))

log("INFO", string.format("  agenci: %d", #agents))

if #agents == 0 then
    log("WARN", "  brak agentow -- stop")
    return
end

local qkey      = queue_name .. "@" .. cfg.sip_domain
local caller_did = (api:execute("uuid_getvar", caller_uuid .. " destination_number") or "")
    :match("^%s*(.-)%s*$")

-- Dzwon do agentow
for i, agent in ipairs(agents) do
    local status = agent.status or ""
    if status == "Logged Out" then
        log("INFO", string.format("  SKIP[%d] %s Logged Out", i, agent.extension or "?"))
    else
        -- Buduj contact
        local contact = ""
        if agent.mobile_number and agent.mobile_number ~= "" then
            local gw  = (agent.mobile_gateway and agent.mobile_gateway ~= "")
                        and agent.mobile_gateway or cfg.gateway
            local cid = caller_did ~= "" and caller_did or agent.mobile_number
            contact = string.format(
                "{origination_caller_id_name=%s,origination_caller_id_number=%s}"
                .. "sofia/gateway/%s/%s",
                cid, cid, gw, agent.mobile_number)
        elseif agent.contact and agent.contact ~= "" then
            contact = agent.contact
        elseif agent.extension and agent.extension ~= "" then
            contact = "user/" .. agent.extension .. "@" .. cfg.sip_domain
        end

        if contact ~= "" then
            local is_pstn = (agent.mobile_number and agent.mobile_number ~= "")
            local call_timeout = tostring(agent.call_timeout or agent_timeout)
            local member_wait  = agent.member_wait or "nowait"

            local vars = {
                string.format("origination_caller_id_name=%s",   caller_did),
                string.format("origination_caller_id_number=%s", caller_did),
                string.format("originate_timeout=%s",            call_timeout),
                string.format("fifo_outbound_uuid=%s",           caller_uuid),
                string.format("fifo_member_wait=%s",             member_wait),
            }

            if is_pstn then
                table.insert(vars, "ignore_early_media=true")
            elseif agent.group_confirm_file ~= "" then
                table.insert(vars, string.format("group_confirm_file=%s", agent.group_confirm_file))
                table.insert(vars, string.format("group_confirm_key=%s",
                    agent.group_confirm_key ~= "" and agent.group_confirm_key or "1"))
            end

            if agent.pop_order and agent.pop_order ~= "" then
                table.insert(vars, string.format("fifo_pop_order=%s", agent.pop_order))
            end
            if agent.wrapup_sound and agent.wrapup_sound ~= "" then
                table.insert(vars, string.format("fifo_consumer_wrapup_sound=%s", agent.wrapup_sound))
            end
            if agent.wrapup_key and agent.wrapup_key ~= "" then
                table.insert(vars, string.format("fifo_consumer_wrapup_key=%s", agent.wrapup_key))
            end

            local orig_vars = table.concat(vars, ",")
            local orig_cmd  = string.format(
                "originate {%s}%s '&fifo(%s out)'",
                orig_vars, contact, qkey)

            log("NOTICE", string.format("  REDIAL agent[%d] ext=%s pstn=%s",
                i, agent.extension or "?", tostring(is_pstn)))
            log("DEBUG", "  cmd: " .. orig_cmd:sub(1, 180))
            local reply = api:execute("bgapi", orig_cmd) or ""
            log("DEBUG", "  bgapi reply: " .. tostring(reply))
        end
    end
end

-- Zaplanuj kolejne ponowienie
local redial_delay = agent_timeout + 2
local sched_cmd = string.format("+%d %s lua fifo_redial.lua %s %s",
    redial_delay, caller_uuid, queue_name, caller_uuid)
local sched_reply = api:execute("sched_api", sched_cmd) or ""
log("NOTICE", string.format(
    "  Kolejne ponowienie za %ds  sched_reply=%s", redial_delay, sched_reply))
