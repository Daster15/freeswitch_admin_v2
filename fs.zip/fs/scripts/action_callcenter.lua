-- =============================================================================
-- action_callcenter.lua
-- Obsuga kolejki CallCenter (mod_callcenter) z penym auto-provisioningiem.
-- =============================================================================
local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db    = require("odoo_db")
local sound = require("sound")
local cfg   = db.company_config()

local M = {}

--  Logger z timestampem i poziomem 

local LOG_LEVELS = { DEBUG=1, INFO=2, NOTICE=3, WARN=4, ERR=5 }
local LOG_MIN    = LOG_LEVELS["DEBUG"]   -- zmie na INFO eby wyciszy DEBUG

local function make_logger(queue_name)
    return function(level, msg)
        if (LOG_LEVELS[level] or 0) < LOG_MIN then return end
        -- freeswitch.consoleLog przyjmuje poziom jako string
        freeswitch.consoleLog(level,
            string.format("[CC:%s] %s\n", queue_name or "?", msg))
    end
end

--  Separator sekcji 

local function section(log, title)
    log("NOTICE", string.rep("", 60))
    log("NOTICE", "  " .. title)
    log("NOTICE", string.rep("", 60))
end

--  Helper: ESL API z penym logowaniem 

local function esl(cmd, log)
    local app, args = cmd:match("^(%S+)%s*(.*)")
    args = args or ""
    log("DEBUG", string.format("  ESL CALL  app=%-30s args=%s", app or "", args))

    local api   = freeswitch.API()
    local reply = api:execute(app, args) or ""
    reply = reply:match("^%s*(.-)%s*$")

    if reply:match("^%-ERR") or reply:match("^%-err") or reply:match("INVALID COMMAND") then
        log("WARN", string.format("  ESL ERROR  %q  (cmd: %s %s)", reply, app, args))
        return false, reply
    end

    local short = #reply > 120 and (reply:sub(1,120) .. "") or reply
    log("DEBUG", string.format("  ESL OK     %q", short))
    return true, reply
end

--  Sprawd czy kolejka istnieje 

local function queue_exists(queue_name, log)
    log("DEBUG", "queue_exists? name=" .. queue_name)
    local ok, reply = esl("callcenter_config queue list", log)
    if not ok then
        log("WARN", "  queue_exists: ESL zwrcio bd  zakadam brak kolejki")
        return false
    end

    local count = 0
    for line in reply:gmatch("[^\n]+") do
        count = count + 1
        local name = line:match("^([^\t|]+)")
        if name then
            name = name:match("^%s*(.-)%s*$")
            if name:match("^" .. queue_name .. "@") then
                log("DEBUG", "  queue_exists: ZNALEZIONO w linii: " .. line:sub(1,80))
                return true
            end
        end
    end
    log("DEBUG", string.format("  queue_exists: nie znaleziono (przeszukano %d linii)", count))
    return false
end

--  Sprawd czy agent istnieje 

local function agent_exists(agent_name, log)
    log("DEBUG", "agent_exists? name=" .. agent_name)
    local ok, reply = esl("callcenter_config agent list", log)
    if not ok then
        log("WARN", "  agent_exists: ESL zwrcio bd  zakadam brak agenta")
        return false
    end
    for line in reply:gmatch("[^\n]+") do
        local name = line:match("^([^\t|]+)")
        if name then
            name = name:match("^%s*(.-)%s*$")
            if name == agent_name then
                log("DEBUG", "  agent_exists: ZNALEZIONO")
                return true
            end
        end
    end
    log("DEBUG", "  agent_exists: NIE ZNALEZIONO")
    return false
end

--  Pobierz stan / status agenta 

local function get_agent_state(agent_name, log)
    local api   = freeswitch.API()
    local reply = api:execute("callcenter_config", "agent get state " .. agent_name) or ""
    reply = reply:match("^%s*(.-)%s*$")
    log("DEBUG", string.format("  get_agent_state(%s) = %q", agent_name, reply))
    if reply == "" or reply:match("^%-ERR") or reply:match("INVALID") then
        log("WARN", "  get_agent_state: nieprawidowa odpowied  Unknown")
        return "Unknown"
    end
    return reply
end

local function get_agent_status(agent_name, log)
    local api   = freeswitch.API()
    local reply = api:execute("callcenter_config", "agent get status " .. agent_name) or ""
    reply = reply:match("^%s*(.-)%s*$")
    log("DEBUG", string.format("  get_agent_status(%s) = %q", agent_name, reply))
    if reply == "" or reply:match("^%-ERR") or reply:match("INVALID") then
        log("WARN", "  get_agent_status: nieprawidowa odpowied  Unknown")
        return "Unknown"
    end
    return reply
end

--  Provision kolejki 

local function provision_queue(queue, log)
    section(log, "PROVISION QUEUE: " .. queue.name)

    local qkey = queue.name .. "@" .. cfg.sip_domain
    log("INFO", "  qkey        = " .. qkey)
    log("INFO", "  strategy    = " .. (queue.strategy or "?"))
    log("INFO", "  company_id  = " .. tostring(cfg.company_id))
    log("INFO", "  sip_domain  = " .. (cfg.sip_domain or "?"))

    -- cieka MOH
    local moh = "local_stream://moh"
    if queue.moh_sound_id and tostring(queue.moh_sound_id) ~= "" then
        log("DEBUG", "  moh_sound_id = " .. tostring(queue.moh_sound_id))
        local moh_path = sound.resolve(queue.moh_sound_id)
        log("DEBUG", "  sound.resolve  " .. tostring(moh_path))
        if moh_path and moh_path ~= "" then
            moh = moh_path
            log("INFO",  "  MOH z Odoo filestore: " .. moh)
        else
            log("WARN",  "  sound.resolve zwrcio pusty wynik  uywam domylnego MOH")
        end
    else
        log("DEBUG", "  brak moh_sound_id  uywam local_stream://moh")
    end

    -- Helper: ustaw parametr kolejki przez ESL
    local function qset(param, value)
        if value ~= nil and tostring(value) ~= "" then
            log("DEBUG", string.format("    qset %s = %s", param, tostring(value)))
            local ok3, r3 = esl(string.format(
                "callcenter_config queue set %s %s %s", param, qkey, tostring(value)), log)
            if not ok3 then
                log("WARN", string.format("    qset %s FAILED: %s", param, tostring(r3)))
            end
        else
            log("DEBUG", string.format("    qset %s SKIP (pusta warto)", param))
        end
    end

    -- FS aduje kolejk automatycznie przez mod_xml_curl  Odoo (_handle_configuration)
    -- gdy wykonamy session:execute("callcenter", qkey) i kolejka nie istnieje w pamici.
    -- Nie musimy nic robi eby j "zaoy"  wystarczy e jest aktywna w Odoo.
    -- Przez ESL moemy tylko zaktualizowa parametry ju istniejcej kolejki.
    local exists = queue_exists(queue.name, log)
    log("INFO", "  kolejka istnieje w FS: " .. (exists and "TAK" or "NIE"))

    if exists then
        -- Kolejka ju jest w pamici  zaktualizuj parametry runtime
        log("NOTICE", "  ACTION: UPDATE parametrw kolejki " .. qkey)
        qset("strategy",                    queue.strategy or "longest-idle-agent")
        qset("moh-sound",                   moh)
        qset("time-base-score",             queue.time_base_score or "queue")
        qset("max-wait-time",               queue.max_wait_time or "0")
        qset("max-wait-time-with-no-agent", queue.max_wait_no_agent or "120")
        qset("tier-rules-apply",            queue.tier_rules_apply == "t" and "true" or "false")
        qset("discard-abandoned-after",     queue.discard_abnd_after or "60")
        qset("abandoned-resume-allowed",    queue.abandoned_resume   == "t" and "true" or "false")
        log("INFO", "  UPDATE parametrw  GOTOWE")
    else
        -- Kolejka nie istnieje jeszcze w pamici FS.
        -- session:execute("callcenter", qkey) wywoa mod_xml_curl  Odoo  _handle_configuration
        -- i FS zaaduje j automatycznie z pen konfiguracj (strategia, MOH, tiery, agenci).
        -- Nie robimy nic  pozwalamy FS zaadowa przy wejciu do kolejki.
        log("NOTICE", "  kolejka zostanie zaadowana przez xml_curl przy wejciu do callcenter")
        log("DEBUG",  "  Odoo musi odpowiedzie na: POST /freeswitch/xml_curl "
                   .. "section=configuration key_value=callcenter.conf CC-Queue=" .. queue.name)
    end

    session:setVariable("cc_moh_override", moh)
    log("DEBUG", "  session var cc_moh_override = " .. moh)
end

--  Provision agenta 

local function provision_agent(agent, log)
    local name    = agent.name    or ""
    local atype   = agent.agent_type or "callback"
    local timeout = tostring(agent.call_timeout or 20)
    local status  = agent.status  or "Logged Out"

    section(log, "PROVISION AGENT: " .. (name ~= "" and name or "[BRAK NAZWY]"))

    if name == "" then
        log("WARN", "  SKIP: brak pola name  agent pominity!")
        return
    end

    log("INFO", string.format("  name=%s  type=%s  timeout=%s  status=%s",
        name, atype, timeout, status))
    log("DEBUG", string.format("  contact=%s  extension=%s  sip_ext=%s",
        agent.contact or "", agent.extension or "", agent.sip_ext or ""))
    log("DEBUG", string.format("  mobile_number=%s  mobile_gateway=%s",
        agent.mobile_number or "", agent.mobile_gateway or ""))

    -- Wyznacz contact
    local contact = ""
    local contact_src = ""

    if agent.mobile_number and agent.mobile_number ~= "" then
        local gw  = (agent.mobile_gateway and agent.mobile_gateway ~= "")
                    and agent.mobile_gateway or cfg.gateway
        local num = agent.mobile_number
        -- Caller ID = numer DID na ktry dzwoni klient (destination_number z sesji).
        -- Dziki temu agent widzi waciwy numer placwki, a nie swj wasny numer.
        local cid = session:getVariable("destination_number") or
                    session:getVariable("dialed_number")       or num
        -- {origination_caller_id_name=...,origination_caller_id_number=...}
        contact     = string.format(
            "{origination_caller_id_name=%s,origination_caller_id_number=%s}sofia/gateway/%s/%s",
            cid, cid, gw, num)
        contact_src = "PSTN/mobile"
        log("INFO", string.format("  PSTN contact: gw=%s num=%s cid=%s (destination_number)", gw, num, cid))
    elseif agent.contact and agent.contact ~= "" then
        contact     = agent.contact
        contact_src = "pole contact"
    elseif agent.sip_ext and agent.sip_ext ~= "" then
        contact     = "user/" .. agent.sip_ext .. "@" .. cfg.sip_domain
        contact_src = "sip_ext"
    end

    if contact == "" then
        log("WARN", "  SKIP: brak contact, mobile_number i sip_ext  agent pominity!")
        return
    end

    log("INFO", string.format("  contact = %s  (rdo: %s)", contact, contact_src))

    local exists = agent_exists(name, log)
    log("INFO", "  agent istnieje w FS: " .. (exists and "TAK" or "NIE"))

    if not exists then
        log("NOTICE", "  ACTION: CREATE agent " .. name)
        local ok, r

        ok, r = esl("callcenter_config agent add " .. name .. " " .. atype, log)
        if not ok then log("WARN", "  agent add ERROR: " .. tostring(r)) end

        ok, r = esl("callcenter_config agent set contact "      .. name .. " " .. contact, log)
        if not ok then log("WARN", "  set contact ERROR: " .. tostring(r)) end

        ok, r = esl("callcenter_config agent set call_timeout " .. name .. " " .. timeout, log)
        if not ok then log("WARN", "  set call_timeout ERROR: " .. tostring(r)) end

        ok, r = esl("callcenter_config agent set status "       .. name .. " " .. status, log)
        if not ok then log("WARN", "  set status ERROR: " .. tostring(r)) end

        log("INFO", "  CREATE agenta  GOTOWE")
    else
        log("NOTICE", "  ACTION: UPDATE agenta " .. name)

        esl("callcenter_config agent set contact "      .. name .. " " .. contact, log)
        esl("callcenter_config agent set call_timeout " .. name .. " " .. timeout, log)

        -- Synchronizuj status tylko gdy nie prowadzi rozmowy
        local state = get_agent_state(name, log)
        log("INFO", "  aktualny state = " .. state)

        if state == "Receiving" then
            log("INFO",  "  SKIP status sync: agent prowadzi aktywn rozmow (Receiving)")
        else
            local current_status = get_agent_status(name, log)
            log("INFO", string.format("  status: Odoo=%q  FS=%q", status, current_status))

            if current_status ~= status then
                log("NOTICE", string.format("  STATUS CHANGE: %s  %s", current_status, status))
                esl("callcenter_config agent set status " .. name .. " " .. status, log)
            else
                log("DEBUG", "  status bez zmian  pomijam")
            end
        end

        log("INFO", "  UPDATE agenta  GOTOWE")
    end
end

--  Provision tierw 

local function provision_tiers(queue_name, agent_name, level, position, log)
    local qkey = queue_name .. "@" .. cfg.sip_domain

    log("DEBUG", string.format("provision_tiers: queue=%s agent=%s level=%d pos=%d",
        qkey, agent_name, level, position))

    local ok, reply = esl("callcenter_config tier list", log)
    local tier_exists = false

    if ok then
        local tier_count = 0
        for line in reply:gmatch("[^\n]+") do
            tier_count = tier_count + 1
            local q, a = line:match("^([^\t|]+)[|\t]([^\t|]+)")
            if q and a then
                q = q:match("^%s*(.-)%s*$")
                a = a:match("^%s*(.-)%s*$")
                if q == qkey and a == agent_name then
                    tier_exists = true
                    log("DEBUG", "  tier EXISTS (znaleziono w linii: " .. line:sub(1,80) .. ")")
                    break
                end
            end
        end
        log("DEBUG", string.format("  tier list: %d linii, tier istnieje: %s",
            tier_count, tostring(tier_exists)))
    else
        log("WARN", "  tier list: ESL zwrcio bd!")
    end

    if not tier_exists then
        log("NOTICE", string.format("  ACTION: ADD tier queue=%s agent=%s", qkey, agent_name))
        local ok2, r2 = esl("callcenter_config tier add " .. qkey .. " " .. agent_name, log)
        if not ok2 then log("WARN", "  tier add ERROR: " .. tostring(r2)) end
    end

    -- Zawsze aktualizuj level i position
    log("DEBUG", string.format("  SET level=%d  position=%d", level, position))
    esl(string.format("callcenter_config tier set level %s %s %d",    qkey, agent_name, level),    log)
    esl(string.format("callcenter_config tier set position %s %s %d", qkey, agent_name, position), log)
end

--  Sync stanw agentw  Odoo 

local function sync_states_to_odoo(agents, log)
    section(log, "SYNC STANW AGENTW  ODOO")
    local updates = {}
    local errors  = 0

    for _, agent in ipairs(agents) do
        local name = agent.name or ""
        if name == "" then goto continue end

        local state  = get_agent_state(name, log)
        local status = get_agent_status(name, log)
        log("INFO", string.format("  sync: agent=%-30s state=%-12s status=%s",
            name, state, status))

        local ok = pcall(function()
            db.query_all(string.format([[
                UPDATE freeswitch_cc_agent
                SET    status = %s,
                       state  = %s
                WHERE  name       = %s
                  AND  company_id = %d
            ]],
                db.esc(status),
                db.esc(state),
                db.esc(name),
                cfg.company_id
            ))
        end)

        if ok then
            table.insert(updates, string.format("%s:%s/%s", name, status, state))
        else
            errors = errors + 1
            log("WARN", "  DB UPDATE FAILED dla agenta: " .. name)
        end

        ::continue::
    end

    log("INFO", string.format("  sync zakoczony: %d OK, %d bdw",
        #updates, errors))
    if #updates > 0 then
        log("DEBUG", "  zaktualizowane: " .. table.concat(updates, ", "))
    end
end

--  Pobierz konfiguracj kolejki z Odoo 

local function fetch_queue(queue_name, log)
    section(log, "FETCH QUEUE z Odoo: " .. queue_name)
    log("DEBUG", string.format("  SQL: WHERE name=%q AND company_id=%d AND active=true",
        queue_name, cfg.company_id))

    local queue = db.query_one(string.format([[
        SELECT
            q.id,
            q.name,
            q.description,
            q.strategy,
            q.moh_sound_id,
            q.record_template,
            q.time_base_score,
            q.max_wait_time,
            q.max_wait_no_agent,
            q.tier_rules_apply,
            q.discard_abnd_after,
            q.abandoned_resume
        FROM  freeswitch_cc_queue q
        WHERE q.name       = %s
          AND q.company_id = %d
          AND q.active     = true
        LIMIT 1
    ]], db.esc(queue_name), cfg.company_id))

    if queue then
        log("INFO",  "  ZNALEZIONO: id=" .. tostring(queue.id)
                  .. "  desc=" .. (queue.description or "")
                  .. "  strategy=" .. (queue.strategy or ""))
        log("DEBUG", "  moh_sound_id="     .. tostring(queue.moh_sound_id or "NULL"))
        log("DEBUG", "  record_template="  .. tostring(queue.record_template or "NULL"))
        log("DEBUG", "  max_wait_time="    .. tostring(queue.max_wait_time or 0)
                  .. "  max_wait_no_agent=" .. tostring(queue.max_wait_no_agent or 0))
    else
        log("WARN",
            "  !! NIE ZNALEZIONO kolejki w Odoo !!")
        log("WARN",
            "  Sprawd: name=" .. queue_name
            .. "  company_id=" .. tostring(cfg.company_id)
            .. "  active=true")
        log("WARN",
            "  Hint: czy kolejka istnieje? czy jest aktywna? czy company_id pasuje?")
    end

    return queue
end

--  Pobierz agentw kolejki z Odoo 

local function fetch_agents(queue_id, log)
    section(log, string.format("FETCH AGENTS z Odoo: queue_id=%d", tonumber(queue_id)))
    log("DEBUG", "  company_id = " .. tostring(cfg.company_id))

    local rows = db.query_all(string.format([[
        SELECT
            a.name,
            a.contact,
            a.extension,
            a.agent_type,
            a.call_timeout,
            a.status,
            a.active,
            t.level,
            t.position,
            -- Numer PSTN: najpierw z urzdze przypisanych bezporednio do agenta
            -- (cc_agent_sip_device_rel / sip_device_ids), potem fallback na
            -- urzdzenia powizanego uytkownika SIP
            COALESCE(
                (SELECT d.mobile_number
                 FROM   freeswitch_sip_device d
                 JOIN   cc_agent_sip_device_rel r ON r.device_id = d.id
                 WHERE  r.agent_id = a.id
                   AND  d.mobile_number IS NOT NULL
                   AND  d.mobile_number <> ''
                   AND  d.active = true
                 ORDER  BY d.sequence
                 LIMIT  1),
                (SELECT d.mobile_number
                 FROM   freeswitch_sip_device d
                 WHERE  d.user_id = u.id
                   AND  d.mobile_number IS NOT NULL
                   AND  d.mobile_number <> ''
                   AND  d.active = true
                 ORDER  BY d.sequence
                 LIMIT  1)
            ) AS mobile_number,
            -- Gateway PSTN: ta sama kolejno priorytetw
            COALESCE(
                (SELECT d.mobile_gateway
                 FROM   freeswitch_sip_device d
                 JOIN   cc_agent_sip_device_rel r ON r.device_id = d.id
                 WHERE  r.agent_id = a.id
                   AND  d.mobile_number IS NOT NULL
                   AND  d.mobile_number <> ''
                   AND  d.active = true
                 ORDER  BY d.sequence
                 LIMIT  1),
                (SELECT d.mobile_gateway
                 FROM   freeswitch_sip_device d
                 WHERE  d.user_id = u.id
                   AND  d.mobile_number IS NOT NULL
                   AND  d.mobile_number <> ''
                   AND  d.active = true
                 ORDER  BY d.sequence
                 LIMIT  1)
            ) AS mobile_gateway,
            u.name AS sip_ext
        FROM  freeswitch_cc_tier    t
        JOIN  freeswitch_cc_agent   a ON a.id = t.agent_id
        LEFT  JOIN freeswitch_sip_user u ON u.id = a.sip_user_id
        WHERE t.queue_id   = %d
          AND a.active     = true
          AND a.company_id = %d
        ORDER BY t.level, t.position
    ]], tonumber(queue_id), cfg.company_id))

    log("INFO", string.format("  pobranych agentw: %d", #rows))

    for i, a in ipairs(rows) do
        log("DEBUG", string.format(
            "  [%d] name=%-25s status=%-20s level=%s pos=%s ext=%s",
            i, a.name or "?", a.status or "?",
            tostring(a.level), tostring(a.position),
            a.sip_ext or a.extension or "?"))
    end

    if #rows == 0 then
        log("WARN", "  !! BRAK AGENTW w kolejce !!")
        log("WARN", "  Sprawd: freeswitch_cc_tier JOIN freeswitch_cc_agent "
                  .. "WHERE queue_id=" .. tostring(queue_id)
                  .. " AND active=true AND company_id=" .. tostring(cfg.company_id))
    end

    return rows
end

-- 
-- Pobierz pozycj w kolejce przez ESL
-- 

local function get_queue_position(queue_name, caller_uuid, log)
    -- callcenter_config queue list czonkw kolejki (callers)
    local qkey = queue_name .. "@" .. cfg.sip_domain
    local api   = freeswitch.API()
    local reply = api:execute("callcenter_config", "queue list members " .. qkey) or ""

    local position = 0
    local total    = 0
    for line in reply:gmatch("[^\n]+") do
        -- Format linii: uuid|system|queue|proto|from|created|created_epoch|joined_epoch|state|cid_num|cid_name|serving_agent|serving_system|abandoned
        local uuid_col = line:match("^([^\t|]+)")
        if uuid_col then
            uuid_col = uuid_col:match("^%s*(.-)%s*$")
            total = total + 1
            if uuid_col == caller_uuid then
                position = total
            end
        end
    end

    log("DEBUG", string.format("  queue position: %d/%d (uuid=%s)", position, total, caller_uuid))
    return position, total
end

--  Zaplanuj cykliczne ogaszanie pozycji przez sched_api 

local function schedule_position_announcer(queue_name, caller_uuid, interval_sec, log)
    -- Zapisz zmienne do sesji eby skrypt cc_position.lua mg je odczyta
    session:setVariable("cc_announce_queue",    queue_name)
    session:setVariable("cc_announce_interval", tostring(interval_sec or 30))

    -- Zaplanuj pierwsze wywoanie cc_position.lua po interval_sec sekundach
    -- sched_api: sched_api +<sekundy> <uuid> lua cc_position.lua
    local api = freeswitch.API()
    local sched_cmd = string.format("+%d %s lua cc_position.lua %s %s",
        interval_sec or 30,
        caller_uuid,
        queue_name,
        caller_uuid)
    local reply = api:execute("sched_api", sched_cmd) or ""
    log("INFO", string.format(
        "  sched_api pozycja: interval=%ds  reply=%s", interval_sec or 30, reply))
end

-- 
-- Gwna funkcja
-- 

function M.run(queue_name, log)
    log = log or make_logger(queue_name)

    log("NOTICE", string.rep("", 60))
    log("NOTICE", string.format("  ACTION_CALLCENTER START  queue=%s", queue_name))
    log("NOTICE", string.rep("", 60))
    log("INFO",   "  company_id  = " .. tostring(cfg.company_id))
    log("INFO",   "  sip_domain  = " .. tostring(cfg.sip_domain or "?"))
    log("INFO",   "  gateway     = " .. tostring(cfg.gateway    or "?"))
    log("INFO",   "  session uuid= " .. (session:getVariable("uuid") or "?"))

    --  KROK 0: Odbierz poczenie i uruchom MOH natychmiast 
    -- Robimy to PRZED provisioningiem eby dzwonicy nie sysza ciszy
    -- podczas gdy skrypt odpytuje baz danych i ESL.
    -- mod_callcenter zastpi MOH swoim wasnym po wejciu do kolejki.
    log("NOTICE", "  ANSWER + wstpne MOH przed provisioningiem")
    session:execute("answer")

    -- Pobierz MOH z konfiguracji kolejki  szybkie zapytanie tylko po moh_sound_id
    local early_moh = "local_stream://moh"
    local moh_row = db.query_one(string.format([[
        SELECT s.fs_path, s.audio_fname
        FROM   freeswitch_cc_queue q
        LEFT   JOIN freeswitch_sound s ON s.id = q.moh_sound_id
        WHERE  q.name       = %s
          AND  q.company_id = %d
          AND  q.active     = true
        LIMIT  1
    ]], db.esc(queue_name), cfg.company_id))

    if moh_row then
        if moh_row.fs_path and moh_row.fs_path ~= "" then
            early_moh = moh_row.fs_path
        elseif moh_row.audio_fname and moh_row.audio_fname ~= "" then
            early_moh = cfg.sounds_dir and
                (cfg.sounds_dir .. "/" .. moh_row.audio_fname) or
                ("/etc/freeswitch/sounds/" .. moh_row.audio_fname)
        end
    end

    log("INFO", "  early MOH: " .. early_moh)

    -- Ustaw muzyk oczekiwania na kanale.
    -- hold_music jest odtwarzane przez mod_callcenter gdy kolejka jest aktywna.
    -- endless_playback gra teraz, podczas provisioning  bez blokowania.
    session:setVariable("hold_music", early_moh)
    session:setVariable("cc_moh_override", early_moh)

    local uuid = session:getVariable("uuid") or ""
    if uuid ~= "" then
        local api = freeswitch.API()
        -- Zatrzymaj poprzedni playback (np. z action_playback lub IVR)
        -- żeby nie zagłuszał MOH kolejki
        api:execute("uuid_break", uuid)
        -- Krótka pauza żeby kanał zdążył zwolnić bufor audio
        session:execute("sleep", "150")
        -- Uruchom MOH w tle — mod_callcenter zastąpi go swoim po wejściu do kolejki
        local bc_reply = api:execute("uuid_broadcast",
            uuid .. " " .. early_moh .. "@ aleg")
        log("DEBUG", "  uuid_break + uuid_broadcast reply: " .. tostring(bc_reply))
    end

    --  KROK 1: Pobierz konfiguracj z Odoo 
    local queue = fetch_queue(queue_name, log)

    if not queue then
        log("WARN", "SKIP provisioning  kolejka nie znaleziona w Odoo")
        log("WARN", "Wchodz do kolejki FS bez provisioning (moe nie istnie!)")
    else
        --  KROK 2: Provision kolejki 
        provision_queue(queue, log)

        --  KROK 3: Agenci 
        local agents = fetch_agents(queue.id, log)

        section(log, string.format("PROVISION AGENTW (%d)", #agents))

        if #agents == 0 then
            log("WARN", "  BRAK AGENTW  kolejka pusta, nie wchodz do callcenter!")
            log("WARN", "  Rozczam poczenie (NO_ROUTE_DESTINATION).")
            session:setVariable("odoo_route_type",   "callcenter")
            session:setVariable("odoo_route_target", queue_name)
            session:execute("answer")
            session:execute("playback", "ivr/ivr-no_agents_are_available_at_this_time.wav")
            session:execute("hangup", "NO_ROUTE_DESTINATION")
            return
        end

        for i, agent in ipairs(agents) do
            log("INFO", string.format(" Agent %d/%d ", i, #agents))
            provision_agent(agent, log)
            provision_tiers(
                queue_name,
                agent.name,
                tonumber(agent.level)    or 1,
                tonumber(agent.position) or 1,
                log
            )
        end

        --  KROK 4: Sync stanw FS  Odoo 
        local ok = pcall(sync_states_to_odoo, agents, log)
        if not ok then
            log("WARN", "  sync_states_to_odoo: bd (niekrytyczny  poczenie kontynuowane)")
        end

        --  KROK 5: Nagrywanie 
        -- Nagrywanie jest uruchamiane globalnie w route.lua przed wywoaniem
        -- tej funkcji (record_session na kanale callera).
        -- record_template z kolejki jest zachowany jako dodatkowe nagranie
        -- po stronie agenta (stereo), jeli skonfigurowane.
        section(log, "NAGRYWANIE")
        local rec_template = queue.record_template or ""
        if rec_template ~= "" then
            local rec_uuid = session:getVariable("uuid") or "unknown"
            local rec_path = rec_template:gsub("{uuid}", rec_uuid)
            session:setVariable("cc_record_filename", rec_path)
            log("DEBUG", "  cc record_template: " .. rec_path .. " (uruchamiane przez FS automatycznie)")
        else
            log("DEBUG", "  brak record_template  tylko globalne nagranie z route.lua")
        end
    end

    --  KROK 6: Zmienne CDR 
    session:setVariable("odoo_route_type",   "callcenter")
    session:setVariable("odoo_route_target", queue_name)
    log("DEBUG", "  CDR vars: route_type=callcenter  route_target=" .. queue_name)

    --  KROK 7: Wejcie do kolejki 
    local cc_str     = queue_name .. "@" .. cfg.sip_domain
    local caller_uuid = session:getVariable("uuid") or ""

    log("NOTICE", string.rep("", 60))
    log("NOTICE", "  ENTER callcenter: " .. cc_str)
    log("NOTICE", string.rep("", 60))

    -- Zaplanuj cykliczne ogaszanie pozycji co 30 sekund
    -- (pierwsze ogoszenie po 30s  daje czas eby agent odebra od razu)
    local announce_interval = tonumber(
        (queue and queue.announce_position_interval) or 20)
    if announce_interval > 0 then
        schedule_position_announcer(queue_name, caller_uuid, announce_interval, log)
    else
        log("DEBUG", "  ogaszanie pozycji wyczone (announce_position_interval=0)")
    end

    -- answer ju wykonany na pocztku (KROK 0)
    session:execute("callcenter", cc_str)

    --  Po wyjciu z kolejki 
    local cc_agent = session:getVariable("cc_agent")     or ""
    local cc_queue = session:getVariable("cc_selection") or queue_name
    local cc_cause = session:getVariable("cc_cause")     or ""

    log("NOTICE", string.rep("", 60))
    log("NOTICE", "  EXIT callcenter")
    log("NOTICE", string.rep("", 60))
    log("INFO", "  agent    = " .. (cc_agent ~= "" and cc_agent or "(brak  nikt nie odebra)"))
    log("INFO", "  queue    = " .. cc_queue)
    log("INFO", "  cause    = " .. (cc_cause ~= "" and cc_cause or "?"))

    session:setVariable("cc_agent_called", cc_agent)
    session:setVariable("cc_selection",    cc_queue)
end

--  Wywoanie bezporednio z dialplanu 
if argv and argv[1] then
    M.run(argv[1])
end

return M
