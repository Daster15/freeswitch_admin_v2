-- =============================================================================
-- action_fifo.lua  — kolejka FIFO w Lua bez mod_fifo
--
-- POPRAWKI na podstawie logów:
--
--  1. MOH: endless_playback przez uuid_broadcast nie działa.
--     Rozwiązanie: session:execute("endless_playback", plik) — blokuje Lua,
--     więc używamy wątku przez bgapi + sched_api albo prostszego podejścia:
--     klient siedzi na session:execute("sleep") a MOH gra przez uuid_broadcast
--     z loopback. Właściwe rozwiązanie: uuid_broadcast z playback w pętli
--     realizowanej przez sched_api co N sekund.
--
--     WŁAŚCIWA SKŁADNIA uuid_broadcast dla endless_playback:
--       api:execute("uuid_broadcast", uuid .. " playback::" .. plik .. " aleg")
--     lub po prostu zaplanować przez sched_api.
--
--     NAJPROSTSZE: klient wykonuje session:execute("playback", plik) w pętli
--     z krótkimi breakami na sprawdzenia — ale to blokuje.
--
--     WŁAŚCIWE: użyć hold_music channel variable + uuid_hold.
--     uuid_hold wstrzymuje kanał i gra hold_music w pętli — to jest dokładnie
--     to czego potrzebujemy.
--
--  2. Agent: NO_ANSWER po odebraniu — group_confirm_key powoduje że FS czeka
--     na DTMF. Agent odbiera ale nie naciska klawisza → timeout → NO_ANSWER.
--     Dla PSTN bez skonfigurowanego confirm: nie ustawiamy group_confirm_key.
--
--  3. fifo_agent_answer.lua nie startuje — bo kanał agenta rozłącza się
--     zanim skrypt się uruchomi. Originate_timeout musi być wystarczający.
--
-- ARCHITEKTURA MOH (poprawiona):
--   1. Ustaw hold_music = ścieżka MOH na kanale klienta
--   2. uuid_hold → klient słyszy MOH w pętli (FS sam zapętla hold_music)
--   3. Przed ogłoszeniem: uuid_unhold → klient "wraca" → uuid_broadcast ogłoszenie
--   4. Po ogłoszeniu: uuid_hold znowu
--
-- ARCHITEKTURA BRIDGE (intercept — bez zmian, działa):
--   action_fifo.lua → session:execute("intercept", agent_uuid)
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db    = require("odoo_db")
local sound = require("sound")
local cfg   = db.company_config()

local M = {}

local MOH_DEFAULT = "local_stream://moh"
local LOOP_MS     = 500
local DIGITS_DIR  = "/usr/local/freeswitch/sounds/en/us/callie/digits/8000"

local LOG_LEVELS = { DEBUG=1, INFO=2, NOTICE=3, WARN=4, ERR=5 }
local LOG_MIN    = LOG_LEVELS["DEBUG"]

local function make_logger(q)
    return function(lvl, msg)
        if (LOG_LEVELS[lvl] or 0) < LOG_MIN then return end
        freeswitch.consoleLog(lvl, string.format("[FIFO:%s] %s\n", q or "?", msg))
    end
end

local function sep(log, title)
    log("NOTICE", string.rep("─", 56))
    log("NOTICE", "  " .. title)
    log("NOTICE", string.rep("─", 56))
end

-- ══════════════════════════════════════════════════════════════════════════════
-- DANE Z ODOO
-- ══════════════════════════════════════════════════════════════════════════════

local function fetch_fifo(queue_name, log)
    local r = db.query_one(string.format([[
        SELECT id, name, max_wait_sec, caller_priority,
               ring_strategy, ring_progressive_sec,
               moh_sound_id, announce_sound_id, announce_freq,
               timeout_action_type,
               timeout_ivr_id, timeout_fifo_id, timeout_cc_id,
               timeout_user_id, timeout_pstn, timeout_sound_id,
               record_template
        FROM   freeswitch_fifo
        WHERE  name = %s AND company_id = %d AND active = true
        LIMIT  1
    ]], db.esc(queue_name), cfg.company_id))
    if r then
        log("INFO", string.format(
            "  id=%s max_wait=%ss strategy=%s prog=%ss announce=%ss",
            r.id, r.max_wait_sec or 300, r.ring_strategy or "ringall",
            r.ring_progressive_sec or 15, r.announce_freq or 0))
    else
        log("WARN", "  NIE ZNALEZIONO: " .. queue_name)
    end
    return r
end

local function fetch_agents(fifo_id, log)
    local rows = db.query_all(string.format([[
        SELECT
            a.id            AS agent_id,
            a.extension,
            a.contact,
            a.sequence,
            a.simo,
            a.group_confirm_key,
            COALESCE(NULLIF(a.call_timeout,0), ca.call_timeout, 30) AS call_timeout,
            ca.status,
            ca.name         AS agent_name,
            a.last_answered_at,
            COALESCE(
                (SELECT d.mobile_number FROM freeswitch_sip_device d
                 JOIN   fifo_agent_sip_device_rel r ON r.device_id = d.id
                 WHERE  r.fifo_agent_id = a.id
                   AND  d.mobile_number IS NOT NULL AND d.mobile_number <> ''
                   AND  d.active = true ORDER BY d.sequence LIMIT 1),
                (SELECT d.mobile_number FROM freeswitch_sip_device d
                 WHERE  d.user_id = su.id
                   AND  d.mobile_number IS NOT NULL AND d.mobile_number <> ''
                   AND  d.active = true ORDER BY d.sequence LIMIT 1)
            ) AS mobile_number,
            COALESCE(
                (SELECT d.mobile_gateway FROM freeswitch_sip_device d
                 JOIN   fifo_agent_sip_device_rel r ON r.device_id = d.id
                 WHERE  r.fifo_agent_id = a.id
                   AND  d.mobile_number IS NOT NULL AND d.mobile_number <> ''
                   AND  d.active = true ORDER BY d.sequence LIMIT 1),
                (SELECT d.mobile_gateway FROM freeswitch_sip_device d
                 WHERE  d.user_id = su.id
                   AND  d.mobile_number IS NOT NULL AND d.mobile_number <> ''
                   AND  d.active = true ORDER BY d.sequence LIMIT 1)
            ) AS mobile_gateway,
            COALESCE(sgc.fs_path, sgc.audio_fname, '') AS confirm_file_path
        FROM  freeswitch_fifo_agent a
        LEFT  JOIN freeswitch_cc_agent ca  ON ca.id  = a.cc_agent_id
        LEFT  JOIN freeswitch_sip_user su  ON su.id  = ca.sip_user_id
        LEFT  JOIN freeswitch_sound    sgc ON sgc.id = a.group_confirm_file
        WHERE a.fifo_id = %d AND a.active = true
        ORDER BY a.last_answered_at ASC NULLS FIRST, a.sequence ASC
    ]], tonumber(fifo_id)))
    log("INFO", string.format("  agentów: %d", #rows))
    for i, a in ipairs(rows) do
        log("DEBUG", string.format("  [%d] ext=%-6s timeout=%2ss mobile=%-12s",
            i, a.extension or "?", tostring(a.call_timeout or 30), a.mobile_number or ""))
    end
    return rows
end

local function mark_agent_answered(agent_id, log)
    if not agent_id or agent_id == "" then return end
    local ok = pcall(function()
        db.execute(string.format([[
            UPDATE freeswitch_fifo_agent SET last_answered_at = NOW() WHERE id = %d
        ]], tonumber(agent_id)))
    end)
    log(ok and "INFO" or "WARN",
        "  last_answered_at " .. (ok and "OK" or "BŁĄD") .. " id=" .. agent_id)
end

-- ══════════════════════════════════════════════════════════════════════════════
-- MOH przez uuid_hold
--
-- uuid_hold wstrzymuje kanał klienta i gra hold_music w pętli.
-- Jest to wbudowany mechanizm FS — niezawodny i nie blokuje Lua.
-- hold_music musi być ustawiony przed uuid_hold.
-- ══════════════════════════════════════════════════════════════════════════════

local function moh_start(caller_uuid, moh_path, log)
    local api = freeswitch.API()
    -- Ustaw hold_music na kanale — FS będzie grał to w pętli podczas hold
    api:execute("uuid_setvar", caller_uuid .. " hold_music " .. moh_path)
    -- Wstrzymaj kanał → gra hold_music w pętli
    local r = api:execute("uuid_hold", caller_uuid)
    log("INFO", "  MOH start (uuid_hold): " .. moh_path .. " → " .. tostring(r))
end

local function moh_stop(caller_uuid, log)
    local api = freeswitch.API()
    -- Zdejmij hold → klient "wraca" (cisza lub dalsze wykonanie)
    local r = api:execute("uuid_hold", "off " .. caller_uuid)
    log("DEBUG", "  MOH stop (uuid_hold off): " .. tostring(r))
    -- Krótka przerwa żeby FS zdążył zdjąć hold
    api:execute("sleep", "200")
end

-- ══════════════════════════════════════════════════════════════════════════════
-- OGŁOSZENIA POZYCJI
-- ══════════════════════════════════════════════════════════════════════════════

local function play_number(caller_uuid, n)
    if n <= 0 then return end
    local api = freeswitch.API()
    local function play(f)
        -- uuid_broadcast działa gdy kanał jest zdejmowany z hold
        api:execute("uuid_broadcast", caller_uuid .. " " .. f .. " aleg")
        api:execute("sleep", "700")
    end
    if     n <= 20  then play(DIGITS_DIR .. "/" .. n .. ".wav")
    elseif n <  100 then
        play(DIGITS_DIR .. "/" .. math.floor(n/10)*10 .. ".wav")
        if n % 10 > 0 then play(DIGITS_DIR .. "/" .. n%10 .. ".wav") end
    elseif n <  1000 then
        play(DIGITS_DIR .. "/" .. math.floor(n/100) .. ".wav")
        play(DIGITS_DIR .. "/hundred.wav")
        if n % 100 > 0 then play_number(caller_uuid, n % 100) end
    else   play(DIGITS_DIR .. "/thousand.wav")
    end
end

local function announce_position(caller_uuid, position, announce_sound_id, moh, log)
    log("INFO", string.format("  OGŁOSZENIE pozycji=%d", position))
    -- Zdejmij hold żeby kanał był aktywny
    moh_stop(caller_uuid, log)
    local api = freeswitch.API()
    api:execute("sleep", "200")

    -- Plik zapowiedzi (opcjonalny)
    if announce_sound_id then
        local path = sound.resolve(announce_sound_id)
        if path ~= "" then
            api:execute("uuid_broadcast", caller_uuid .. " " .. path .. " aleg")
            api:execute("sleep", "1500")
        end
    end

    -- Cyfra pozycji
    play_number(caller_uuid, position)
    api:execute("sleep", "400")

    -- Wznów MOH
    moh_start(caller_uuid, moh, log)
end

-- ══════════════════════════════════════════════════════════════════════════════
-- DZWONIENIE DO AGENTÓW
-- ══════════════════════════════════════════════════════════════════════════════

local function build_contact(agent, log)
    if agent.mobile_number and agent.mobile_number ~= "" then
        local gw = (agent.mobile_gateway and agent.mobile_gateway ~= "")
                   and agent.mobile_gateway or cfg.gateway
        return string.format("sofia/gateway/%s/%s", gw, agent.mobile_number), true
    end
    if agent.contact and agent.contact ~= "" then return agent.contact, false end
    if agent.extension and agent.extension ~= "" then
        return string.format("user/%s@%s", agent.extension, cfg.sip_domain), false
    end
    log("WARN", "  brak contact ext=" .. tostring(agent.extension))
    return "", false
end

local function ring_agent(agent, caller_uuid, caller_did, log)
    local contact, is_pstn = build_contact(agent, log)
    if contact == "" then return 0 end

    local api          = freeswitch.API()
    local call_timeout = tonumber(agent.call_timeout) or 30
    local simo         = is_pstn and 1 or (tonumber(agent.simo) or 1)

    -- Zmienne kanału agenta
    -- WAŻNE: originate_timeout musi być > ring_timeout żeby agent miał czas odebrać
    -- ignore_early_media=true dla PSTN — nie bridguj przy 183 (dzwonku)
    local vars = string.format(
        "originate_timeout=%d,"
        .. "origination_caller_id_name=%s,"
        .. "origination_caller_id_number=%s,"
        .. "fifo_caller_uuid=%s,"
        .. "fifo_agent_db_id=%s",
        call_timeout + 5,   -- +5s bufor na odebranie i uruchomienie Lua
        caller_did, caller_did,
        caller_uuid,
        tostring(agent.agent_id or ""))

    if is_pstn then
        -- ignore_early_media: nie traktuj 183 (dzwonku) jako odebrania
        vars = vars .. ",ignore_early_media=true"
        -- NIE ustawiamy group_confirm_key dla PSTN — powoduje NO_ANSWER gdy agent nie naciska klawisza
        -- group_confirm_key ustawiamy TYLKO jeśli agent ma to skonfigurowane w Odoo
        -- i tylko gdy chcemy potwierdzenia (np. chronić przed pocztą głosową)
    end

    -- group_confirm_key tylko jeśli jawnie skonfigurowane w Odoo dla tego agenta
    local ck = agent.group_confirm_key or ""
    if ck ~= "" then
        local cf = (agent.confirm_file_path and agent.confirm_file_path ~= "")
                   and agent.confirm_file_path or "tone_stream://%(1000,0,440)"
        vars = vars
            .. ",group_confirm_key=" .. ck
            .. ",group_confirm_file=" .. cf
            .. ",group_confirm_read_timeout=5000"
        log("INFO", "  group_confirm_key=" .. ck)
    end

    local rang = 0
    for s = 1, simo do
        -- fifo_agent_answer.lua sygnalizuje że agent odebrał
        local cmd = string.format(
            "originate {%s}%s &lua(fifo_agent_answer.lua %s %s)",
            vars, contact, caller_uuid, tostring(agent.agent_id or ""))
        log("INFO", string.format(
            "  RING [%d/%d] ext=%-6s timeout=%ds pstn=%s",
            s, simo, agent.extension or "?", call_timeout, tostring(is_pstn)))
        log("DEBUG", "    cmd: " .. cmd:sub(1, 200))
        api:execute("bgapi", cmd)
        rang = rang + 1
    end
    return rang
end

local function active_agent_channels(caller_uuid)
    local api  = freeswitch.API()
    local json = api:execute("show", "channels as json") or "{}"
    local n    = 0
    for chan_uuid in json:gmatch('"uuid"%s*:%s*"([^"]+)"') do
        if chan_uuid ~= caller_uuid then
            local v = (api:execute("uuid_getvar",
                chan_uuid .. " fifo_caller_uuid") or ""):match("^%s*(.-)%s*$")
            if v == caller_uuid then n = n + 1 end
        end
    end
    return n
end

local function cancel_agents(caller_uuid, except_uuid, log)
    local api  = freeswitch.API()
    local json = api:execute("show", "channels as json") or "{}"
    local n    = 0
    for chan_uuid in json:gmatch('"uuid"%s*:%s*"([^"]+)"') do
        if chan_uuid ~= caller_uuid and chan_uuid ~= (except_uuid or "") then
            local v = (api:execute("uuid_getvar",
                chan_uuid .. " fifo_caller_uuid") or ""):match("^%s*(.-)%s*$")
            if v == caller_uuid then
                api:execute("uuid_kill", chan_uuid)
                n = n + 1
            end
        end
    end
    if n > 0 then log("INFO", "  anulowano " .. n .. " kanałów") end
end

local function check_answered(caller_uuid)
    local api = freeswitch.API()
    local v   = (api:execute("uuid_getvar",
        caller_uuid .. " fifo_answered_by") or ""):match("^%s*(.-)%s*$")
    if v ~= "" and v ~= "_undef_" and v ~= "false" then return v end
    return nil
end

-- ══════════════════════════════════════════════════════════════════════════════
-- AKCJA PO TIMEOUT
-- ══════════════════════════════════════════════════════════════════════════════

local function handle_timeout(fifo, log)
    local t = fifo.timeout_action_type
    if not t or t == "" then return end
    sep(log, "TIMEOUT: " .. t)
    if t == "ivr" and fifo.timeout_ivr_id then
        local r = db.query_one(string.format(
            "SELECT name FROM freeswitch_ivr WHERE id=%d LIMIT 1",
            tonumber(fifo.timeout_ivr_id)))
        if r then require("ivr").run(r.name, log) end
    elseif t == "fifo" and fifo.timeout_fifo_id then
        local r = db.query_one(string.format(
            "SELECT name FROM freeswitch_fifo WHERE id=%d LIMIT 1",
            tonumber(fifo.timeout_fifo_id)))
        if r then M.run(r.name, log) end
    elseif t == "callcenter" and fifo.timeout_cc_id then
        local r = db.query_one(string.format(
            "SELECT name FROM freeswitch_cc_queue WHERE id=%d LIMIT 1",
            tonumber(fifo.timeout_cc_id)))
        if r then require("action_callcenter").run(r.name, log) end
    elseif t == "user" and fifo.timeout_user_id then
        local r = db.query_one(string.format([[
            SELECT su.name FROM freeswitch_sip_user su
            JOIN freeswitch_cc_agent ca ON ca.sip_user_id=su.id
            WHERE ca.id=%d LIMIT 1]], tonumber(fifo.timeout_user_id)))
        if r then require("action_user").run(r.name, log) end
    elseif t == "pstn" and fifo.timeout_pstn and fifo.timeout_pstn ~= "" then
        session:execute("bridge",
            "sofia/gateway/" .. (cfg.gateway or "default") .. "/" .. fifo.timeout_pstn)
    elseif t == "playback" and fifo.timeout_sound_id then
        local sf = sound.resolve(fifo.timeout_sound_id)
        if sf ~= "" then session:execute("playback", sf) end
    end
end

-- ══════════════════════════════════════════════════════════════════════════════
-- GŁÓWNA FUNKCJA
-- ══════════════════════════════════════════════════════════════════════════════

function M.run(queue_name, log)
    log = log or make_logger(queue_name)
    sep(log, "ACTION_FIFO START  queue=" .. queue_name)

    local caller_uuid = session:getVariable("uuid") or ""
    local caller_did  = session:getVariable("destination_number") or ""
    log("INFO", "  uuid=" .. caller_uuid .. "  did=" .. caller_did)

    -- ── Konfiguracja ─────────────────────────────────────────────────────────
    local fifo = fetch_fifo(queue_name, log)
    if not fifo then
        log("ERR", "  kolejka nie znaleziona")
        session:execute("playback", "ivr/ivr-call_cannot_be_completed_as_dialed.wav")
        return
    end

    local max_wait = tonumber(fifo.max_wait_sec)         or 300
    local ann_freq = tonumber(fifo.announce_freq)        or 0
    local strategy = fifo.ring_strategy                  or "ringall"
    local prog_sec = tonumber(fifo.ring_progressive_sec) or 15

    local moh = MOH_DEFAULT
    if fifo.moh_sound_id then
        local r = sound.resolve(fifo.moh_sound_id)
        if r ~= "" then moh = r end
    end

    -- ── Answer ───────────────────────────────────────────────────────────────
    session:execute("answer")
    session:setVariable("odoo_route_type",   "fifo")
    session:setVariable("odoo_route_target", queue_name)

    if fifo.record_template and fifo.record_template ~= "" then
        local rp = fifo.record_template:gsub("{uuid}", caller_uuid)
        session:execute("record_session", rp)
        log("INFO", "  nagrywanie: " .. rp)
    end

    log("INFO", "  strategy=" .. strategy .. "  max_wait=" .. max_wait ..
                "s  ann_freq=" .. ann_freq .. "s  moh=" .. moh)

    -- ── MOH przez uuid_hold ───────────────────────────────────────────────────
    -- hold_music musi być ustawiony przed answer lub zaraz po
    -- uuid_hold wstrzymuje kanał i gra hold_music w pętli nieskończonej
    moh_start(caller_uuid, moh, log)

    -- ── Agenci ───────────────────────────────────────────────────────────────
    local agents = fetch_agents(fifo.id, log)
    if #agents == 0 then log("WARN", "  brak agentów") end

    -- ── Pierwsze dzwonienie ───────────────────────────────────────────────────
    local queue_start   = os.time()
    local last_announce = queue_start
    local next_prog_idx = 1
    local last_prog_add = queue_start
    local answered_by   = nil

    if #agents > 0 then
        sep(log, "PIERWSZE DZWONIENIE [" .. strategy .. "]")
        if strategy == "progressive" then
            for i, a in ipairs(agents) do
                if (a.status or "") ~= "Logged Out" then
                    ring_agent(a, caller_uuid, caller_did, log)
                    last_prog_add = queue_start
                    next_prog_idx = i + 1
                    break
                end
            end
        else
            for _, a in ipairs(agents) do
                if (a.status or "") ~= "Logged Out" then
                    ring_agent(a, caller_uuid, caller_did, log)
                end
            end
        end
    end

    -- ── Pętla oczekiwania ─────────────────────────────────────────────────────
    -- session:execute("sleep") działa nawet gdy kanał jest na hold
    while session:ready() do
        session:execute("sleep", tostring(LOOP_MS))
        if not session:ready() then break end

        local now     = os.time()
        local elapsed = now - queue_start

        if elapsed >= max_wait then
            log("NOTICE", "  TIMEOUT po " .. elapsed .. "s"); break
        end

        answered_by = check_answered(caller_uuid)
        if answered_by then
            log("NOTICE", "  ODEBRAŁ uuid=" .. answered_by); break
        end

        -- Ogłoszenie pozycji
        if ann_freq > 0 and (now - last_announce) >= ann_freq then
            announce_position(caller_uuid, 1, fifo.announce_sound_id, moh, log)
            last_announce = now
        end

        local active = active_agent_channels(caller_uuid)

        if strategy == "progressive" then
            if next_prog_idx <= #agents and (now - last_prog_add) >= prog_sec then
                while next_prog_idx <= #agents do
                    local a = agents[next_prog_idx]
                    next_prog_idx = next_prog_idx + 1
                    if (a.status or "") ~= "Logged Out" then
                        log("NOTICE", string.format(
                            "  PROGRESSIVE: [%d] ext=%s po %ds",
                            next_prog_idx-1, a.extension or "?", now-last_prog_add))
                        ring_agent(a, caller_uuid, caller_did, log)
                        last_prog_add = now
                        break
                    end
                end
            end
            if next_prog_idx > #agents and active == 0 then
                log("INFO", "  PROGRESSIVE: restart cyklu")
                next_prog_idx = 1; last_prog_add = now
                for _, a in ipairs(agents) do
                    if (a.status or "") ~= "Logged Out" then
                        ring_agent(a, caller_uuid, caller_did, log)
                    end
                end
            end
        else
            if active == 0 and #agents > 0 then
                log("INFO", "  RINGALL: ponawiam elapsed=" .. elapsed .. "s")
                for _, a in ipairs(agents) do
                    if (a.status or "") ~= "Logged Out" then
                        ring_agent(a, caller_uuid, caller_did, log)
                    end
                end
            end
        end

        log("DEBUG", string.format("  tick %ds active=%d", elapsed, active))
    end

    -- ── Finalizacja ───────────────────────────────────────────────────────────
    local elapsed = os.time() - queue_start
    sep(log, string.format("EXIT elapsed=%ds answered=%s ready=%s",
        elapsed, tostring(answered_by), tostring(session:ready())))

    if answered_by and session:ready() then
        cancel_agents(caller_uuid, answered_by, log)
        -- Zdejmij hold zanim intercept
        moh_stop(caller_uuid, log)

        local api = freeswitch.API()

        -- Zapisz rotację FIFO
        local agent_db_id = (api:execute("uuid_getvar",
            answered_by .. " fifo_agent_db_id") or ""):match("^%s*(.-)%s*$")
        if agent_db_id ~= "" and agent_db_id ~= "_undef_" then
            mark_agent_answered(agent_db_id, log)
        end

        -- INTERCEPT: przejmuje kanał agenta do bieżącej sesji klienta
        -- Działa nawet gdy kanał agenta jest w środku skryptu Lua
        log("NOTICE", "  INTERCEPT: " .. answered_by)
        session:execute("intercept", answered_by)
        log("NOTICE", "  rozmowa zakończona")

        session:setVariable("fifo_status",   "answered")
        session:setVariable("wait_time_sec", tostring(elapsed))

    elseif session:ready() then
        cancel_agents(caller_uuid, "", log)
        moh_stop(caller_uuid, log)
        session:setVariable("fifo_status",   "timeout")
        session:setVariable("wait_time_sec", tostring(elapsed))
        handle_timeout(fifo, log)
    else
        cancel_agents(caller_uuid, "", log)
        log("NOTICE", "  klient rozłączył się po " .. elapsed .. "s")
        session:setVariable("fifo_status",   "abandoned")
        session:setVariable("wait_time_sec", tostring(elapsed))
    end

    log("NOTICE", "  ACTION_FIFO DONE")
end

if argv and argv[1] then M.run(argv[1]) end
return M
