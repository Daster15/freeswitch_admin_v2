-- =============================================================================
-- action_pstn.lua
-- Przekazuje połączenie na numer zewnętrzny PSTN z właściwym caller_id.
--
-- Dialstring:
--   {absolute_codec_string=PCMA,
--    origination_caller_id_name=<pstn_cli>,
--    origination_caller_id_number=<pstn_cli>}sofia/gateway/<gw>/<numer>
--
-- CLI pobierany z puli PSTN firmy (freeswitch_pstn_number).
-- Jeśli pula pusta — gateway użyje własnego CLI.
--
-- Użycie:
--   require("action_pstn").run(numer_docelowy, log_fn)
--   require("action_pstn").bridge_str(numer_docelowy)  -- samo budowanie stringa
-- =============================================================================
local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db  = require("odoo_db")
local cfg = db.company_config()

local M = {}

-- ── Pobierz CLI z puli PSTN firmy (cache w obrębie jednego wywołania lua) ────

local _cli_cache = nil

local function get_cli()
    if _cli_cache ~= nil then return _cli_cache end

    local row = db.query_one(string.format([[
        SELECT n.number
        FROM   freeswitch_pstn_number n
        JOIN   freeswitch_company_config c ON c.id = n.config_id
        WHERE  c.company_id = %d
          AND  n.active     = true
        ORDER  BY n.number
        LIMIT  1
    ]], cfg.company_id))

    _cli_cache = (row and row.number and row.number ~= "") and row.number or ""
    return _cli_cache
end

-- ── Zbuduj dialstring ─────────────────────────────────────────────────────────

function M.bridge_str(number)
    local cli     = get_cli()
    local gateway = cfg.gateway or "default"
    local codec   = "PCMA"

    local chan_vars
    if cli ~= "" then
        chan_vars = string.format(
            "absolute_codec_string=%s,origination_caller_id_name=%s,origination_caller_id_number=%s",
            codec, cli, cli)
    else
        chan_vars = string.format("absolute_codec_string=%s", codec)
    end

    return string.format("{%s}sofia/gateway/%s/%s", chan_vars, gateway, number), cli
end

-- ── Wykonaj akcję bridge na PSTN ─────────────────────────────────────────────

function M.run(number, log)
    log = log or function(l, m) freeswitch.consoleLog(l, "[action_pstn] " .. m) end

    if not number or number == "" then
        log("ERR", "Brak numeru docelowego — hangup")
        return
    end

    local ds, cli = M.bridge_str(number)

    log("INFO", string.format("AKCJA: PSTN  cel=%s  cli=%s", number, cli ~= "" and cli or "(brak)"))
    log("INFO", "  bridge: " .. ds)

    session:setVariable("odoo_route_type",   "pstn")
    session:setVariable("odoo_route_target", number)

    session:execute("bridge", ds)

    local cause = session:getVariable("originate_disposition") or
                  session:getVariable("hangup_cause") or ""
    log("INFO", "  bridge zakończony: cause=" .. cause)
end

return M
