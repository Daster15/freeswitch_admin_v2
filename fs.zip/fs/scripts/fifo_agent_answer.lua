-- =============================================================================
-- fifo_agent_answer.lua
-- Wywoływany przez originate gdy agent odbierze telefon.
--
-- Rola:
--   1. Sprawdź czy klient żyje
--   2. Ustaw fifo_answered_by na kanale klienta → budzi pętlę action_fifo.lua
--   3. Trzymaj kanał agenta otwarty — action_fifo.lua wykona intercept
--   4. Po intercept — kanał przejęty przez FS, ten skrypt kończy się sam
--      gdy rozmowa się zakończy (session:ready() zwróci false)
--
-- DLACZEGO INTERCEPT DZIAŁA:
--   intercept "wciąga" kanał agenta do sesji klienta bezpośrednio przez FS.
--   Nie wymaga żeby kanał agenta był "wolny" — działa nawet gdy jest w Lua.
--   Po intercept bridge jest zarządzany przez FS, nie przez Lua.
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local caller_uuid = argv[1] or ""
local agent_db_id = argv[2] or ""

local function log(lvl, msg)
    freeswitch.consoleLog(lvl, "[fifo_agent] " .. msg .. "\n")
end

if caller_uuid == "" then
    log("WARN", "brak caller_uuid — kończę")
    return
end

local agent_uuid = session:getVariable("uuid") or ""
log("NOTICE", string.format(
    "ANSWER: agent=%s db_id=%s caller=%s", agent_uuid, agent_db_id, caller_uuid))

local api = freeswitch.API()

-- Sprawdź czy klient jeszcze żyje
local alive = (api:execute("uuid_exists", caller_uuid) or ""):match("^%s*(.-)%s*$")
if alive ~= "true" then
    log("INFO", "klient rozłączony — kończę")
    return
end

-- Sygnalizuj action_fifo.lua że ten agent odebrał
-- action_fifo.lua sprawdza tę zmienną w pętli co LOOP_MS
local r = api:execute("uuid_setvar", caller_uuid .. " fifo_answered_by " .. agent_uuid)
log("NOTICE", "  fifo_answered_by=" .. agent_uuid
           .. " → " .. (r or ""):match("^%s*(.-)%s*$"))

-- Trzymaj kanał agenta otwarty
-- action_fifo.lua wykona session:execute("intercept", agent_uuid)
-- Po intercept:
--   - FS łączy kanał agenta z kanałem klienta
--   - session:ready() na kanale agenta zostaje false gdy rozmowa się kończy
--   - ten skrypt kończy się naturalnie

-- Czekaj na intercept (max 10s)
local MAX_WAIT_MS  = 10000
local STEP_MS      = 200
local waited       = 0
local intercepted  = false

log("INFO", "  czekam na intercept (max 10s)...")

while waited < MAX_WAIT_MS do
    -- Jeśli session:ready() zwróci false — intercept nastąpił lub klient zniknął
    if not session:ready() then
        log("NOTICE", "  session nie ready — intercept nastąpił lub klient zniknął")
        intercepted = true
        break
    end

    session:execute("sleep", tostring(STEP_MS))
    waited = waited + STEP_MS

    -- Sprawdź czy intercept nastąpił przez bridge_uuid na tym kanale
    local buu = (api:execute("uuid_getvar",
        agent_uuid .. " bridge_uuid") or ""):match("^%s*(.-)%s*$")
    if buu ~= "" and buu ~= "_undef_" and buu ~= "false" then
        log("NOTICE", "  bridge_uuid=" .. buu .. " — intercept OK")
        intercepted = true
        break
    end

    -- Klient żyje?
    local c = (api:execute("uuid_exists", caller_uuid) or ""):match("^%s*(.-)%s*$")
    if c ~= "true" then
        log("INFO", "  klient zniknął — kończę")
        return
    end
end

if not intercepted then
    log("WARN", string.format("  intercept nie nastąpił po %dms — kończę", waited))
    return
end

-- Po intercept: kanał agenta jest bridgowany z klientem przez FS
-- Pozostajemy w pętli żeby nie zamknąć kanału przed końcem rozmowy
log("INFO", "  intercept OK — trzymam kanał podczas rozmowy")

local MAX_CALL_S = 7200  -- max 2h rozmowy
local call_sec   = 0
while session:ready() and call_sec < MAX_CALL_S do
    session:execute("sleep", "2000")
    call_sec = call_sec + 2
end

log("INFO", string.format("  koniec rozmowy: agent=%s czas=%ds", agent_uuid, call_sec))
