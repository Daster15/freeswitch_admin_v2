-- =============================================================================
-- cdr_writer.lua
-- Zapisuje CDR do tabeli freeswitch_cdr w bazie Odoo (PostgreSQL).
-- Model: freeswitch.cdr    tabela: freeswitch_cdr
--
-- Kolumny zgodne z call_record.py:
--   fs_uuid, caller_id_name, caller_id_num, destination_num,
--   direction, status, start_time, answer_time, end_time,
--   duration_sec, billsec, wait_time_sec, hangup_cause,
--   recording_path, route_type, route_target,
--   queue_name, agent_id, ivr_name, ivr_selections, placowka
--
-- Wywoanie z dialplanu:
--   <action application="lua" data="cdr_writer.lua"/>
-- =============================================================================
local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db = require("odoo_db")

--  Pomocnicze 

local function var(name, default)
    local v = session:getVariable(name)
    if v == nil or v == "" then return default or "" end
    return v
end

local function epoch_to_ts(epoch_str)
    local e = tonumber(epoch_str)
    if not e or e == 0 then return "NULL" end
    -- FreeSWITCH zwraca mikrosekundy w niektrych zmiennych  normalizuj
    if e > 9999999999 then e = math.floor(e / 1000000) end
    return string.format("to_timestamp(%d)", e)
end

-- start_epoch moe by 0 dla pocze ktre nie doszy do skutku.
-- Fallback kolejno na: start_epoch  created_epoch  Event-Date-Timestamp  NOW()
local function start_ts()
    local candidates = {
        var("start_epoch"),
        var("created_epoch"),
        var("Event-Date-Timestamp"),
    }
    for _, v in ipairs(candidates) do
        local e = tonumber(v)
        if e and e > 0 then
            if e > 9999999999 then e = math.floor(e / 1000000) end
            return string.format("to_timestamp(%d)", e)
        end
    end
    return "NOW()"   -- absolutny fallback  przynajmniej bdzie data
end

local function safe_int(val, default)
    return tostring(tonumber(val) or default or 0)
end

--  Oblicz status 
-- UWAGA: billsec na kanale callera jest zawsze 0 w mod_callcenter i mod_fifo
-- bo billing jest liczony na kanale B (agenta), nie na kanale callera.
-- Dlatego sprawdzamy dodatkowe zmienne ustawiane przez te moduy.

local billsec      = tonumber(var("billsec", "0")) or 0
local hangup_cause = var("hangup_cause", "")
local route_type   = var("odoo_route_type", "")

-- mod_callcenter ustawia cc_cause="answered" gdy agent odebra
local cc_cause     = var("cc_cause", "")
local cc_agent     = var("cc_agent_called", "")

-- mod_fifo ustawia fifo_status="answered" gdy agent odebra
local fifo_status  = var("fifo_status", "")

-- NOWE: ujednolicone zmienne ustawiane przez action_callcenter/action_fifo
local odoo_answered = var("odoo_answered", "")   -- "true" / "false"
local odoo_agent    = var("odoo_agent_name", "") -- czytelna nazwa agenta bez domeny
local odoo_wait_sec = tonumber(var("odoo_wait_sec", "0")) or 0
local odoo_talk_sec = tonumber(var("odoo_talk_sec", "0")) or 0

-- mod_callcenter: cc_cause moze byc "answered" LUB "success" w roznych wersjach FS
-- Sprawdzamy obie wartosci
local cc_answered = (cc_cause == "answered" or cc_cause == "success")

-- Wykryj odebranie przez agenta w kolejce
-- UWAZNE: sprawdzamy wiele zrodel bo rozne sciezki (IVR->CC, bezposrednie) ustawiaja rozne zmienne
local answered_by_agent =
    odoo_answered == "true" or           -- ustawiane przez action_callcenter/action_fifo
    odoo_talk_sec > 0 or                 -- jest czas rozmowy = ktos odebral
    (cc_answered and cc_agent ~= "") or  -- natywne mod_callcenter
    (fifo_status == "answered") or       -- natywne mod_fifo (ustawiane przez action_fifo)
    (var("cc_agent", "") ~= "" and var("cc_agent", "") ~= "false")  -- agent w sesji

-- Faktyczny czas rozmowy: priorytety: odoo_talk_sec -> cc_talk_time -> fifo_talk_time
local talk_time = odoo_talk_sec
if talk_time == 0 then
    talk_time = tonumber(var("cc_talk_time", "0")) or 0
end
if talk_time == 0 then
    talk_time = tonumber(var("fifo_talk_time", "0")) or 0
end
-- Fallback: duration - wait (przyblizone)
if talk_time == 0 then
    local dur  = tonumber(var("duration", "0")) or 0
    local wait = odoo_wait_sec > 0 and odoo_wait_sec or
                 (tonumber(var("wait_time_sec", "0")) or 0)
    if dur > wait and wait > 0 then talk_time = dur - wait end
end

-- Czytelna nazwa agenta (priorytet: nowe odoo_agent_name, potem cc_agent_called)
local agent_display = odoo_agent
if agent_display == "" then agent_display = cc_agent end
if agent_display == "" then
    local raw = var("cc_agent", "")
    if raw ~= "" then agent_display = raw:match("^([^@]+)") or raw end
end

-- Faktyczny czas oczekiwania
local wait_sec = odoo_wait_sec
if wait_sec == 0 then
    wait_sec = tonumber(var("wait_time_sec", "0")) or 0
end

-- Uzupelnij billsec z talk_time jeli billsec=0 ale rozmowa bya
if billsec == 0 and talk_time > 0 then
    billsec = talk_time
end

local status
if billsec > 0 or answered_by_agent or talk_time > 0 then
    status = "completed"
elseif hangup_cause == "NO_ANSWER" or hangup_cause == "PROGRESS_TIMEOUT" then
    status = "no_answer"
elseif hangup_cause == "ORIGINATOR_CANCEL" then
    -- Dzwonicy rozczy si podczas oczekiwania w kolejce
    if route_type == "callcenter" or route_type == "fifo" then
        status = "cancelled"
    else
        status = "cancelled"
    end
elseif hangup_cause == "USER_BUSY" or hangup_cause == "CALL_REJECTED" then
    status = "busy"
elseif hangup_cause == "SUBSCRIBER_ABSENT"
    or hangup_cause == "NO_ROUTE_DESTINATION"
    or hangup_cause == "USER_NOT_REGISTERED" then
    status = "no_answer"
elseif hangup_cause == "NORMAL_CLEARING" and (route_type == "callcenter" or route_type == "fifo") then
    -- NORMAL_CLEARING na kanale callera po wyjciu z kolejki bez agenta = porzucone
    status = "cancelled"
else
    status = "failed"
end

-- Uzupenij billsec z talk_time jeli billsec=0 ale rozmowa bya
if billsec == 0 and talk_time > 0 then
    billsec = talk_time
end

--  Walidacja UUID 

local uuid = var("uuid")
if uuid == "" then
    freeswitch.consoleLog("WARN", "[cdr_writer.lua] Brak UUID  pomijam zapis CDR")
    return
end

freeswitch.consoleLog("INFO",
    "[cdr_writer.lua] uuid=" .. uuid ..
    " status=" .. status ..
    " agent=" .. (agent_display ~= "" and agent_display or "(brak)") ..
    " wait=" .. tostring(wait_sec) .. "s" ..
    " talk=" .. tostring(talk_time) .. "s" ..
    " billsec=" .. tostring(billsec) ..
    " ivr_sel=" .. (var("odoo_ivr_selections") ~= "" and var("odoo_ivr_selections") or "(brak)"))

--  Sprawd czy rekord ju istnieje 

local existing = db.query_one(string.format(
    "SELECT id FROM freeswitch_cdr WHERE fs_uuid = %s LIMIT 1",
    db.esc(uuid)
))

--  Dane do zapisu (kolumny 1:1 z modelem call_record.py) 

local cols = {
    "fs_uuid",
    "caller_id_name",
    "caller_id_num",
    "destination_num",
    "direction",
    "status",
    "start_time",
    "answer_time",
    "end_time",
    "duration_sec",
    "billsec",
    "wait_time_sec",
    "hangup_cause",
    "recording_path",
    "route_type",
    "route_target",
    "queue_name",
    "agent_id",
    "ivr_name",
    "ivr_selections",   --  historia wyborw DTMF: "menu:2  submenu:1  cc-kolejka"
    "placowka",
}

local values = {
    db.esc(uuid),
    db.esc(var("caller_id_name")),
    db.esc(var("caller_id_number")),
    db.esc(var("destination_number")),
    db.esc(var("call_direction", "inbound")),
    db.esc(status),
    start_ts(),                           -- start_time z fallbackiem
    epoch_to_ts(var("answer_epoch")),
    epoch_to_ts(var("end_epoch")),
    safe_int(var("duration")),
    tostring(billsec),  -- local billsec (may be updated from cc_talk_time/fifo_talk_time)
    tostring(wait_sec),                    -- faktyczny czas oczekiwania w kolejce
    db.esc(hangup_cause),
    db.esc(var("recording_file")),
    db.esc(var("odoo_route_type")),
    db.esc(var("odoo_route_target")),
    db.esc(var("odoo_route_target")),  -- queue_name = odoo_route_target (bez domeny, zawsze poprawne)
    db.esc(agent_display),                 -- czytelna nazwa agenta ktory odebral
    db.esc(var("odoo_ivr_name")),
    db.esc(var("odoo_ivr_selections")),   --  zmienna ustawiana przez ivr.lua
    db.esc(var("odoo_placowka")),
}

--  INSERT lub UPDATE 

if existing then
    -- UPDATE  pomijamy fs_uuid (klucz)
    local set_parts = {}
    for i, col in ipairs(cols) do
        if col ~= "fs_uuid" then
            table.insert(set_parts, col .. " = " .. values[i])
        end
    end
    local sql = string.format(
        "UPDATE freeswitch_cdr SET %s WHERE fs_uuid = %s",
        table.concat(set_parts, ", "),
        db.esc(uuid)
    )
    db.execute(sql)
    freeswitch.consoleLog("INFO",
        "[cdr_writer.lua] CDR zaktualizowany: uuid=" .. uuid)
else
    -- INSERT
    local sql = string.format(
        "INSERT INTO freeswitch_cdr (%s) VALUES (%s)",
        table.concat(cols, ", "),
        table.concat(values, ", ")
    )
    db.execute(sql)
    freeswitch.consoleLog("INFO",
        "[cdr_writer.lua] CDR zapisany: uuid=" .. uuid)
end
