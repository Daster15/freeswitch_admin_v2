-- =============================================================================
-- action_user.lua
-- Obsługa połączenia do użytkownika SIP z wieloma urządzeniami.
-- Tabele Odoo: freeswitch_sip_user, freeswitch_sip_device
--
-- Użycie:
--   require("action_user").run(ext, log_fn)
-- =============================================================================

local FS_SCRIPTS = "/usr/local/freeswitch/scripts"
package.path = FS_SCRIPTS .. "/?.lua;" .. package.path

local db  = require("odoo_db")
local cfg = db.company_config()

local M = {}

-- ── Wykonaj akcję fallback po nieudanym bridge ────────────────────────────────

local function do_fallback(action, target, log)
    action = action or "hangup"
    target = target or ""
    log("INFO", string.format("  fallback → action=%-12s  target=%s", action, target))

    if action == "ivr" and target ~= "" then
        require("ivr").run(target)

    elseif action == "fifo" and target ~= "" then
        session:setVariable("odoo_route_type",   "fifo")
        session:setVariable("odoo_route_target", target)
        session:execute("fifo",
            target .. "@" .. cfg.sip_domain ..
            " in /usr/share/freeswitch/sounds/en/us/callie/ivr/8000/ivr-hold_connect_call.wav")

    elseif action == "callcenter" and target ~= "" then
        session:setVariable("odoo_route_type",   "callcenter")
        session:setVariable("odoo_route_target", target)
        session:execute("callcenter", target .. "@" .. cfg.sip_domain)

    elseif action == "user" and target ~= "" then
        -- Rekurencja do innego użytkownika (1 poziom głębokości)
        M.run(target, log)

    elseif action == "pstn" and target ~= "" then
        require("action_pstn").run(target, log)

    elseif action == "voicemail" and target ~= "" then
        session:execute("voicemail",
            "default " .. cfg.sip_domain .. " " .. target)

    else
        log("WARN", "  fallback: hangup (action=" .. action .. ", target=" .. target .. ")")
    end
end

-- ── Główna funkcja ────────────────────────────────────────────────────────────

function M.run(ext, log)
    log = log or function(l, m) freeswitch.consoleLog(l, "[action_user] " .. m) end

    log("INFO", string.format("AKCJA: UŻYTKOWNIK SIP  ext=%s", ext))

    -- Pobierz użytkownika
    local user_row = db.query_one(string.format([[
        SELECT id, noanswer_timeout, noanswer_action, noanswer_target,
               busy_action, busy_target,
               unreg_action, unreg_target,
               first_name, last_name, outbound_caller_id
        FROM   freeswitch_sip_user
        WHERE  name       = %s
          AND  company_id = %d
          AND  active     = true
        LIMIT  1
    ]], db.esc(ext), cfg.company_id))

    if not user_row then
        log("WARN", "  Nie znaleziono użytkownika ext=" .. ext .. " → hangup")
        return
    end

    -- ── Caller ID ─────────────────────────────────────────────────────────
    -- Priorytet: outbound_caller_id z Odoo → numer wewnętrzny jako fallback
    local cid_num = (user_row.outbound_caller_id and user_row.outbound_caller_id ~= "")
                    and user_row.outbound_caller_id or ext
    local fn = user_row.first_name or ""
    local ln = user_row.last_name  or ""
    local cid_name = (fn .. " " .. ln):match("^%s*(.-)%s*$")
    if cid_name == "" then cid_name = cid_num end

    log("INFO", string.format("  caller_id: num=%s  name=%s", cid_num, cid_name))

    -- Zmienne FreeSWITCH caller ID — do użycia w każdym device_dial()
    local cid_vars = string.format(
        "{origination_caller_id_number=%s,origination_caller_id_name=%s}",
        cid_num, cid_name
    )

    -- Pobierz aktywne urządzenia posortowane wg sequence
    local devices = db.query_all(string.format([[
        SELECT d.device_type, d.ring_strategy, d.sequence,
               d.mobile_number, d.mobile_gateway,
               d.label,
               lu.name AS linked_user_ext
        FROM   freeswitch_sip_device d
        LEFT   JOIN freeswitch_sip_user lu ON lu.id = d.linked_user_id
        WHERE  d.user_id = %d
          AND  d.active  = true
        ORDER  BY d.sequence
    ]], tonumber(user_row.id)))

    if #devices == 0 then
        log("WARN", "  Brak aktywnych urządzeń → bridge bezpośredni")
        session:execute("bridge", cid_vars .. "sofia/internal/" .. ext .. "@" .. cfg.sip_domain)
        local cause = session:getVariable("originate_disposition") or
                      session:getVariable("hangup_cause") or ""
        log("INFO", "  bridge cause=" .. cause)
        if cause ~= "NORMAL_CLEARING" and cause ~= "SUCCESS" and cause ~= "" and cause ~= "ORIGINATOR_CANCEL" then
            if cause == "SUBSCRIBER_ABSENT" or cause == "NO_ROUTE_DESTINATION" or cause == "USER_NOT_REGISTERED" then
                do_fallback(user_row.unreg_action, user_row.unreg_target, log)
            elseif cause == "NO_ANSWER" or cause == "PROGRESS_TIMEOUT" then
                do_fallback(user_row.noanswer_action, user_row.noanswer_target, log)
            elseif cause == "USER_BUSY" or cause == "CALL_REJECTED" then
                do_fallback(user_row.busy_action, user_row.busy_target, log)
            end
        end
        return
    end

    log("INFO", string.format("  znaleziono %d urządzeń", #devices))

    -- ── Buduj dial string dla urządzenia ─────────────────────────────────────
    local function device_dial(dev)
        local label = dev.label or dev.device_type or "?"

        if dev.mobile_number and dev.mobile_number ~= "" then
            local gw = (dev.mobile_gateway and dev.mobile_gateway ~= "")
                       and dev.mobile_gateway or cfg.gateway
            local ds = cid_vars .. "sofia/gateway/" .. gw .. "/" .. dev.mobile_number
            log("INFO", string.format("    [%s] PSTN %s gw=%s cid=%s → %s",
                label, dev.mobile_number, gw, cid_num, ds))
            return ds

        elseif dev.linked_user_ext and dev.linked_user_ext ~= "" then
            local ds = cid_vars .. "sofia/internal/" .. dev.linked_user_ext .. "@" .. cfg.sip_domain
            log("INFO", string.format("    [%s] linked SIP ext=%s cid=%s → %s",
                label, dev.linked_user_ext, cid_num, ds))
            return ds

        else
            local ds = cid_vars .. "sofia/internal/" .. ext .. "@" .. cfg.sip_domain
            log("INFO", string.format("    [%s] SIP ext=%s cid=%s → %s", label, ext, cid_num, ds))
            return ds
        end
    end

    -- ── Wybierz strategię ─────────────────────────────────────────────────────
    local timeout    = tonumber(user_row.noanswer_timeout) or 30
    local bridge_str = ""

    -- Exclusive — jedno urządzenie z wyłącznym dostępem
    local exclusive_dev = nil
    for _, dev in ipairs(devices) do
        if dev.ring_strategy == "exclusive" then
            exclusive_dev = dev
            break
        end
    end

    if exclusive_dev then
        log("INFO", string.format("  strategia: EXCLUSIVE [%s]",
            exclusive_dev.label or exclusive_dev.device_type))
        bridge_str = device_dial(exclusive_dev)

    else
        local sim_parts = {}
        local seq_parts = {}

        for _, dev in ipairs(devices) do
            if dev.ring_strategy == "sequential" then
                table.insert(seq_parts, device_dial(dev))
            else
                table.insert(sim_parts, device_dial(dev))
            end
        end

        local parts = {}

        if #sim_parts > 0 then
            log("INFO", string.format("  simultaneous: %d urządzeń", #sim_parts))
            table.insert(parts, table.concat(sim_parts, ":_:"))
        end

        if #seq_parts > 0 then
            log("INFO", string.format("  sequential: %d urządzeń", #seq_parts))
            for _, p in ipairs(seq_parts) do
                table.insert(parts, p)
            end
        end

        log("INFO", string.format("  strategia: SIM(%d) + SEQ(%d)", #sim_parts, #seq_parts))
        bridge_str = table.concat(parts, string.format(
            "|{call_timeout=%d}", timeout))
    end

    log("INFO", "  bridge: " .. bridge_str)
    -- Ustaw też na poziomie sesji jako backup
    session:setVariable("origination_caller_id_number", cid_num)
    session:setVariable("origination_caller_id_name",   cid_name)
    session:execute("bridge", string.format(
        "{call_timeout=%d}%s", timeout, bridge_str))

    -- ── Obsługa cause po bridge ───────────────────────────────────────────────

    local cause = session:getVariable("originate_disposition") or ""
    local hcause = session:getVariable("hangup_cause") or ""

    log("INFO", "  originate_disposition=" .. cause)
    log("INFO", "  hangup_cause=" .. hcause)

    -- Użyj originate_disposition jeśli dostępny, inaczej hangup_cause
    if cause == "" then cause = hcause end

    log("INFO", "  bridge zakończony: cause=" .. cause)

    -- Sprawdź czy dzwoniący sam się rozłączył (ORIGINATOR_CANCEL)
    if cause == "ORIGINATOR_CANCEL" or cause == "NORMAL_CLEARING" or cause == "SUCCESS" or cause == "" then
        log("INFO", "  rozmowa zakończona normalnie lub przerwana przez dzwoniącego")
        return
    end

    if cause == "SUBSCRIBER_ABSENT"    or
       cause == "NO_ROUTE_DESTINATION" or
       cause == "USER_NOT_REGISTERED"  then

        log("WARN", "  NIEZAREJESTROWANY (" .. cause .. ")")
        if user_row.unreg_action and user_row.unreg_action ~= "" then
            do_fallback(user_row.unreg_action, user_row.unreg_target, log)
        else
            log("WARN", "  brak unreg_action — hangup")
        end

    elseif cause == "NO_ANSWER" or cause == "PROGRESS_TIMEOUT" then

        log("WARN", "  NIE ODBIERA (" .. cause .. ")")
        if user_row.noanswer_action and user_row.noanswer_action ~= "" then
            do_fallback(user_row.noanswer_action, user_row.noanswer_target, log)
        else
            log("WARN", "  brak noanswer_action — hangup")
        end

    elseif cause == "USER_BUSY" or cause == "CALL_REJECTED" then

        log("WARN", "  ZAJĘTY (" .. cause .. ")")
        if user_row.busy_action and user_row.busy_target ~= "" then
            do_fallback(user_row.busy_action, user_row.busy_target, log)
        else
            log("WARN", "  brak busy_action — hangup")
        end

    else
        log("WARN", "  nieobsłużony cause=" .. cause)
    end
end

return M
