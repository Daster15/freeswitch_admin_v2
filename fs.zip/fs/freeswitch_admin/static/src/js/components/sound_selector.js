/** @odoo-module **/
/**
 * SoundSelector
 * =============
 * Współdzielony komponent do wyboru nagrania z freeswitch.sound.
 * Wyświetla select z listą plików + opcjonalny odtwarzacz audio.
 *
 * Props:
 *   - soundId    {Number|null}  - aktualnie wybrany ID
 *   - sounds     {Array}        - lista rekordów { id, name, audio_fname, fs_path, audio_url }
 *   - label      {String}       - etykieta pola
 *   - required   {Boolean}
 *
 * Emits:
 *   - onChange(soundId, soundRecord)
 */
import { Component, useState } from "@odoo/owl";

export class SoundSelector extends Component {
    static template = "freeswitch_admin.SoundSelector";
    static props = {
        soundId:  { type: [Number, Boolean], optional: true },
        sounds:   { type: Array },
        label:    { type: String, optional: true },
        required: { type: Boolean, optional: true },
        onChange: { type: Function },
    };

    setup() {
        this.state = useState({ playing: false });
        this.audioEl = null;

        this.onChange    = this.onChange.bind(this);
        this.togglePlay  = this.togglePlay.bind(this);
        this.stopAudio   = this.stopAudio.bind(this);
    }

    get selectedSound() {
        if (!this.props.soundId) return null;
        return this.props.sounds.find(s => s.id === this.props.soundId) || null;
    }

    get audioUrl() {
        const s = this.selectedSound;
        if (!s) return null;
        return s.audio_url || (s.audio_fname ? `/web/content/freeswitch.sound/${s.id}/audio_file` : null);
    }

    onChange(ev) {
        const id  = parseInt(ev.target.value) || null;
        const rec = id ? this.props.sounds.find(s => s.id === id) : null;
        this.stopAudio();
        this.props.onChange(id, rec);
    }

    togglePlay() {
        if (!this.audioUrl) return;
        if (this.state.playing) {
            this.stopAudio();
        } else {
            this.audioEl = new Audio(this.audioUrl);
            this.audioEl.onended = () => { this.state.playing = false; };
            this.audioEl.play().catch(() => { this.state.playing = false; });
            this.state.playing = true;
        }
    }

    stopAudio() {
        if (this.audioEl) { this.audioEl.pause(); this.audioEl = null; }
        this.state.playing = false;
    }
}