/** @odoo-module **/
import { Component, useState } from "@odoo/owl";
import { SoundSelector } from "@freeswitch_admin/js/components/sound_selector";

const AFTER_ACTIONS = [
    { value: 'hangup',      label: '📵 Rozłącz połączenie' },
    { value: 'ivr',         label: '🎛 Przejdź do menu IVR' },
    { value: 'fifo',        label: '📋 Przejdź do kolejki FIFO' },
    { value: 'callcenter',  label: '🏢 Przejdź do kolejki CC' },
    { value: 'user',        label: '👤 Przekaż do użytkownika SIP' },
    { value: 'pstn',        label: '🌐 Przekaż na numer zewnętrzny' },
    { value: 'repeat',      label: '🔁 Powtórz nagranie' },
];

export class AudioPlayerPanel extends Component {
    static template   = "freeswitch_admin.AudioPlayerPanel";
    static components = { SoundSelector };
    static props = {
        node:     { type: Object },
        sounds:   { type: Array },
        records:  { type: Object },
        onApply:  { type: Function },
        onDelete: { type: Function },
        onClose:  { type: Function },
    };

    setup() {
        const cfg = this.props.node.config || {};
        this.state = useState({
            label:           this.props.node.label || 'Odtwórz Nagranie',
            sound_id:        cfg.sound_id        || null,
            after_action:    cfg.after_action    || 'hangup',
            after_target_id: cfg.after_target_id || null,
            after_pstn:      cfg.after_pstn      || '',
            playing:         false,
        });
        this._audioEl = null;

        this.onSoundChange       = this.onSoundChange.bind(this);
        this.onAfterActionChange = this.onAfterActionChange.bind(this);
        this.onTargetChange      = this.onTargetChange.bind(this);
        this.togglePlay          = this.togglePlay.bind(this);
        this.stopAudio           = this.stopAudio.bind(this);
        this.apply               = this.apply.bind(this);
    }

    get afterActions() { return AFTER_ACTIONS; }

    get needsRecord() {
        return ['ivr', 'fifo', 'callcenter', 'user'].includes(this.state.after_action);
    }

    get needsPstn() {
        return this.state.after_action === 'pstn';
    }

    // hangup i repeat nie generują portu wyjściowego
    get hasDonePort() {
        return !['hangup', 'repeat'].includes(this.state.after_action);
    }

    get targetRecords() {
        const r = this.props.records || {};
        const action = this.state.after_action;
        if (action === 'ivr')        return r.ivr        || [];
        if (action === 'fifo')       return r.fifo       || [];
        if (action === 'callcenter') return r.callcenter || [];
        if (action === 'user')       return r.user       || [];
        return [];
    }

    recordLabel(rec) {
        return rec.name || rec.display_name_full || ('#' + rec.id);
    }

    get selectedSoundName() {
        if (!this.state.sound_id) return '';
        const s = this.props.sounds.find(x => x.id === this.state.sound_id);
        return s ? (s.name || s.audio_fname) : '#' + this.state.sound_id;
    }

    get audioUrl() {
        if (!this.state.sound_id) return null;
        const s = this.props.sounds.find(x => x.id === this.state.sound_id);
        return s ? (s.audio_url || `/web/content/freeswitch.sound/${s.id}/audio_file`) : null;
    }

    onSoundChange(soundId) {
        this.stopAudio();
        this.state.sound_id = soundId;
    }

    onAfterActionChange(ev) {
        this.state.after_action    = ev.target.value;
        this.state.after_target_id = null;
        this.state.after_pstn      = '';
    }

    onTargetChange(ev) {
        this.state.after_target_id = parseInt(ev.target.value) || null;
    }

    togglePlay() {
        if (this.state.playing) {
            this.stopAudio();
        } else {
            const url = this.audioUrl;
            if (!url) return;
            this._audioEl = new Audio(url);
            this._audioEl.onended = () => { this.state.playing = false; };
            this._audioEl.onerror = () => { this.state.playing = false; };
            this._audioEl.play().catch(() => { this.state.playing = false; });
            this.state.playing = true;
        }
    }

    stopAudio() {
        if (this._audioEl) { this._audioEl.pause(); this._audioEl = null; }
        this.state.playing = false;
    }

    _resolveTarget() {
        const action = this.state.after_action;
        if (action === 'pstn') return this.state.after_pstn || '';
        if (!this.state.after_target_id) return '';
        const rec = this.targetRecords.find(r => r.id === this.state.after_target_id);
        return rec ? (rec.name || rec.extension || '') : '';
    }

    apply() {
        this.props.onApply({
            ...this.props.node,
            label:   this.state.label,
            odoo_id: this.state.sound_id,
            config: {
                sound_id:        this.state.sound_id,
                sound_name:      this.selectedSoundName,
                after_action:    this.state.after_action,
                after_target_id: this.state.after_target_id,
                after_pstn:      this.state.after_pstn,
                after_target:    this._resolveTarget(),
                has_done_port:   this.hasDonePort,
            },
        });
    }
}