/** @odoo-module **/
import { Component, useState } from "@odoo/owl";

const DAYS = [
    { key: 'mon', label: 'Pn' },
    { key: 'tue', label: 'Wt' },
    { key: 'wed', label: 'Śr' },
    { key: 'thu', label: 'Cz' },
    { key: 'fri', label: 'Pt' },
    { key: 'sat', label: 'Sb' },
    { key: 'sun', label: 'Nd' },
];

const COUNTRIES = [
    { value: 'PL', label: '🇵🇱 Polska' },
    { value: 'DE', label: '🇩🇪 Niemcy' },
    { value: 'GB', label: '🇬🇧 Wielka Brytania' },
    { value: 'FR', label: '🇫🇷 Francja' },
    { value: 'US', label: '🇺🇸 USA' },
    { value: 'CZ', label: '🇨🇿 Czechy' },
    { value: 'SK', label: '🇸🇰 Słowacja' },
    { value: 'UA', label: '🇺🇦 Ukraina' },
];

const ACTION_TYPES = [
    { value: '',           label: '— wybierz —' },
    { value: 'ivr',        label: '🎛 Menu IVR' },
    { value: 'callcenter', label: '🏢 Call Center' },
    { value: 'playback',   label: '🎵 Odtwórz nagranie' },
    { value: 'pstn',       label: '🌐 Numer PSTN' },
];

export class DidPanel extends Component {
    static template = "freeswitch_admin.DidPanel";
    static props = {
        node:     { type: Object },
        records:  { type: Array },
        onApply:  { type: Function },
        onDelete: { type: Function },
        onClose:  { type: Function },
        orm:      { type: Object },
    };

    setup() {
        const cfg     = this.props.node.config || {};
        const defDays = { mon:true, tue:true, wed:true, thu:true, fri:true, sat:false, sun:false };
        const saved   = cfg.time_days || {};

        this.days        = DAYS;
        this.countries   = COUNTRIES;
        this.actionTypes = ACTION_TYPES;

        this.state = useState({
            label:       this.props.node.label || '',
            odoo_id:     this.props.node.odoo_id || null,
            pstn_number_id: cfg.pstn_number_id || null,
            did_pattern: cfg.did_pattern || '',
            description: cfg.description || '',
            priority:    cfg.priority    || '10',

            // ── Godziny pracy ────────────────────────────────────────────
            use_time_rules: cfg.use_time_rules ?? false,
            time_days: DAYS.reduce((acc, d) => {
                acc[d.key] = d.key in saved ? saved[d.key] : defDays[d.key];
                return acc;
            }, {}),
            time_start: cfg.time_start || '08:00',
            time_end:   cfg.time_end   || '17:00',
            timezone:   cfg.timezone   || 'Europe/Warsaw',
            // Akcja POZA godzinami → fallback_type / fallback_target
            fallback_type:   cfg.fallback_type   || '',
            fallback_target: cfg.fallback_target || '',
            fallback_oid:    cfg.fallback_oid    || null,

            // ── Dni wolne ────────────────────────────────────────────────
            use_holidays:          cfg.use_holidays          ?? false,
            holiday_country_code:  cfg.holiday_country_code  || 'PL',
            // Akcja W dzień wolny → holiday_action_type / holiday_action_target
            holiday_action_type:   cfg.holiday_action_type   || '',
            holiday_action_target: cfg.holiday_action_target || '',
            holiday_oid:           cfg.holiday_oid           || null,

            saving: false,
        });

        // listy rekordów per typ — ładowane z props.records (did records)
        // ale potrzebujemy IVR/FIFO/CC — wczytamy przez orm przy otwieraniu
        this._ivrList = [];
        this._fifoList = [];
        this._ccList = [];

        this.linkRecord  = this.linkRecord.bind(this);
        this.toggleDay   = this.toggleDay.bind(this);
        this.apply       = this.apply.bind(this);

        // Wczytaj listy docelowe asynchronicznie
        this._loadTargetLists();
    }

    async _loadTargetLists() {
        try {
            const [ivrs, ccs, pstnNums] = await Promise.all([
                this.props.orm.searchRead('freeswitch.ivr',         [['active','=',true]], ['id','name'],                   {order:'name',   limit:100}),
                this.props.orm.searchRead('freeswitch.cc.queue',    [['active','=',true]], ['id','name'],                   {order:'name',   limit:100}),
                this.props.orm.searchRead('freeswitch.pstn.number', [['active','=',true]], ['id','number','description'],   {order:'number', limit:200}),
            ]);
            this._ivrList   = ivrs;
            this._ccList    = ccs;
            this._pstnNums  = pstnNums;
        } catch(e) {
            console.warn('DidPanel: nie udało się wczytać list docelowych', e);
        }
    }

    get pstnNums() { return this._pstnNums || []; }

    onPstnNumberChange(ev) {
        const id  = parseInt(ev.target.value) || null;
        const rec = (this._pstnNums || []).find(r => r.id === id);
        this.state.pstn_number_id = id;
        this.state.did_pattern    = rec ? rec.number : '';
        if (rec && !this.state.description) {
            this.state.description = rec.description || rec.number;
        }
    }

    /** Zwróć listę rekordów dla danego typu akcji */
    targetList(actionType) {
        if (actionType === 'ivr')        return this._ivrList;
        if (actionType === 'callcenter') return this._ccList;
        return [];
    }

    get linkedRecord() {
        if (!this.state.odoo_id) return null;
        return this.props.records.find(r => r.id === this.state.odoo_id) || null;
    }

    get daysLabel() {
        return DAYS.filter(d => this.state.time_days[d.key]).map(d => d.label).join(' ') || '—';
    }

    get needsTargetSelect() {
        return (t) => ['ivr','callcenter'].includes(t);
    }

    get needsTextInput() {
        return (t) => t === 'pstn';
    }

    linkRecord(ev) {
        const id = parseInt(ev.target.value) || null;
        this.state.odoo_id = id;
        if (!id) return;
        const rec = this.props.records.find(r => r.id === id);
        if (!rec) return;
        this.state.pstn_number_id = rec.pstn_number_id?.[0] || null;
        this.state.did_pattern = rec.name        || '';
        this.state.description = rec.description || '';

        if (rec.use_time_rules !== undefined) this.state.use_time_rules = rec.use_time_rules;
        if (rec.fallback_type)  this.state.fallback_type   = rec.fallback_type;
        if (rec.fallback_target) this.state.fallback_target = rec.fallback_target;
        // M2O zwraca [id, name] lub false
        const fbOid = rec.fallback_ivr_id?.[0] || rec.fallback_cc_id?.[0] || null;
        this.state.fallback_oid = fbOid;

        if (rec.use_holidays !== undefined)  this.state.use_holidays = rec.use_holidays;
        if (rec.holiday_country_code)        this.state.holiday_country_code  = rec.holiday_country_code;
        if (rec.holiday_action_type)         this.state.holiday_action_type   = rec.holiday_action_type;
        if (rec.holiday_action_target)       this.state.holiday_action_target = rec.holiday_action_target;
        const holOid = rec.holiday_ivr_id?.[0] || rec.holiday_cc_id?.[0] || null;
        this.state.holiday_oid = holOid;
    }

    toggleDay(key) {
        this.state.time_days[key] = !this.state.time_days[key];
    }

    onFallbackTypeChange(ev) {
        this.state.fallback_type   = ev.target.value;
        this.state.fallback_target = '';
        this.state.fallback_oid    = null;
    }

    onFallbackTargetSelect(ev) {
        const id  = parseInt(ev.target.value) || null;
        const list = this.targetList(this.state.fallback_type);
        const rec  = list.find(r => r.id === id);
        this.state.fallback_oid    = id;
        this.state.fallback_target = rec ? rec.name : '';
    }

    onHolidayTypeChange(ev) {
        this.state.holiday_action_type   = ev.target.value;
        this.state.holiday_action_target = '';
        this.state.holiday_oid           = null;
    }

    onHolidayTargetSelect(ev) {
        const id  = parseInt(ev.target.value) || null;
        const list = this.targetList(this.state.holiday_action_type);
        const rec  = list.find(r => r.id === id);
        this.state.holiday_oid           = id;
        this.state.holiday_action_target = rec ? rec.name : '';
    }

    async apply() {
        console.log('[DidPanel] apply() start — odoo_id:', this.state.odoo_id);
        console.log('[DidPanel] state:', {
            use_time_rules: this.state.use_time_rules,
            fallback_type:  this.state.fallback_type,
            fallback_target: this.state.fallback_target,
            use_holidays:   this.state.use_holidays,
            holiday_action_type: this.state.holiday_action_type,
            holiday_action_target: this.state.holiday_action_target,
        });

        this.state.saving = true;
        try {
            if (this.state.odoo_id) {
                const vals = {
                    use_time_rules:       this.state.use_time_rules,
                    use_holidays:         this.state.use_holidays,
                    holiday_country_code: this.state.holiday_country_code,
                };

                if (this.state.use_time_rules && this.state.fallback_type) {
                    vals.fallback_type   = this.state.fallback_type;
                    vals.fallback_target = this.state.fallback_target || '';
                    vals.fallback_ivr_id  = false;
                    vals.fallback_cc_id   = false;
                    const oid = this.state.fallback_oid;
                    if (oid) {
                        if (this.state.fallback_type === 'ivr')             vals.fallback_ivr_id  = oid;
                        else if (this.state.fallback_type === 'callcenter') vals.fallback_cc_id   = oid;
                    }
                }

                if (this.state.use_holidays && this.state.holiday_action_type) {
                    vals.holiday_action_type   = this.state.holiday_action_type;
                    vals.holiday_action_target = this.state.holiday_action_target || '';
                    vals.holiday_ivr_id  = false;
                    vals.holiday_cc_id   = false;
                    const oid = this.state.holiday_oid;
                    if (oid) {
                        if (this.state.holiday_action_type === 'ivr')             vals.holiday_ivr_id  = oid;
                        else if (this.state.holiday_action_type === 'callcenter') vals.holiday_cc_id   = oid;
                    }
                }

                console.log('[DidPanel] orm.write freeswitch.route id=%d vals=', this.state.odoo_id, vals);
                try {
                    await this.props.orm.write('freeswitch.route', [this.state.odoo_id], vals);
                    console.log('[DidPanel] orm.write OK');
                } catch(e) {
                    console.error('[DidPanel] orm.write FAILED:', e);
                    throw e;
                }

                if (this.state.use_time_rules) {
                    console.log('[DidPanel] saving time_rule...');
                    const old = await this.props.orm.searchRead(
                        'freeswitch.route.time_rule',
                        [['route_id', '=', this.state.odoo_id]],
                        ['id']
                    );
                    if (old.length) {
                        await this.props.orm.unlink('freeswitch.route.time_rule', old.map(r => r.id));
                        console.log('[DidPanel] unlinked old time_rules:', old.map(r=>r.id));
                    }
                    const d = this.state.time_days;
                    const newId = await this.props.orm.create('freeswitch.route.time_rule', [{
                        route_id:   this.state.odoo_id,
                        sequence:   10,
                        name:       'Godziny pracy',
                        day_mon:    d.mon, day_tue: d.tue, day_wed: d.wed,
                        day_thu:    d.thu, day_fri: d.fri,
                        day_sat:    d.sat, day_sun: d.sun,
                        time_start: this.state.time_start,
                        time_end:   this.state.time_end,
                        timezone:   this.state.timezone,
                    }]);
                    console.log('[DidPanel] created time_rule id:', newId);
                }
            } else {
                console.warn('[DidPanel] brak odoo_id — pomiń zapis do Odoo');
            }

            this.props.onApply({
                ...this.props.node,
                label:   this.state.label,
                odoo_id: this.state.odoo_id,
                config: {
                    pstn_number_id:        this.state.pstn_number_id,
                    did_pattern:           this.state.did_pattern,
                    description:           this.state.description,
                    priority:              this.state.priority,
                    use_time_rules:        this.state.use_time_rules,
                    time_days:             { ...this.state.time_days },
                    time_start:            this.state.time_start,
                    time_end:              this.state.time_end,
                    timezone:              this.state.timezone,
                    fallback_type:         this.state.fallback_type,
                    fallback_target:       this.state.fallback_target,
                    fallback_oid:          this.state.fallback_oid,
                    use_holidays:          this.state.use_holidays,
                    holiday_country_code:  this.state.holiday_country_code,
                    holiday_action_type:   this.state.holiday_action_type,
                    holiday_action_target: this.state.holiday_action_target,
                    holiday_oid:           this.state.holiday_oid,
                },
            });
            console.log('[DidPanel] apply() done');
        } catch(e) {
            console.error('[DidPanel] apply() ERROR:', e);
        } finally {
            this.state.saving = false;
        }
    }
}