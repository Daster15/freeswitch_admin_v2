/** @odoo-module **/
import { Component, useState } from "@odoo/owl";
import { SoundSelector } from "@freeswitch_admin/js/components/sound_selector";

// ─────────────────────────────────────────────────────────────────────────────
// FifoPanel — freeswitch.fifo + freeswitch.fifo.agent
// ─────────────────────────────────────────────────────────────────────────────
export class FifoPanel extends Component {
    static template   = "freeswitch_admin.FifoPanel";
    static components = { SoundSelector };
    static props = {
        node:       { type: Object },
        records:    { type: Array },
        allRecords: { type: Object },  // { ivr:[], fifo:[], callcenter:[], user:[] }
        sounds:     { type: Array },
        agents:     { type: Array },   // lista freeswitch.cc.agent do wyboru
        onApply:    { type: Function },
        onDelete:   { type: Function },
        onClose:    { type: Function },
        orm:        { type: Object },
    };

    // Typy akcji po timeout — takie same jak w IVR / DID
    get timeoutActionTypes() {
        return [
            { value: '',           label: '— brak (rozłącz) —' },
            { value: 'ivr',        label: '🎛 Menu IVR' },
            { value: 'callcenter', label: '🏢 Call Center' },
            { value: 'user',       label: '👤 Użytkownik SIP' },
            { value: 'voicemail',  label: '📬 Poczta głosowa' },
            { value: 'hangup',     label: '📵 Rozłącz' },
        ];
    }

    _parseTimeoutAction(raw) {
        // Format: "transfer:name XML context" lub "hangup" lub ""
        // Przechowujemy jako { type, target_id }
        if (!raw) return { type: '', target_id: null };
        if (raw === 'hangup') return { type: 'hangup', target_id: null };
        const m = raw.match(/^transfer:([^\s]+)/);
        if (!m) return { type: '', target_id: null };
        const name = m[1];
        // Spróbuj dopasować do rekordu
        const all = this.props.allRecords || {};
        for (const [rtype, recs] of Object.entries(all)) {
            if (!Array.isArray(recs)) continue;
            const found = recs.find(r => r.name === name);
            if (found) return { type: rtype, target_id: found.id };
        }
        return { type: 'ivr', target_id: null }; // fallback
    }

    _buildTimeoutAction(type, target_id) {
        if (!type || type === 'hangup') return type || '';
        const all = this.props.allRecords || {};
        if (target_id) {
            const recs = all[type] || [];
            const rec = recs.find(r => r.id === parseInt(target_id));
            if (rec) return `transfer:${rec.name} XML default`;
        }
        return '';
    }

    setup() {
        this._agentKey = 0;
        const cfg = this.props.node.config || {};
        const parsed = this._parseTimeoutAction(cfg.timeout_action || '');
        this.state = useState({
            label:                this.props.node.label || 'Kolejka FIFO',
            odoo_id:              this.props.node.odoo_id || null,
            name:                 cfg.name           || '',
            description:          cfg.description    || '',
            moh_id:               cfg.moh_id         || null,
            announce_id:          cfg.announce_id    || null,
            max_wait:             cfg.max_wait        ?? 300,
            announce_freq:        cfg.announce_freq   ?? 60,
            timeout_action_type:  parsed.type,
            timeout_action_target: parsed.target_id,
            importance:           cfg.importance      ?? 0,
            agents:               this._initAgents(cfg.agents || []),
            loading:              false,
        });
        this.onMohChange         = this.onMohChange.bind(this);
        this.onAnnounceChange    = this.onAnnounceChange.bind(this);
        this.linkRecord          = this.linkRecord.bind(this);
        this.addAgent            = this.addAgent.bind(this);
        this.removeAgent         = this.removeAgent.bind(this);
        this.onAgentSelect       = this.onAgentSelect.bind(this);
        this.toggleDevice        = this.toggleDevice.bind(this);
        this.isDeviceSelected    = this.isDeviceSelected.bind(this);
        this.effectiveDeviceLabel = this.effectiveDeviceLabel.bind(this);
        this.deviceLabel         = this.deviceLabel.bind(this);
        this.apply               = this.apply.bind(this);
    }

    _initAgents(raw) {
        return raw.map(a => ({
            _key:        ++this._agentKey,
            cc_agent_id: a.cc_agent_id || null,
            device_ids:  Array.isArray(a.device_ids) ? a.device_ids : (a.device_id ? [a.device_id] : []),
            extension:   a.extension   || '',
            contact:     a.contact     || '',
            sequence:    a.sequence    ?? 10,
            active:      a.active      ?? true,
        }));
    }

    get linkedRecord() {
        return this.props.records.find(r => r.id === this.state.odoo_id) || null;
    }

    async linkRecord(ev) {
        const id = parseInt(ev.target.value) || null;
        this.state.odoo_id = id;
        if (!id) { this.state.agents = []; return; }
        const rec = this.props.records.find(r => r.id === id);
        if (rec) {
            this.state.name          = rec.name          || '';
            this.state.description   = rec.description   || '';
            this.state.moh_id        = rec.moh_sound_id  ? rec.moh_sound_id[0] : null;
            this.state.max_wait      = rec.max_wait_sec  || 300;
            this.state.announce_freq = rec.announce_freq || 60;
            this.state.timeout_action = rec.timeout_action || '';
            this.state.importance    = rec.importance    || 0;
        }
        this.state.loading = true;
        try {
            const rows = await this.props.orm.searchRead(
                'freeswitch.fifo.agent',
                [['fifo_id', '=', id]],
                ['sequence', 'cc_agent_id', 'sip_device_ids', 'extension', 'contact', 'active'],
                { order: 'sequence asc' }
            );
            this.state.agents = rows.map(a => ({
                _key:        ++this._agentKey,
                cc_agent_id: a.cc_agent_id ? a.cc_agent_id[0] : null,
                device_ids:  Array.isArray(a.sip_device_ids) ? a.sip_device_ids : [],
                extension:   a.extension   || '',
                contact:     a.contact     || '',
                sequence:    a.sequence    ?? 10,
                active:      a.active      ?? true,
            }));
        } finally {
            this.state.loading = false;
        }
    }

    onMohChange(id)      { this.state.moh_id     = id; }
    onAnnounceChange(id) { this.state.announce_id = id; }

    addAgent() {
        this.state.agents.push({
            _key:        ++this._agentKey,
            cc_agent_id: null,
            device_ids:  [],
            extension:   '',
            contact:     '',
            sequence:    (this.state.agents.length + 1) * 10,
            active:      true,
        });
    }

    removeAgent(key) {
        const idx = this.state.agents.findIndex(a => a._key === key);
        if (idx !== -1) this.state.agents.splice(idx, 1);
    }

    onAgentSelect(ev, key) {
        const agentId = parseInt(ev.target.value) || null;
        const row = this.state.agents.find(a => a._key === key);
        if (!row) return;
        row.cc_agent_id = agentId;
        row.device_ids  = [];
        if (agentId) {
            const agent = this.props.agents.find(a => a.id === agentId);
            if (agent) {
                row.extension = agent.extension || '';
                row.contact   = agent.contact   || '';
                // Domyślnie zaznacz urządzenia SIP (type='sip') — zgodnie z wymaganiem
                // "jeśli brak wyboru → konto SIP"
                const devices = this._devicesForAgent(agentId);
                const sipDevices = devices.filter(d => d.device_type === 'sip');
                row.device_ids = sipDevices.length
                    ? sipDevices.map(d => d.id)
                    : devices.length ? [] : [];  // brak urządzeń → puste (agent.contact jako fallback)
            }
        }
    }

    toggleDevice(deviceId, key) {
        const row = this.state.agents.find(a => a._key === key);
        if (!row) return;
        const idx = row.device_ids.indexOf(deviceId);
        if (idx === -1) {
            row.device_ids.push(deviceId);
        } else {
            row.device_ids.splice(idx, 1);
        }
    }

    isDeviceSelected(deviceId, key) {
        const row = this.state.agents.find(a => a._key === key);
        if (!row) return false;
        return row.device_ids.includes(deviceId);
    }

    _devicesForAgent(agentId) {
        if (!agentId) return [];
        const agent = this.props.agents.find(a => a.id === agentId);
        if (!agent) return [];
        if (Array.isArray(agent.devices) && agent.devices.length) {
            return agent.devices;
        }
        const deviceIds = Array.isArray(agent.sip_device_ids) ? agent.sip_device_ids : [];
        return deviceIds.map(id => ({ id, display_name_device: `Urządzenie #${id}`, device_type: 'sip' }));
    }

    devicesForAgent(agentId) {
        return this._devicesForAgent(agentId);
    }

    // Zwraca etykietę urządzenia z informacją o typie
    deviceLabel(dev) {
        const icons = { sip: '☎️', mobile: '📱', webrtc: '🌐', softphone: '💻' };
        const icon = icons[dev.device_type] || '📟';
        return icon + ' ' + (dev.display_name_device || dev.label || ('#' + dev.id));
    }

    // Czy dla agenta nie zaznaczono żadnego urządzenia → domyślnie konto SIP
    effectiveDeviceLabel(key) {
        const row = this.state.agents.find(a => a._key === key);
        if (!row || !row.cc_agent_id) return '';
        if (!row.device_ids || row.device_ids.length === 0) {
            return '(domyślnie: konto SIP)';
        }
        const devices = this._devicesForAgent(row.cc_agent_id);
        const selected = devices.filter(d => row.device_ids.includes(d.id));
        return selected.map(d => this.deviceLabel(d)).join(', ');
    }

    agentLabel(ag) {
        return ag.display_name_field || ag.name || ag.extension || ('#' + ag.id);
    }

    targetListForTimeout(type) {
        const all = this.props.allRecords || {};
        return (all[type] || []);
    }

    apply() {
        const timeout_action = this._buildTimeoutAction(
            this.state.timeout_action_type,
            this.state.timeout_action_target,
        );
        this.props.onApply({
            ...this.props.node,
            label:   this.state.label,
            odoo_id: this.state.odoo_id,
            config: {
                name:           this.state.name,
                description:    this.state.description,
                moh_id:         this.state.moh_id,
                announce_id:    this.state.announce_id,
                max_wait:       Number(this.state.max_wait),
                announce_freq:  Number(this.state.announce_freq),
                timeout_action: timeout_action,
                importance:     Number(this.state.importance),
                agents: this.state.agents.map(a => ({
                    cc_agent_id: a.cc_agent_id,
                    device_ids:  a.device_ids,
                    extension:   a.extension,
                    contact:     a.contact,
                    sequence:    Number(a.sequence),
                    active:      a.active,
                })),
            },
        });
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// CallCenterPanel — freeswitch.cc.queue + freeswitch.cc.tier
// ─────────────────────────────────────────────────────────────────────────────
const CC_STRATEGIES = [
    { value: 'longest-idle-agent',        label: 'Najdłużej bezczynny (zalecane)' },
    { value: 'round-robin',               label: 'Round-robin' },
    { value: 'top-down',                  label: 'Od góry listy' },
    { value: 'agent-with-fewest-calls',   label: 'Najmniej połączeń' },
    { value: 'agent-with-least-talk-time',label: 'Najkrótszy czas rozmów' },
    { value: 'ring-all',                  label: 'Dzwoń do wszystkich' },
    { value: 'random',                    label: 'Losowy' },
];

export class CallCenterPanel extends Component {
    static template   = "freeswitch_admin.CallCenterPanel";
    static components = { SoundSelector };
    static props = {
        node:     { type: Object },
        records:  { type: Array },
        sounds:   { type: Array },
        agents:   { type: Array },   // lista freeswitch.cc.agent do wyboru
        onApply:  { type: Function },
        onDelete: { type: Function },
        onClose:  { type: Function },
        orm:      { type: Object },
    };

    setup() {
        this._tierKey = 0;
        const cfg = this.props.node.config || {};
        this.state = useState({
            label:             this.props.node.label || 'Call Center',
            odoo_id:           this.props.node.odoo_id || null,
            name:              cfg.name              || '',
            description:       cfg.description       || '',
            strategy:          cfg.strategy          || 'longest-idle-agent',
            moh_id:            cfg.moh_id            || null,
            max_wait_time:     cfg.max_wait_time      ?? 300,
            max_wait_no_agent: cfg.max_wait_no_agent  ?? 120,
            record_template:   cfg.record_template    || '/nagrania/{uuid}.wav',
            tiers:             this._initTiers(cfg.tiers || []),
            loading:           false,
        });
        this.ccStrategies       = CC_STRATEGIES;
        this.onMohChange        = this.onMohChange.bind(this);
        this.linkRecord         = this.linkRecord.bind(this);
        this.addTier            = this.addTier.bind(this);
        this.removeTier         = this.removeTier.bind(this);
        this.onTierAgentSelect  = this.onTierAgentSelect.bind(this);
        this.toggleTierDevice   = this.toggleTierDevice.bind(this);
        this.onTierDeviceSelect = this.onTierDeviceSelect.bind(this);
        this.apply              = this.apply.bind(this);
    }

    _initTiers(raw) {
        return raw.map(t => ({
            _key:      ++this._tierKey,
            agent_id:  t.agent_id  || null,
            device_ids: Array.isArray(t.device_ids) ? t.device_ids : (t.device_id ? [t.device_id] : []),
            level:     t.level     ?? 1,
            position:  t.position  ?? 1,
        }));
    }

    get linkedRecord() {
        return this.props.records.find(r => r.id === this.state.odoo_id) || null;
    }

    async linkRecord(ev) {
        const id = parseInt(ev.target.value) || null;
        this.state.odoo_id = id;
        if (!id) { this.state.tiers = []; return; }
        const rec = this.props.records.find(r => r.id === id);
        if (rec) {
            this.state.name              = rec.name              || '';
            this.state.description       = rec.description       || '';
            this.state.strategy          = rec.strategy          || 'longest-idle-agent';
            this.state.moh_id            = rec.moh_sound_id      ? rec.moh_sound_id[0] : null;
            this.state.max_wait_time     = rec.max_wait_time     || 300;
            this.state.max_wait_no_agent = rec.max_wait_no_agent || 120;
            this.state.record_template   = rec.record_template   || '/nagrania/{uuid}.wav';
        }
        this.state.loading = true;
        try {
            const rows = await this.props.orm.searchRead(
                'freeswitch.cc.tier',
                [['queue_id', '=', id]],
                ['agent_id', 'level', 'position'],
                { order: 'level asc, position asc' }
            );
            this.state.tiers = rows.map(t => ({
                _key:      ++this._tierKey,
                agent_id:  t.agent_id ? t.agent_id[0] : null,
                device_ids: [],
                level:     t.level    ?? 1,
                position:  t.position ?? 1,
            }));
        } finally {
            this.state.loading = false;
        }
    }

    onMohChange(id) { this.state.moh_id = id; }

    addTier() {
        const maxPos = this.state.tiers.reduce((m, t) => Math.max(m, t.position), 0);
        this.state.tiers.push({
            _key:      ++this._tierKey,
            agent_id:  null,
            device_ids: [],
            level:     1,
            position:  maxPos + 1,
        });
    }

    removeTier(key) {
        const idx = this.state.tiers.findIndex(t => t._key === key);
        if (idx !== -1) this.state.tiers.splice(idx, 1);
    }

    onTierAgentSelect(ev, key) {
        const tier = this.state.tiers.find(t => t._key === key);
        if (tier) {
            tier.agent_id  = parseInt(ev.target.value) || null;
            tier.device_ids = [];
        }
    }

    toggleTierDevice(deviceId, key) {
        const tier = this.state.tiers.find(t => t._key === key);
        if (!tier) return;
        const idx = tier.device_ids.indexOf(deviceId);
        if (idx === -1) {
            tier.device_ids.push(deviceId);
        } else {
            tier.device_ids.splice(idx, 1);
        }
    }

    // Obsługuje single-select urządzenia w szablonie (onTierDeviceSelect)
    onTierDeviceSelect(ev, key) {
        const tier = this.state.tiers.find(t => t._key === key);
        if (!tier) return;
        const val = parseInt(ev.target.value) || null;
        tier.device_ids = val ? [val] : [];
    }

    devicesForAgent(agentId) {
        if (!agentId) return [];
        const agent = this.props.agents.find(a => a.id === agentId);
        if (!agent) return [];
        if (Array.isArray(agent.devices) && agent.devices.length) {
            return agent.devices;
        }
        const deviceIds = Array.isArray(agent.sip_device_ids) ? agent.sip_device_ids : [];
        return deviceIds.map(id => ({ id, display_name_device: `Urządzenie #${id}` }));
    }

    agentLabel(ag) {
        return ag.display_name_field || ag.name || ag.extension || ('#' + ag.id);
    }

    apply() {
        this.props.onApply({
            ...this.props.node,
            label:   this.state.label,
            odoo_id: this.state.odoo_id,
            config: {
                name:              this.state.name,
                description:       this.state.description,
                strategy:          this.state.strategy,
                moh_id:            this.state.moh_id,
                max_wait_time:     Number(this.state.max_wait_time),
                max_wait_no_agent: Number(this.state.max_wait_no_agent),
                record_template:   this.state.record_template,
                tiers: this.state.tiers.map(t => ({
                    agent_id:  t.agent_id,
                    device_ids: t.device_ids,
                    level:     Number(t.level),
                    position:  Number(t.position),
                })),
            },
        });
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// SipUserPanel — freeswitch.sip.user
// Sekcje: podstawowe dane, urządzenia, routing warunkowy, kalendarz dostępności
// ─────────────────────────────────────────────────────────────────────────────

const ROUTE_TYPE_OPTIONS = [
    { value: '',           label: '— brak —' },
    { value: 'ivr',        label: 'Menu IVR' },
    { value: 'callcenter', label: 'Kolejka CallCenter' },
    { value: 'user',       label: 'Inny użytkownik SIP' },
    { value: 'pstn',       label: 'Numer zewnętrzny PSTN' },
    { value: 'sound',      label: 'Odtwórz plik dźwiękowy' },
    { value: 'voicemail',  label: 'Poczta głosowa' },
    { value: 'hangup',     label: 'Rozłącz' },
];

const DEVICE_TYPE_OPTIONS = [
    { value: 'sip',       label: 'Konto SIP (telefon / softphone)' },
    { value: 'mobile',    label: 'Telefon komórkowy (PSTN)' },
    { value: 'webrtc',    label: 'WebRTC (przeglądarka)' },
    { value: 'softphone', label: 'Softphone zewnętrzny' },
];

const RING_STRATEGY_OPTIONS = [
    { value: 'simultaneous', label: 'Jednocześnie' },
    { value: 'sequential',   label: 'Po kolei' },
    { value: 'exclusive',    label: 'Tylko to urządzenie' },
];

const CAL_DAYS = [
    { key: 'day_mon', label: 'Pn' },
    { key: 'day_tue', label: 'Wt' },
    { key: 'day_wed', label: 'Śr' },
    { key: 'day_thu', label: 'Cz' },
    { key: 'day_fri', label: 'Pt' },
    { key: 'day_sat', label: 'Sob' },
    { key: 'day_sun', label: 'Nd' },
];

export class SipUserPanel extends Component {
    static template = "freeswitch_admin.SipUserPanel";
    static props = {
        node:       { type: Object },
        records:    { type: Array },       // lista freeswitch.sip.user
        allRecords: { type: Object },      // { ivr:[], fifo:[], callcenter:[], user:[] }
        sounds:     { type: Array },       // lista freeswitch.sound
        onApply:    { type: Function },
        onDelete:   { type: Function },
        onClose:    { type: Function },
        orm:        { type: Object },
    };

    setup() {
        this._devKey = 0;
        this._calKey = 0;
        const cfg = this.props.node.config || {};

        this.routeTypeOptions    = ROUTE_TYPE_OPTIONS;
        this.deviceTypeOptions   = DEVICE_TYPE_OPTIONS;
        this.ringStrategyOptions = RING_STRATEGY_OPTIONS;
        this.calDays             = CAL_DAYS;

        this.state = useState({
            // ── podstawowe ──────────────────────────────────────────────────
            label:      this.props.node.label || 'Użytkownik SIP',
            odoo_id:    this.props.node.odoo_id || null,
            extension:  cfg.extension   || '',
            first_name: cfg.first_name  || '',
            last_name:  cfg.last_name   || '',
            timeout:    cfg.timeout      ?? 30,
            domain:     cfg.domain       || '',

            // ── urządzenia ──────────────────────────────────────────────────
            devices: this._initDevices(cfg.devices || []),

            // ── routing warunkowy ───────────────────────────────────────────
            busy_action:     cfg.busy_action     || '',
            busy_target:     cfg.busy_target     || '',
            noanswer_action: cfg.noanswer_action || '',
            noanswer_target: cfg.noanswer_target || '',
            unreg_action:    cfg.unreg_action    || '',
            unreg_target:    cfg.unreg_target    || '',

            // ── kalendarz ───────────────────────────────────────────────────
            use_calendar:        cfg.use_calendar        ?? false,
            calendar:            this._initCalendar(cfg.calendar || []),
            calendar_off_action: cfg.calendar_off_action || '',
            calendar_off_target: cfg.calendar_off_target || '',

            // ── nowy użytkownik (modal) ─────────────────────────────────────
            showNewModal: false,
            newExt:       '',
            newFirstName: '',
            newLastName:  '',
            creating:     false,

            // ── UI ──────────────────────────────────────────────────────────
            loading:   false,
            activeTab: 'basic',
        });

        this.linkRecord   = this.linkRecord.bind(this);
        this.openNewModal = this.openNewModal.bind(this);
        this.closeModal   = this.closeModal.bind(this);
        this.createNew    = this.createNew.bind(this);
        this.addDevice    = this.addDevice.bind(this);
        this.removeDevice = this.removeDevice.bind(this);
        this.addCalRow    = this.addCalRow.bind(this);
        this.removeCalRow = this.removeCalRow.bind(this);
        this.toggleCalDay = this.toggleCalDay.bind(this);
        this.apply        = this.apply.bind(this);
    }

    // ── inicjalizatory ──────────────────────────────────────────────────────

    _initDevices(raw) {
        return raw.map(d => ({
            _key:          ++this._devKey,
            device_type:   d.device_type   || 'sip',
            label:         d.label         || '',
            mobile_number: d.mobile_number || '',
            ring_strategy: d.ring_strategy || 'simultaneous',
            sequence:      d.sequence       ?? 10,
            active:        d.active         ?? true,
        }));
    }

    _initCalendar(raw) {
        return raw.map(r => ({
            _key:       ++this._calKey,
            name:       r.name       || 'Godziny pracy',
            day_mon:    r.day_mon    ?? true,
            day_tue:    r.day_tue    ?? true,
            day_wed:    r.day_wed    ?? true,
            day_thu:    r.day_thu    ?? true,
            day_fri:    r.day_fri    ?? true,
            day_sat:    r.day_sat    ?? false,
            day_sun:    r.day_sun    ?? false,
            time_start: r.time_start || '08:00',
            time_end:   r.time_end   || '17:00',
        }));
    }

    // ── selectory dla celu akcji ────────────────────────────────────────────

    get ivrList()  { return this.props.allRecords.ivr        || []; }
    get fifoList() { return this.props.allRecords.fifo       || []; }
    get ccList()   { return this.props.allRecords.callcenter || []; }
    get userList()  { return this.props.allRecords.user       || []; }
    get soundList() { return this.props.sounds                || []; }

    get linkedRecord() {
        return this.props.records.find(r => r.id === this.state.odoo_id) || null;
    }

    // ── wybór docelowego rekordu wg akcji ───────────────────────────────────

    _targetListForAction(action) {
        if (action === 'ivr')        return this.ivrList;
        if (action === 'callcenter') return this.ccList;
        if (action === 'user')       return this.userList;
        return [];
    }

    _targetLabelField(action) {
        if (action === 'user') return 'display_name_full';
        return 'name';
    }

    _targetValueField(action) {
        // target przechowywany jako name/extension (string)
        if (action === 'user') return 'name';  // numer wewnętrzny
        return 'name';
    }

    // ── zdarzenia — wybór istniejącego użytkownika ──────────────────────────

    async linkRecord(ev) {
        const id = parseInt(ev.target.value) || null;
        this.state.odoo_id = id;
        const rec = this.props.records.find(r => r.id === id);
        if (!rec) { this.state.devices = []; this.state.calendar = []; return; }

        this.state.extension  = rec.name               || '';
        this.state.first_name = rec.first_name         || '';
        this.state.last_name  = rec.last_name          || '';
        this.state.timeout    = rec.noanswer_timeout   ?? 30;
        this.state.busy_action     = rec.busy_action     || '';
        this.state.busy_target     = rec.busy_target     || '';
        this.state.noanswer_action = rec.noanswer_action || '';
        this.state.noanswer_target = rec.noanswer_target || '';
        this.state.unreg_action    = rec.unreg_action    || '';
        this.state.unreg_target    = rec.unreg_target    || '';

        this.state.use_calendar        = rec.use_calendar        ?? false;
        this.state.calendar_off_action = rec.calendar_off_action || '';
        this.state.calendar_off_target = rec.calendar_off_target || '';

        this.state.loading = true;
        try {
            const [devRows, calRows] = await Promise.all([
                this.props.orm.searchRead(
                    'freeswitch.sip.device',
                    [['user_id', '=', id]],
                    ['device_type', 'label', 'mobile_number', 'ring_strategy', 'sequence', 'active'],
                    { order: 'sequence asc' }
                ),
                this.props.orm.searchRead(
                    'freeswitch.sip.calendar',
                    [['user_id', '=', id]],
                    ['name', 'day_mon', 'day_tue', 'day_wed', 'day_thu',
                     'day_fri', 'day_sat', 'day_sun', 'time_start', 'time_end'],
                    { order: 'sequence asc' }
                ),
            ]);
            this.state.devices  = devRows.map(d => ({
                _key:          ++this._devKey,
                device_type:   d.device_type   || 'sip',
                label:         d.label         || '',
                mobile_number: d.mobile_number || '',
                ring_strategy: d.ring_strategy || 'simultaneous',
                sequence:      d.sequence       ?? 10,
                active:        d.active         ?? true,
            }));
            this.state.calendar = calRows.map(r => ({
                _key:       ++this._calKey,
                name:       r.name       || 'Godziny pracy',
                day_mon:    r.day_mon    ?? true,
                day_tue:    r.day_tue    ?? true,
                day_wed:    r.day_wed    ?? true,
                day_thu:    r.day_thu    ?? true,
                day_fri:    r.day_fri    ?? true,
                day_sat:    r.day_sat    ?? false,
                day_sun:    r.day_sun    ?? false,
                time_start: r.time_start || '08:00',
                time_end:   r.time_end   || '17:00',
            }));
        } finally {
            this.state.loading = false;
        }
    }

    // ── modal tworzenia nowego użytkownika ──────────────────────────────────

    openNewModal() {
        this.state.newExt       = '';
        this.state.newFirstName = '';
        this.state.newLastName  = '';
        this.state.showNewModal = true;
    }

    closeModal() {
        this.state.showNewModal = false;
    }

    async createNew() {
        const ext   = (this.state.newExt       || '').trim();
        const fname = (this.state.newFirstName || '').trim();
        const lname = (this.state.newLastName  || '').trim();
        if (!ext || !fname || !lname) return;

        this.state.creating = true;
        try {
            const newId = await this.props.orm.create('freeswitch.sip.user', [{
                name:       ext,
                first_name: fname,
                last_name:  lname,
                active:     true,
            }]);
            // Wczytaj nowy rekord
            const rows = await this.props.orm.searchRead(
                'freeswitch.sip.user',
                [['id', '=', newId]],
                ['id', 'name', 'display_name_full', 'first_name', 'last_name',
                 'noanswer_timeout',
                 'busy_action', 'busy_target', 'noanswer_action', 'noanswer_target',
                 'unreg_action', 'unreg_target',
                 'use_calendar', 'calendar_off_action', 'calendar_off_target']
            );
            if (rows.length) {
                const rec = rows[0];
                // Dodaj do reaktywnej listy records (allRecords.user) żeby select go widział
                this.props.allRecords.user.push(rec);
                this.state.odoo_id    = rec.id;
                this.state.extension  = rec.name       || '';
                this.state.first_name = rec.first_name || '';
                this.state.last_name  = rec.last_name  || '';
                this.state.timeout    = rec.noanswer_timeout ?? 30;
                this.state.domain     = '';
                this.state.devices    = [];
                this.state.calendar   = [];
            }
            this.state.showNewModal = false;
        } finally {
            this.state.creating = false;
        }
    }

    // ── urządzenia ───────────────────────────────────────────────────────────

    addDevice() {
        this.state.devices.push({
            _key:          ++this._devKey,
            device_type:   'sip',
            label:         '',
            mobile_number: '',
            ring_strategy: 'simultaneous',
            sequence:      (this.state.devices.length + 1) * 10,
            active:        true,
        });
    }

    removeDevice(key) {
        const idx = this.state.devices.findIndex(d => d._key === key);
        if (idx !== -1) this.state.devices.splice(idx, 1);
    }

    // ── kalendarz ────────────────────────────────────────────────────────────

    addCalRow() {
        this.state.calendar.push({
            _key:       ++this._calKey,
            name:       'Godziny pracy',
            day_mon:    true, day_tue:  true, day_wed: true,
            day_thu:    true, day_fri:  true, day_sat: false, day_sun: false,
            time_start: '08:00',
            time_end:   '17:00',
        });
    }

    removeCalRow(key) {
        const idx = this.state.calendar.findIndex(r => r._key === key);
        if (idx !== -1) this.state.calendar.splice(idx, 1);
    }

    toggleCalDay(key, dayKey) {
        const row = this.state.calendar.find(r => r._key === key);
        if (row) row[dayKey] = !row[dayKey];
    }

    // ── zapis ─────────────────────────────────────────────────────────────────

    apply() {
        this.props.onApply({
            ...this.props.node,
            label:   this.state.label,
            odoo_id: this.state.odoo_id,
            config: {
                extension:  this.state.extension,
                first_name: this.state.first_name,
                last_name:  this.state.last_name,
                timeout:    Number(this.state.timeout),
                domain:     this.state.domain,

                devices: this.state.devices.map(d => ({
                    device_type:   d.device_type,
                    label:         d.label,
                    mobile_number: d.mobile_number,
                    ring_strategy: d.ring_strategy,
                    sequence:      Number(d.sequence),
                    active:        d.active,
                })),

                busy_action:     this.state.busy_action,
                busy_target:     this.state.busy_target,
                noanswer_action: this.state.noanswer_action,
                noanswer_target: this.state.noanswer_target,
                unreg_action:    this.state.unreg_action,
                unreg_target:    this.state.unreg_target,

                use_calendar:        this.state.use_calendar,
                calendar_off_action: this.state.calendar_off_action,
                calendar_off_target: this.state.calendar_off_target,
                calendar: this.state.calendar.map(r => ({
                    name: r.name, day_mon: r.day_mon, day_tue: r.day_tue,
                    day_wed: r.day_wed, day_thu: r.day_thu, day_fri: r.day_fri,
                    day_sat: r.day_sat, day_sun: r.day_sun,
                    time_start: r.time_start, time_end: r.time_end,
                })),
            },
        });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TimerulePanel
// ─────────────────────────────────────────────────────────────────────────────
const DAY_OPTIONS = [
    { key: 'mon', label: 'Pn' }, { key: 'tue', label: 'Wt' },
    { key: 'wed', label: 'Śr' }, { key: 'thu', label: 'Cz' },
    { key: 'fri', label: 'Pt' }, { key: 'sat', label: 'Sob' },
    { key: 'sun', label: 'Nd' },
];

export class TimerulePanel extends Component {
    static template = "freeswitch_admin.TimerulePanel";
    static props = {
        node:     { type: Object },
        onApply:  { type: Function },
        onDelete: { type: Function },
        onClose:  { type: Function },
    };

    setup() {
        const cfg  = this.props.node.config || {};
        const days = (cfg.days || 'mon,tue,wed,thu,fri').split(',').map(d => d.trim());
        this.dayOptions = DAY_OPTIONS;
        this.state = useState({
            label:      this.props.node.label || 'Reguła Czasowa',
            time_start: cfg.time_start || '08:00',
            time_end:   cfg.time_end   || '17:00',
            timezone:   cfg.timezone   || 'Europe/Warsaw',
            days:       Object.fromEntries(DAY_OPTIONS.map(d => [d.key, days.includes(d.key)])),
        });
        this.toggleDay = this.toggleDay.bind(this);
        this.apply     = this.apply.bind(this);
    }

    toggleDay(key) { this.state.days[key] = !this.state.days[key]; }

    get daysString() {
        return DAY_OPTIONS.filter(d => this.state.days[d.key]).map(d => d.key).join(',');
    }

    apply() {
        this.props.onApply({
            ...this.props.node,
            label:  this.state.label,
            config: {
                days:       this.daysString,
                time_start: this.state.time_start,
                time_end:   this.state.time_end,
                timezone:   this.state.timezone,
            },
        });
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// PstnPanel
// ─────────────────────────────────────────────────────────────────────────────
export class PstnPanel extends Component {
    static template = "freeswitch_admin.PstnPanel";
    static props = {
        node:     { type: Object },
        onApply:  { type: Function },
        onDelete: { type: Function },
        onClose:  { type: Function },
    };

    setup() {
        const cfg = this.props.node.config || {};
        this.state = useState({
            label:     this.props.node.label || 'PSTN',
            number:    cfg.number    || '',
            gateway:   cfg.gateway   || '',
            caller_id: cfg.caller_id || '',
            record:    cfg.record    || 'false',
        });
        this.apply = this.apply.bind(this);
    }

    apply() {
        this.props.onApply({
            ...this.props.node,
            label:  this.state.label,
            config: {
                number:    this.state.number,
                gateway:   this.state.gateway,
                caller_id: this.state.caller_id,
                record:    this.state.record,
            },
        });
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// HolidayPanel — węzeł "Dni wolne od pracy"
//
// Panel konfiguruje TYLKO:
//   • Kraj (który zestaw świąt sprawdzać)
//   • Wyjątki (konkretne daty z własnym portem wyjściowym)
//   • Podgląd / usuwanie świąt z bazy
//
// Routing (co się dzieje na porcie holiday / workday / exc_*) konfiguruje się
// wyłącznie przez połączenie kablem na kanwie — tak jak w każdym innym węźle.
// ─────────────────────────────────────────────────────────────────────────────
const HOLIDAY_COUNTRIES = [
    { value: 'PL', label: '🇵🇱 Polska' },
    { value: 'DE', label: '🇩🇪 Niemcy' },
    { value: 'GB', label: '🇬🇧 Wielka Brytania' },
    { value: 'FR', label: '🇫🇷 Francja' },
    { value: 'US', label: '🇺🇸 USA' },
    { value: 'CZ', label: '🇨🇿 Czechy' },
    { value: 'SK', label: '🇸🇰 Słowacja' },
    { value: 'UA', label: '🇺🇦 Ukraina' },
];

export class HolidayPanel extends Component {
    static template   = "freeswitch_admin.HolidayPanel";
    static components = {};
    static props = {
        node:     { type: Object },
        records:  { type: Object },
        sounds:   { type: Array },
        onApply:  { type: Function },
        onDelete: { type: Function },
        onClose:  { type: Function },
        orm:      { type: Object },
    };

    setup() {
        this._exKey = 0;
        const cfg = this.props.node.config || {};
        this.holidayCountries = HOLIDAY_COUNTRIES;

        this.state = useState({
            label:        this.props.node.label || 'Dni wolne',
            country_code: cfg.country_code || 'PL',

            // Każdy wyjątek = { _key, odoo_id, name, date, recurring }
            // Tworzy osobny port wyjściowy "exc_YYYYMMDD" na węźle
            exceptions:   this._initExceptions(cfg.exceptions || []),

            // UI
            dbHolidays:      [],
            upcoming:        [],
            loadingHolidays: false,
            savingException: false,
            showAddForm:     false,
            newExcName:      '',
            newExcDate:      '',
            newExcRecurring: false,
        });

        this.loadDbHolidays   = this.loadDbHolidays.bind(this);
        this.loadUpcoming     = this.loadUpcoming.bind(this);
        this.toggleAddForm    = this.toggleAddForm.bind(this);
        this.saveNewException = this.saveNewException.bind(this);
        this.removeException  = this.removeException.bind(this);
        this.deleteDbHoliday  = this.deleteDbHoliday.bind(this);
        this.apply            = this.apply.bind(this);
    }

    _initExceptions(raw) {
        return raw.map(e => ({
            _key:      ++this._exKey,
            odoo_id:   e.odoo_id   || null,
            name:      e.name      || '',
            date:      e.date      || '',
            recurring: e.recurring ?? false,
        }));
    }

    excPortKey(exc) {
        const d = (exc.date || '').replace(/-/g, '');
        return d ? `exc_${d}` : `exc_${exc._key}`;
    }

    async loadDbHolidays() {
        this.state.loadingHolidays = true;
        try {
            const rows = await this.props.orm.searchRead(
                'freeswitch.public.holiday',
                [['country_code', '=', this.state.country_code], ['active', '=', true]],
                ['name', 'date', 'recurring', 'note'],
                { order: 'date asc', limit: 50 }
            );
            this.state.dbHolidays = rows;
        } finally {
            this.state.loadingHolidays = false;
        }
    }

    async loadUpcoming() {
        this.state.loadingHolidays = true;
        try {
            const today = new Date().toISOString().slice(0, 10);
            const rows = await this.props.orm.searchRead(
                'freeswitch.public.holiday',
                [['country_code', '=', this.state.country_code],
                 ['active', '=', true],
                 ['date', '>=', today]],
                ['name', 'date', 'recurring', 'is_moveable'],
                { order: 'date asc', limit: 10 }
            );
            this.state.upcoming = rows;
        } finally {
            this.state.loadingHolidays = false;
        }
    }

    toggleAddForm() {
        this.state.showAddForm     = !this.state.showAddForm;
        this.state.newExcName      = '';
        this.state.newExcDate      = new Date().toISOString().slice(0, 10);
        this.state.newExcRecurring = false;
    }

    async saveNewException() {
        if (!this.state.newExcDate || !this.state.newExcName) return;
        this.state.savingException = true;
        try {
            const odoo_id = await this.props.orm.create('freeswitch.public.holiday', [{
                name:         this.state.newExcName,
                country_code: this.state.country_code,
                date:         this.state.newExcDate,
                recurring:    this.state.newExcRecurring,
                active:       true,
            }]);
            this.state.exceptions.push({
                _key:      ++this._exKey,
                odoo_id,
                name:      this.state.newExcName,
                date:      this.state.newExcDate,
                recurring: this.state.newExcRecurring,
            });
            await this.loadDbHolidays();
            this.state.showAddForm = false;
        } finally {
            this.state.savingException = false;
        }
    }

    removeException(key) {
        const idx = this.state.exceptions.findIndex(e => e._key === key);
        if (idx !== -1) this.state.exceptions.splice(idx, 1);
    }

    async deleteDbHoliday(id) {
        if (!confirm('Usunąć ten dzień wolny z bazy danych?')) return;
        await this.props.orm.unlink('freeswitch.public.holiday', [id]);
        const idx = this.state.exceptions.findIndex(e => e.odoo_id === id);
        if (idx !== -1) this.state.exceptions.splice(idx, 1);
        await this.loadDbHolidays();
    }

    apply() {
        this.props.onApply({
            ...this.props.node,
            label:  this.state.label,
            config: {
                country_code: this.state.country_code,
                exceptions:   this.state.exceptions.map(e => ({
                    odoo_id:   e.odoo_id,
                    name:      e.name,
                    date:      e.date,
                    recurring: e.recurring,
                    port_key:  this.excPortKey(e),
                })),
            },
        });
    }
}