/** @odoo-module **/
import { Component, useState } from "@odoo/owl";
import { SoundSelector } from "@freeswitch_admin/js/components/sound_selector";

const DTMF_DIGITS = ['0','1','2','3','4','5','6','7','8','9','*','#'];

export class IvrPanel extends Component {
    static template   = "freeswitch_admin.IvrPanel";
    static components = { SoundSelector };
    static props = {
        node:     { type: Object },
        records:  { type: Object },
        sounds:   { type: Array },
        onApply:  { type: Function },
        onDelete: { type: Function },
        onClose:  { type: Function },
        orm:      { type: Object },
    };

    setup() {
        this._itemKey = 0;
        const cfg = this.props.node.config || {};
        this.state = useState({
            label:        this.props.node.label || 'IVR Menu',
            odoo_id:      this.props.node.odoo_id || null,
            name:         cfg.name        || '',
            description:  cfg.description || '',
            greeting_id:  cfg.greeting_id || null,
            timeout:      cfg.timeout      ?? 7,
            max_failures: cfg.max_failures ?? 3,
            items:        this._initItems(cfg.menu_items || []),
            loading:      false,
        });
        this.linkRecord          = this.linkRecord.bind(this);
        this.onGreetingChange    = this.onGreetingChange.bind(this);
        this.addItem             = this.addItem.bind(this);
        this.removeItem          = this.removeItem.bind(this);
        this.onItemDigitChange   = this.onItemDigitChange.bind(this);
        this.onItemDescChange    = this.onItemDescChange.bind(this);
        this.apply               = this.apply.bind(this);
    }

    _initItems(rawItems) {
        return rawItems.map(it => ({
            _key:        ++this._itemKey,
            digit:       it.digit       || '0',
            description: it.description || '',
        }));
    }

    get linkedRecord() {
        return (this.props.records.ivr || []).find(r => r.id === this.state.odoo_id) || null;
    }

    async linkRecord(ev) {
        const id = parseInt(ev.target.value) || null;
        this.state.odoo_id = id;
        if (!id) { this.state.items = []; return; }
        const rec = (this.props.records.ivr || []).find(r => r.id === id);
        if (rec) {
            this.state.name         = rec.name         || '';
            this.state.description  = rec.description  || '';
            this.state.greeting_id  = rec.greeting_id  ? rec.greeting_id[0] : null;
            this.state.timeout      = rec.timeout_sec  || 7;
            this.state.max_failures = rec.max_failures || 3;
        }
        this.state.loading = true;
        try {
            const items = await this.props.orm.searchRead(
                'freeswitch.ivr.item',
                [['ivr_id', '=', id]],
                ['digit', 'description'],
                { order: 'sequence asc' },
            );
            this.state.items = items.map(it => ({
                _key:        ++this._itemKey,
                digit:       it.digit       || '0',
                description: it.description || '',
            }));
        } finally {
            this.state.loading = false;
        }
    }

    onGreetingChange(soundId) { this.state.greeting_id = soundId; }

    get dtmfDigits()    { return DTMF_DIGITS; }
    get usedDigits()    { return new Set(this.state.items.map(it => it.digit)); }
    get nextFreeDigit() { return DTMF_DIGITS.find(d => !this.usedDigits.has(d)) || null; }

    addItem() {
        const digit = this.nextFreeDigit;
        if (!digit) return;
        this.state.items.push({ _key: ++this._itemKey, digit, description: '' });
    }

    removeItem(key) {
        const idx = this.state.items.findIndex(it => it._key === key);
        if (idx !== -1) this.state.items.splice(idx, 1);
    }

    onItemDigitChange(ev, key) {
        const it = this.state.items.find(i => i._key === key);
        if (it) it.digit = ev.target.value;
    }

    onItemDescChange(ev, key) {
        const it = this.state.items.find(i => i._key === key);
        if (it) it.description = ev.target.value;
    }

    apply() {
        this.props.onApply({
            ...this.props.node,
            label:   this.state.label,
            odoo_id: this.state.odoo_id,
            config: {
                name:         this.state.name,
                description:  this.state.description,
                greeting_id:  this.state.greeting_id,
                timeout:      Number(this.state.timeout),
                max_failures: Number(this.state.max_failures),
                menu_items:   this.state.items.map(it => ({
                    digit:       it.digit,
                    description: it.description,
                })),
            },
        });
    }
}