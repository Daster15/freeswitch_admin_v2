/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { Component, useState, onMounted, onWillUnmount } from "@odoo/owl";

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtDuration(sec) {
    if (sec == null || sec < 0) return "—";
    sec = Math.floor(sec);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) return `${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
    return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
}

// ── Sub-components ────────────────────────────────────────────────────────────

class CallerRow extends Component {
    static template = "freeswitch.CallerRow";
    static props = ["caller"];
}

class QueueCard extends Component {
    static template = "freeswitch.QueueCard";
    static props = ["queue"];
    static components = { CallerRow };
}

class AgentCard extends Component {
    static template = "freeswitch.AgentCard";
    static props = ["agent"];

    getInitials() {
        const n = this.props.agent.display_name || this.props.agent.name || "?";
        return n.split(/[\s-]/).map(w => w[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
    }
}

// ── Główny dashboard ──────────────────────────────────────────────────────────

class CCDashboard extends Component {
    static template = "freeswitch.CCDashboard";
    static components = { QueueCard, AgentCard };

    setup() {
        this.notification = useService("notification");
        this.state = useState({
            loading:      true,
            error:        null,
            data:         null,
            lastUpdate:   null,
            autoRefresh:  true,
            filterStatus: "all",
            selectedQueue: null,
        });
        this._timer = null;

        onMounted(() => {
            this._doLoad();
            this._timer = setInterval(() => {
                if (this.state.autoRefresh) {
                    this._doLoad();
                }
            }, 5000);
        });

        onWillUnmount(() => {
            if (this._timer) clearInterval(this._timer);
        });
    }

    // ── Ładowanie danych ──────────────────────────────────────────────────────
    // Używamy window.odoo.rpc zamiast fetch żeby mieć poprawną sesję Odoo

    async _doLoad() {
        try {
            // Używamy jsonrpc (type=json w Odoo) — poprawna sesja, brak problemów z CSRF
            const resp = await window.fetch("/freeswitch/cc_dashboard", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                credentials: "include",
                body: JSON.stringify({
                    jsonrpc: "2.0",
                    method:  "call",
                    id:      Date.now(),
                    params:  {},
                }),
            });
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const result = await resp.json();
            if (result.error) throw new Error(result.error.data?.message || result.error.message || "Błąd serwera");
            const data = result.result;
            if (!data) throw new Error("Brak danych");
            if (data.error) throw new Error(data.error);
            this.state.data       = data;
            this.state.error      = null;
            this.state.loading    = false;
            this.state.lastUpdate = new Date().toLocaleTimeString("pl-PL");
            if (!data.db_ok) {
                console.warn("CC Dashboard: brak połączenia z bazą FS — dane tylko z Odoo");
            }
        } catch (e) {
            this.state.error   = e.message;
            this.state.loading = false;
            console.error("CC Dashboard load error:", e);
        }
    }

    // ── Akcje — używamy normalnych metod (NIE arrow functions w szablonie) ────

    onRefresh() {
        this._doLoad();
    }

    onToggleAutoRefresh() {
        this.state.autoRefresh = !this.state.autoRefresh;
    }

    onSetQueue(name) {
        this.state.selectedQueue = (this.state.selectedQueue === name) ? null : name;
    }

    onClearQueue() {
        this.state.selectedQueue = null;
    }

    // Obsługa kliknięcia przycisku kolejki (data-queue)
    onQueueClick(ev) {
        const name = ev.currentTarget.dataset.queue;
        if (name) this.onSetQueue(name);
    }

    onSetFilter(f) {
        this.state.filterStatus = f;
    }

    // Obsługa kliknięcia filtra agentów (data-filter)
    onFilterClick(ev) {
        const f = ev.currentTarget.dataset.filter;
        if (f) this.onSetFilter(f);
    }

    // ── Computed ──────────────────────────────────────────────────────────────

    get queues() {
        if (!this.state.data) return [];
        const qs = this.state.data.queues || [];
        if (this.state.selectedQueue)
            return qs.filter(x => x.name === this.state.selectedQueue);
        return qs;
    }

    get agents() {
        if (!this.state.data) return [];
        let a = this.state.data.agents || [];
        if (this.state.selectedQueue)
            a = a.filter(x => (x.queues || []).includes(this.state.selectedQueue));
        const f = this.state.filterStatus;
        if (f === "available") a = a.filter(x => x.status === "Available");
        else if (f === "break") a = a.filter(x => x.status === "On Break");
        else if (f === "busy")  a = a.filter(x => x.state === "In a queue call" || x.state === "Receiving");
        else if (f === "logout") a = a.filter(x => x.status === "Logged Out");
        return a;
    }

    get summary() {
        if (!this.state.data) return {
            total_agents:0, available:0, on_break:0, logged_out:0,
            in_call:0, callers_waiting:0, total_queues:0
        };
        const ag = this.state.data.agents || [];
        const qu = this.state.data.queues || [];
        return {
            total_agents:    ag.length,
            available:       ag.filter(a => a.status === "Available").length,
            on_break:        ag.filter(a => a.status === "On Break").length,
            logged_out:      ag.filter(a => a.status === "Logged Out").length,
            in_call:         ag.filter(a => a.state === "In a queue call" || a.state === "Receiving").length,
            callers_waiting: qu.reduce((s, q) => s + (q.callers_waiting || 0), 0),
            total_queues:    qu.length,
        };
    }

    get allQueues() {
        if (!this.state.data) return [];
        return this.state.data.queues || [];
    }
}

registry.category("actions").add("freeswitch_cc_dashboard", CCDashboard);