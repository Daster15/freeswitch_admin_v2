/** @odoo-module **/
/**
 * FlowDesignerAction — główny komponent orchestratora
 * Odpowiada za: kanwę, drag & drop, połączenia, toolbar, zapis do Odoo.
 * Panel właściwości każdego węzła to osobny komponent.
 */
import { Component, useState, useRef, onMounted, onWillUnmount } from "@odoo/owl";
import { registry }    from "@web/core/registry";
import { useService }  from "@web/core/utils/hooks";

import { SoundSelector }    from "@freeswitch_admin/js/components/sound_selector";
import { DidPanel }         from "@freeswitch_admin/js/components/did_panel";
import { IvrPanel }         from "@freeswitch_admin/js/components/ivr_panel";
import { AudioPlayerPanel }  from "@freeswitch_admin/js/components/audio_player_panel";
import { FifoPanel,
         CallCenterPanel,
         SipUserPanel,
         TimerulePanel,
         PstnPanel,
         HolidayPanel }      from "@freeswitch_admin/js/components/node_panels";

// ─── NODE DEFS (metadane bez pól — te są w panelach) ─────────────────────────
const NODE_DEFS = {
    did:        { label: 'DID Inbound',    icon: '📞', inputs: [],     outputs: ['out'], odooModel: 'freeswitch.route'   },
    ivr:        { label: 'IVR Menu',       icon: '🎛', inputs: ['in'], outputs: ['timeout','fail'],               odooModel: 'freeswitch.ivr'     },
    timerule:   { label: 'Reguła Czasu',   icon: '⏰', inputs: ['in'], outputs: ['match','no_match'],             odooModel: null                 },
    holiday:    { label: 'Dni wolne',      icon: '🗓️', inputs: ['in'], outputs: ['holiday','workday'],            odooModel: null                 },
    callcenter: { label: 'Call Center',    icon: '🏢', inputs: ['in'], outputs: ['answered','abandoned'],         odooModel: 'freeswitch.cc.queue'},
    user:       { label: 'Użytkownik SIP', icon: '👤', inputs: ['in'], outputs: ['answered'],                    odooModel: 'freeswitch.sip.user'},
    pstn:       { label: 'PSTN / Gateway', icon: '🌐', inputs: ['in'], outputs: ['answered','failed'],            odooModel: null                 },
    audioplayer:{ label: 'Odtwórz Nagranie', icon: '🎵', inputs: ['in'], outputs: ['done'],                      odooModel: null                 },
};

const PALETTE_GROUPS = [
    { title: 'Wejście',         types: ['did'] },
    { title: 'Logika routingu', types: ['ivr'] },
    { title: 'Kolejki',         types: ['callcenter'] },
    { title: 'Cel',             types: ['user', 'pstn'] },
    { title: 'Media',           types: ['audioplayer'] },
];

// ─────────────────────────────────────────────────────────────────────────────
export class FlowDesignerAction extends Component {
    static template    = "freeswitch_admin.FlowDesignerAction";
    static components  = {
        SoundSelector,
        DidPanel, IvrPanel,
        FifoPanel, CallCenterPanel, SipUserPanel,
        TimerulePanel, PstnPanel, AudioPlayerPanel,
        HolidayPanel,
    };
    static props = ["action", "actionType?"];

    setup() {
        this.orm          = useService("orm");
        this.notification = useService("notification");
        this.actionSvc    = useService("action");

        this.canvasRef  = useRef("canvas");
        this.svgRef     = useRef("svgLayer");
        this.wrapperRef = useRef("wrapper");

        this.state = useState({
            nodes:       [],
            connections: [],

            // Wybrany węzeł (do pokazania panelu)
            selectedNode: null,

            // Dane z Odoo
            availableRecords: {},   // { did:[], ivr:[], fifo:[], callcenter:[], user:[] }
            availableSounds:  [],
            availableAgents:  [],   // freeswitch.cc.agent — do FIFO i CC

            // UI
            flowId:       null,
            flowName:     'Nowy przepływ',
            saving:       false,
            loading:      true,
            nodeCount:    0,
            connCount:    0,
            statusMsg:    'Wczytywanie...',
            showDropHint: true,
        });

        this._nodeCounter    = 0;
        this._isDraggingNode = false;
        this._dragNodeId     = null;
        this._dragOffsetX    = 0;
        this._dragOffsetY    = 0;
        this._isDrawingConn  = false;
        this._connFrom       = null;
        this._tempLinePath   = null;

        this._boundMouseMove = this._onMouseMove.bind(this);
        this._boundMouseUp   = this._onMouseUp.bind(this);

        // Bindy dla template
        this.onPaletteDragStart    = this.onPaletteDragStart.bind(this);
        this.onCanvasDragOver      = this.onCanvasDragOver.bind(this);
        this.onCanvasDrop          = this.onCanvasDrop.bind(this);
        this.onCanvasClick         = this.onCanvasClick.bind(this);
        this.onNodeClick           = this.onNodeClick.bind(this);
        this.onNodeHeaderMouseDown = this.onNodeHeaderMouseDown.bind(this);
        this.onPortOutMouseDown    = this.onPortOutMouseDown.bind(this);
        this.onPortInMouseUp       = this.onPortInMouseUp.bind(this);
        this.deleteNodeById        = this.deleteNodeById.bind(this);
        this.deleteConnection      = this.deleteConnection.bind(this);
        this.onPanelApply          = this.onPanelApply.bind(this);
        this.onPanelDelete         = this.onPanelDelete.bind(this);
        this.onPanelClose          = this.onPanelClose.bind(this);
        this.autoLayout            = this.autoLayout.bind(this);
        this.clearCanvas           = this.clearCanvas.bind(this);
        this.saveFlow              = this.saveFlow.bind(this);
        this.exportJSON            = this.exportJSON.bind(this);
        this.goBack                = this.goBack.bind(this);

        onMounted(() => this._init());
        onWillUnmount(() => {
            document.removeEventListener('mousemove', this._boundMouseMove);
            document.removeEventListener('mouseup',   this._boundMouseUp);
        });
    }

    // ─── INIT ────────────────────────────────────────────────────────────────

    async _init() {
        document.addEventListener('mousemove', this._boundMouseMove);
        document.addEventListener('mouseup',   this._boundMouseUp);

        const flowId = this.props.action.context?.flow_id;
        this.state.flowId = flowId || null;

        try {
            const data = await this.orm.call(
                'freeswitch.flow', 'get_designer_data', [flowId || 0]
            );
            this.state.availableRecords = data.records || {};
            this.state.availableSounds  = data.sounds  || [];

            // Pobierz urządzenia dla każdego agenta (model może nie istnieć)
            const rawAgents = data.agents || [];
            if (rawAgents.length) {
                try {
                    const agentIds = rawAgents.map(a => a.id);
                    const devices  = await this.orm.searchRead(
                        'freeswitch.sip.device',
                        [['user_id.cc_agent_id', 'in', agentIds], ['active', '=', true]],
                        ['id', 'display_name_device', 'label', 'device_type',
                         'ring_strategy', 'sequence', 'user_id', 'cc_agent_id'],
                        { order: 'user_id asc, sequence asc' }
                    );
                    this.state.availableAgents = rawAgents.map(agent => ({
                        ...agent,
                        devices: devices.filter(d =>
                            d.cc_agent_id && d.cc_agent_id[0] === agent.id
                        ),
                    }));
                } catch (_e) {
                    // freeswitch.sip.device może nie istnieć — ignorujemy
                    this.state.availableAgents = rawAgents.map(agent => ({
                        ...agent,
                        devices: [],
                    }));
                }
            } else {
                this.state.availableAgents = [];
            }
            this.state.flowName = data.flow_name || 'Przepływ';

            const nodes = data.flow_data?.nodes;
            if (nodes && Array.isArray(nodes) && nodes.length > 0) {
                this._restoreFlow(data.flow_data);
            } else {
                this._loadEmpty();
            }
        } catch (e) {
            console.error('FlowDesigner _init error:', e);
            this._loadEmpty();
            this._setStatus('Błąd wczytywania danych');
        } finally {
            this.state.loading = false;
        }
    }

    _restoreFlow(flowData) {
        flowData.nodes.forEach(n => {
            this._nodeCounter = Math.max(
                this._nodeCounter,
                parseInt(n.id.replace('n','')) || 0
            );
            this.state.nodes.push({
                id:      n.id,
                type:    n.type,
                x:       n.position?.x ?? n.x ?? 0,
                y:       n.position?.y ?? n.y ?? 0,
                label:   n.label,
                config:  n.config  || {},
                odoo_id: n.odoo_id || null,
            });
        });
        this.state.connections = flowData.connections || [];
        this._updateStats();
        this.state.showDropHint = false;
        this._setStatus(`Wczytano: ${this.state.flowName}`);
    }

    _loadEmpty() {
        this.state.nodes = [];
        this.state.connections = [];
        this.state.selectedNode = null;
        this._updateStats();
        this.state.showDropHint = true;
        this._setStatus('Nowy przepływ — przeciągnij węzły z palety');
    }

    _loadDemo() {
        const d  = this._addNode('did',        60,   80);
        const t  = this._addNode('timerule',  320,   80);
        const iv = this._addNode('ivr',        580,   60);
        const cc = this._addNode('callcenter', 840,  240);
        const us = this._addNode('user',      1100,   40);

        d.label  = 'Numer Główny';    d.config  = { did_pattern: '^\\+?48221234567$', description: 'Infolinia' };
        t.label  = 'Godziny Pracy';
        iv.label = 'IVR Główne';      iv.config = { name: 'ivr-glowne', description: 'Menu główne', menu_items: [
            { digit:'1', description:'Sprzedaż',  action:'callcenter', target_id:null, target_pstn:'', target:'' },
            { digit:'2', description:'Serwis',    action:'callcenter', target_id:null, target_pstn:'', target:'' },
            { digit:'3', description:'Sekretariat',action:'user',      target_id:null, target_pstn:'', target:'' },
        ], timeout:7, max_failures:3, default_action:'hangup' };
        cc.label = 'Serwis CC';      cc.config = { name:'cc-serwis', strategy:'longest-idle-agent' };
        us.label = 'Sekretariat';    us.config = { extension:'1001', first_name:'Jan', last_name:'Kowalski' };

        this.state.connections = [
            { id:'c1', fromNode:d.id,  fromPort:'out',     toNode:t.id,  toPort:'in' },
            { id:'c2', fromNode:t.id,  fromPort:'match',   toNode:iv.id, toPort:'in' },
        ];
        this._updateStats();
        this._setStatus('Demo załadowane');
    }

    // ─── WĘZŁY ───────────────────────────────────────────────────────────────

    _addNode(type, x, y) {
        if (!NODE_DEFS[type]) return null;
        const node = { id:`n${++this._nodeCounter}`, type, x, y,
                       label: NODE_DEFS[type].label, config:{}, odoo_id:null };
        this.state.nodes.push(node);
        this._updateStats();
        this.state.showDropHint = false;
        return node;
    }

    _deleteNode(nodeId) {
        const idx = this.state.nodes.findIndex(n => n.id === nodeId);
        if (idx !== -1) this.state.nodes.splice(idx, 1);
        this.state.connections = this.state.connections.filter(
            c => c.fromNode !== nodeId && c.toNode !== nodeId
        );
        if (this.state.selectedNode?.id === nodeId) this.state.selectedNode = null;
        this._updateStats();
        if (!this.state.nodes.length) this.state.showDropHint = true;
    }

    _updateStats() {
        this.state.nodeCount = this.state.nodes.length;
        this.state.connCount = this.state.connections.length;
    }

    _setStatus(msg) { this.state.statusMsg = msg; }

    getNodeDef(type)   { return NODE_DEFS[type] || {}; }
    getPaletteGroups() { return PALETTE_GROUPS; }

    getNodeOutputs(node) {
        if (node.type === 'ivr') {
            const digits = (node.config && node.config.menu_items || [])
                .map(function(it) { return it.digit; })
                .filter(function(d) { return !!d; });
            return digits.concat(['timeout', 'fail']);
        }
        if (node.type === 'audioplayer') {
            const action = (node.config && node.config.after_action) || 'hangup';
            return (action === 'hangup' || action === 'repeat') ? [] : ['done'];
        }
        return (NODE_DEFS[node.type] && NODE_DEFS[node.type].outputs) || [];
    }

    // ─── DRAG PALETTE ─────────────────────────────────────────────────────────

    onPaletteDragStart(ev, type) {
        ev.dataTransfer.setData('nodeType', type);
        ev.dataTransfer.effectAllowed = 'copy';
    }

    onCanvasDragOver(ev) { ev.preventDefault(); ev.dataTransfer.dropEffect = 'copy'; }

    onCanvasDrop(ev) {
        ev.preventDefault();
        const type = ev.dataTransfer.getData('nodeType');
        if (!type || !NODE_DEFS[type]) return;
        const rect = this.wrapperRef.el.getBoundingClientRect();
        this._addNode(type, ev.clientX - rect.left - 90, ev.clientY - rect.top - 40);
    }

    // ─── DRAG WĘZŁA ──────────────────────────────────────────────────────────

    onNodeHeaderMouseDown(ev, nodeId) {
        if (ev.button !== 0) return;
        ev.stopPropagation();
        this._isDraggingNode = true;
        this._dragNodeId     = nodeId;
        const nodeEl = this.canvasRef.el.querySelector(`[data-node-id="${nodeId}"]`);
        const rect   = nodeEl.getBoundingClientRect();
        this._dragOffsetX = ev.clientX - rect.left;
        this._dragOffsetY = ev.clientY - rect.top;
    }

    _onMouseMove(ev) {
        if (this._isDraggingNode && this._dragNodeId) {
            const wRect = this.wrapperRef.el.getBoundingClientRect();
            const node  = this.state.nodes.find(n => n.id === this._dragNodeId);
            if (node) {
                node.x = Math.max(0, ev.clientX - wRect.left - this._dragOffsetX);
                node.y = Math.max(0, ev.clientY - wRect.top  - this._dragOffsetY);
            }
        }
        if (this._isDrawingConn && this._tempLinePath) {
            const wRect = this.wrapperRef.el.getBoundingClientRect();
            const from  = this._getPortPos(this._connFrom.nodeId, this._connFrom.portName, 'out');
            this._tempLinePath.setAttribute('d',
                this._bezier(from.x, from.y,
                    ev.clientX - wRect.left,
                    ev.clientY - wRect.top));
        }
    }

    _onMouseUp() {
        this._isDraggingNode = false;
        this._dragNodeId     = null;
        if (this._isDrawingConn) this._cancelDrawConn();
    }

    // ─── KLIK WĘZŁA / KANWA ──────────────────────────────────────────────────

    onNodeClick(ev, nodeId) {
        if (ev.target.closest('[data-port]') || ev.target.closest('.o-fs-node-delete')) return;
        const node = this.state.nodes.find(n => n.id === nodeId);
        this.state.selectedNode = node || null;
    }

    onCanvasClick(ev) {
        if (ev.target === this.wrapperRef.el || ev.target.closest('.o-fs-grid-bg')) {
            this.state.selectedNode = null;
        }
    }

    deleteNodeById(nodeId) { this._deleteNode(nodeId); }

    // ─── POŁĄCZENIA ───────────────────────────────────────────────────────────

    onPortOutMouseDown(ev, nodeId, portName) {
        ev.preventDefault();
        ev.stopPropagation();
        this._isDrawingConn = true;
        this._connFrom      = { nodeId, portName };
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        line.setAttribute('fill', 'none');
        line.setAttribute('stroke', '#94a3b8');
        line.setAttribute('stroke-width', '2');
        line.setAttribute('stroke-dasharray', '6 4');
        this.svgRef.el.appendChild(line);
        this._tempLinePath = line;
    }

    onPortInMouseUp(ev, nodeId, portName) {
        ev.stopPropagation();
        if (!this._isDrawingConn || !this._connFrom || this._connFrom.nodeId === nodeId) {
            this._cancelDrawConn(); return;
        }
        // Jeden port out → tylko jedno połączenie
        const dup = this.state.connections.find(c =>
            c.fromNode === this._connFrom.nodeId && c.fromPort === this._connFrom.portName
        );
        if (!dup) {
            this.state.connections.push({
                id:       `c${Date.now()}`,
                fromNode: this._connFrom.nodeId,
                fromPort: this._connFrom.portName,
                toNode:   nodeId,
                toPort:   portName,
            });
            this._updateStats();
        }
        this._cancelDrawConn();
    }

    _cancelDrawConn() {
        this._isDrawingConn = false;
        this._connFrom      = null;
        if (this._tempLinePath) { this._tempLinePath.remove(); this._tempLinePath = null; }
    }

    deleteConnection(connId) {
        this.state.connections = this.state.connections.filter(c => c.id !== connId);
        this._updateStats();
    }

    // ─── GEOMETRIA ────────────────────────────────────────────────────────────

    _getPortPos(nodeId, portName, dir) {
        if (!this.canvasRef.el) return { x:0, y:0 };
        const nodeEl = this.canvasRef.el.querySelector(`[data-node-id="${nodeId}"]`);
        if (!nodeEl) return { x:0, y:0 };
        const portEl = nodeEl.querySelector(`[data-port="${portName}"][data-dir="${dir}"]`);
        if (!portEl) return { x:0, y:0 };
        const dot   = portEl.querySelector('.o-fs-port-dot');
        if (!dot) return { x:0, y:0 };
        const wRect = this.wrapperRef.el.getBoundingClientRect();
        const dRect = dot.getBoundingClientRect();
        return { x: dRect.left - wRect.left + dRect.width/2, y: dRect.top - wRect.top + dRect.height/2 };
    }

    _bezier(x1, y1, x2, y2) {
        const dx = Math.abs(x2-x1) * 0.5 + 40;
        return `M${x1},${y1} C${x1+dx},${y1} ${x2-dx},${y2} ${x2},${y2}`;
    }

    get renderedConnections() {
        return this.state.connections.map(c => {
            const fromNode = this.state.nodes.find(n => n.id === c.fromNode);
            const from = this._getPortPos(c.fromNode, c.fromPort, 'out');
            const to   = this._getPortPos(c.toNode,   c.toPort,   'in');
            if (from.x === 0 && from.y === 0) return null;
            return {
                id:       c.id,
                path:     this._bezier(from.x, from.y, to.x, to.y),
                colorKey: fromNode?.type || 'default',
                label:    c.fromPort,
                labelX:   (from.x + to.x) / 2,
                labelY:   (from.y + to.y) / 2 - 8,
            };
        }).filter(Boolean);
    }

    // ─── PANEL CALLBACKS ─────────────────────────────────────────────────────

    onPanelApply(updatedNode) {
        const idx = this.state.nodes.findIndex(n => n.id === updatedNode.id);
        if (idx !== -1) this.state.nodes[idx] = updatedNode;
        this.state.selectedNode = updatedNode;

        // Usuń połączenia z portów które już nie istnieją (IVR cyfry, audioplayer akcja)
        if (updatedNode.type === 'ivr' || updatedNode.type === 'audioplayer') {
            const validPorts = this.getNodeOutputs(updatedNode);
            const validSet = {};
            validPorts.forEach(function(p) { validSet[p] = true; });
            this.state.connections = this.state.connections.filter(function(c) {
                return c.fromNode !== updatedNode.id || validSet[c.fromPort];
            });
        }

        this._setStatus(`Zaktualizowano: ${updatedNode.label}`);
        this.notification.add('Zastosowano. Kliknij "Zapisz do Odoo" aby zsynchronizować.', {
            type: 'info', sticky: false,
        });
    }

    onPanelDelete() {
        if (this.state.selectedNode) this._deleteNode(this.state.selectedNode.id);
    }

    onPanelClose() {
        this.state.selectedNode = null;
    }

    // ─── PANEL PROPS DO PODKOMPONENTÓW ───────────────────────────────────────

    get panelPropsBase() {
        return {
            node:     this.state.selectedNode,
            onApply:  this.onPanelApply,
            onDelete: this.onPanelDelete,
            onClose:  this.onPanelClose,
        };
    }

    get didPanelProps() {
        return { ...this.panelPropsBase, records: this.state.availableRecords.did || [], orm: this.orm };
    }
    get ivrPanelProps() {
        return { ...this.panelPropsBase, records: this.state.availableRecords, sounds: this.state.availableSounds, orm: this.orm };
    }
    get fifoPanelProps() {
        return { ...this.panelPropsBase, records: this.state.availableRecords.fifo || [], allRecords: this.state.availableRecords, sounds: this.state.availableSounds, agents: this.state.availableAgents, orm: this.orm };
    }
    get ccPanelProps() {
        return { ...this.panelPropsBase, records: this.state.availableRecords.callcenter || [], sounds: this.state.availableSounds, agents: this.state.availableAgents, orm: this.orm };
    }
    get userPanelProps() {
        // Zapewnij że records i allRecords.user to ta sama instancja tablicy
        if (!this.state.availableRecords.user) {
            this.state.availableRecords.user = [];
        }
        return { ...this.panelPropsBase, records: this.state.availableRecords.user, allRecords: this.state.availableRecords, sounds: this.state.availableSounds, orm: this.orm };
    }
    get timerulePanelProps() {
        return this.panelPropsBase;
    }
    get pstnPanelProps() {
        return this.panelPropsBase;
    }
    get audioPlayerPanelProps() {
        return { ...this.panelPropsBase, sounds: this.state.availableSounds, records: this.state.availableRecords };
    }
    get holidayPanelProps() {
        return {
            ...this.panelPropsBase,
            records: this.state.availableRecords,
            sounds:  this.state.availableSounds,
            orm:     this.orm,
        };
    }

    // ─── LAYOUT / CLEAR ──────────────────────────────────────────────────────

    autoLayout() {
        const order = ['did','timerule','ivr','callcenter','user','pstn'];
        const cols  = {};
        this.state.nodes.forEach(n => {
            const col = order.includes(n.type) ? order.indexOf(n.type) : order.length;
            (cols[col] = cols[col] || []).push(n);
        });
        Object.keys(cols).sort().forEach((col, ci) => {
            cols[col].forEach((n, ri) => { n.x = 60 + ci*270; n.y = 80 + ri*210; });
        });
        this.notification.add('⚡ Auto-layout zastosowany', { type:'info', sticky:false });
    }

    clearCanvas() {
        if (this.state.nodes.length && !confirm('Wyczyścić całe płótno?')) return;
        this.state.nodes.splice(0);
        this.state.connections = [];
        this.state.selectedNode = null;
        this._updateStats();
        this.state.showDropHint = true;
    }

    // ─── ZAPIS ────────────────────────────────────────────────────────────────

    async saveFlow() {
        this.state.saving = true;
        const payload = {
            nodes: this.state.nodes.map(n => ({
                id: n.id, type: n.type, label: n.label,
                position: { x: n.x, y: n.y },
                config:   n.config,
                odoo_id:  n.odoo_id || null,
            })),
            connections: this.state.connections,
        };
        try {
            let result;
            if (this.state.flowId) {
                result = await this.orm.call('freeswitch.flow', 'save_flow_with_sync', [this.state.flowId, payload]);
            } else {
                const id = await this.orm.create('freeswitch.flow', [{ name: this.state.flowName, flow_data: JSON.stringify(payload) }]);
                this.state.flowId = id;
                result = await this.orm.call('freeswitch.flow', 'save_flow_with_sync', [id, payload]);
            }
            // Zaktualizuj odoo_id
            if (result?.flow_data?.nodes) {
                result.flow_data.nodes.forEach(upd => {
                    const local = this.state.nodes.find(n => n.id === upd.id);
                    if (local && upd.odoo_id) local.odoo_id = upd.odoo_id;
                });
            }
            this.notification.add(`💾 Zapisano i zsynchronizowano ${result?.node_count || 0} węzłów.`, { type:'success' });
            this._setStatus('Zapisano do Odoo');
        } catch (e) {
            this.notification.add(`❌ ${e.message || e}`, { type:'danger', sticky:true });
        } finally {
            this.state.saving = false;
        }
    }

    exportJSON() {
        const blob = new Blob([JSON.stringify({
            version:'2.0', flow_name:this.state.flowName, generated:new Date().toISOString(),
            nodes:this.state.nodes, connections:this.state.connections,
        }, null, 2)], { type:'application/json' });
        const a = Object.assign(document.createElement('a'), { href:URL.createObjectURL(blob), download:`flow-${Date.now()}.json` });
        a.click(); URL.revokeObjectURL(a.href);
    }

    goBack() {
        this.actionSvc.doAction({ type:'ir.actions.act_window', res_model:'freeswitch.flow', view_mode:'list,form' });
    }
}

registry.category("actions").add("freeswitch_flow_designer", FlowDesignerAction);