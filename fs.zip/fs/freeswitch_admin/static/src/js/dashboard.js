/** @odoo-module **/

/**
 * freeswitch_admin — dashboard.js
 * Pomocnik JS dla modułu FreeSWITCH Admin.
 */

// Formatowanie sekund → "mm:ss"
export function formatDuration(seconds) {
    if (!seconds || seconds <= 0) return "–";
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
}
