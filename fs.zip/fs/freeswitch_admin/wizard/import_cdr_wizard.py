# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class ImportCDRWizard(models.TransientModel):
    _name        = 'freeswitch.import.cdr.wizard'
    _description = 'Import CDR z FreeSWITCH'
    _inherit     = ['freeswitch.db.mixin']

    date_from = fields.Date(
        string='Data od',
        required=True,
        default=lambda self: fields.Date.subtract(fields.Date.today(), days=7),
    )
    date_to = fields.Date(
        string='Data do',
        required=True,
        default=lambda self: fields.Date.today(),
    )
    limit = fields.Integer(string='Limit rekordów', default=1000)
    queue_name = fields.Char(string='Filtr kolejki (opcjonalnie)')

    def action_import(self):
        CDR = self.env['freeswitch.cdr']
        return CDR.action_sync_from_fs(
            limit=self.limit,
            date_from=self.date_from,
        )
