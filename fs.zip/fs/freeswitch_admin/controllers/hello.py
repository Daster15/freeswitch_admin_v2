# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

print("=== HELLO.PY ZALADOWANY ===")


class HelloController(http.Controller):

    @http.route('/fs/api/hello', type="json", auth="none", methods=['POST'])
    def prosave_push_order(self, **post):
        return 'czesc'

    @http.route('/hello', auth='public')
    def hello(self, **kw):
        print("=== HELLO ENDPOINT HIT ===")
        return 'czesc'