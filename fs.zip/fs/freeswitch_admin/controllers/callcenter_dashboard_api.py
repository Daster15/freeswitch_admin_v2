# -*- coding: utf-8 -*-
"""
callcenter_dashboard_api.py
===========================
Endpoint JSON dla dashboardu CC.
Używa jsonrpc (type='json') żeby działać poprawnie z OWL/fetch w Odoo.
Dane FS czyta przez model freeswitch.cc.queue który dziedziczy freeswitch.db.mixin.
"""
import time
import logging

from odoo import http, models, fields, api
from odoo.http import request

_logger = logging.getLogger(__name__)


def _fmt_duration(sec):
    if sec is None or sec < 0:
        return '—'
    sec = int(sec)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    if h > 0:
        return f'{h}:{m:02d}:{s:02d}'
    return f'{m:02d}:{s:02d}'


class CallCenterDashboardController(http.Controller):

    @http.route('/freeswitch/cc_dashboard', type='json', auth='user',
                methods=['POST'], csrf=False)
    def cc_dashboard_data(self, **kwargs):
        """
        Endpoint JSON (type='json' = jsonrpc) — poprawnie obsługiwany
        przez fetch/OWL w Odoo bez problemów z CSRF.
        """
        try:
            return self._build_dashboard_data()
        except Exception as e:
            _logger.error('CC dashboard error: %s', e, exc_info=True)
            return {'error': str(e), 'ts': int(time.time())}

    def _build_dashboard_data(self):
        env = request.env
        company_id = env.company.id

        # ── Konfiguracja z Odoo ───────────────────────────────────────────────
        cfg        = env['freeswitch.company.config'].sudo()._get_for_company(env.company)
        sip_domain = cfg.sip_domain or 'localhost'

        queues_odoo = env['freeswitch.cc.queue'].sudo().search([
            ('active', '=', True),
            ('company_id', '=', company_id),
        ])
        agents_odoo = env['freeswitch.cc.agent'].sudo().search([
            ('active', '=', True),
            ('company_id', '=', company_id),
        ])

        # ── Live data z bazy FS ───────────────────────────────────────────────
        # freeswitch.cc.queue dziedziczy freeswitch.db.mixin → _fs_query działa
        fs_agents  = {}  # name → dict
        fs_members = []  # aktywni callerzy
        now = int(time.time())

        db_ok = False
        if queues_odoo:
            try:
                # Test połączenia
                test = queues_odoo[0]._fs_query("SELECT 1 AS ok")
                if test:
                    db_ok = True
            except Exception as e:
                _logger.warning('CC dashboard: brak połączenia z bazą FS: %s', e)

        if db_ok:
            try:
                # Agenci — status runtime, talk_time, calls_answered itp.
                rows = queues_odoo[0]._fs_query("""
                    SELECT
                        name, instance_id, uuid, type, contact,
                        status, state,
                        last_bridge_start, last_bridge_end,
                        calls_answered, talk_time, no_answer_count,
                        wrap_up_time, ready_time
                    FROM agents
                    ORDER BY name
                """)
                for r in (rows or []):
                    n = r.get('name')
                    if n:
                        fs_agents[n] = r
                _logger.info('CC dashboard: %d agentów z bazy FS', len(fs_agents))
            except Exception as e:
                _logger.warning('CC dashboard agents query error: %s', e)

            try:
                # Callerzy — aktywni members w kolejkach
                fs_members = queues_odoo[0]._fs_query("""
                    SELECT
                        queue, uuid, session_uuid,
                        cid_number, cid_name,
                        joined_epoch, bridge_epoch,
                        state, serving_agent
                    FROM members
                    WHERE state NOT IN ('Abandoned')
                    ORDER BY joined_epoch
                """) or []
                _logger.info('CC dashboard: %d memberów z bazy FS', len(fs_members))
            except Exception as e:
                _logger.warning('CC dashboard members query error: %s', e)

        # ── Buduj dane kolejek ────────────────────────────────────────────────
        queues_data = []
        for q in queues_odoo:
            fs_name = f'{q.name}@{sip_domain}'

            # Callerzy w tej kolejce z bazy FS
            callers = []
            for m in fs_members:
                mq = m.get('queue', '')
                if mq != fs_name:
                    continue
                joined   = int(m.get('joined_epoch') or 0)
                wait_sec = max(0, now - joined) if joined > 0 else 0
                callers.append({
                    'uuid':          m.get('uuid', ''),
                    'cid_number':    m.get('cid_number') or '',
                    'cid_name':      m.get('cid_name')   or '',
                    'state':         m.get('state')       or '',
                    'serving_agent': m.get('serving_agent') or '',
                    'wait_sec':      wait_sec,
                    'wait_fmt':      _fmt_duration(wait_sec),
                })

            # Agenci przypisani do kolejki (przez tiery Odoo)
            queue_agent_names = [
                t.agent_id.name for t in q.tier_ids
                if t.agent_id and t.agent_id.active
            ]

            # Status agentów z bazy FS (fallback: z Odoo)
            agents_available = 0
            for aname in queue_agent_names:
                fs_a = fs_agents.get(aname)
                status = (fs_a.get('status') if fs_a else None) or ''
                if status == 'Available':
                    agents_available += 1

            queues_data.append({
                'id':               q.id,
                'name':             q.name,
                'fs_name':          fs_name,
                'description':      q.description or '',
                'strategy':         q.strategy    or '',
                'agents_total':     len(queue_agent_names),
                'agents_available': agents_available,
                'callers_waiting':  len([c for c in callers if c['state'] == 'Waiting']),
                'callers_trying':   len([c for c in callers if c['state'] == 'Trying']),
                'callers_answered': len([c for c in callers if c['state'] == 'Answered']),
                'callers':          callers,
            })

        # ── Buduj dane agentów ────────────────────────────────────────────────
        agents_data = []
        for a in agents_odoo:
            fs  = fs_agents.get(a.name, {})

            # Status: priorytet baza FS → Odoo
            status = fs.get('status') or a.status or 'Logged Out'
            state  = fs.get('state')  or a.state  or 'Waiting'

            last_bridge_end = int(fs.get('last_bridge_end') or 0)
            talk_time       = int(fs.get('talk_time')       or 0)
            calls_answered  = int(fs.get('calls_answered')  or 0)
            idle_sec        = (now - last_bridge_end) if last_bridge_end > 0 else None

            agent_queues = [
                t.queue_id.name for t in a.tier_ids
                if t.queue_id and t.queue_id.active
            ]

            agents_data.append({
                'id':             a.id,
                'name':           a.name,
                'display_name':   a.display_name_field or a.name,
                'extension':      a.extension or '',
                'status':         status,
                'state':          state,
                'talk_time':      talk_time,
                'talk_time_fmt':  _fmt_duration(talk_time),
                'calls_answered': calls_answered,
                'idle_sec':       idle_sec,
                'idle_fmt':       _fmt_duration(idle_sec) if idle_sec is not None else '—',
                'queues':         agent_queues,
                'fs_data':        db_ok,   # czy dane są z FS czy tylko z Odoo
            })

        return {
            'queues':  queues_data,
            'agents':  agents_data,
            'ts':      now,
            'db_ok':   db_ok,
            'company': env.company.name,
        }