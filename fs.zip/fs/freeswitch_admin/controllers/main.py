# -*- coding: utf-8 -*-
"""
controllers/main.py
===================
Endpointy HTTP dla FreeSWITCH → Odoo:
  POST  /freeswitch/cdr/webhook      — CDR webhook (cdr_writer.lua / mod_json_cdr)
  GET   /freeswitch/health           — health check
  POST  /freeswitch/xml_curl         — mod_xml_curl (directory + callcenter.conf + fifo.conf)
  GET   /freeswitch/cc/agents        — lista agentów CC dla cc_heartbeat.lua

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PRZYKŁADY ZAPYTAŃ POST
======================

────────────────────────────────────────────────────────────────────────────────
1. CDR Webhook — POST /freeswitch/cdr/webhook
────────────────────────────────────────────────────────────────────────────────
curl -X POST http://localhost:8069/freeswitch/cdr/webhook \\
     -H "Content-Type: application/json" \\
     -d '{"uuid": "550e8400-...", "hangup_cause": "NORMAL_CLEARING", "billsec": "120", ...}'

────────────────────────────────────────────────────────────────────────────────
2. XML cURL — section=directory (użytkownicy SIP)
────────────────────────────────────────────────────────────────────────────────
curl -X POST http://localhost:8069/freeswitch/xml_curl \\
     -d "section=directory" -d "tag_name=user" -d "key_name=id" \\
     -d "key_value=1001" -d "domain=sip.firma.pl"

────────────────────────────────────────────────────────────────────────────────
3. XML cURL — section=configuration, key_value=callcenter.conf
────────────────────────────────────────────────────────────────────────────────
curl -X POST http://localhost:8069/freeswitch/xml_curl \\
     -d "section=configuration" -d "key_value=callcenter.conf"

────────────────────────────────────────────────────────────────────────────────
4. XML cURL — section=configuration, key_value=fifo.conf
────────────────────────────────────────────────────────────────────────────────
Wywoływane przez mod_fifo przy starcie / reload mod_fifo.
Zwraca kolejki FIFO z agentami jako statyczne <member> (jak fifo.conf).

curl -X POST http://localhost:8069/freeswitch/xml_curl \\
     -d "section=configuration" -d "key_value=fifo.conf"

Przykładowa odpowiedź:
  <fifo name="fifo-kolejka@sip.example.pl" importance="0" music-on-hold="...">
    <member timeout="30" simo="1" lag="0">
      {call_timeout=30,fifo_member_wait=nowait,ignore_early_media=true}
      sofia/gateway/PSTN/609224226
    </member>
  </fifo>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
import json
import logging
from datetime import datetime

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)

# ── Dozwolone adresy IP dla xml_curl i cc/agents ─────────────────────────────
_ALLOWED_IPS = {
    '127.0.0.1',
    '::1',
    '192.168.0.58',   # FreeSWITCH — ltech-ARYK-T16
}


# ══════════════════════════════════════════════════════════════════════════════
# CDR WEBHOOK + HEALTH CHECK
# ══════════════════════════════════════════════════════════════════════════════

class FreeSwitchWebhookController(http.Controller):

    @http.route('/freeswitch/cdr/webhook', type='json', auth='none', methods=['POST'], csrf=False)
    def cdr_webhook(self, **kwargs):
        """Odbiera CDR z FreeSWITCH i zapisuje do modelu freeswitch.cdr."""
        try:
            data = json.loads(request.httprequest.data)
        except Exception:
            data = kwargs

        uuid = data.get('uuid') or data.get('call_uuid', '')
        if not uuid:
            return {'status': 'error', 'message': 'Brak UUID'}

        _logger.info("CDR webhook: uuid=%s cause=%s dur=%s",
                     uuid, data.get('hangup_cause'), data.get('duration'))

        def to_dt(epoch):
            try:
                e = int(epoch)
                return datetime.utcfromtimestamp(e) if e > 0 else None
            except Exception:
                return None

        def to_int(val, default=0):
            try:
                return int(val or 0)
            except Exception:
                return default

        billsec = to_int(data.get('billsec'))
        status  = (
            'completed'  if billsec > 0                                      else
            'no_answer'  if data.get('hangup_cause') == 'NO_ANSWER'          else
            'cancelled'  if data.get('hangup_cause') == 'ORIGINATOR_CANCEL'  else
            'busy'       if data.get('hangup_cause') == 'USER_BUSY'          else
            'failed'
        )

        vals = {
            'fs_uuid':         uuid,
            'caller_id_name':  data.get('caller_id_name', ''),
            'caller_id_num':   data.get('caller_id_number') or data.get('caller_id_num', ''),
            'destination_num': data.get('destination_number') or data.get('destination_num', ''),
            'direction':       data.get('direction', 'inbound'),
            'status':          status,
            'start_time':      to_dt(data.get('start_epoch')),
            'answer_time':     to_dt(data.get('answer_epoch')),
            'end_time':        to_dt(data.get('end_epoch')),
            'duration_sec':    to_int(data.get('duration')),
            'billsec':         billsec,
            'wait_time_sec':   to_int(data.get('wait_time_sec')),
            'hangup_cause':    data.get('hangup_cause', ''),
            'recording_path':  data.get('recording_file') or data.get('recording_path', ''),
            'route_type':      data.get('route_type', ''),
            'route_target':    data.get('route_target', ''),
            'queue_name':      data.get('queue_name') or data.get('cc_queue', ''),
            'agent_id':        data.get('agent_id') or data.get('cc_agent', ''),
            'ivr_name':        data.get('ivr_name', ''),
            'placowka':        data.get('placowka', ''),
        }

        CDR = request.env['freeswitch.cdr'].sudo()
        existing = CDR.search([('fs_uuid', '=', uuid)], limit=1)
        if existing:
            existing.write(vals)
        else:
            CDR.create(vals)

        return {'status': 'ok', 'uuid': uuid}

    @http.route('/freeswitch/health', type='http', auth='none', methods=['GET'], csrf=False)
    def health(self):
        """Health check — sprawdza czy Odoo jest żywe."""
        return request.make_response('{"status":"ok","app":"freeswitch_admin"}',
                                     headers=[('Content-Type', 'application/json')])


# ══════════════════════════════════════════════════════════════════════════════
# XML CURL — główny router + helpery
# ══════════════════════════════════════════════════════════════════════════════

class FreeSwitchXmlCurlController(http.Controller):

    # ── Helpery XML ───────────────────────────────────────────────────────────

    @staticmethod
    def _xml_resp(root_el):
        from xml.etree.ElementTree import tostring
        body = b'<?xml version="1.0" encoding="UTF-8"?>\n' + tostring(root_el, encoding='utf-8')
        return request.make_response(body, headers=[('Content-Type', 'text/xml; charset=utf-8')])

    @staticmethod
    def _not_found():
        from xml.etree.ElementTree import Element, SubElement
        root = Element('document', type='freeswitch/xml')
        SubElement(SubElement(root, 'section', name='result'), 'not-found')
        return FreeSwitchXmlCurlController._xml_resp(root)

    @staticmethod
    def _get_remote_ip():
        remote_ip = request.httprequest.remote_addr or ''
        fwd = request.httprequest.headers.get('X-Forwarded-For', '')
        if fwd:
            remote_ip = fwd.split(',')[0].strip()
        return remote_ip

    def _get_cfg(self, params):
        """Uwierzytelnij po IP i zwróć freeswitch.company.config."""
        if self._get_remote_ip() not in _ALLOWED_IPS:
            _logger.warning('xml_curl: odrzucono IP=%s', self._get_remote_ip())
            return None
        domain_hint = params.get('domain') or params.get('key_value') or ''
        cfg = None
        if domain_hint:
            cfg = request.env['freeswitch.company.config'].sudo().search(
                [('sip_domain', '=', domain_hint)], limit=1)
        if not cfg:
            cfg = request.env['freeswitch.company.config'].sudo().search([], limit=1)
        return cfg or None

    # ── Główny endpoint ───────────────────────────────────────────────────────

    @http.route('/freeswitch/xml_curl', type='http', auth='none',
                methods=['POST', 'GET'], csrf=False)
    def xml_curl(self, **kw):
        params  = request.httprequest.form.to_dict()
        params.update(request.httprequest.args.to_dict())
        section = params.get('section', '')
        _logger.warning(
            'xml_curl HIT: method=%s ip=%s section=%s key_value=%s CC-Queue=%s all_params=%s',
            request.httprequest.method,
            request.httprequest.remote_addr,
            section,
            params.get('key_value'),
            params.get('CC-Queue'),
            params,
        )

        if self._get_remote_ip() not in _ALLOWED_IPS:
            _logger.warning('xml_curl: odrzucono IP=%s', self._get_remote_ip())
            return self._not_found()

        if section == 'directory':
            return self._handle_directory(params)
        if section == 'configuration':
            return self._handle_configuration(params)
        return self._not_found()

    # ══════════════════════════════════════════════════════════════════════════
    # DIRECTORY — użytkownicy SIP
    # ══════════════════════════════════════════════════════════════════════════

    def _handle_directory(self, params):
        from xml.etree.ElementTree import Element, SubElement
        cfg = self._get_cfg(params)
        if not cfg:
            return self._not_found()

        tag_name  = params.get('tag_name', '')
        key_name  = params.get('key_name', '')
        key_value = params.get('key_value', '')
        domain    = cfg.sip_domain or key_value

        root      = Element('document', type='freeswitch/xml')
        section   = SubElement(root, 'section', name='directory')
        domain_el = SubElement(section, 'domain', name=domain)

        dom_params = SubElement(domain_el, 'params')
        SubElement(dom_params, 'param', name='dial-string',
                   value='{^^:sip_invite_domain=${dialed_domain}'
                         ':presence_id=${dialed_user}@${dialed_domain}}'
                         'sofia/internal/${dialed_user}@${dialed_domain}')
        dom_vars = SubElement(domain_el, 'variables')
        SubElement(dom_vars, 'variable', name='record_stereo',               value='true')
        SubElement(dom_vars, 'variable', name='default_gateway',             value=cfg.gateway or '')
        SubElement(dom_vars, 'variable', name='transfer_fallback_extension', value='operator')

        users_el = SubElement(domain_el, 'users')

        if tag_name == 'user' or key_name == 'id':
            user = request.env['freeswitch.sip.user'].sudo().search([
                ('name',       '=', key_value),
                ('company_id', '=', cfg.company_id.id),
                ('active',     '=', True),
            ], limit=1)
            if not user:
                return self._not_found()
            self._user_xml(users_el, user, cfg)
        else:
            users = request.env['freeswitch.sip.user'].sudo().search([
                ('company_id', '=', cfg.company_id.id),
                ('active',     '=', True),
            ])
            for u in users:
                self._user_xml(users_el, u, cfg)

        return self._xml_resp(root)

    def _user_xml(self, parent, user, cfg, with_domain_params=False):
        from xml.etree.ElementTree import SubElement
        codec   = 'G722,PCMU,PCMA'
        devices = user.device_ids.filtered(
            lambda d: d.active and d.device_type in ('sip', 'webrtc', 'softphone')
        ).sorted('sequence')
        for d in devices:
            if d.codec_string:
                codec = d.codec_string
                break

        user_el   = SubElement(parent, 'user', id=user.name)
        params_el = SubElement(user_el, 'params')
        SubElement(params_el, 'param', name='password',    value=user.sip_password or '')
        SubElement(params_el, 'param', name='vm-password', value=user.vm_password  or '0000')

        vars_el   = SubElement(user_el, 'variables')
        full_name = ((user.first_name or '') + ' ' + (user.last_name or '')).strip() or user.name
        SubElement(vars_el, 'variable', name='toll_allow',   value='domestic,international,local')
        SubElement(vars_el, 'variable', name='accountcode',  value=user.name)
        SubElement(vars_el, 'variable', name='user_context', value='default')
        SubElement(vars_el, 'variable', name='effective_caller_id_name',   value=full_name)
        SubElement(vars_el, 'variable', name='effective_caller_id_number',
                   value=user.outbound_caller_id or user.name)
        SubElement(vars_el, 'variable', name='outbound_caller_id_name',    value=full_name)
        SubElement(vars_el, 'variable', name='outbound_caller_id_number',
                   value=user.outbound_caller_id or user.name)
        SubElement(vars_el, 'variable', name='codec_string', value=codec)
        SubElement(vars_el, 'variable', name='callgroup',    value=user.department or 'default')
        if user.noanswer_action:
            SubElement(vars_el, 'variable', name='noanswer_action',  value=user.noanswer_action)
            SubElement(vars_el, 'variable', name='noanswer_target',  value=user.noanswer_target or '')
            SubElement(vars_el, 'variable', name='noanswer_timeout', value=str(user.noanswer_timeout or 30))
        if user.busy_action:
            SubElement(vars_el, 'variable', name='busy_action', value=user.busy_action)
            SubElement(vars_el, 'variable', name='busy_target', value=user.busy_target or '')
        if user.unreg_action:
            SubElement(vars_el, 'variable', name='unreg_action', value=user.unreg_action)
            SubElement(vars_el, 'variable', name='unreg_target', value=user.unreg_target or '')

    # ══════════════════════════════════════════════════════════════════════════
    # CONFIGURATION — router do callcenter.conf / fifo.conf
    # ══════════════════════════════════════════════════════════════════════════

    def _handle_configuration(self, params):
        key_name  = params.get('key_name',  '').strip()
        key_value = params.get('key_value', '').strip()

        if key_value == 'fifo.conf':
            return self._handle_fifo_conf(params)

        if key_value == 'callcenter.conf' or key_name == 'CC-Queue':
            return self._handle_callcenter_conf(params)

        _logger.warning('xml_curl configuration: nieznany key_name=%r key_value=%r — not-found',
                        key_name, key_value)
        return self._not_found()

    # ══════════════════════════════════════════════════════════════════════════
    # CALLCENTER.CONF — kolejki CallCenter, agenci, tiery
    # ══════════════════════════════════════════════════════════════════════════

    def _handle_callcenter_conf(self, params):
        from xml.etree.ElementTree import Element, SubElement

        key_name  = params.get('key_name',  '').strip()
        key_value = params.get('key_value', '').strip()

        if key_name == 'CC-Queue':
            # Zapytanie per-kolejka — key_value = "nazwa@domena"
            queue_name = key_value.split('@')[0].strip()
            _logger.warning('xml_curl callcenter per-queue: %s -> %s', key_value, queue_name)
        else:
            # Zapytanie globalne
            queue_name = ''

        CCQueue = request.env['freeswitch.cc.queue'].sudo()
        if queue_name:
            queues = CCQueue.search([('name', '=', queue_name), ('active', '=', True)])
            if not queues:
                _logger.warning('xml_curl callcenter.conf: CC-Queue=%s nie znaleziono', queue_name)
                return self._not_found()
        else:
            queues = CCQueue.search([('active', '=', True)])

        _logger.info('xml_curl callcenter.conf: CC-Queue=%r found=%d', queue_name, len(queues))

        FsConfig      = request.env['freeswitch.company.config'].sudo()
        _domain_cache = {}

        def _get_domain(company_id):
            if company_id not in _domain_cache:
                cfg = FsConfig.search([('company_id', '=', company_id)], limit=1)
                _domain_cache[company_id] = cfg.sip_domain if cfg else ''
            return _domain_cache[company_id]

        def _moh_path(q):
            if q.moh_sound_id and q.moh_sound_id.fs_path:
                return q.moh_sound_id.fs_path
            if q.moh_sound_id and q.moh_sound_id.audio_fname:
                return '/etc/freeswitch/sounds/%d/%s' % (
                    q.company_id.id, q.moh_sound_id.audio_fname)
            return 'local_stream://moh'

        root    = Element('document', type='freeswitch/xml')
        section = SubElement(root, 'section', name='configuration')
        conf    = SubElement(section, 'configuration',
                             name='callcenter.conf', description='CallCenter')

        # Kolejki
        queues_el = SubElement(conf, 'queues')
        for q in queues:
            domain     = _get_domain(q.company_id.id)
            qname_full = ('%s@%s' % (q.name, domain)) if domain else q.name
            _logger.info('xml_curl queue XML name: %s', qname_full)
            qel = SubElement(queues_el, 'queue', name=qname_full)
            pel = SubElement(qel, 'params')
            def qp(n, v): SubElement(pel, 'param', name=n, value=str(v))
            qp('strategy',                    q.strategy or 'longest-idle-agent')
            qp('moh-sound',                   _moh_path(q))
            qp('record-template',             q.record_template or '')
            qp('time-base-score',             q.time_base_score or 'queue')
            qp('max-wait-time',               q.max_wait_time or 0)
            qp('max-wait-time-with-no-agent', q.max_wait_no_agent or 120)
            qp('tier-rules-apply',            'true' if q.tier_rules_apply else 'false')
            qp('discard-abandoned-after',     q.discard_abnd_after or 60)
            qp('abandoned-resume-allowed',    'true' if q.abandoned_resume else 'false')

        # Agenci
        agents_el = SubElement(conf, 'agents')
        if queue_name and queues:
            agent_domain = [('tier_ids.queue_id', 'in', queues.ids), ('active', '=', True)]
        else:
            agent_domain = [('active', '=', True)]
        agents = request.env['freeswitch.cc.agent'].sudo().search(agent_domain)
        for a in agents:
            ael = SubElement(agents_el, 'agent', name=a.name,
                             type=a.agent_type or 'callback')
            SubElement(ael, 'param', name='contact',      value=a.contact or '')
            SubElement(ael, 'param', name='status',       value=a.status  or 'Logged Out')
            SubElement(ael, 'param', name='call-timeout', value=str(a.call_timeout or 20))

        # Tiery
        tiers_el    = SubElement(conf, 'tiers')
        tier_domain = [('queue_id.active', '=', True), ('agent_id.active', '=', True)]
        if queue_name and queues:
            tier_domain.append(('queue_id', 'in', queues.ids))
        tiers = request.env['freeswitch.cc.tier'].sudo().search(tier_domain)
        for t in tiers:
            t_domain = _get_domain(t.queue_id.company_id.id)
            t_qname  = ('%s@%s' % (t.queue_id.name, t_domain)) if t_domain else t.queue_id.name
            SubElement(tiers_el, 'tier',
                       queue=t_qname, agent=t.agent_id.name,
                       level=str(t.level), position=str(t.position))

        _logger.info('xml_curl callcenter.conf: zwracam queues=%d agents=%d tiers=%d',
                     len(queues), len(agents), len(tiers))
        return self._xml_resp(root)

    # ══════════════════════════════════════════════════════════════════════════
    # FIFO.CONF — kolejki FIFO z agentami jako statyczne <member>
    #
    # Format zgodny z dokumentacją FreeSWITCH:
    #   <fifo name="kolejka@domain" importance="0" music-on-hold="/path/moh.mp3">
    #     <member timeout="30" simo="1" lag="0">
    #       {call_timeout=30,fifo_member_wait=nowait}user/1001@domain
    #     </member>
    #   </fifo>
    #
    # mod_fifo ładuje tę konfigurację przy starcie / reload mod_fifo.
    # Sam dzwoni do agentów gdy klient wejdzie do kolejki przez "fifo in".
    # ══════════════════════════════════════════════════════════════════════════

    def _handle_fifo_conf(self, params):
        from xml.etree.ElementTree import Element, SubElement

        FsConfig      = request.env['freeswitch.company.config'].sudo()
        _domain_cache = {}
        _gw_cache     = {}

        def _get_domain(company_id):
            if company_id not in _domain_cache:
                cfg = FsConfig.search([('company_id', '=', company_id)], limit=1)
                _domain_cache[company_id] = cfg.sip_domain if cfg else ''
            return _domain_cache[company_id]

        def _get_gateway(company_id):
            if company_id not in _gw_cache:
                cfg = FsConfig.search([('company_id', '=', company_id)], limit=1)
                _gw_cache[company_id] = cfg.gateway if cfg else 'default'
            return _gw_cache[company_id]

        fifos = request.env['freeswitch.fifo'].sudo().search([('active', '=', True)])
        _logger.info('xml_curl fifo.conf: found=%d queues', len(fifos))

        root     = Element('document', type='freeswitch/xml')
        section  = SubElement(root, 'section', name='configuration')
        conf     = SubElement(section, 'configuration',
                              name='fifo.conf', description='FIFO')
        fifos_el = SubElement(conf, 'fifos')

        total_members = 0

        for f in fifos:
            domain     = _get_domain(f.company_id.id)
            fname_full = ('%s@%s' % (f.name, domain)) if domain else f.name

            # MOH — atrybut elementu <fifo>, nie <param>
            moh = 'local_stream://moh'
            if f.moh_sound_id and f.moh_sound_id.fs_path:
                moh = f.moh_sound_id.fs_path
            elif f.moh_sound_id and f.moh_sound_id.audio_fname:
                moh = '/etc/freeswitch/sounds/%s' % f.moh_sound_id.audio_fname

            _logger.info('xml_curl fifo: name=%s moh=%s', fname_full, moh)

            fifo_el = SubElement(fifos_el, 'fifo',
                                 name=fname_full,
                                 importance=str(f.importance or 0),
                                 **{'music-on-hold': moh})

            # Announce chime (opcjonalny)
            if f.announce_sound_id:
                ann_path = (f.announce_sound_id.fs_path or
                            ('/etc/freeswitch/sounds/%s' % f.announce_sound_id.audio_fname
                             if f.announce_sound_id.audio_fname else ''))
                if ann_path:
                    SubElement(fifo_el, 'action',
                               type='announce', sound=ann_path,
                               freq=str(f.announce_freq or 60))

            # ── Agenci jako <member> ──────────────────────────────────────────
            gateway       = _get_gateway(f.company_id.id)
            active_agents = f.agent_ids.filtered(lambda a: a.active).sorted('sequence')

            for agent in active_agents:
                call_timeout = agent.call_timeout or 30
                member_wait  = agent.member_wait or 'nowait'

                # Szukaj numeru PSTN w urządzeniach agenta FIFO,
                # a potem w urządzeniach użytkownika SIP powiązanego z agentem CC
                mobile_number = mobile_gateway = ''
                if agent.sip_device_ids:
                    for dev in agent.sip_device_ids.filtered(
                            lambda d: d.active).sorted('sequence'):
                        mn = getattr(dev, 'mobile_number', '')
                        if mn:
                            mobile_number  = mn
                            mobile_gateway = getattr(dev, 'mobile_gateway', '') or gateway
                            break
                if not mobile_number and agent.cc_agent_id and agent.cc_agent_id.sip_user_id:
                    for dev in agent.cc_agent_id.sip_user_id.device_ids.filtered(
                            lambda d: d.active).sorted('sequence'):
                        mn = getattr(dev, 'mobile_number', '')
                        if mn:
                            mobile_number  = mn
                            mobile_gateway = getattr(dev, 'mobile_gateway', '') or gateway
                            break

                is_pstn = bool(mobile_number)
                # Dla PSTN simo=1 — operator blokuje równoległe wywołania do jednego numeru
                simo = 1 if is_pstn else (agent.simo or 1)
                lag  = agent.lag or 0

                # Buduj contact — czysty adres, bez żadnych dodatkowych zmiennych
                if is_pstn:
                    gw      = mobile_gateway or gateway
                    contact = 'sofia/gateway/%s/%s' % (gw, mobile_number)
                elif agent.contact:
                    contact = agent.contact
                elif agent.extension:
                    contact = 'user/%s@%s' % (agent.extension, domain)
                else:
                    _logger.warning('xml_curl fifo member: brak contact ext=%s — pomijam',
                                    agent.extension or '?')
                    continue

                # Zmienne kanału w {} — tylko niezbędne
                chan_vars = {
                    'call_timeout':    str(call_timeout),
                    'fifo_member_wait': member_wait,
                }
                if is_pstn:
                    # Ignoruj 183 Session Progress (dzwonek) — czekaj na 200 OK
                    chan_vars['ignore_early_media'] = 'true'
                if agent.group_confirm_key:
                    # Agent musi nacisnąć klawisz po odebraniu (dla PSTN z pocztą głosową)
                    chan_vars['group_confirm_key'] = agent.group_confirm_key
                    confirm_file = ''
                    if agent.group_confirm_file:
                        confirm_file = (
                            agent.group_confirm_file.fs_path or
                            ('/etc/freeswitch/sounds/%s' % agent.group_confirm_file.audio_fname
                             if agent.group_confirm_file.audio_fname else '')
                        )
                    chan_vars['group_confirm_file'] = (
                        confirm_file or 'tone_stream://%(1000,0,440)')
                    chan_vars['group_confirm_read_timeout'] = '5000'

                vars_str       = ','.join('%s=%s' % kv for kv in chan_vars.items())
                member_contact = '{%s}%s' % (vars_str, contact)

                SubElement(fifo_el, 'member',
                           timeout=str(call_timeout),
                           simo=str(simo),
                           lag=str(lag)).text = member_contact

                _logger.info('xml_curl fifo member: ext=%s simo=%d timeout=%ds pstn=%s  %s',
                             agent.extension or '?', simo, call_timeout, is_pstn,
                             member_contact[:80])
                total_members += 1

        _logger.info('xml_curl fifo.conf: returning %d fifos %d members',
                     len(fifos), total_members)
        return self._xml_resp(root)


# ══════════════════════════════════════════════════════════════════════════════
# CC/AGENTS — lista agentów dla cc_heartbeat.lua
# ══════════════════════════════════════════════════════════════════════════════

class FreeSwitchCCHeartbeatController(http.Controller):
    """
    Endpoint dla cc_heartbeat.lua — zwraca listę agentów CC z ich statusami.
    URL:  GET /freeswitch/cc/agents
    Auth: X-API-Key (odoo_api_key z freeswitch.company.config) lub IP
    """

    @http.route('/freeswitch/cc/agents', type='http', auth='none',
                methods=['GET'], csrf=False)
    def cc_agents(self, **kw):
        cfg = self._get_cfg()
        if not cfg:
            return request.make_response(
                '{"error":"unauthorized"}', status=401,
                headers=[('Content-Type', 'application/json')])

        agents = request.env['freeswitch.cc.agent'].sudo().search([
            ('company_id', '=', cfg.company_id.id),
            ('active',     '=', True),
        ])

        result = []
        for a in agents:
            tiers = [
                {'queue_name': t.queue_id.name, 'level': t.level, 'position': t.position}
                for t in a.tier_ids if t.queue_id and t.queue_id.active
            ]
            result.append({
                'name':         a.name,
                'status':       a.status       or 'Logged Out',
                'contact':      a.contact      or '',
                'extension':    a.extension    or '',
                'agent_type':   a.agent_type   or 'callback',
                'call_timeout': a.call_timeout or 20,
                'active':       a.active,
                'tiers':        tiers,
            })

        body = json.dumps({
            'company_id': cfg.company_id.id,
            'count':      len(result),
            'agents':     result,
        }, ensure_ascii=False)
        return request.make_response(body, headers=[('Content-Type', 'application/json')])

    def _get_cfg(self):
        """Uwierzytelnij po X-API-Key lub IP."""
        api_key = (request.httprequest.headers.get('X-API-Key', '').strip() or
                   request.httprequest.args.get('api_key', ''))
        if api_key:
            cfg = request.env['freeswitch.company.config'].sudo().search(
                [('odoo_api_key', '=', api_key)], limit=1)
            if cfg:
                return cfg

        remote_ip = request.httprequest.remote_addr or ''
        fwd = request.httprequest.headers.get('X-Forwarded-For', '')
        if fwd:
            remote_ip = fwd.split(',')[0].strip()
        if remote_ip in _ALLOWED_IPS:
            return request.env['freeswitch.company.config'].sudo().search([], limit=1)
        return None