# -*- coding: utf-8 -*-
"""
controllers/xml_curl.py
=======================
Endpoint mod_xml_curl dla FreeSWITCH.

FreeSWITCH odpytuje ten endpoint gdy:
  - użytkownik SIP próbuje się zarejestrować (directory lookup)
  - FreeSWITCH potrzebuje danych użytkownika (hasło, kodeki, parametry)

URL:  POST /freeswitch/xml_curl
Auth: Basic HTTP (username=fs_user, password=api_key z freeswitch.company.config)
      lub X-API-Key w nagłówku

FreeSWITCH wysyła POST z parametrami:
  section    : directory
  tag_name   : domain / user
  key_name   : name / id
  key_value  : domena SIP / numer wewnętrzny
  Event-Name : REQUEST_PARAMS
  action     : sip_auth / user_call / message_query

Odpowiedź: XML zgodny z formatem FreeSWITCH directory.

Konfiguracja FreeSWITCH (xml_curl.conf.xml):
  <param name="gateway-url" value="http://odoo:8069/freeswitch/xml_curl"/>
  <param name="bindings" value="directory"/>

Dokumentacja:
  https://developer.signalwire.com/freeswitch/FreeSWITCH-Explained/Modules/mod_xml_curl_1049001/
"""

import logging
from xml.etree.ElementTree import Element, SubElement, tostring

from odoo import http
from odoo.http import request, Response

_logger = logging.getLogger(__name__)

XML_CURL_URL = '/freeswitch/xml_curl'


def _xml_response(root_element):
    """Zwróć odpowiedź HTTP z XML dla FreeSWITCH."""
    xml_str = b'<?xml version="1.0" encoding="UTF-8"?>\n' + tostring(root_element, encoding='utf-8')
    return Response(xml_str, status=200, headers={'Content-Type': 'text/xml; charset=utf-8'})


def _not_found():
    """Standardowa odpowiedź 'not found' dla mod_xml_curl."""
    root = Element('document', type='freeswitch/xml')
    SubElement(root, 'section', name='result')
    result = SubElement(root, 'result')
    SubElement(result, 'not-found')
    return _xml_response(root)


# Adresy IP z których FreeSWITCH może odpytywać xml_curl.
# Dodaj tutaj IP swoich serwerów FreeSWITCH.
# Można też ustawić przez ir.config_parameter: freeswitch.xml_curl_allowed_ips
ALLOWED_IPS_DEFAULT = {
    '127.0.0.1',
    '::1',
    # '192.168.1.100',  # IP serwera FreeSWITCH
}


def _get_allowed_ips():
    """Pobierz dozwolone IP z ustawień Odoo lub użyj domyślnych."""
    try:
        param = request.env['ir.config_parameter'].sudo().get_param(
            'freeswitch.xml_curl_allowed_ips', ''
        )
        if param:
            return {ip.strip() for ip in param.split(',')}
    except Exception:
        pass
    return ALLOWED_IPS_DEFAULT


def _authenticate_xml_curl():
    """
    Uwierzytelnienie żądania mod_xml_curl — tylko po IP źródłowym.
    Endpoint jest wewnętrzny, dostępny wyłącznie dla serwera FreeSWITCH.

    Firma identyfikowana po domenie SIP przekazanej w parametrze POST
    (key_value gdy tag_name=domain) lub po hostname.

    Zwraca rekord freeswitch.company.config lub None.
    """
    remote_ip = request.httprequest.remote_addr or ''

    # Obsługa proxy (X-Forwarded-For) — tylko gdy FS stoi za reverse proxy
    forwarded_for = request.httprequest.headers.get('X-Forwarded-For', '')
    if forwarded_for:
        remote_ip = forwarded_for.split(',')[0].strip()

    allowed = _get_allowed_ips()
    if remote_ip not in allowed:
        _logger.warning('xml_curl: odrzucono żądanie z IP=%s (dozwolone: %s)',
                        remote_ip, allowed)
        return None

    # Znajdź konfigurację firmy — pierwsza aktywna
    # (w środowisku multi-tenant: po domenie SIP z parametru POST)
    params      = request.httprequest.form.to_dict()
    domain_hint = (
        params.get('domain') or
        params.get('key_value') or
        params.get('hostname', '').split('.', 1)[-1]  # strip hostname prefix
    )

    cfg = None
    if domain_hint:
        cfg = request.env['freeswitch.company.config'].sudo().search(
            [('sip_domain', '=', domain_hint), ('active', '=', True)], limit=1
        )

    # Fallback: pierwsza aktywna konfiguracja (środowisko single-tenant)
    if not cfg:
        cfg = request.env['freeswitch.company.config'].sudo().search(
            [('active', '=', True)], limit=1
        )

    if not cfg:
        _logger.warning('xml_curl: brak konfiguracji firmy dla domeny=%s', domain_hint)
        return None

    _logger.debug('xml_curl: IP=%s domena=%s firma=%s',
                  remote_ip, domain_hint, cfg.company_id.name)
    return cfg


def _build_user_xml(section_el, domain_name, user, devices, cfg):
    """
    Zbuduj XML directory dla jednego użytkownika SIP.

    Struktura:
      <section name="directory">
        <domain name="sip.example.com">
          <params>...</params>
          <variables>...</variables>
          <user id="1001">
            <params>
              <param name="password" value="secret"/>
              <param name="vm-password" value="0000"/>
            </params>
            <variables>
              <variable name="toll_allow" value="domestic"/>
              <variable name="accountcode" value="1001"/>
              ...
            </variables>
          </user>
        </domain>
      </section>
    """
    domain_el = SubElement(section_el, 'domain', name=domain_name)

    # Parametry domeny
    domain_params = SubElement(domain_el, 'params')
    SubElement(domain_params, 'param', name='dial-string',
               value='{^^:sip_invite_domain=${dialed_domain}'
                     ':presence_id=${dialed_user}@${dialed_domain}}'
                     'sofia/internal/${dialed_user}@${dialed_domain}')

    # Zmienne domeny
    domain_vars = SubElement(domain_el, 'variables')
    SubElement(domain_vars, 'variable', name='record_stereo',    value='true')
    SubElement(domain_vars, 'variable', name='default_gateway',  value=cfg.gateway or '')
    SubElement(domain_vars, 'variable', name='default_areacode', value='')
    SubElement(domain_vars, 'variable', name='transfer_fallback_extension', value='operator')

    # Użytkownicy
    users_el = SubElement(domain_el, 'users')
    user_el  = SubElement(users_el, 'user', id=user.name)

    # Parametry użytkownika
    params_el = SubElement(user_el, 'params')
    SubElement(params_el, 'param', name='password',    value=user.sip_password or '')
    SubElement(params_el, 'param', name='vm-password', value=user.vm_password  or '0000')

    # Kodeki z pierwszego aktywnego urządzenia SIP lub domyślne
    codec = 'G722,PCMU,PCMA'
    for dev in devices:
        if dev.device_type in ('sip', 'webrtc', 'softphone') and dev.codec_string:
            codec = dev.codec_string
            break

    # Zmienne użytkownika
    vars_el = SubElement(user_el, 'variables')
    SubElement(vars_el, 'variable', name='toll_allow',
               value='domestic,international,local')
    SubElement(vars_el, 'variable', name='accountcode',       value=user.name)
    SubElement(vars_el, 'variable', name='user_context',      value='default')
    SubElement(vars_el, 'variable', name='effective_caller_id_name',
               value=f'{user.first_name or ""} {user.last_name or ""}'.strip() or user.name)
    SubElement(vars_el, 'variable', name='effective_caller_id_number',
               value=user.outbound_caller_id or user.name)
    SubElement(vars_el, 'variable', name='outbound_caller_id_name',
               value=f'{user.first_name or ""} {user.last_name or ""}'.strip() or user.name)
    SubElement(vars_el, 'variable', name='outbound_caller_id_number',
               value=user.outbound_caller_id or user.name)
    SubElement(vars_el, 'variable', name='codec_string',      value=codec)
    SubElement(vars_el, 'variable', name='callgroup',
               value=user.department or 'default')

    # Routing warunkowy — przekazywane do action_user.lua przez zmienne sesji
    if user.noanswer_action:
        SubElement(vars_el, 'variable', name='noanswer_action',
                   value=user.noanswer_action)
        SubElement(vars_el, 'variable', name='noanswer_target',
                   value=user.noanswer_target or '')
        SubElement(vars_el, 'variable', name='noanswer_timeout',
                   value=str(user.noanswer_timeout or 30))
    if user.busy_action:
        SubElement(vars_el, 'variable', name='busy_action',
                   value=user.busy_action)
        SubElement(vars_el, 'variable', name='busy_target',
                   value=user.busy_target or '')
    if user.unreg_action:
        SubElement(vars_el, 'variable', name='unreg_action',
                   value=user.unreg_action)
        SubElement(vars_el, 'variable', name='unreg_target',
                   value=user.unreg_target or '')

    return user_el


class FreeSwitchXmlCurlController(http.Controller):

    @http.route(XML_CURL_URL, type='http', auth='none',
                methods=['POST', 'GET'], csrf=False)
    def xml_curl(self, **kw):
        """
        Główny endpoint mod_xml_curl.
        FreeSWITCH wysyła POST z parametrami sekcji, tagu i klucza.
        """
        params  = request.httprequest.form.to_dict()
        section = params.get('section', '')
        _logger.debug('xml_curl: section=%s tag=%s key=%s val=%s',
                      section,
                      params.get('tag_name'),
                      params.get('key_name'),
                      params.get('key_value'))

        if section == 'directory':
            return self._handle_directory(params)

        if section == 'configuration':
            return self._handle_configuration(params)

        return _not_found()

    # ── Directory ─────────────────────────────────────────────────────────────

    def _handle_directory(self, params):
        """
        Obsłuż zapytanie o katalog użytkowników SIP.

        FreeSWITCH wysyła:
          tag_name  = 'domain'  key_name = 'name'  key_value = 'sip.example.com'
          tag_name  = 'user'    key_name = 'id'    key_value = '1001'
        """
        cfg = _authenticate_xml_curl()
        if not cfg:
            return _not_found()

        tag_name  = params.get('tag_name',  '')
        key_name  = params.get('key_name',  '')
        key_value = params.get('key_value', '')

        domain_name = cfg.sip_domain or key_value

        # FreeSWITCH pyta o konkretnego użytkownika
        if tag_name == 'user' or key_name == 'id':
            return self._directory_user(cfg, domain_name, key_value)

        # FreeSWITCH pyta o całą domenę
        if tag_name == 'domain' or key_name == 'name':
            return self._directory_domain(cfg, domain_name)

        return _not_found()

    def _handle_configuration(self, params):
        """
        Obsłuż zapytanie o konfigurację modułu.
        FreeSWITCH wysyła gdy mod_callcenter ładuje kolejkę:
          section=configuration key_value=callcenter.conf CC-Queue=nazwa_kolejki
        """
        cfg = _authenticate_xml_curl()
        if not cfg:
            return _not_found()

        key_value = params.get('key_value', '')

        if key_value == 'callcenter.conf':
            return self._callcenter_conf(cfg, params)

        return _not_found()

    def _callcenter_conf(self, cfg, params):
        """
        Zwróć konfigurację mod_callcenter dla żądanej kolejki.
        FreeSWITCH przekazuje CC-Queue=nazwa_kolejki gdy ładuje konkretną kolejkę.
        """
        queue_name = params.get('CC-Queue', '')

        CCQueue = request.env['freeswitch.cc.queue'].sudo()

        if queue_name:
            queues = CCQueue.search([
                ('name',       '=',  queue_name),
                ('company_id', '=',  cfg.company_id.id),
                ('active',     '=',  True),
            ])
        else:
            queues = CCQueue.search([
                ('company_id', '=',  cfg.company_id.id),
                ('active',     '=',  True),
            ])

        _logger.info('xml_curl callcenter.conf: CC-Queue=%s queues=%d',
                     queue_name, len(queues))

        root    = Element('document', type='freeswitch/xml')
        section = SubElement(root, 'section', name='configuration')
        conf_el = SubElement(section, 'configuration',
                             name='callcenter.conf',
                             description='CallCenter Queues')
        queues_el = SubElement(conf_el, 'queues')

        for q in queues:
            # MOH — ścieżka do pliku audio
            moh = 'local_stream://moh'
            if q.moh_sound_id:
                if q.moh_sound_id.fs_path:
                    moh = q.moh_sound_id.fs_path
                elif q.moh_sound_id.audio_fname:
                    moh = '/etc/freeswitch/sounds/%d/%s' % (
                        q.company_id.id, q.moh_sound_id.audio_fname
                    )

            queue_el = SubElement(queues_el, 'queue', name=q.name)
            params_el = SubElement(queue_el, 'params')

            def qp(name, value):
                SubElement(params_el, 'param', name=name, value=str(value))

            qp('strategy',                    q.strategy or 'longest-idle-agent')
            qp('moh-sound',                   moh)
            qp('record-template',             q.record_template or '')
            qp('time-base-score',             q.time_base_score or 'queue')
            qp('max-wait-time',               q.max_wait_time or 0)
            qp('max-wait-time-with-no-agent', q.max_wait_no_agent or 120)
            qp('tier-rules-apply',            'true' if q.tier_rules_apply else 'false')
            qp('discard-abandoned-after',     q.discard_abnd_after or 60)
            qp('abandoned-resume-allowed',    'true' if q.abandoned_resume else 'false')

        # Agenci — wszyscy aktywni agenci firmy
        agents_el = SubElement(conf_el, 'agents')
        CCAgent = request.env['freeswitch.cc.agent'].sudo()
        agents  = CCAgent.search([
            ('company_id', '=', cfg.company_id.id),
            ('active',     '=', True),
        ])
        for a in agents:
            agent_el = SubElement(agents_el, 'agent',
                                  name=a.name,
                                  type=a.agent_type or 'callback')
            SubElement(agent_el, 'param', name='contact',      value=a.contact or '')
            SubElement(agent_el, 'param', name='status',       value=a.status  or 'Logged Out')
            SubElement(agent_el, 'param', name='call-timeout', value=str(a.call_timeout or 20))

        # Tiery
        tiers_el = SubElement(conf_el, 'tiers')
        CCTier = request.env['freeswitch.cc.tier'].sudo()
        tiers  = CCTier.search([
            ('queue_id.company_id', '=', cfg.company_id.id),
            ('queue_id.active',     '=', True),
            ('agent_id.active',     '=', True),
        ])
        for t in tiers:
            SubElement(tiers_el, 'tier',
                       queue=t.queue_id.name,
                       agent=t.agent_id.name,
                       level=str(t.level),
                       position=str(t.position))

        return _xml_response(root)

    def _directory_user(self, cfg, domain_name, extension):
        """Zwróć dane jednego użytkownika SIP."""
        if not extension:
            return _not_found()

        SipUser = request.env['freeswitch.sip.user'].sudo()
        user = SipUser.search([
            ('name',       '=',  extension),
            ('company_id', '=',  cfg.company_id.id),
            ('active',     '=',  True),
            ('status',     'in', ['active', 'vacation']),
        ], limit=1)

        if not user:
            _logger.info('xml_curl directory: użytkownik %s@%s nie znaleziony',
                         extension, domain_name)
            return _not_found()

        devices = user.device_ids.filtered(
            lambda d: d.active and d.device_type in ('sip', 'webrtc', 'softphone')
        ).sorted('sequence')

        _logger.info('xml_curl directory: %s@%s devices=%d',
                     extension, domain_name, len(devices))

        # Buduj XML
        root       = Element('document', type='freeswitch/xml')
        section_el = SubElement(root, 'section', name='directory')
        _build_user_xml(section_el, domain_name, user, devices, cfg)

        return _xml_response(root)

    def _directory_domain(self, cfg, domain_name):
        """Zwróć wszystkich aktywnych użytkowników domeny."""
        SipUser = request.env['freeswitch.sip.user'].sudo()
        users = SipUser.search([
            ('company_id', '=',  cfg.company_id.id),
            ('active',     '=',  True),
            ('status',     'in', ['active', 'vacation']),
        ])

        _logger.info('xml_curl directory domain: %s users=%d', domain_name, len(users))

        root       = Element('document', type='freeswitch/xml')
        section_el = SubElement(root, 'section', name='directory')
        domain_el  = SubElement(section_el, 'domain', name=domain_name)
        users_el   = SubElement(domain_el, 'users')

        for user in users:
            devices = user.device_ids.filtered(
                lambda d: d.active and d.device_type in ('sip', 'webrtc', 'softphone')
            ).sorted('sequence')
            # Wstaw tylko element <user> bez pełnej domeny
            user_el = Element('user', id=user.name)
            params_el = SubElement(user_el, 'params')
            SubElement(params_el, 'param', name='password',    value=user.sip_password or '')
            SubElement(params_el, 'param', name='vm-password', value=user.vm_password  or '0000')
            codec = 'G722,PCMU,PCMA'
            for dev in devices:
                if dev.codec_string:
                    codec = dev.codec_string
                    break
            vars_el = SubElement(user_el, 'variables')
            SubElement(vars_el, 'variable', name='accountcode',  value=user.name)
            SubElement(vars_el, 'variable', name='codec_string', value=codec)
            SubElement(vars_el, 'variable', name='effective_caller_id_name',
                       value=f'{user.first_name or ""} {user.last_name or ""}'.strip())
            SubElement(vars_el, 'variable', name='effective_caller_id_number',
                       value=user.outbound_caller_id or user.name)
            users_el.append(user_el)

        return _xml_response(root)