# -*- coding: utf-8 -*-
"""
controllers/api.py
==================
REST API FreeSWITCH Admin — endpoint HTTP w Odoo.

Uwierzytelnienie: nagłówek  X-API-Key: <klucz z freeswitch.company.config>
Firma identyfikowana na podstawie klucza API.

Bazowy URL:  /freeswitch/api/v1/

Endpointy
---------
Trasy DID
  GET    /freeswitch/api/v1/routes
  GET    /freeswitch/api/v1/routes/<id>
  POST   /freeswitch/api/v1/routes
  PUT    /freeswitch/api/v1/routes/<id>
  DELETE /freeswitch/api/v1/routes/<id>

Użytkownicy SIP
  GET    /freeswitch/api/v1/sip_users
  GET    /freeswitch/api/v1/sip_users/<id>
  POST   /freeswitch/api/v1/sip_users
  PUT    /freeswitch/api/v1/sip_users/<id>
  DELETE /freeswitch/api/v1/sip_users/<id>

Konfiguracje IVR
  GET    /freeswitch/api/v1/ivr
  GET    /freeswitch/api/v1/ivr/<id>
  POST   /freeswitch/api/v1/ivr
  PUT    /freeswitch/api/v1/ivr/<id>
  DELETE /freeswitch/api/v1/ivr/<id>

Kolejki CallCenter
  GET    /freeswitch/api/v1/cc_queues
  GET    /freeswitch/api/v1/cc_queues/<id>
  POST   /freeswitch/api/v1/cc_queues
  PUT    /freeswitch/api/v1/cc_queues/<id>
  DELETE /freeswitch/api/v1/cc_queues/<id>

Kolejki FIFO
  GET    /freeswitch/api/v1/fifo_queues
  GET    /freeswitch/api/v1/fifo_queues/<id>

Dialplan
  POST   /freeswitch/api/v1/dialplan/reload

Statusy
  GET    /freeswitch/api/v1/health
  GET    /freeswitch/api/v1/cc_queues/<id>/stats

Dokumentacja
  GET    /freeswitch/api/v1/openapi.json  — specyfikacja OpenAPI 3.0
  GET    /freeswitch/api/v1/docs          — Swagger UI
"""

import json
import logging

from odoo import http, _
from odoo.http import request, Response

_logger = logging.getLogger(__name__)

# ── Stałe ────────────────────────────────────────────────────────────────────
API_BASE = '/freeswitch/api/v1'


# ── Helpery ───────────────────────────────────────────────────────────────────

def _json_response(data, status=200):
    return Response(
        json.dumps(data, default=str, ensure_ascii=False),
        status=status,
        headers={'Content-Type': 'application/json; charset=utf-8'},
    )


def _error(message, status=400, code=None):
    return _json_response(
        {'error': message, 'code': code or str(status)},
        status=status,
    )


def _authenticate(func):
    """
    Dekorator sprawdzający nagłówek X-API-Key.
    Wstrzykuje obiekt `company_config` do kwargs wywoływanej metody.
    """
    def wrapper(self, *args, **kwargs):
        api_key = request.httprequest.headers.get('X-API-Key', '').strip()
        if not api_key:
            return _error('Brak nagłówka X-API-Key', 401, 'missing_key')

        cfg = request.env['freeswitch.company.config'].sudo().search(
            [('odoo_api_key', '=', api_key)], limit=1
        )
        if not cfg:
            return _error('Nieprawidłowy klucz API', 401, 'invalid_key')

        kwargs['_company_cfg'] = cfg
        # Pracuj w kontekście firmy powiązanej z kluczem
        request.env = request.env(context=dict(
            request.env.context,
            allowed_company_ids=[cfg.company_id.id],
            force_company=cfg.company_id.id,
        ))
        return func(self, *args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper


def _parse_body():
    """Parsuj JSON body z żądania."""
    try:
        data = request.httprequest.get_data(as_text=True)
        return json.loads(data) if data else {}
    except json.JSONDecodeError:
        return None


# ── Kontroler ─────────────────────────────────────────────────────────────────

class FreeSwitchApiController(http.Controller):

    # ══ HEALTH ══════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/health', type='http', auth='none', methods=['GET'], csrf=False)
    def health(self, **kw):
        return _json_response({'status': 'ok', 'module': 'freeswitch_admin'})

    # ══ WHOAMI ══════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/me', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def whoami(self, _company_cfg=None, **kw):
        """Zwróć informacje o kliencie powiązanym z kluczem API."""
        company = _company_cfg.company_id
        return _json_response({
            'company_id':    company.id,
            'company_name':  company.name,
            'company_vat':   company.vat or '',
            'company_email': company.email or '',
            'sip_domain':    _company_cfg.sip_domain or '',
            'gateway':       _company_cfg.gateway or '',
            'api_url':       _company_cfg.api_url or '',
        })

    # ══ TRASY DID ═══════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/routes', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def routes_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        # Opcjonalne filtry query string
        if kw.get('active'):
            domain.append(('active', '=', kw['active'].lower() == 'true'))
        if kw.get('name'):
            domain.append(('name', 'ilike', kw['name']))

        routes = request.env['freeswitch.route'].sudo().search(domain)
        return _json_response({'count': len(routes), 'results': [
            _route_to_dict(r) for r in routes
        ]})

    @http.route(f'{API_BASE}/routes/<int:route_id>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def routes_get(self, route_id, _company_cfg=None, **kw):
        route = _get_record('freeswitch.route', route_id, _company_cfg.company_id.id)
        if not route:
            return _error('Trasa nie znaleziona', 404)
        return _json_response(_route_to_dict(route))

    @http.route(f'{API_BASE}/routes', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def routes_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            route = request.env['freeswitch.route'].sudo().create(body)
            return _json_response(_route_to_dict(route), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/routes/<int:route_id>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def routes_update(self, route_id, _company_cfg=None, **kw):
        route = _get_record('freeswitch.route', route_id, _company_cfg.company_id.id)
        if not route:
            return _error('Trasa nie znaleziona', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)   # company_id nie można zmieniać
        try:
            route.sudo().write(body)
            return _json_response(_route_to_dict(route))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/routes/<int:route_id>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def routes_delete(self, route_id, _company_cfg=None, **kw):
        route = _get_record('freeswitch.route', route_id, _company_cfg.company_id.id)
        if not route:
            return _error('Trasa nie znaleziona', 404)
        route.sudo().unlink()
        return _json_response({'deleted': True, 'id': route_id})

    # ══ UŻYTKOWNICY SIP ═════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/sip_users', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sip_users_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        if kw.get('active'):
            domain.append(('active', '=', kw['active'].lower() == 'true'))
        if kw.get('extension'):
            domain.append(('extension', '=', kw['extension']))

        users = request.env['freeswitch.sip.user'].sudo().search(domain)
        return _json_response({'count': len(users), 'results': [
            _sip_user_to_dict(u) for u in users
        ]})

    @http.route(f'{API_BASE}/sip_users/<int:uid>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def sip_users_get(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        return _json_response(_sip_user_to_dict(user))

    @http.route(f'{API_BASE}/sip_users', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def sip_users_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            user = request.env['freeswitch.sip.user'].sudo().create(body)
            return _json_response(_sip_user_to_dict(user), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sip_users/<int:uid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def sip_users_update(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)
        try:
            user.sudo().write(body)
            return _json_response(_sip_user_to_dict(user))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/sip_users/<int:uid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def sip_users_delete(self, uid, _company_cfg=None, **kw):
        user = _get_record('freeswitch.sip.user', uid, _company_cfg.company_id.id)
        if not user:
            return _error('Użytkownik SIP nie znaleziony', 404)
        user.sudo().unlink()
        return _json_response({'deleted': True, 'id': uid})

    # ══ IVR ════════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/ivr', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def ivr_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        if kw.get('active'):
            domain.append(('active', '=', kw['active'].lower() == 'true'))

        ivrs = request.env['freeswitch.ivr'].sudo().search(domain)
        return _json_response({'count': len(ivrs), 'results': [
            _ivr_to_dict(i) for i in ivrs
        ]})

    @http.route(f'{API_BASE}/ivr/<int:ivr_id>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def ivr_get(self, ivr_id, _company_cfg=None, **kw):
        ivr = _get_record('freeswitch.ivr', ivr_id, _company_cfg.company_id.id)
        if not ivr:
            return _error('IVR nie znaleziony', 404)
        return _json_response(_ivr_to_dict(ivr, full=True))

    @http.route(f'{API_BASE}/ivr', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def ivr_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            ivr = request.env['freeswitch.ivr'].sudo().create(body)
            return _json_response(_ivr_to_dict(ivr), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/ivr/<int:ivr_id>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def ivr_update(self, ivr_id, _company_cfg=None, **kw):
        ivr = _get_record('freeswitch.ivr', ivr_id, _company_cfg.company_id.id)
        if not ivr:
            return _error('IVR nie znaleziony', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)
        try:
            ivr.sudo().write(body)
            return _json_response(_ivr_to_dict(ivr))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/ivr/<int:ivr_id>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def ivr_delete(self, ivr_id, _company_cfg=None, **kw):
        ivr = _get_record('freeswitch.ivr', ivr_id, _company_cfg.company_id.id)
        if not ivr:
            return _error('IVR nie znaleziony', 404)
        ivr.sudo().unlink()
        return _json_response({'deleted': True, 'id': ivr_id})

    # ══ KOLEJKI CALLCENTER ══════════════════════════════════════════════════

    @http.route(f'{API_BASE}/cc_queues', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_queues_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        queues = request.env['freeswitch.cc.queue'].sudo().search(domain)
        return _json_response({'count': len(queues), 'results': [
            _cc_queue_to_dict(q) for q in queues
        ]})

    @http.route(f'{API_BASE}/cc_queues/<int:qid>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_queues_get(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        return _json_response(_cc_queue_to_dict(queue, full=True))

    @http.route(f'{API_BASE}/cc_queues', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def cc_queues_create(self, _company_cfg=None, **kw):
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body['company_id'] = _company_cfg.company_id.id
        try:
            queue = request.env['freeswitch.cc.queue'].sudo().create(body)
            return _json_response(_cc_queue_to_dict(queue), status=201)
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/cc_queues/<int:qid>', type='http', auth='none', methods=['PUT'], csrf=False)
    @_authenticate
    def cc_queues_update(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        body = _parse_body()
        if body is None:
            return _error('Nieprawidłowy JSON', 400)
        body.pop('company_id', None)
        try:
            queue.sudo().write(body)
            return _json_response(_cc_queue_to_dict(queue))
        except Exception as e:
            return _error(str(e), 422)

    @http.route(f'{API_BASE}/cc_queues/<int:qid>', type='http', auth='none', methods=['DELETE'], csrf=False)
    @_authenticate
    def cc_queues_delete(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        queue.sudo().unlink()
        return _json_response({'deleted': True, 'id': qid})

    @http.route(f'{API_BASE}/cc_queues/<int:qid>/stats', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def cc_queues_stats(self, qid, _company_cfg=None, **kw):
        queue = _get_record('freeswitch.cc.queue', qid, _company_cfg.company_id.id)
        if not queue:
            return _error('Kolejka nie znaleziona', 404)
        return _json_response({
            'id':               queue.id,
            'name':             queue.name,
            'callers_waiting':  queue.callers_waiting,
            'agents_available': queue.agents_available,
            'calls_today':      queue.calls_today,
        })

    # ══ KOLEJKI FIFO ════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/fifo_queues', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def fifo_list(self, _company_cfg=None, **kw):
        domain = [('company_id', '=', _company_cfg.company_id.id)]
        fifos = request.env['freeswitch.fifo'].sudo().search(domain)
        return _json_response({'count': len(fifos), 'results': [
            _fifo_to_dict(f) for f in fifos
        ]})

    @http.route(f'{API_BASE}/fifo_queues/<int:fid>', type='http', auth='none', methods=['GET'], csrf=False)
    @_authenticate
    def fifo_get(self, fid, _company_cfg=None, **kw):
        fifo = _get_record('freeswitch.fifo', fid, _company_cfg.company_id.id)
        if not fifo:
            return _error('Kolejka FIFO nie znaleziona', 404)
        return _json_response(_fifo_to_dict(fifo))

    # ══ SWAGGER / OpenAPI ═══════════════════════════════════════════════════

    @http.route(f'{API_BASE}/openapi.json', type='http', auth='none', methods=['GET'], csrf=False)
    def openapi_spec(self, **kw):
        """Zwróć specyfikację OpenAPI 3.0 w formacie JSON."""
        return _json_response(_build_openapi_spec())

    @http.route(f'{API_BASE}/docs', type='http', auth='none', methods=['GET'], csrf=False)
    def swagger_ui(self, **kw):
        """Zwróć interaktywny Swagger UI."""
        html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeSWITCH Admin API — Dokumentacja</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css">
  <style>
    body {{ margin: 0; background: #fafafa; }}
    .topbar {{ display: none !important; }}

    /* ── Okienko autoryzacji wyśrodkowane na ekranie ── */
    .swagger-ui .dialog-ux .modal-ux {{
      position: fixed !important;
      top: 50% !important;
      left: 50% !important;
      transform: translate(-50%, -50%) !important;
      margin: 0 !important;
      max-height: 90vh;
      overflow-y: auto;
      z-index: 9999;
    }}
    .swagger-ui .dialog-ux .backdrop-ux {{
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      z-index: 9998;
    }}
  </style>
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    SwaggerUIBundle({{
      url: '{API_BASE}/openapi.json',
      dom_id: '#swagger-ui',
      deepLinking: true,
      persistAuthorization: true,
      presets: [
        SwaggerUIBundle.presets.apis,
        SwaggerUIBundle.SwaggerUIStandalonePreset
      ],
      layout: 'BaseLayout',
    }});
  </script>
</body>
</html>"""
        return Response(html, status=200, headers={'Content-Type': 'text/html; charset=utf-8'})

    # ══ DIALPLAN ════════════════════════════════════════════════════════════

    @http.route(f'{API_BASE}/dialplan/reload', type='http', auth='none', methods=['POST'], csrf=False)
    @_authenticate
    def dialplan_reload(self, _company_cfg=None, **kw):
        try:
            mixin = request.env['freeswitch.db.mixin'].with_company(
                _company_cfg.company_id
            )
            result = mixin._fs_api_call('POST', '/routing/dialplan/reload')
            return _json_response({
                'status':  'ok',
                'company': _company_cfg.company_id.name,
                'result':  result,
            })
        except Exception as e:
            return _error(str(e), 502, 'dialplan_reload_failed')


# ── Funkcje serializujące modele do dict ─────────────────────────────────────

def _get_record(model, record_id, company_id):
    """Pobierz rekord sprawdzając przynależność do firmy."""
    rec = request.env[model].sudo().browse(record_id)
    if not rec.exists():
        return None
    if hasattr(rec, 'company_id') and rec.company_id.id != company_id:
        return None
    return rec


def _route_to_dict(r):
    return {
        'id':           r.id,
        'fs_uuid':      r.fs_uuid,
        'name':         r.name,
        'description':  r.description,
        'route_type':   r.route_type,
        'route_target': r.route_target,
        'active':       r.active,
        'company_id':   r.company_id.id,
        'company_name': r.company_id.name,
        'use_time_rules': r.use_time_rules,
    }


def _sip_user_to_dict(u):
    return {
        'id':           u.id,
        'fs_uuid':      u.fs_uuid,
        'name':         u.name,
        'extension':    u.extension,
        'sip_password': u.sip_password,
        'status':       u.status,
        'active':       u.active,
        'company_id':   u.company_id.id,
        'company_name': u.company_id.name,
        'email':        u.email or '',
    }


def _ivr_to_dict(i, full=False):
    data = {
        'id':           i.id,
        'fs_uuid':      i.fs_uuid,
        'name':         i.name,
        'description':  i.description,
        'active':       i.active,
        'timeout_sec':  i.timeout_sec,
        'max_failures': i.max_failures,
        'company_id':   i.company_id.id,
        'company_name': i.company_id.name,
        'item_count':   i.item_count,
    }
    if full:
        data['menu_items'] = [
            {
                'id':     item.id,
                'digit':  item.digit,
                'action': item.action,
                'target': item.target,
            }
            for item in i.menu_item_ids
        ]
    return data


def _cc_queue_to_dict(q, full=False):
    data = {
        'id':               q.id,
        'fs_uuid':          q.fs_uuid,
        'name':             q.name,
        'description':      q.description,
        'strategy':         q.strategy,
        'active':           q.active,
        'company_id':       q.company_id.id,
        'company_name':     q.company_id.name,
        'callers_waiting':  q.callers_waiting,
        'agents_available': q.agents_available,
        'calls_today':      q.calls_today,
    }
    if full:
        data['tiers'] = [
            {
                'id':       t.id,
                'agent_id': t.agent_id.id,
                'agent':    t.agent_id.name,
                'level':    t.level,
                'position': t.position,
            }
            for t in q.tier_ids
        ]
    return data


def _fifo_to_dict(f):
    return {
        'id':            f.id,
        'fs_uuid':       f.fs_uuid,
        'name':          f.name,
        'description':   f.description,
        'importance':    f.importance,
        'max_wait_sec':  f.max_wait_sec,
        'active':        f.active,
        'company_id':    f.company_id.id,
        'company_name':  f.company_id.name,
    }


# ── Specyfikacja OpenAPI 3.0 ──────────────────────────────────────────────────

def _build_openapi_spec():
    """Zwróć słownik zgodny z OpenAPI 3.0.3 opisujący wszystkie endpointy API."""

    def _resp(description, schema_ref=None):
        r = {'description': description}
        if schema_ref:
            r['content'] = {'application/json': {'schema': {'$ref': f'#/components/schemas/{schema_ref}'}}}
        return r

    return {
        'openapi': '3.0.3',
        'info': {
            'title':       'FreeSWITCH Admin REST API',
            'version':     '1.0.0',
            'description': (
                'REST API modułu **freeswitch_admin** w Odoo.\n\n'
                '**Uwierzytelnienie:** nagłówek `X-API-Key` z kluczem '
                'wygenerowanym w *FreeSWITCH → Konfiguracja → Ustawienia per firma*.'
            ),
        },
        'servers': [{'url': API_BASE, 'description': 'Odoo FreeSWITCH API'}],
        'security': [{'ApiKeyAuth': []}],
        'components': {
            'securitySchemes': {
                'ApiKeyAuth': {
                    'type': 'apiKey',
                    'in':   'header',
                    'name': 'X-API-Key',
                    'description': 'Klucz API z konfiguracji firmy FreeSWITCH w Odoo.',
                }
            },
            'schemas': {
                'Error': {
                    'type': 'object',
                    'properties': {
                        'error': {'type': 'string', 'example': 'Nie znaleziono'},
                        'code':  {'type': 'string', 'example': '404'},
                    }
                },
                'Route': {
                    'type': 'object',
                    'properties': {
                        'id':             {'type': 'integer'},
                        'fs_uuid':        {'type': 'string', 'format': 'uuid'},
                        'name':           {'type': 'string'},
                        'description':    {'type': 'string'},
                        'route_type':     {'type': 'string'},
                        'route_target':   {'type': 'string'},
                        'active':         {'type': 'boolean'},
                        'company_id':     {'type': 'integer'},
                        'company_name':   {'type': 'string'},
                        'use_time_rules': {'type': 'boolean'},
                    }
                },
                'SipUser': {
                    'type': 'object',
                    'properties': {
                        'id':           {'type': 'integer'},
                        'fs_uuid':      {'type': 'string', 'format': 'uuid'},
                        'name':         {'type': 'string'},
                        'extension':    {'type': 'string', 'example': '1001'},
                        'sip_password': {'type': 'string'},
                        'status':       {'type': 'string', 'enum': ['available', 'busy', 'offline']},
                        'active':       {'type': 'boolean'},
                        'company_id':   {'type': 'integer'},
                        'company_name': {'type': 'string'},
                        'email':        {'type': 'string', 'format': 'email'},
                    }
                },
                'IVR': {
                    'type': 'object',
                    'properties': {
                        'id':           {'type': 'integer'},
                        'fs_uuid':      {'type': 'string', 'format': 'uuid'},
                        'name':         {'type': 'string'},
                        'description':  {'type': 'string'},
                        'active':       {'type': 'boolean'},
                        'timeout_sec':  {'type': 'integer'},
                        'max_failures': {'type': 'integer'},
                        'company_id':   {'type': 'integer'},
                        'company_name': {'type': 'string'},
                        'item_count':   {'type': 'integer'},
                        'menu_items': {
                            'type': 'array',
                            'items': {
                                'type': 'object',
                                'properties': {
                                    'id':     {'type': 'integer'},
                                    'digit':  {'type': 'string'},
                                    'action': {'type': 'string'},
                                    'target': {'type': 'string'},
                                }
                            }
                        },
                    }
                },
                'CCQueue': {
                    'type': 'object',
                    'properties': {
                        'id':               {'type': 'integer'},
                        'fs_uuid':          {'type': 'string', 'format': 'uuid'},
                        'name':             {'type': 'string'},
                        'description':      {'type': 'string'},
                        'strategy':         {'type': 'string'},
                        'active':           {'type': 'boolean'},
                        'company_id':       {'type': 'integer'},
                        'company_name':     {'type': 'string'},
                        'callers_waiting':  {'type': 'integer'},
                        'agents_available': {'type': 'integer'},
                        'calls_today':      {'type': 'integer'},
                        'tiers': {
                            'type': 'array',
                            'items': {
                                'type': 'object',
                                'properties': {
                                    'id':       {'type': 'integer'},
                                    'agent_id': {'type': 'integer'},
                                    'agent':    {'type': 'string'},
                                    'level':    {'type': 'integer'},
                                    'position': {'type': 'integer'},
                                }
                            }
                        },
                    }
                },
                'FIFOQueue': {
                    'type': 'object',
                    'properties': {
                        'id':           {'type': 'integer'},
                        'fs_uuid':      {'type': 'string', 'format': 'uuid'},
                        'name':         {'type': 'string'},
                        'description':  {'type': 'string'},
                        'importance':   {'type': 'integer'},
                        'max_wait_sec': {'type': 'integer'},
                        'active':       {'type': 'boolean'},
                        'company_id':   {'type': 'integer'},
                        'company_name': {'type': 'string'},
                    }
                },
                'ListMeta': {
                    'type': 'object',
                    'properties': {
                        'count':   {'type': 'integer'},
                        'results': {'type': 'array', 'items': {}},
                    }
                },
                'Deleted': {
                    'type': 'object',
                    'properties': {
                        'deleted': {'type': 'boolean', 'example': True},
                        'id':      {'type': 'integer'},
                    }
                },
            }
        },
        'paths': {
            # ── Health ────────────────────────────────────────────────────
            '/health': {
                'get': {
                    'tags':    ['Status'],
                    'summary': 'Status serwisu',
                    'security': [],
                    'operationId': 'health_get',
                    'responses': {
                        '200': {
                            'description': 'Serwis działa',
                            'content': {'application/json': {'schema': {
                                'type': 'object',
                                'properties': {
                                    'status': {'type': 'string', 'example': 'ok'},
                                    'module': {'type': 'string', 'example': 'freeswitch_admin'},
                                }
                            }}}
                        }
                    }
                }
            },
            # ── Whoami ────────────────────────────────────────────────────
            '/me': {
                'get': {
                    'tags':        ['Klient'],
                    'summary':     'Informacje o kliencie (firma powiązana z kluczem API)',
                    'operationId': 'whoami',
                    'responses': {
                        '200': {
                            'description': 'Dane klienta',
                            'content': {'application/json': {'schema': {
                                'type': 'object',
                                'properties': {
                                    'company_id':    {'type': 'integer', 'example': 1},
                                    'company_name':  {'type': 'string',  'example': 'Moja Firma Sp. z o.o.'},
                                    'company_vat':   {'type': 'string',  'example': 'PL1234567890'},
                                    'company_email': {'type': 'string',  'example': 'biuro@firma.pl'},
                                    'sip_domain':    {'type': 'string',  'example': 'sip.firma.pl'},
                                    'gateway':       {'type': 'string',  'example': 'default'},
                                    'api_url':       {'type': 'string',  'example': 'http://127.0.0.1:8000/api/v1'},
                                }
                            }}}
                        },
                        '401': _resp('Brak/nieprawidłowy klucz API', 'Error'),
                    }
                }
            },
            # ── Trasy DID ─────────────────────────────────────────────────
            '/routes': {
                'get': {
                    'tags':        ['Trasy DID'],
                    'summary':     'Lista tras DID',
                    'operationId': 'routes_list',
                    'parameters': [
                        {'name': 'active', 'in': 'query', 'description': 'Filtr: aktywne/nieaktywne', 'schema': {'type': 'boolean'}},
                        {'name': 'name',   'in': 'query', 'description': 'Filtr: szukaj po nazwie (ilike)', 'schema': {'type': 'string'}},
                    ],
                    'responses': {
                        '200': {'description': 'Lista tras', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}},
                        '401': _resp('Brak autoryzacji', 'Error'),
                    }
                },
                'post': {
                    'tags':        ['Trasy DID'],
                    'summary':     'Utwórz trasę DID',
                    'operationId': 'routes_create',
                    'requestBody': {
                        'required': True,
                        'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}
                    },
                    'responses': {
                        '201': {'description': 'Trasa utworzona', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}},
                        '400': _resp('Nieprawidłowy JSON', 'Error'),
                        '422': _resp('Błąd walidacji', 'Error'),
                    }
                },
            },
            '/routes/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}, 'description': 'ID trasy'}],
                'get': {
                    'tags': ['Trasy DID'], 'summary': 'Pobierz trasę DID', 'operationId': 'routes_get',
                    'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}}, '404': _resp('Nie znaleziono', 'Error')}
                },
                'put': {
                    'tags': ['Trasy DID'], 'summary': 'Zaktualizuj trasę DID', 'operationId': 'routes_update',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}},
                    'responses': {'200': {'description': 'Zaktualizowano', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Route'}}}}, '404': _resp('Nie znaleziono', 'Error'), '422': _resp('Błąd walidacji', 'Error')}
                },
                'delete': {
                    'tags': ['Trasy DID'], 'summary': 'Usuń trasę DID', 'operationId': 'routes_delete',
                    'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}
                },
            },
            # ── SIP Users ─────────────────────────────────────────────────
            '/sip_users': {
                'get': {
                    'tags': ['Użytkownicy SIP'], 'summary': 'Lista użytkowników SIP', 'operationId': 'sip_users_list',
                    'parameters': [
                        {'name': 'active',    'in': 'query', 'schema': {'type': 'boolean'}},
                        {'name': 'extension', 'in': 'query', 'schema': {'type': 'string'}, 'description': 'Numer wewnętrzny'},
                    ],
                    'responses': {'200': {'description': 'Lista użytkowników', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}, '401': _resp('Brak autoryzacji', 'Error')}
                },
                'post': {
                    'tags': ['Użytkownicy SIP'], 'summary': 'Utwórz użytkownika SIP', 'operationId': 'sip_users_create',
                    'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}},
                    'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}}, '422': _resp('Błąd walidacji', 'Error')}
                },
            },
            '/sip_users/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['Użytkownicy SIP'], 'summary': 'Pobierz użytkownika SIP', 'operationId': 'sip_users_get', 'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['Użytkownicy SIP'], 'summary': 'Zaktualizuj użytkownika SIP', 'operationId': 'sip_users_update', 'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}}, 'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/SipUser'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'delete': {'tags': ['Użytkownicy SIP'], 'summary': 'Usuń użytkownika SIP', 'operationId': 'sip_users_delete', 'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── IVR ───────────────────────────────────────────────────────
            '/ivr': {
                'get':  {'tags': ['IVR'], 'summary': 'Lista konfiguracji IVR', 'operationId': 'ivr_list', 'parameters': [{'name': 'active', 'in': 'query', 'schema': {'type': 'boolean'}}], 'responses': {'200': {'description': 'Lista IVR', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}}},
                'post': {'tags': ['IVR'], 'summary': 'Utwórz konfigurację IVR', 'operationId': 'ivr_create', 'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}}, 'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}}, '422': _resp('Błąd walidacji', 'Error')}},
            },
            '/ivr/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['IVR'], 'summary': 'Pobierz IVR (z pozycjami menu)', 'operationId': 'ivr_get', 'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['IVR'], 'summary': 'Zaktualizuj IVR', 'operationId': 'ivr_update', 'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}}, 'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/IVR'}}}}}},
                'delete': {'tags': ['IVR'], 'summary': 'Usuń IVR', 'operationId': 'ivr_delete', 'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── CC Queues ─────────────────────────────────────────────────
            '/cc_queues': {
                'get':  {'tags': ['Kolejki CallCenter'], 'summary': 'Lista kolejek CC', 'operationId': 'cc_queues_list', 'responses': {'200': {'description': 'Lista kolejek', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}}},
                'post': {'tags': ['Kolejki CallCenter'], 'summary': 'Utwórz kolejkę CC', 'operationId': 'cc_queues_create', 'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}}, 'responses': {'201': {'description': 'Utworzono', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}}}},
            },
            '/cc_queues/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get':    {'tags': ['Kolejki CallCenter'], 'summary': 'Pobierz kolejkę CC (z tierami)', 'operationId': 'cc_queues_get', 'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
                'put':    {'tags': ['Kolejki CallCenter'], 'summary': 'Zaktualizuj kolejkę CC', 'operationId': 'cc_queues_update', 'requestBody': {'required': True, 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}}, 'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/CCQueue'}}}}}},
                'delete': {'tags': ['Kolejki CallCenter'], 'summary': 'Usuń kolejkę CC', 'operationId': 'cc_queues_delete', 'responses': {'200': {'description': 'Usunięto', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/Deleted'}}}}}},
            },
            '/cc_queues/{id}/stats': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get': {
                    'tags': ['Kolejki CallCenter'], 'summary': 'Statystyki kolejki CC', 'operationId': 'cc_queues_stats',
                    'responses': {'200': {'description': 'Statystyki', 'content': {'application/json': {'schema': {
                        'type': 'object',
                        'properties': {
                            'id':               {'type': 'integer'},
                            'name':             {'type': 'string'},
                            'callers_waiting':  {'type': 'integer'},
                            'agents_available': {'type': 'integer'},
                            'calls_today':      {'type': 'integer'},
                        }
                    }}}}, '404': _resp('Nie znaleziono', 'Error')}
                }
            },
            # ── FIFO Queues ───────────────────────────────────────────────
            '/fifo_queues': {
                'get': {'tags': ['Kolejki FIFO'], 'summary': 'Lista kolejek FIFO', 'operationId': 'fifo_list', 'responses': {'200': {'description': 'Lista FIFO', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/ListMeta'}}}}}},
            },
            '/fifo_queues/{id}': {
                'parameters': [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'integer'}}],
                'get': {'tags': ['Kolejki FIFO'], 'summary': 'Pobierz kolejkę FIFO', 'operationId': 'fifo_get', 'responses': {'200': {'description': 'OK', 'content': {'application/json': {'schema': {'$ref': '#/components/schemas/FIFOQueue'}}}}, '404': _resp('Nie znaleziono', 'Error')}},
            },
            # ── Dialplan ──────────────────────────────────────────────────
            '/dialplan/reload': {
                'post': {
                    'tags': ['Dialplan'], 'summary': 'Przeładuj dialplan FreeSWITCH', 'operationId': 'dialplan_reload',
                    'responses': {
                        '200': {'description': 'Dialplan przeładowany', 'content': {'application/json': {'schema': {'type': 'object', 'properties': {'status': {'type': 'string'}, 'company': {'type': 'string'}, 'result': {'type': 'object'}}}}}},
                        '502': _resp('Błąd komunikacji z FreeSWITCH', 'Error'),
                    }
                }
            },
        },
        'tags': [
            {'name': 'Status',              'description': 'Sprawdzenie stanu serwisu'},
            {'name': 'Klient',              'description': 'Informacje o kliencie powiązanym z kluczem API'},
            {'name': 'Trasy DID',           'description': 'Zarządzanie trasami DID / inbound routes'},
            {'name': 'Użytkownicy SIP',     'description': 'Zarządzanie użytkownikami SIP'},
            {'name': 'IVR',                 'description': 'Konfiguracje Interactive Voice Response'},
            {'name': 'Kolejki CallCenter',  'description': 'Kolejki CallCenter (CC) z agentami i tierami'},
            {'name': 'Kolejki FIFO',        'description': 'Kolejki FIFO'},
            {'name': 'Dialplan',            'description': 'Operacje na dialplanie FreeSWITCH'},
        ],
    }