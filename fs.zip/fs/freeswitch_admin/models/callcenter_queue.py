# -*- coding: utf-8 -*-
"""
callcenter_queue.py
===================
Model kolejki CallCenter.

Architektura xml_curl:
  - Konfiguracja kolejek → serwowana przez POST /freeswitch/xml_curl (main.py)
  - FreeSWITCH wywołuje xml_curl przy "callcenter_config queue reload"
  - Odoo jest jedynym źródłem prawdy, zero plików XML na dysku

Przy zmianie kolejki w Odoo:
    fs_cli -x "callcenter_config queue reload nazwa@domena"
    → FS wysyła xml_curl do Odoo → dostaje aktualną konfigurację
"""
import logging
import subprocess

from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)

STRATEGIES = [
    ('longest-idle-agent',         'Najdłużej bezczynny (zalecane)'),
    ('round-robin',                'Round-robin'),
    ('top-down',                   'Od góry listy (top-down)'),
    ('agent-with-fewest-calls',    'Najmniej połączeń (FIFO )'),
    ('agent-with-least-talk-time', 'Najkrótszy czas rozmów'),
    ('random',                     'Losowy'),
    ('ring-all',                   'Dzwoń do wszystkich'),
]


class FreeSwitchCCQueue(models.Model):
    _name        = 'freeswitch.cc.queue'
    _description = 'FreeSWITCH — Kolejka CallCenter'
    _inherit     = ['mail.thread', 'mail.activity.mixin', 'freeswitch.db.mixin',
                    'freeswitch.multicompany.mixin']
    _order       = 'name'

    company_id = fields.Many2one(
        'res.company', string='Firma', required=True, index=True,
        default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('name_company_unique', 'UNIQUE(name, company_id)',
         'Nazwa kolejki musi być unikalna w ramach firmy!'),
    ]

    # ── Pola — identyczne jak poprzednio, nic nie usuwamy ─────────────────────
    name        = fields.Char('Nazwa kolejki (klucz)', required=True, tracking=True)
    description = fields.Char('Opis', tracking=True)
    strategy    = fields.Selection(STRATEGIES, string='Strategia',
                                   default='longest-idle-agent', required=True, tracking=True)

    moh_sound_id = fields.Many2one(
        'freeswitch.sound', string='Muzyka oczekiwania', ondelete='set null',
        help='Puste = local_stream://moh',
    )
    moh_sound_player = fields.Html(
        related='moh_sound_id.audio_player',
        string='Odsłuch muzyki oczekiwania', sanitize=False,
    )
    record_template = fields.Char(
        'Szablon nagrania', default='/nagrania/{uuid}.wav',
        help='{uuid} zostanie zastąpiony UUID połączenia.',
    )
    time_base_score = fields.Selection(
        [('queue', 'Czas w kolejce'), ('system', 'Czas systemowy')],
        string='Podstawa czasu', default='queue',
    )
    max_wait_time      = fields.Integer('Maks. czas oczekiwania (s)', default=0,
                                         help='0 = bez limitu')
    max_wait_no_agent  = fields.Integer('Maks. oczekiwanie bez agenta (s)', default=120)
    tier_rules_apply   = fields.Boolean('Stosuj reguły tierów', default=False)
    discard_abnd_after  = fields.Integer('Odrzuć porzucone po (s)', default=60)
    abandoned_resume    = fields.Boolean('Wznów porzucone', default=False)
    active              = fields.Boolean('Aktywna', default=True, tracking=True)

    announce_position_interval = fields.Integer(
        'Ogłaszaj pozycję co (s)', default=30,
        help='0 = wyłączone. Skrypt cc_position.lua odczytuje tę wartość.',
    )

    no_agents_action = fields.Selection([
        ('hangup',   'Rozłącz'),
        ('playback', 'Odtwórz komunikat i rozłącz'),
        ('ivr',      'Przekieruj do IVR'),
    ], string='Akcja gdy brak agentów', default='hangup',
       help='Co zrobić gdy w kolejce nie ma żadnego dostępnego agenta.')
    no_agents_sound_id = fields.Many2one(
        'freeswitch.sound', string='Komunikat (brak agentów)', ondelete='set null',
    )
    no_agents_ivr_id = fields.Many2one(
        'freeswitch.ivr', string='IVR (brak agentów)', ondelete='set null',
    )

    tier_ids   = fields.One2many('freeswitch.cc.tier', 'queue_id', string='Tiery agentów')
    tier_count = fields.Integer('Agenci', compute='_compute_tier_count')

    callers_waiting  = fields.Integer('Oczekujący',      readonly=True, default=0)
    agents_available = fields.Integer('Dostępni agenci', readonly=True, default=0)
    calls_today      = fields.Integer('Połączeń dziś',   readonly=True, default=0)

    @api.depends('tier_ids')
    def _compute_tier_count(self):
        for rec in self:
            rec.tier_count = len(rec.tier_ids)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _moh_path(self):
        self.ensure_one()
        if self.moh_sound_id:
            return (self.moh_sound_id.fs_path
                    or self.moh_sound_id.audio_fname
                    or 'local_stream://moh')
        return 'local_stream://moh'

    def _sip_domain(self):
        cfg = self._get_fs_config()
        return cfg.sip_domain or 'localhost'

    def _fs_queue_name(self):
        """Klucz kolejki w mod_callcenter = nazwa@sip_domain."""
        self.ensure_one()
        return f'{self.name}@{self._sip_domain()}'

    # ── Reload mod_callcenter przez fs_cli ────────────────────────────────────

    def _fs_cc_reload(self, queue_names=None):
        """
        Wyślij sygnał przeładowania do mod_callcenter.

        mod_callcenter odpowiada żądaniem xml_curl do Odoo
        → main.py _handle_callcenter_conf() serwuje aktualną konfigurację.

        queue_names: lista 'nazwa@domena' do przeładowania.
                     None = reload całego modułu (przy create/unlink).
        """
        if not queue_names:
            cmds = ['reload mod_callcenter']
        else:
            cmds = [f'callcenter_config queue reload {qname}'
                    for qname in queue_names]

        for cmd in cmds:
            try:
                result = subprocess.run(
                    ['fs_cli', '-x', cmd],
                    capture_output=True, text=True, timeout=10,
                )
                output = (result.stdout or '').strip()
                _logger.info('fs_cli [%s] → %s', cmd, output[:120])
            except FileNotFoundError:
                _logger.warning(
                    'fs_cli nie znaleziony — FreeSWITCH pobierze konfigurację '
                    'przy następnym połączeniu przez xml_curl.'
                )
                break
            except subprocess.TimeoutExpired:
                _logger.warning('fs_cli timeout: %s', cmd)
            except Exception as e:
                _logger.warning('fs_cli błąd: %s', e)

    # ── ORM hooks ─────────────────────────────────────────────────────────────

    _FS_QUEUE_FIELDS = {
        'name', 'strategy', 'moh_sound_id', 'record_template',
        'time_base_score', 'max_wait_time', 'max_wait_no_agent',
        'tier_rules_apply', 'discard_abnd_after', 'abandoned_resume',
        'active',
    }

    def write(self, vals):
        res = super().write(vals)
        if self._FS_QUEUE_FIELDS & set(vals.keys()):
            try:
                queue_names = [r._fs_queue_name() for r in self if r.active]
                self._fs_cc_reload(queue_names or None)
            except Exception as e:
                _logger.warning('CC queue reload błąd (niekrytyczny): %s', e)
        return res

    def create(self, vals_list):
        recs = super().create(vals_list)
        try:
            recs._fs_cc_reload(queue_names=None)
        except Exception as e:
            _logger.warning('CC queue create reload błąd (niekrytyczny): %s', e)
        return recs

    def unlink(self):
        try:
            self._fs_cc_reload(queue_names=None)
        except Exception as e:
            _logger.warning('CC queue unlink reload błąd (niekrytyczny): %s', e)
        return super().unlink()

    # ── Akcje UI ──────────────────────────────────────────────────────────────

    def action_push_to_fs(self):
        """
        Ręczna synchronizacja:
        1. Reload kolejki w mod_callcenter (wyzwala xml_curl → Odoo odpowiada XML)
        2. Upsert agentów i tierów do PostgreSQL FS (runtime)
        """
        reloaded  = []
        ag_pushed = []

        for rec in self.filtered('active'):
            self._fs_cc_reload([rec._fs_queue_name()])
            reloaded.append(rec.name)

            for tier in rec.tier_ids:
                try:
                    tier.agent_id._fs_agent_upsert()
                    if tier.agent_id.name not in ag_pushed:
                        ag_pushed.append(tier.agent_id.name)
                    tier._fs_tier_upsert()
                except Exception as e:
                    _logger.error('CC push tier/agent błąd: %s', e)

        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title':   _('CallCenter'),
                'message': _('Przeładowano %d kolejek, %d agentów w PostgreSQL ✓')
                           % (len(reloaded), len(ag_pushed)),
                'type': 'success',
            }
        }

    def action_refresh_stats(self):
        """Odczytaj live stats z tabeli members PostgreSQL FS."""
        for rec in self:
            try:
                rows = rec._fs_query("""
                    SELECT
                        COUNT(*) FILTER (WHERE state NOT IN ('Answered','Abandoned'))
                            AS callers_waiting,
                        (SELECT COUNT(*) FROM agents WHERE status = 'Available')
                            AS agents_available
                    FROM members
                    WHERE queue = %(queue)s
                """, {'queue': rec._fs_queue_name()})
                if rows:
                    row = rows[0]
                    rec.write({
                        'callers_waiting':  int(row.get('callers_waiting') or 0),
                        'agents_available': int(row.get('agents_available') or 0),
                    })
            except Exception as e:
                _logger.warning('CC queue refresh_stats błąd: %s', e)

    def action_import_from_fs(self):
        """Zachowane dla kompatybilności — przy xml_curl nieużywane."""
        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title':   _('Info'),
                'message': _('Import z FS nieużywany w trybie xml_curl. '
                             'Odoo jest źródłem prawdy.'),
                'type': 'info',
            }
        }