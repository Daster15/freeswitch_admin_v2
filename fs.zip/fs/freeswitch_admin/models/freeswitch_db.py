# -*- coding: utf-8 -*-
"""
freeswitch_db.py
================
Mixin połączenia z bazą PostgreSQL FreeSWITCH oraz helper REST API.

ZMIANA (multi-company):
  Konfiguracja jest teraz przechowywana w modelu freeswitch.company.config
  per firma, nie w globalnych ir.config_parameter.
  Metody automatycznie odczytują konfigurację dla self.env.company.
"""

import logging
from contextlib import contextmanager

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class FreeSwitchDBMixin(models.AbstractModel):
    _name        = 'freeswitch.db.mixin'
    _description = 'FreeSWITCH DB / API Mixin (multi-company)'

    # ── Pobierz konfigurację dla bieżącej firmy ──────────────────────────
    def _get_fs_config(self, company=None):
        """
        Zwróć rekord freeswitch.company.config dla bieżącej (lub podanej) firmy.
        """
        return self.env['freeswitch.company.config']._get_for_company(
            company or self.env.company
        )

    def _get_fs_dsn(self, company=None):
        """Zwróć słownik z parametrami połączenia do bazy FreeSWITCH."""
        cfg = self._get_fs_config(company)
        return {
            'use_same_db': cfg.use_same_db,
            'host':        cfg.db_host or '127.0.0.1',
            'port':        int(cfg.db_port or 5432),
            'dbname':      cfg.db_name  or 'freeswitch',
            'user':        cfg.db_user  or 'freeswitch',
            'password':    cfg.db_password or '',
        }

    # ── Cache połączeń psycopg2 (per DSN, per proces Odoo) ──────────────
    _fs_conn_cache = {}

    @classmethod
    def _fs_get_cached_conn(cls, dsn):
        """
        Zwróć istniejące połączenie psycopg2 lub otwórz nowe.
        Połączenie jest współdzielone w ramach procesu Odoo dla danego DSN.
        Przy błędzie (connection closed) otwiera nowe.
        """
        import psycopg2
        import psycopg2.extras

        key = (dsn['host'], dsn['port'], dsn['dbname'], dsn['user'])
        conn = cls._fs_conn_cache.get(key)

        # Sprawdź czy połączenie żyje
        if conn is not None:
            try:
                conn.cursor().execute('SELECT 1')
            except Exception:
                try:
                    conn.close()
                except Exception:
                    pass
                conn = None
                cls._fs_conn_cache.pop(key, None)

        if conn is None:
            conn = psycopg2.connect(
                host=dsn['host'],
                port=dsn['port'],
                dbname=dsn['dbname'],
                user=dsn['user'],
                password=dsn['password'],
                connect_timeout=5,
                options='-c timezone=Europe/Warsaw',
            )
            conn.autocommit = True   # autocommit=True: każde execute commituje od razu
            cls._fs_conn_cache[key] = conn
            _logger.info('FS DB: nowe połączenie do %s/%s', dsn['host'], dsn['dbname'])

        return conn

    # ── Cursor do bazy FreeSWITCH ─────────────────────────────────────────
    @contextmanager
    def _fs_cursor(self, company=None):
        """
        Context manager zwracający cursor do bazy FreeSWITCH.

        use_same_db=True  → kursor Odoo (self.env.cr) z SAVEPOINT
        use_same_db=False → cached psycopg2 conn z autocommit=True (szybkie, bez transakcji)
        """
        dsn = self._get_fs_dsn(company)

        if dsn['use_same_db']:
            cr = self.env.cr
            savepoint = 'fs_db_%s' % id(self)
            cr.execute('SAVEPOINT %s' % savepoint)
            try:
                yield cr
                cr.execute('RELEASE SAVEPOINT %s' % savepoint)
            except Exception:
                cr.execute('ROLLBACK TO SAVEPOINT %s' % savepoint)
                raise
        else:
            try:
                import psycopg2.extras
                conn = self._fs_get_cached_conn(dsn)
                cur  = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
                try:
                    yield cur
                finally:
                    cur.close()
            except Exception as e:
                _logger.error('FS DB błąd: %s', e)
                # Usuń cache — przy następnym wywołaniu otworzy nowe połączenie
                key = (dsn['host'], dsn['port'], dsn['dbname'], dsn['user'])
                self.__class__._fs_conn_cache.pop(key, None)
                raise UserError(
                    _('Błąd bazy FreeSWITCH (%s): %s') % (self.env.company.name, str(e))
                )

    def _fs_query(self, sql, params=None, company=None):
        """Wykonaj SELECT — zwróć listę dict."""
        with self._fs_cursor(company) as cr:
            cr.execute(sql, params or ())
            if hasattr(cr, 'dictfetchall'):
                return cr.dictfetchall()          # Odoo cr
            return [dict(r) for r in (cr.fetchall() or [])]  # psycopg2

    def _fs_execute(self, sql, params=None, company=None):
        """Wykonaj INSERT / UPDATE / DELETE."""
        with self._fs_cursor(company) as cr:
            cr.execute(sql, params or ())

    def test_connection(self, company=None):
        """Testuj połączenie — zwróć True lub rzuć UserError."""
        rows = self._fs_query('SELECT version() AS ver, NOW() AS ts', company=company)
        if rows:
            ver = rows[0].get('ver', '') if isinstance(rows[0], dict) else rows[0][0]
            _logger.info('FreeSWITCH DB OK [%s]: %s', self.env.company.name, ver)
            return True
        return False

    # ── REST API helper (do FreeSWITCH FastAPI) ───────────────────────────
    def _fs_api_call(self, method, path, data=None, company=None):
        """
        Wywołaj REST API serwisu FastAPI FreeSWITCH.
        Używane do operacji ESL: reload dialplan, transfer, originate itp.
        """
        import requests as _requests
        cfg = self._get_fs_config(company)
        base_url = (cfg.api_url or 'http://127.0.0.1:8000/api/v1').rstrip('/')
        url      = base_url + '/' + path.lstrip('/')
        headers  = {'Content-Type': 'application/json'}
        if cfg.api_key:
            headers['X-API-Key'] = cfg.api_key

        try:
            resp = _requests.request(
                method.upper(), url,
                json=data, headers=headers, timeout=10,
            )
            resp.raise_for_status()
            return resp.json()
        except _requests.exceptions.ConnectionError:
            raise UserError(
                _('Brak połączenia z REST API FreeSWITCH (%s): %s')
                % (self.env.company.name, url)
            )
        except _requests.exceptions.HTTPError as e:
            raise UserError(_('Błąd REST API [%s]: %s') % (self.env.company.name, str(e)))
        except Exception as e:
            _logger.warning('FreeSWITCH API error [%s]: %s', self.env.company.name, e)
            return None