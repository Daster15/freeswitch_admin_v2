# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

IVR_ACTIONS = [
    ('ivr',         'Zagnieżdżone menu IVR'),
    ('callcenter',  'Kolejka CallCenter'),
    ('user',        'Użytkownik / Wewnętrzny'),
    ('pstn',        'Numer zewnętrzny PSTN'),
    ('playback',    'Odtwórz plik audio'),
    ('voicemail',   'Poczta głosowa'),
    ('hangup',      'Rozłącz'),
    ('repeat',      'Powtórz menu'),
]

DIGITS = [(str(i), str(i)) for i in range(10)] + [('*', '*'), ('#', '#')]


class FreeSwitchIVRItem(models.Model):
    _name        = 'freeswitch.ivr.item'
    _description = 'FreeSWITCH — Opcja menu IVR'
    _order       = 'sequence, digit'

    ivr_id      = fields.Many2one('freeswitch.ivr', string='IVR', ondelete='cascade', required=True)
    sequence    = fields.Integer('Kolejność', default=10)
    digit       = fields.Selection(DIGITS, string='Cyfra', required=True)
    description = fields.Char('Opis opcji',
                               help='Np. "Rejestracja wizyty" — dla dokumentacji i IVR TTS')
    action      = fields.Selection(IVR_ACTIONS, string='Akcja', required=True, default='callcenter')
    target      = fields.Char('Cel',
                               help='Wypełniane automatycznie przez selektor')

    # ── Selektory celu (Many2one dla każdego typu) ───────────────────────
    target_ivr_id = fields.Many2one(
        'freeswitch.ivr', string='Docelowe IVR', ondelete='set null',
    )
    target_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO', ondelete='set null',
    )
    target_cc_id = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CC', ondelete='set null',
    )
    # ZMIANA: freeswitch.sip.user zamiast freeswitch.cc.agent
    target_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik SIP',
        domain=[('active', '=', True)], ondelete='set null',
    )
    target_sound_id = fields.Many2one(
        'freeswitch.sound', string='Plik audio', ondelete='set null',
    )
    target_sound_player = fields.Html(
        related='target_sound_id.audio_player',
        string='Odsłuch', sanitize=False,
    )

    # Akcja po odtworzeniu nagrania
    playback_after = fields.Selection([
        ('hangup',      'Rozłącz połączenie'),
        ('ivr',         'Przejdź do menu IVR'),
        ('callcenter',  'Przejdź do kolejki CallCenter'),
        ('pstn',        'Przekaż na numer zewnętrzny'),
        ('repeat',      'Powtórz nagranie'),
    ], string='Po odtworzeniu', default='hangup')
    playback_after_ivr_id  = fields.Many2one('freeswitch.ivr', string='IVR po odtworzeniu', ondelete='set null')
    playback_after_fifo_id = fields.Many2one('freeswitch.fifo', string='FIFO po odtworzeniu', ondelete='set null')
    playback_after_cc_id   = fields.Many2one('freeswitch.cc.queue', string='CC po odtworzeniu', ondelete='set null')
    playback_after_pstn    = fields.Char('Numer PSTN po odtworzeniu')

    # ── Onchange: selektor → target ──────────────────────────────────────
    @api.onchange('action')
    def _onchange_action(self):
        self.target_ivr_id   = False
        self.target_fifo_id  = False
        self.target_cc_id    = False
        self.target_user_id  = False
        self.target_sound_id = False
        self.target          = ''

    @api.onchange('target_ivr_id')
    def _onchange_target_ivr_id(self):
        if self.target_ivr_id:
            self.target = self.target_ivr_id.name

    @api.onchange('target_fifo_id')
    def _onchange_target_fifo_id(self):
        if self.target_fifo_id:
            self.target = self.target_fifo_id.name

    @api.onchange('target_cc_id')
    def _onchange_target_cc_id(self):
        if self.target_cc_id:
            self.target = self.target_cc_id.name

    # ZMIANA: .name zamiast .extension (freeswitch.sip.user)
    @api.onchange('target_user_id')
    def _onchange_target_user_id(self):
        if self.target_user_id:
            self.target = self.target_user_id.name

    @api.onchange('target_sound_id')
    def _onchange_target_sound_id(self):
        if self.target_sound_id:
            self.target = self.target_sound_id.fs_path

    @api.constrains('digit', 'ivr_id')
    def _check_unique_digit(self):
        for rec in self:
            dup = self.search([
                ('ivr_id', '=', rec.ivr_id.id),
                ('digit',  '=', rec.digit),
                ('id',     '!=', rec.id),
            ])
            if dup:
                raise ValidationError(
                    _('Cyfra "%s" jest już używana w tym menu IVR.') % rec.digit)