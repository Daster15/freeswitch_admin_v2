# -*- coding: utf-8 -*-
import json
import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

ROUTE_TYPES = [
    ('ivr',         'Menu IVR'),
    ('callcenter',  'CallCenter'),
    ('user',        'Użytkownik / Wewnętrzny'),
    ('pstn',        'Numer zewnętrzny PSTN'),
    ('playback',    'Odtwórz plik audio'),
]

DAYS_OF_WEEK = [
    ('mon', 'Poniedziałek'),
    ('tue', 'Wtorek'),
    ('wed', 'Środa'),
    ('thu', 'Czwartek'),
    ('fri', 'Piątek'),
    ('sat', 'Sobota'),
    ('sun', 'Niedziela'),
]


class FreeSwitchInboundRoute(models.Model):
    _name        = 'freeswitch.route'
    _description = 'FreeSWITCH — Routing DID'
    _inherit     = ['mail.thread', 'mail.activity.mixin', 'freeswitch.db.mixin',
                    'freeswitch.multicompany.mixin']
    _order       = 'name'
    _rec_name    = 'description'

    company_id = fields.Many2one(
        'res.company',
        string='Firma',
        required=True,
        index=True,
        default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('name_company_unique', 'UNIQUE(name, company_id)',
         'Numer DID musi być unikalny w ramach firmy!'),
    ]

    # ── Pola podstawowe ─────────────────────────────────────────────────
    fs_uuid = fields.Char(
        string='UUID FreeSWITCH',
        readonly=True, copy=False, index=True,
        help='UUID rekordu w tabeli inbound_routes (PostgreSQL FreeSWITCH).',
    )
    pstn_number_id = fields.Many2one(
        'freeswitch.pstn.number',
        string='Numer DID / DDI',
        required=True,
        tracking=True,
        ondelete='restrict',
        help='Wybierz numer z puli PSTN przypisanej do firmy. '
             'Listę numerów zarządza administrator w: Konfiguracja → Ustawienia per firma.',
    )
    name = fields.Char(
        string='Numer DID / Wzorzec',
        related='pstn_number_id.number',
        store=True,
        readonly=True,
        help='Numer PSTN z wybranego rekordu DDI.',
    )
    description = fields.Char(
        string='Opis',
        required=True, tracking=True,
        help='Np. "Infolinia Placówka Mokotów"',
    )
    route_type = fields.Selection(
        ROUTE_TYPES, string='Typ przekierowania',
        required=True, tracking=True, default='ivr',
    )
    route_target = fields.Char(
        string='Cel',
        tracking=True,
        help='Wypełniane automatycznie przez selektor poniżej.',
    )
    active = fields.Boolean(
        string='Aktywna',
        default=True, tracking=True,
    )

    # ── Reguły czasowe ───────────────────────────────────────────────────
    use_time_rules = fields.Boolean(
        string='Ogranicz godzinami pracy',
        default=False,
    )
    time_rule_ids = fields.One2many(
        'freeswitch.route.time_rule', 'route_id',
        string='Harmonogram',
    )

    # ── Fallback ─────────────────────────────────────────────────────────
    fallback_type = fields.Selection(
        ROUTE_TYPES, string='Typ fallbacku',
        tracking=True,
        help='Przekierowanie poza godzinami pracy lub przy braku agentów.',
    )
    fallback_target = fields.Char(
        string='Cel fallbacku',
        tracking=True,
    )

    # ── Selektory celu (Many2one dla każdego typu) ───────────────────────
    route_ivr_id = fields.Many2one(
        'freeswitch.ivr', string='Menu IVR',
        ondelete='set null',
    )
    route_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO',
        ondelete='set null',
    )
    route_cc_id = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CallCenter',
        ondelete='set null',
    )
    route_user_id = fields.Many2one(
        'freeswitch.cc.agent', string='Użytkownik SIP',
        domain=[('active', '=', True)],
        ondelete='set null',
    )
    route_sound_id = fields.Many2one(
        'freeswitch.sound', string='Plik audio',
        ondelete='set null',
    )
    route_sound_player = fields.Html(
        related='route_sound_id.audio_player',
        string='Odsłuch', sanitize=False,
    )
    # Akcja po odtworzeniu (route)
    route_sound_after = fields.Selection(
        ROUTE_TYPES + [('hangup', 'Rozłącz'), ('repeat', 'Powtórz nagranie')],
        string='Po odtworzeniu', default='hangup',
    )
    route_sound_after_ivr_id  = fields.Many2one('freeswitch.ivr', string='IVR po odtworzeniu', ondelete='set null')
    route_sound_after_fifo_id = fields.Many2one('freeswitch.fifo', string='FIFO po odtworzeniu', ondelete='set null')
    route_sound_after_cc_id   = fields.Many2one('freeswitch.cc.queue', string='CC po odtworzeniu', ondelete='set null')
    route_sound_after_user_id = fields.Many2one('freeswitch.sip.user', string='Użytkownik SIP po odtworzeniu',
                                                domain=[('active', '=', True)], ondelete='set null')
    route_sound_after_pstn    = fields.Char('Numer PSTN po odtworzeniu')

    # ── Selektory fallbacku ──────────────────────────────────────────────
    fallback_ivr_id = fields.Many2one(
        'freeswitch.ivr', string='Menu IVR (fallback)',
        ondelete='set null',
    )
    fallback_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO (fallback)',
        ondelete='set null',
    )
    fallback_cc_id = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CallCenter (fallback)',
        ondelete='set null',
    )
    fallback_user_id = fields.Many2one(
        'freeswitch.cc.agent', string='Użytkownik SIP (fallback)',
        domain=[('active', '=', True)],
        ondelete='set null',
    )
    fallback_sound_id = fields.Many2one(
        'freeswitch.sound', string='Plik audio (fallback)',
        ondelete='set null',
    )
    fallback_sound_player = fields.Html(
        related='fallback_sound_id.audio_player',
        string='Odsłuch (fallback)', sanitize=False,
    )
    # Akcja po odtworzeniu (fallback)
    fallback_sound_after = fields.Selection(
        ROUTE_TYPES + [('hangup', 'Rozłącz'), ('repeat', 'Powtórz nagranie')],
        string='Po odtworzeniu (fallback)', default='hangup',
    )
    fallback_sound_after_ivr_id  = fields.Many2one('freeswitch.ivr', string='IVR po odtworzeniu (fb)', ondelete='set null')
    fallback_sound_after_fifo_id = fields.Many2one('freeswitch.fifo', string='FIFO po odtworzeniu (fb)', ondelete='set null')
    fallback_sound_after_cc_id   = fields.Many2one('freeswitch.cc.queue', string='CC po odtworzeniu (fb)', ondelete='set null')
    fallback_sound_after_user_id = fields.Many2one('freeswitch.sip.user', string='Użytkownik SIP po odtworzeniu (fb)',
                                                   domain=[('active', '=', True)], ondelete='set null')
    fallback_sound_after_pstn    = fields.Char('Numer PSTN po odtworzeniu (fb)')

    # ── Dni wolne od pracy ───────────────────────────────────────────────────
    use_holidays = fields.Boolean(
        string='Uwzględnij dni wolne od pracy',
        default=False,
        help='Jeśli zaznaczone, w dni wolne trasa będzie przekierowana do wybranej akcji.',
    )
    holiday_country_code = fields.Selection(
        [('PL','Polska'),('DE','Niemcy'),('GB','Wielka Brytania'),
         ('FR','Francja'),('US','USA'),('CZ','Czechy'),('SK','Słowacja'),
         ('UA','Ukraina'),('OTHER','Inny')],
        string='Kraj (dni wolne)', default='PL',
    )
    holiday_action_type = fields.Selection(
        ROUTE_TYPES, string='Akcja w dzień wolny', tracking=True,
    )
    holiday_action_target = fields.Char(
        string='Cel (dzień wolny)', tracking=True,
    )
    holiday_ivr_id = fields.Many2one(
        'freeswitch.ivr', string='Menu IVR (dzień wolny)', ondelete='set null',
    )
    holiday_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO (dzień wolny)', ondelete='set null',
    )
    holiday_cc_id = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CC (dzień wolny)', ondelete='set null',
    )
    holiday_sound_id = fields.Many2one(
        'freeswitch.sound', string='Plik audio (dzień wolny)', ondelete='set null',
    )
    holiday_sound_player = fields.Html(
        related='holiday_sound_id.audio_player',
        string='Odsłuch (dzień wolny)', sanitize=False,
    )

    # ── Statystyki ───────────────────────────────────────────────────────
    cdr_count = fields.Integer(
        string='Połączeń',
        compute='_compute_cdr_count',
    )

    # ────────────────────────────────────────────────────────────────────
    # Onchange — wypełniaj route_target na podstawie wybranego rekordu
    @api.onchange('pstn_number_id')
    def _onchange_pstn_number_id(self):
        """Ustaw opis trasy na podstawie wybranego numeru PSTN."""
        if self.pstn_number_id and not self.description:
            self.description = self.pstn_number_id.description or self.pstn_number_id.number

    @api.constrains('pstn_number_id', 'company_id')
    def _check_pstn_number_company(self):
        for rec in self:
            if rec.pstn_number_id and rec.pstn_number_id.company_id != rec.company_id:
                raise ValidationError(
                    _('Numer PSTN "%s" nie należy do firmy "%s".')
                    % (rec.pstn_number_id.number, rec.company_id.name)
                )

    @api.onchange('route_ivr_id')
    def _onchange_route_ivr_id(self):
        if self.route_ivr_id:
            self.route_target = self.route_ivr_id.name

    @api.onchange('route_fifo_id')
    def _onchange_route_fifo_id(self):
        if self.route_fifo_id:
            self.route_target = self.route_fifo_id.name

    @api.onchange('route_cc_id')
    def _onchange_route_cc_id(self):
        if self.route_cc_id:
            self.route_target = self.route_cc_id.name

    @api.onchange('route_user_id')
    def _onchange_route_user_id(self):
        if self.route_user_id:
            self.route_target = self.route_user_id.extension

    @api.onchange('route_sound_id')
    def _onchange_route_sound_id(self):
        if self.route_sound_id:
            self.route_target = (
                self.route_sound_id.fs_path or self.route_sound_id.audio_fname or ''
            )

    @api.onchange('fallback_ivr_id')
    def _onchange_fallback_ivr_id(self):
        if self.fallback_ivr_id:
            self.fallback_target = self.fallback_ivr_id.name

    @api.onchange('fallback_fifo_id')
    def _onchange_fallback_fifo_id(self):
        if self.fallback_fifo_id:
            self.fallback_target = self.fallback_fifo_id.name

    @api.onchange('fallback_cc_id')
    def _onchange_fallback_cc_id(self):
        if self.fallback_cc_id:
            self.fallback_target = self.fallback_cc_id.name

    @api.onchange('fallback_user_id')
    def _onchange_fallback_user_id(self):
        if self.fallback_user_id:
            self.fallback_target = self.fallback_user_id.extension

    @api.onchange('fallback_sound_id')
    def _onchange_fallback_sound_id(self):
        if self.fallback_sound_id:
            self.fallback_target = (
                self.fallback_sound_id.fs_path or self.fallback_sound_id.audio_fname or ''
            )

    @api.onchange('route_sound_after_user_id')
    def _onchange_route_sound_after_user_id(self):
        """Selektor użytkownika SIP po odtworzeniu (route) — nie nadpisuje route_target."""
        pass  # pole używane tylko jako selektor

    @api.onchange('fallback_sound_after_user_id')
    def _onchange_fallback_sound_after_user_id(self):
        """Selektor użytkownika SIP po odtworzeniu (fallback) — nie nadpisuje fallback_target."""
        pass  # pole używane tylko jako selektor

    # Onchange — czyść selektory przy zmianie typu
    @api.onchange('route_type')
    def _onchange_route_type(self):
        self.route_ivr_id  = False
        self.route_fifo_id = False
        self.route_cc_id   = False
        self.route_user_id = False
        self.route_sound_id = False
        self.route_sound_after_user_id = False
        self.route_target  = ''

    @api.onchange('fallback_type')
    def _onchange_fallback_type(self):
        self.fallback_ivr_id  = False
        self.fallback_fifo_id = False
        self.fallback_cc_id   = False
        self.fallback_user_id = False
        self.fallback_sound_id = False
        self.fallback_sound_after_user_id = False
        self.fallback_target  = ''

    @api.onchange('holiday_ivr_id')
    def _onchange_holiday_ivr_id(self):
        if self.holiday_ivr_id:
            self.holiday_action_target = self.holiday_ivr_id.name

    @api.onchange('holiday_fifo_id')
    def _onchange_holiday_fifo_id(self):
        if self.holiday_fifo_id:
            self.holiday_action_target = self.holiday_fifo_id.name

    @api.onchange('holiday_cc_id')
    def _onchange_holiday_cc_id(self):
        if self.holiday_cc_id:
            self.holiday_action_target = self.holiday_cc_id.name

    @api.onchange('holiday_sound_id')
    def _onchange_holiday_sound_id(self):
        if self.holiday_sound_id:
            self.holiday_action_target = (
                self.holiday_sound_id.fs_path or self.holiday_sound_id.audio_fname or ''
            )

    @api.onchange('holiday_action_type')
    def _onchange_holiday_action_type(self):
        self.holiday_ivr_id = self.holiday_fifo_id = self.holiday_cc_id = False
        self.holiday_sound_id = False
        self.holiday_action_target = ''

    @api.model
    def _is_today_holiday(self, country_code='PL'):
        import datetime
        today = datetime.date.today()
        return self.env['freeswitch.public.holiday'].is_holiday(today, country_code)

    def _compute_cdr_count(self):
        for rec in self:
            rec.cdr_count = self.env['freeswitch.cdr'].search_count([
                ('destination_num', '=like', rec.name),
            ])

    @api.constrains('route_type', 'route_target')
    def _check_route_target(self):
        for rec in self:
            if not rec.route_target:
                raise ValidationError(_('Należy wybrać cel przekierowania.'))

    # ── Sync z FreeSWITCH DB ─────────────────────────────────────────────
    def _build_time_rules_json(self):
        """Buduj JSON time_rules z podpiętych reguł czasowych."""
        if not self.use_time_rules or not self.time_rule_ids:
            return None
        rules = []
        for r in self.time_rule_ids:
            days = [d for d in ['mon','tue','wed','thu','fri','sat','sun']
                    if getattr(r, 'day_' + d, False)]
            rules.append({
                'days':       days,
                'time_start': r.time_start,
                'time_end':   r.time_end,
                'timezone':   r.timezone or 'Europe/Warsaw',
            })
        return json.dumps(rules)

    def action_sync_to_fs(self):
        """Zapisz rekord do tabeli inbound_routes w PostgreSQL FreeSWITCH."""
        for rec in self:
            time_rules = rec._build_time_rules_json()

            if rec.fs_uuid:
                # UPDATE
                sql = """
                    UPDATE inbound_routes SET
                        did_pattern     = %s,
                        description     = %s,
                        route_type      = %s,
                        route_target    = %s,
                        priority        = %s,
                        active          = %s,
                        time_rules      = %s::jsonb,
                        fallback_type   = %s,
                        fallback_target = %s,
                        updated_at      = NOW()
                    WHERE id = %s::uuid
                """
                rec._fs_execute(sql, (
                    rec.name, rec.description,
                    rec.route_type, rec.route_target,
                    10, rec.active,
                    time_rules, rec.fallback_type or None,
                    rec.fallback_target or None,
                    rec.fs_uuid,
                ))
                _logger.info("Route updated in FS DB: %s", rec.fs_uuid)
            else:
                # INSERT
                sql = """
                    INSERT INTO inbound_routes
                        (did_pattern, description, route_type, route_target,
                         priority, active, time_rules, fallback_type, fallback_target)
                    VALUES (%s, %s, %s, %s, %s, %s, %s::jsonb, %s, %s)
                    RETURNING id::text
                """
                rows = rec._fs_query(sql, (
                    rec.name, rec.description,
                    rec.route_type, rec.route_target,
                    10, rec.active,
                    time_rules, rec.fallback_type or None,
                    rec.fallback_target or None,
                ))
                if rows:
                    rec.fs_uuid = rows[0].get('id') or list(rows[0].values())[0]
                    _logger.info("Route created in FS DB: %s", rec.fs_uuid)

        # Przeładuj dialplan przez REST API
        try:
            self._fs_api_call('POST', '/routing/dialplan/reload')
        except Exception:
            pass  # Nie blokuj zapisu jeśli API niedostępne

        return {
            'type':    'ir.actions.client',
            'tag':     'display_notification',
            'params': {
                'title':   _('Routing DID'),
                'message': _('Zapisano i przeładowano dialplan ✓'),
                'type':    'success',
            }
        }

    def action_sync_from_fs(self):
        """Import tras z PostgreSQL FreeSWITCH do Odoo."""
        rows = self._fs_query("""
            SELECT id::text, did_pattern, description, route_type, route_target,
                   active, time_rules::text,
                   fallback_type, fallback_target
            FROM   inbound_routes
            ORDER  BY name
        """)

        created = updated = 0
        for row in rows:
            existing = self.search([('fs_uuid', '=', row.get('id') or row.get('id::text', ''))])
            vals = {
                'fs_uuid':          row.get('id') or row.get('id::text'),
                'name':             row.get('did_pattern', ''),
                'description':      row.get('description') or row.get('did_pattern', ''),
                'route_type':       row.get('route_type', 'ivr'),
                'route_target':     row.get('route_target', ''),
                'active':           row.get('active', True),
                'fallback_type':    row.get('fallback_type') or False,
                'fallback_target':  row.get('fallback_target') or '',
            }
            if existing:
                existing.write(vals)
                updated += 1
            else:
                self.create(vals)
                created += 1

        return {
            'type':    'ir.actions.client',
            'tag':     'display_notification',
            'params': {
                'title':   _('Import tras DID'),
                'message': _('Zaimportowano: %d nowych, %d zaktualizowanych') % (created, updated),
                'type':    'success',
            }
        }

    def action_view_cdrs(self):
        return {
            'type':    'ir.actions.act_window',
            'name':    _('Połączenia — %s') % self.description,
            'res_model': 'freeswitch.cdr',
            'view_mode': 'tree,form',
            'domain':  [('destination_num', '=like', self.name)],
        }

    def action_open_flow_designer(self):
        """Otwiera Flow Designer z odwzorowaną konfiguracją DID."""
        self.ensure_one()
        Flow = self.env['freeswitch.flow']

        # Szukaj istniejącego flow z węzłem DID powiązanym z tym rekordem
        existing = None
        for flow in Flow.search([('active', '=', True)], order='write_date desc'):
            try:
                data = json.loads(flow.flow_data or '{}')
                for node in data.get('nodes', []):
                    if node.get('type') == 'did' and node.get('odoo_id') == self.id:
                        existing = flow
                        break
            except Exception:
                pass
            if existing:
                break
        if existing:
            return existing.action_open_designer()

        # Buduj nowy graf z konfiguracji
        nodes = []
        connections = []
        counter = [0]

        def make_nid():
            counter[0] += 1
            return 'n%d' % counter[0]

        def add_node(ntype, x, y, label, odoo_id=None, config=None):
            nid = make_nid()
            nodes.append({'id': nid, 'type': ntype, 'x': x, 'y': y,
                          'label': label, 'config': config or {}, 'odoo_id': odoo_id})
            return nid

        def add_conn(from_id, from_port, to_id):
            connections.append({'id': 'c%d' % len(connections),
                                'fromNode': from_id, 'fromPort': from_port,
                                'toNode': to_id, 'toPort': 'in'})

        def build_node(rtype, x, y, ivr_rec=None, fifo_rec=None, cc_rec=None,
                       user_rec=None, sound_rec=None, pstn=None):
            if rtype == 'ivr' and ivr_rec:
                items = sorted(ivr_rec.menu_item_ids, key=lambda i: i.sequence)
                nid = add_node('ivr', x, y,
                    label=ivr_rec.description or ivr_rec.name,
                    odoo_id=ivr_rec.id,
                    config={
                        'name': ivr_rec.name,
                        'description': ivr_rec.description or '',
                        'timeout': ivr_rec.timeout_sec,
                        'max_failures': ivr_rec.max_failures,
                        'default_action': ivr_rec.default_action or 'hangup',
                        'menu_items': [{
                            'digit': it.digit,
                            'description': it.description or '',
                            'action': it.action,
                            'target': it.target or '',
                            'target_id': (
                                it.target_ivr_id.id  if it.action == 'ivr'        and it.target_ivr_id  else
                                it.target_fifo_id.id if it.action == 'fifo'       and it.target_fifo_id else
                                it.target_cc_id.id   if it.action == 'callcenter' and it.target_cc_id   else
                                it.target_user_id.id if it.action == 'user'       and it.target_user_id else
                                None),
                            'target_pstn': '',
                        } for it in items],
                    })
                return nid, ivr_rec
            elif rtype == 'fifo' and fifo_rec:
                nid = add_node('fifo', x, y,
                    label=fifo_rec.description or fifo_rec.name, odoo_id=fifo_rec.id,
                    config={'name': fifo_rec.name, 'description': fifo_rec.description or ''})
                return nid, None
            elif rtype == 'callcenter' and cc_rec:
                nid = add_node('callcenter', x, y,
                    label=cc_rec.description or cc_rec.name, odoo_id=cc_rec.id,
                    config={'name': cc_rec.name, 'strategy': cc_rec.strategy or 'longest-idle-agent'})
                return nid, None
            elif rtype == 'user' and user_rec:
                nid = add_node('user', x, y,
                    label=user_rec.name or '', odoo_id=user_rec.id,
                    config={'name': user_rec.name or ''})
                return nid, None
            elif rtype == 'pstn' and pstn:
                nid = add_node('pstn', x, y, label='PSTN: %s' % pstn,
                    config={'number': pstn})
                return nid, None
            elif rtype == 'playback' and sound_rec:
                nid = add_node('audioplayer', x, y,
                    label=sound_rec.name or 'Audio', odoo_id=sound_rec.id,
                    config={'sound_id': sound_rec.id, 'sound_name': sound_rec.name or ''})
                return nid, None
            return None, None

        col = 60
        did_nid = add_node('did', col, 200,
            label=self.description or self.name, odoo_id=self.id,
            config={'did_pattern': self.name, 'description': self.description or ''})
        prev_id, prev_port = did_nid, 'out'
        col += 280

        timer_nid = None
        if self.use_time_rules and self.time_rule_ids:
            rule = self.time_rule_ids[0]
            days = ','.join(d for d in ['mon','tue','wed','thu','fri','sat','sun']
                            if getattr(rule, 'day_' + d, False))
            timer_nid = add_node('timerule', col, 200, label='Godziny pracy',
                config={'time_start': rule.time_start, 'time_end': rule.time_end,
                        'timezone': rule.timezone or 'Europe/Warsaw', 'days': days})
            add_conn(prev_id, prev_port, timer_nid)
            prev_id, prev_port = timer_nid, 'match'
            col += 280

        holiday_nid = None
        if self.use_holidays:
            holiday_nid = add_node('holiday', col, 200,
                label='Dni wolne (%s)' % (self.holiday_country_code or 'PL'),
                config={'country_code': self.holiday_country_code or 'PL'})
            add_conn(prev_id, prev_port, holiday_nid)
            prev_id, prev_port = holiday_nid, 'workday'
            col += 280

        main_nid, main_ivr = build_node(
            self.route_type, col, 200,
            ivr_rec=self.route_ivr_id, fifo_rec=self.route_fifo_id,
            cc_rec=self.route_cc_id, user_rec=self.route_user_id,
            sound_rec=self.route_sound_id,
            pstn=self.route_target if self.route_type == 'pstn' else None)
        if main_nid:
            add_conn(prev_id, prev_port, main_nid)

        if self.fallback_type:
            fb_nid, fb_ivr = build_node(
                self.fallback_type, col, 460,
                ivr_rec=self.fallback_ivr_id, fifo_rec=self.fallback_fifo_id,
                cc_rec=self.fallback_cc_id, user_rec=self.fallback_user_id,
                sound_rec=self.fallback_sound_id,
                pstn=self.fallback_target if self.fallback_type == 'pstn' else None)
            if fb_nid:
                if timer_nid:
                    add_conn(timer_nid, 'no_match', fb_nid)
                elif holiday_nid:
                    add_conn(holiday_nid, 'holiday', fb_nid)

        if holiday_nid and self.holiday_action_type:
            hol_nid, hol_ivr = build_node(
                self.holiday_action_type, col, 700,
                ivr_rec=self.holiday_ivr_id, fifo_rec=self.holiday_fifo_id,
                cc_rec=self.holiday_cc_id, sound_rec=self.holiday_sound_id,
                pstn=self.holiday_action_target if self.holiday_action_type == 'pstn' else None)
            if hol_nid:
                add_conn(holiday_nid, 'holiday', hol_nid)

        if main_nid and main_ivr:
            ivr_col = col + 280
            for idx, item in enumerate(sorted(main_ivr.menu_item_ids, key=lambda i: i.sequence)):
                sub_nid, sub_ivr = build_node(
                    item.action, ivr_col, 60 + idx * 180,
                    ivr_rec=item.target_ivr_id    if item.action == 'ivr'        else None,
                    fifo_rec=item.target_fifo_id   if item.action == 'fifo'       else None,
                    cc_rec=item.target_cc_id       if item.action == 'callcenter' else None,
                    user_rec=item.target_user_id   if item.action == 'user'       else None,
                    sound_rec=item.target_sound_id  if item.action == 'playback'  else None,
                    pstn=item.target               if item.action == 'pstn'       else None)
                if sub_nid:
                    add_conn(main_nid, item.digit, sub_nid)

        new_flow = Flow.create({
            'name': 'Flow \u2014 %s' % (self.description or self.name),
            'description': 'Wygenerowany z DID: %s' % self.name,
            'flow_data': json.dumps({'nodes': nodes, 'connections': connections},
                                    ensure_ascii=False),
        })
        return new_flow.action_open_designer()


class FreeSwitchRouteTimeRule(models.Model):
    """Reguła czasowa dla trasy DID (wiersze harmonogramu)."""
    _name        = 'freeswitch.route.time_rule'
    _description = 'FreeSWITCH — Reguła czasowa trasy'
    _order       = 'sequence'

    route_id   = fields.Many2one('freeswitch.route', string='Trasa', ondelete='cascade')
    sequence   = fields.Integer(default=10)
    name       = fields.Char(string='Opis', default='Godziny pracy')

    # Dni tygodnia — osobne pola boolean (łatwiejsze w UI niż Many2many)
    day_mon    = fields.Boolean('Pn', default=True)
    day_tue    = fields.Boolean('Wt', default=True)
    day_wed    = fields.Boolean('Śr', default=True)
    day_thu    = fields.Boolean('Cz', default=True)
    day_fri    = fields.Boolean('Pt', default=True)
    day_sat    = fields.Boolean('Sob', default=False)
    day_sun    = fields.Boolean('Nd',  default=False)

    time_start = fields.Char(string='Od',       default='08:00', required=True)
    time_end   = fields.Char(string='Do',       default='17:00', required=True)
    timezone   = fields.Char(string='Strefa czasowa', default='Europe/Warsaw')

    @api.constrains('time_start', 'time_end')
    def _check_times(self):
        import re
        pattern = r'^\d{2}:\d{2}$'
        for rec in self:
            if not re.match(pattern, rec.time_start or ''):
                raise ValidationError(_('Format czasu: HH:MM (np. 08:30)'))
            if not re.match(pattern, rec.time_end or ''):
                raise ValidationError(_('Format czasu: HH:MM (np. 17:00)'))