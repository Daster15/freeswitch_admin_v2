# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    # ── Połączenie z bazą FreeSWITCH ────────────────────────────────────
    freeswitch_use_same_db = fields.Boolean(
        string='Ta sama baza co Odoo',
        config_parameter='freeswitch.use_same_db',
        default=True,
        help='Zaznacz jeśli FreeSWITCH i Odoo korzystają z tej samej bazy PostgreSQL.',
    )
    freeswitch_db_host = fields.Char(
        string='Host PostgreSQL',
        config_parameter='freeswitch.db_host',
        default='127.0.0.1',
    )
    freeswitch_db_port = fields.Char(
        string='Port',
        config_parameter='freeswitch.db_port',
        default='5432',
    )
    freeswitch_db_name = fields.Char(
        string='Nazwa bazy',
        config_parameter='freeswitch.db_name',
        default='freeswitch',
    )
    freeswitch_db_user = fields.Char(
        string='Użytkownik',
        config_parameter='freeswitch.db_user',
        default='freeswitch',
    )
    freeswitch_db_password = fields.Char(
        string='Hasło',
        config_parameter='freeswitch.db_password',
    )

    # ── REST API FreeSWITCH ──────────────────────────────────────────────
    freeswitch_api_url = fields.Char(
        string='URL REST API',
        config_parameter='freeswitch.api_url',
        default='http://127.0.0.1:8000/api/v1',
        help='Bazowy URL serwisu FastAPI FreeSWITCH.',
    )
    freeswitch_api_key = fields.Char(
        string='Klucz API',
        config_parameter='freeswitch.api_key',
    )

    # ── Domena SIP ───────────────────────────────────────────────────────
    freeswitch_sip_domain = fields.Char(
        string='Domena SIP',
        config_parameter='freeswitch.sip_domain',
        default='sip.klinika.pl',
        help='Domena SIP używana do budowania kontaktów agentów (sofia/internal/1001@domena).',
    )
    freeswitch_gateway = fields.Char(
        string='Gateway SIP (PSTN)',
        config_parameter='freeswitch.gateway',
        default='default',
        help='Nazwa bramki do połączeń PSTN.',
    )
    freeswitch_recordings_url = fields.Char(
        string='URL nagrań',
        config_parameter='freeswitch.recordings_url',
        default='http://127.0.0.1:8000/api/v1/recordings/file',
        help='Bazowy URL do pobierania plików nagrań.',
    )

    freeswitch_sounds_dir = fields.Char(
        string='Katalog dźwięków na serwerze FS',
        config_parameter='freeswitch.sounds_dir',
        default='/etc/freeswitch/sounds/pl',
        help='Ścieżka bazowa do katalogu dźwięków na serwerze FreeSWITCH.',
    )

    # ── ElevenLabs TTS ───────────────────────────────────────────────────
    elevenlabs_api_key = fields.Char(
        string='ElevenLabs API Key',
        config_parameter='freeswitch.elevenlabs_api_key',
        help='Klucz API z panelu ElevenLabs (xi-api-key). '
             'Znajdziesz go na: https://elevenlabs.io/app/settings/api-keys',
    )

    # ── Akcje ────────────────────────────────────────────────────────────
    def action_test_db_connection(self):
        self.ensure_one()
        # Najpierw zapisz ustawienia
        self.execute()
        try:
            mixin = self.env['freeswitch.db.mixin']
            mixin.test_connection()
            return {
                'type':    'ir.actions.client',
                'tag':     'display_notification',
                'params': {
                    'title':   _('FreeSWITCH DB'),
                    'message': _('Połączenie z bazą PostgreSQL — OK ✓'),
                    'type':    'success',
                    'sticky':  False,
                }
            }
        except Exception as e:
            raise UserError(str(e))

    def action_test_api_connection(self):
        self.ensure_one()
        self.execute()
        try:
            import requests
        except ImportError:
            raise UserError(_("Brak biblioteki requests. Zainstaluj: pip install requests"))
        ICP = self.env['ir.config_parameter'].sudo()
        url     = ICP.get_param('freeswitch.api_url', '').rstrip('/') + '/health'
        api_key = ICP.get_param('freeswitch.api_key', '')
        headers = {}
        if api_key:
            headers['X-API-Key'] = api_key
        try:
            resp = requests.get(url, headers=headers, timeout=5)
            resp.raise_for_status()
            return {
                'type':    'ir.actions.client',
                'tag':     'display_notification',
                'params': {
                    'title':   _('FreeSWITCH REST API'),
                    'message': _('Połączenie z REST API — OK ✓'),
                    'type':    'success',
                    'sticky':  False,
                }
            }
        except Exception as e:
            raise UserError(_("Błąd REST API: %s") % str(e))

    def action_reload_dialplan(self):
        self.ensure_one()
        self.execute()
        mixin = self.env['freeswitch.db.mixin']
        result = mixin._fs_api_call('POST', '/routing/dialplan/reload')
        if result:
            return {
                'type':    'ir.actions.client',
                'tag':     'display_notification',
                'params': {
                    'title':   _('Dialplan'),
                    'message': _('Dialplan przeładowany pomyślnie ✓'),
                    'type':    'success',
                }
            }