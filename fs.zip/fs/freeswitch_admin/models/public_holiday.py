# -*- coding: utf-8 -*-
"""
public_holiday.py
=================
Globalna lista dni wolnych od pracy (świąt) per kraj.
Używana przez kalendarz dostępności użytkowników SIP.
"""
import logging
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

# Predefiniowane święta polskie (stałe — bez zależności od Wielkanocy)
PL_FIXED_HOLIDAYS = [
    ('01-01', 'Nowy Rok'),
    ('01-06', 'Trzech Króli'),
    ('05-01', 'Święto Pracy'),
    ('05-03', 'Święto Konstytucji 3 Maja'),
    ('08-15', 'Wniebowzięcie NMP'),
    ('11-01', 'Wszystkich Świętych'),
    ('11-11', 'Święto Niepodległości'),
    ('12-25', 'Boże Narodzenie (1. dzień)'),
    ('12-26', 'Boże Narodzenie (2. dzień)'),
]

COUNTRY_CODES = [
    ('PL', 'Polska'),
    ('DE', 'Niemcy'),
    ('GB', 'Wielka Brytania'),
    ('FR', 'Francja'),
    ('US', 'USA'),
    ('CZ', 'Czechy'),
    ('SK', 'Słowacja'),
    ('UA', 'Ukraina'),
    ('OTHER', 'Inny'),
]


class FreeSwitchPublicHoliday(models.Model):
    _name        = 'freeswitch.public.holiday'
    _description = 'FreeSWITCH — Dzień wolny od pracy'
    _order       = 'country_code, date'
    _rec_name    = 'name'

    name = fields.Char(
        'Nazwa święta', required=True,
        help='Np. "Boże Narodzenie", "Wielkanoc"',
    )
    country_code = fields.Selection(
        COUNTRY_CODES, string='Kraj',
        required=True, default='PL', index=True,
    )
    date = fields.Date(
        'Data', required=True, index=True,
        help='Konkretna data tego dnia wolnego.',
    )
    recurring = fields.Boolean(
        'Powtarza się co roku',
        default=True,
        help='Jeśli zaznaczone, dzień wolny jest traktowany jako coroczny '
             '(rok w dacie jest ignorowany przy porównaniu).',
    )
    active = fields.Boolean('Aktywny', default=True)
    note   = fields.Char('Uwagi')

    # Computed: wyświetl MM-DD dla świąt powtarzających się
    month_day = fields.Char(
        'Dzień w roku (MM-DD)',
        compute='_compute_month_day', store=True,
    )

    @api.depends('date')
    def _compute_month_day(self):
        for rec in self:
            if rec.date:
                rec.month_day = rec.date.strftime('%m-%d')
            else:
                rec.month_day = False

    @api.constrains('date')
    def _check_date(self):
        for rec in self:
            if not rec.date:
                raise ValidationError(_('Data jest wymagana.'))

    # ── Akcja: importuj predefiniowane święta PL ─────────────────────────────

    def action_import_pl_holidays(self):
        """Importuj standardowe święta polskie dla bieżącego roku i następnego."""
        import datetime
        current_year = datetime.date.today().year
        created = 0

        for year in [current_year, current_year + 1]:
            for md, hname in PL_FIXED_HOLIDAYS:
                month, day = md.split('-')
                date = datetime.date(year, int(month), int(day))

                # Sprawdź czy już istnieje
                existing = self.search([
                    ('country_code', '=', 'PL'),
                    ('date', '=', date),
                    ('name', '=', hname),
                ])
                if not existing:
                    self.create({
                        'name':         hname,
                        'country_code': 'PL',
                        'date':         date,
                        'recurring':    True,
                    })
                    created += 1

        return {
            'type': 'ir.actions.client',
            'tag':  'display_notification',
            'params': {
                'title':   _('Import świąt PL'),
                'message': _('Dodano %d nowych dni wolnych.') % created,
                'type':    'success',
            }
        }

    # ── Metoda pomocnicza — sprawdź czy data jest dniem wolnym ──────────────

    @api.model
    def is_holiday(self, check_date, country_code='PL'):
        """Zwróć True jeśli podana data jest dniem wolnym dla danego kraju."""
        import datetime
        if isinstance(check_date, str):
            check_date = datetime.date.fromisoformat(check_date)

        md = check_date.strftime('%m-%d')

        # Sprawdź konkretną datę
        exact = self.search([
            ('country_code', '=', country_code),
            ('date',         '=', check_date),
            ('active',       '=', True),
        ], limit=1)
        if exact:
            return True

        # Sprawdź powtarzające się (ignoruj rok)
        recurring = self.search([
            ('country_code', '=', country_code),
            ('recurring',    '=', True),
            ('month_day',    '=', md),
            ('active',       '=', True),
        ], limit=1)
        return bool(recurring)