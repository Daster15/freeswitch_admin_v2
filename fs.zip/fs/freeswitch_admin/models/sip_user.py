# -*- coding: utf-8 -*-
"""
sip_user.py
===========
Model użytkownika SIP (konto FreeSWITCH) z obsługą:
  - wielu urządzeń (konto SIP, komórka, softphone)
  - routingu warunkowego (zajęty / nie odbiera / niezarejestrowany)
  - kalendarza dostępności (harmonogram godzinowy)
  - synchronizacji z bazą FreeSWITCH (tabele users / devices)
"""

import logging
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError

_logger = logging.getLogger(__name__)

# ── Stałe ────────────────────────────────────────────────────────────────────

ROUTE_TYPES = [
    ('ivr',         'Menu IVR'),
    ('fifo',        'Kolejka FIFO'),
    ('callcenter',  'Kolejka CallCenter'),
    ('user',        'Inny użytkownik SIP'),
    ('pstn',        'Numer zewnętrzny PSTN'),
    ('voicemail',   'Poczta głosowa'),
    ('hangup',      'Rozłącz'),
]

DEVICE_TYPES = [
    ('sip',       'Konto SIP (telefon biurowy / softphone)'),
    ('mobile',    'Telefon komórkowy (PSTN)'),
    ('webrtc',    'WebRTC (przeglądarka)'),
    ('softphone', 'Softphone zewnętrzny'),
]

CODEC_OPTIONS = [
    ('PCMU',    'G.711 µ-law (PCMU)'),
    ('PCMA',    'G.711 A-law (PCMA)'),
    ('G722',    'G.722 (HD)'),
    ('G729',    'G.729 (kompresja)'),
    ('opus',    'Opus (WebRTC)'),
    ('PCMU,PCMA', 'PCMU + PCMA'),
    ('G722,PCMU,PCMA', 'G.722 + G.711 (zalecane)'),
]

DAYS_OF_WEEK = [
    ('mon', 'Poniedziałek'),
    ('tue', 'Wtorek'),
    ('wed', 'Środa'),
    ('thu', 'Czwartek'),
    ('fri', 'Piątek'),
    ('sat', 'Sobota'),
    ('sun', 'Niedziela'),
]

USER_STATUS = [
    ('active',    'Aktywny'),
    ('suspended', 'Zawieszony'),
    ('vacation',  'Urlop'),
    ('inactive',  'Nieaktywny'),
]


# ── Model główny: Użytkownik SIP ─────────────────────────────────────────────

class FreeSwitchSipUser(models.Model):
    _name        = 'freeswitch.sip.user'
    _description = 'FreeSWITCH — Użytkownik SIP'
    _inherit     = ['mail.thread', 'mail.activity.mixin', 'freeswitch.db.mixin',
                    'freeswitch.multicompany.mixin']
    _order       = 'name'
    _rec_name    = 'display_name_full'

    company_id = fields.Many2one(
        'res.company',
        string='Firma',
        required=True,
        index=True,
        default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('extension_company_unique', 'UNIQUE(name, company_id)',
         'Numer wewnętrzny musi być unikalny w ramach firmy!'),
    ]

    # ── Podstawowe dane ──────────────────────────────────────────────────────
    fs_uuid = fields.Char(
        'UUID FreeSWITCH', readonly=True, copy=False, index=True,
    )
    name = fields.Char(
        'Numer wewnętrzny', required=True, tracking=True,
        help='Numer wewnętrzny (extension), np. 1001',
    )
    display_name_full = fields.Char(
        'Nazwa wyświetlana', compute='_compute_display_name_full', store=True,
    )
    first_name = fields.Char('Imię', required=True, tracking=True)
    last_name  = fields.Char('Nazwisko', required=True, tracking=True)
    email      = fields.Char('E-mail', tracking=True)
    department = fields.Char('Dział', tracking=True)
    position   = fields.Char('Stanowisko', tracking=True)

    # Powiązanie z użytkownikiem Odoo (opcjonalne)
    odoo_user_id = fields.Many2one(
        'res.users', string='Konto Odoo',
        help='Powiąż z kontem Odoo, aby synchronizować dane użytkownika.',
    )

    # ── Hasło SIP (domyślne dla urządzeń SIP) ───────────────────────────────
    sip_password = fields.Char(
        'Hasło SIP', tracking=False,
        help='Domyślne hasło SIP dla urządzeń tego użytkownika. '
             'Możesz nadpisać je osobno dla każdego urządzenia.',
    )
    vm_password = fields.Char(
        'PIN poczty głosowej', default='0000',
        help='Czterocyfrowy PIN do poczty głosowej.',
    )

    # ── Caller ID wychodzący (prezentacja zewnętrzna) ────────────────────────
    outbound_caller_id_id = fields.Many2one(
        'freeswitch.pstn.number',
        string='Caller ID wychodzący',
        tracking=True,
        domain="[('company_id', '=', company_id), ('active', '=', True)]",
        help='Numer PSTN z puli tenanta prezentowany na zewnątrz podczas połączeń '
             'wychodzących. Puste = domyślny Caller ID bramki.',
    )
    outbound_caller_id = fields.Char(
        string='Caller ID (numer)',
        compute='_compute_outbound_caller_id',
        store=True,
        help='Wartość numeru z wybranego rekordu freeswitch.pstn.number.',
    )

    @api.depends('outbound_caller_id_id', 'outbound_caller_id_id.number')
    def _compute_outbound_caller_id(self):
        for rec in self:
            rec.outbound_caller_id = rec.outbound_caller_id_id.number or False

    # ── Status ogólny ────────────────────────────────────────────────────────
    status = fields.Selection(
        USER_STATUS, string='Status użytkownika',
        default='active', required=True, tracking=True,
    )
    active = fields.Boolean('Aktywny', default=True, tracking=True)

    # ── Urządzenia ───────────────────────────────────────────────────────────
    device_ids = fields.One2many(
        'freeswitch.sip.device', 'user_id',
        string='Urządzenia', copy=True,
    )
    device_count = fields.Integer('Urządzeń', compute='_compute_device_count')

    # ── Routing warunkowy: ZAJĘTY ────────────────────────────────────────────
    busy_action = fields.Selection(
        ROUTE_TYPES, string='Gdy zajęty — akcja', tracking=True,
        help='Co zrobić gdy wszystkie urządzenia są zajęte (busy).',
    )
    busy_ivr_id  = fields.Many2one(
        'freeswitch.ivr', string='IVR (zajęty)',
        compute='_compute_busy_selectors', inverse='_set_busy_from_ivr', store=False,
    )
    busy_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO (zajęty)',
        compute='_compute_busy_selectors', inverse='_set_busy_from_fifo', store=False,
    )
    busy_cc_id   = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CC (zajęty)',
        compute='_compute_busy_selectors', inverse='_set_busy_from_cc', store=False,
    )
    busy_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik SIP (zajęty)',
        compute='_compute_busy_selectors', inverse='_set_busy_from_user', store=False,
    )
    busy_target  = fields.Char(
        'Cel (zajęty)', tracking=True,
        help='Numer PSTN lub numer wewnętrzny — wypełniany automatycznie przez selektor.',
    )

    # ── Routing warunkowy: NIE ODBIERA ───────────────────────────────────────
    noanswer_action = fields.Selection(
        ROUTE_TYPES, string='Gdy nie odbiera — akcja', tracking=True,
    )
    noanswer_timeout = fields.Integer(
        'Czas dzwonienia (s)', default=30,
        help='Po ilu sekundach bez odpowiedzi uruchomić akcję.',
    )
    noanswer_ivr_id  = fields.Many2one(
        'freeswitch.ivr', string='IVR (nie odbiera)',
        compute='_compute_noanswer_selectors', inverse='_set_noanswer_from_ivr', store=False,
    )
    noanswer_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO (nie odbiera)',
        compute='_compute_noanswer_selectors', inverse='_set_noanswer_from_fifo', store=False,
    )
    noanswer_cc_id   = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CC (nie odbiera)',
        compute='_compute_noanswer_selectors', inverse='_set_noanswer_from_cc', store=False,
    )
    noanswer_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik SIP (nie odbiera)',
        compute='_compute_noanswer_selectors', inverse='_set_noanswer_from_user', store=False,
    )
    noanswer_target  = fields.Char(
        'Cel (nie odbiera)', tracking=True,
    )

    # ── Routing warunkowy: NIEZAREJESTROWANY ─────────────────────────────────
    unreg_action = fields.Selection(
        ROUTE_TYPES, string='Gdy niezarejestrowany — akcja', tracking=True,
    )
    unreg_ivr_id  = fields.Many2one(
        'freeswitch.ivr', string='IVR (niezarejestrowany)',
        compute='_compute_unreg_selectors', inverse='_set_unreg_from_ivr', store=False,
    )
    unreg_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO (niezarejestrowany)',
        compute='_compute_unreg_selectors', inverse='_set_unreg_from_fifo', store=False,
    )
    unreg_cc_id   = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CC (niezarejestrowany)',
        compute='_compute_unreg_selectors', inverse='_set_unreg_from_cc', store=False,
    )
    unreg_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik SIP (niezarejestrowany)',
        compute='_compute_unreg_selectors', inverse='_set_unreg_from_user', store=False,
    )
    unreg_target  = fields.Char(
        'Cel (niezarejestrowany)', tracking=True,
    )

    # ── Kalendarz dostępności ────────────────────────────────────────────────
    use_calendar = fields.Boolean(
        'Używaj kalendarza dostępności', default=False,
        help='Poza godzinami kalendarza połączenia będą kierowane do akcji fallback.',
    )
    calendar_ids = fields.One2many(
        'freeswitch.sip.calendar', 'user_id',
        string='Harmonogram dostępności', copy=True,
    )
    # Akcja poza godzinami kalendarza
    calendar_off_action = fields.Selection(
        ROUTE_TYPES, string='Poza godzinami — akcja', tracking=True,
    )
    calendar_off_ivr_id  = fields.Many2one(
        'freeswitch.ivr', string='IVR (poza godzinami)',
        compute='_compute_calendar_off_selectors', inverse='_set_caloff_from_ivr', store=False,
    )
    calendar_off_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO (poza godzinami)',
        compute='_compute_calendar_off_selectors', inverse='_set_caloff_from_fifo', store=False,
    )
    calendar_off_cc_id   = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CC (poza godzinami)',
        compute='_compute_calendar_off_selectors', inverse='_set_caloff_from_cc', store=False,
    )
    calendar_off_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik SIP (poza godzinami)',
        compute='_compute_calendar_off_selectors', inverse='_set_caloff_from_user', store=False,
    )
    calendar_off_target  = fields.Char(
        'Cel (poza godzinami)', tracking=True,
    )

    # ── Dni wolne od pracy ───────────────────────────────────────────────────
    use_holidays = fields.Boolean(
        'Uwzględnij dni wolne od pracy', default=False,
        help='W dni wolne połączenia będą kierowane do wybranej akcji zamiast normalnego routingu.',
    )
    holiday_country_code = fields.Selection([
        ('PL', 'Polska'), ('DE', 'Niemcy'), ('GB', 'Wielka Brytania'),
        ('FR', 'Francja'), ('US', 'USA'), ('CZ', 'Czechy'),
        ('SK', 'Słowacja'), ('UA', 'Ukraina'), ('OTHER', 'Inny'),
    ], string='Kraj (dni wolne)', default='PL')
    holiday_action = fields.Selection(
        ROUTE_TYPES, string='Akcja w dzień wolny', tracking=True,
    )
    holiday_target = fields.Char('Cel (dzień wolny)', tracking=True)
    holiday_ivr_id = fields.Many2one(
        'freeswitch.ivr', string='IVR (dzień wolny)',
        compute='_compute_holiday_selectors', inverse='_set_holiday_from_ivr', store=False,
    )
    holiday_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Kolejka FIFO (dzień wolny)',
        compute='_compute_holiday_selectors', inverse='_set_holiday_from_fifo', store=False,
    )
    holiday_cc_id = fields.Many2one(
        'freeswitch.cc.queue', string='Kolejka CC (dzień wolny)',
        compute='_compute_holiday_selectors', inverse='_set_holiday_from_cc', store=False,
    )
    holiday_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik SIP (dzień wolny)',
        compute='_compute_holiday_selectors', inverse='_set_holiday_from_user', store=False,
    )

    # ── Statystyki ───────────────────────────────────────────────────────────
    cdr_count = fields.Integer('Połączeń', compute='_compute_cdr_count')

    # ══════════════════════════════════════════════════════════════════════════
    # COMPUTE / INVERSE helpers
    # ══════════════════════════════════════════════════════════════════════════

    @api.depends('first_name', 'last_name', 'name')
    def _compute_display_name_full(self):
        for rec in self:
            rec.display_name_full = (
                f"{rec.first_name or ''} {rec.last_name or ''}".strip()
                + (f" ({rec.name})" if rec.name else '')
            )

    def _compute_device_count(self):
        for rec in self:
            rec.device_count = len(rec.device_ids)

    def _compute_cdr_count(self):
        for rec in self:
            rec.cdr_count = self.env['freeswitch.cdr'].search_count([
                '|',
                ('caller_id_num', '=', rec.name),
                ('destination_num', '=', rec.name),
            ])

    # ── Busy selectors ───────────────────────────────────────────────────────
    @api.depends('busy_action', 'busy_target')
    def _compute_busy_selectors(self):
        self._resolve_selectors(
            'busy_action', 'busy_target',
            'busy_ivr_id', 'busy_fifo_id', 'busy_cc_id', 'busy_user_id',
        )

    def _set_busy_from_ivr(self):
        self._write_target_from_m2o('busy_ivr_id', 'busy_target', 'freeswitch.ivr')

    def _set_busy_from_fifo(self):
        self._write_target_from_m2o('busy_fifo_id', 'busy_target', 'freeswitch.fifo')

    def _set_busy_from_cc(self):
        self._write_target_from_m2o('busy_cc_id', 'busy_target', 'freeswitch.cc.queue')

    def _set_busy_from_user(self):
        for rec in self:
            if rec.busy_user_id:
                rec.busy_target = rec.busy_user_id.name

    # ── No-answer selectors ──────────────────────────────────────────────────
    @api.depends('noanswer_action', 'noanswer_target')
    def _compute_noanswer_selectors(self):
        self._resolve_selectors(
            'noanswer_action', 'noanswer_target',
            'noanswer_ivr_id', 'noanswer_fifo_id', 'noanswer_cc_id', 'noanswer_user_id',
        )

    def _set_noanswer_from_ivr(self):
        self._write_target_from_m2o('noanswer_ivr_id', 'noanswer_target', 'freeswitch.ivr')

    def _set_noanswer_from_fifo(self):
        self._write_target_from_m2o('noanswer_fifo_id', 'noanswer_target', 'freeswitch.fifo')

    def _set_noanswer_from_cc(self):
        self._write_target_from_m2o('noanswer_cc_id', 'noanswer_target', 'freeswitch.cc.queue')

    def _set_noanswer_from_user(self):
        for rec in self:
            if rec.noanswer_user_id:
                rec.noanswer_target = rec.noanswer_user_id.name

    # ── Unreg selectors ──────────────────────────────────────────────────────
    @api.depends('unreg_action', 'unreg_target')
    def _compute_unreg_selectors(self):
        self._resolve_selectors(
            'unreg_action', 'unreg_target',
            'unreg_ivr_id', 'unreg_fifo_id', 'unreg_cc_id', 'unreg_user_id',
        )

    def _set_unreg_from_ivr(self):
        self._write_target_from_m2o('unreg_ivr_id', 'unreg_target', 'freeswitch.ivr')

    def _set_unreg_from_fifo(self):
        self._write_target_from_m2o('unreg_fifo_id', 'unreg_target', 'freeswitch.fifo')

    def _set_unreg_from_cc(self):
        self._write_target_from_m2o('unreg_cc_id', 'unreg_target', 'freeswitch.cc.queue')

    def _set_unreg_from_user(self):
        for rec in self:
            if rec.unreg_user_id:
                rec.unreg_target = rec.unreg_user_id.name

    # ── Calendar-off selectors ───────────────────────────────────────────────
    @api.depends('calendar_off_action', 'calendar_off_target')
    def _compute_calendar_off_selectors(self):
        self._resolve_selectors(
            'calendar_off_action', 'calendar_off_target',
            'calendar_off_ivr_id', 'calendar_off_fifo_id',
            'calendar_off_cc_id',  'calendar_off_user_id',
        )

    def _set_caloff_from_ivr(self):
        self._write_target_from_m2o('calendar_off_ivr_id', 'calendar_off_target', 'freeswitch.ivr')

    def _set_caloff_from_fifo(self):
        self._write_target_from_m2o('calendar_off_fifo_id', 'calendar_off_target', 'freeswitch.fifo')

    def _set_caloff_from_cc(self):
        self._write_target_from_m2o('calendar_off_cc_id', 'calendar_off_target', 'freeswitch.cc.queue')

    def _set_caloff_from_user(self):
        for rec in self:
            if rec.calendar_off_user_id:
                rec.calendar_off_target = rec.calendar_off_user_id.name

    # ══════════════════════════════════════════════════════════════════════════
    # Pomocnicy generyczne (DRY)
    # ══════════════════════════════════════════════════════════════════════════

    def _resolve_selectors(self, action_field, target_field,
                           ivr_f, fifo_f, cc_f, user_f):
        """Ustaw pola Many2one na podstawie wartości action + target."""
        for rec in self:
            setattr(rec, ivr_f,  False)
            setattr(rec, fifo_f, False)
            setattr(rec, cc_f,   False)
            setattr(rec, user_f, False)
            action = getattr(rec, action_field)
            target = getattr(rec, target_field)
            if not action or not target:
                continue
            if action == 'ivr':
                setattr(rec, ivr_f,
                        self.env['freeswitch.ivr'].search([('name', '=', target)], limit=1))
            elif action == 'fifo':
                setattr(rec, fifo_f,
                        self.env['freeswitch.fifo'].search([('name', '=', target)], limit=1))
            elif action == 'callcenter':
                setattr(rec, cc_f,
                        self.env['freeswitch.cc.queue'].search([('name', '=', target)], limit=1))
            elif action == 'user':
                setattr(rec, user_f,
                        self.env['freeswitch.sip.user'].search([('name', '=', target)], limit=1))

    def _write_target_from_m2o(self, m2o_field, target_field, model_name):
        for rec in self:
            m2o = getattr(rec, m2o_field)
            if m2o:
                setattr(rec, target_field, m2o.name)

    # ══════════════════════════════════════════════════════════════════════════
    # onchange — czyszczenie celów przy zmianie akcji
    # ══════════════════════════════════════════════════════════════════════════

    @api.onchange('busy_action')
    def _onchange_busy_action(self):
        self.busy_target = False
        self.busy_ivr_id = self.busy_fifo_id = self.busy_cc_id = self.busy_user_id = False

    @api.onchange('noanswer_action')
    def _onchange_noanswer_action(self):
        self.noanswer_target = False
        self.noanswer_ivr_id = self.noanswer_fifo_id = self.noanswer_cc_id = self.noanswer_user_id = False

    @api.onchange('unreg_action')
    def _onchange_unreg_action(self):
        self.unreg_target = False
        self.unreg_ivr_id = self.unreg_fifo_id = self.unreg_cc_id = self.unreg_user_id = False

    @api.onchange('calendar_off_action')
    def _onchange_calendar_off_action(self):
        self.calendar_off_target = False
        self.calendar_off_ivr_id = self.calendar_off_fifo_id = False
        self.calendar_off_cc_id  = self.calendar_off_user_id = False

    # ── Holiday selectors ────────────────────────────────────────────────────
    @api.depends('holiday_action', 'holiday_target')
    def _compute_holiday_selectors(self):
        self._resolve_selectors(
            'holiday_action', 'holiday_target',
            'holiday_ivr_id', 'holiday_fifo_id', 'holiday_cc_id', 'holiday_user_id',
        )

    def _set_holiday_from_ivr(self):
        self._write_target_from_m2o('holiday_ivr_id', 'holiday_target', 'freeswitch.ivr')

    def _set_holiday_from_fifo(self):
        self._write_target_from_m2o('holiday_fifo_id', 'holiday_target', 'freeswitch.fifo')

    def _set_holiday_from_cc(self):
        self._write_target_from_m2o('holiday_cc_id', 'holiday_target', 'freeswitch.cc.queue')

    def _set_holiday_from_user(self):
        for rec in self:
            if rec.holiday_user_id:
                rec.holiday_target = rec.holiday_user_id.name

    @api.onchange('holiday_action')
    def _onchange_holiday_action(self):
        self.holiday_target  = False
        self.holiday_ivr_id  = self.holiday_fifo_id = False
        self.holiday_cc_id   = self.holiday_user_id = False

    @api.model
    def _is_today_holiday(self, country_code='PL'):
        import datetime
        return self.env['freeswitch.public.holiday'].is_holiday(
            datetime.date.today(), country_code
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Walidacja
    # ══════════════════════════════════════════════════════════════════════════

    # ══════════════════════════════════════════════════════════════════════════
    # Sync z FreeSWITCH
    # ══════════════════════════════════════════════════════════════════════════

    def _build_dial_string(self):
        """Zbuduj dial string FreeSWITCH na podstawie aktywnych urządzeń i ich strategii.

        exclusive  → używa TYLKO tego urządzenia (pierwsze z exclusive, lub pierwsze aktywne)
        sequential → urządzenia po kolei (separator |)
        simultaneous → urządzenia jednocześnie (separator :)
        """
        ICP    = self.env['ir.config_parameter'].sudo()
        domain = ICP.get_param('freeswitch.sip_domain', 'sip.klinika.pl')

        active_devs = self.device_ids.filtered(lambda d: d.active).sorted('sequence')

        # Sprawdź czy jest urządzenie exclusive — ono wygrywa
        exclusive_dev = active_devs.filtered(lambda d: d.ring_strategy == 'exclusive')[:1]
        if exclusive_dev:
            return self._device_leg(exclusive_dev, domain)

        if not active_devs:
            return f'user/{self.name}'

        # Czy wszystkie jednocześnie, czy sequential?
        # Decyduje strategia pierwszego urządzenia (lub dominująca)
        legs = [self._device_leg(d, domain) for d in active_devs]
        first_strategy = active_devs[0].ring_strategy or 'simultaneous'
        separator = ':' if first_strategy == 'simultaneous' else '|'
        return separator.join(legs)

    def _device_leg(self, device, domain):
        """Zwróć jeden segment bridge dla danego urządzenia.

        ZAWSZE ustawia origination_caller_id_number i _name żeby rozmówca
        widział poprawny Caller ID niezależnie od typu urządzenia (SIP/PSTN).

        PSTN/mobile : sofia/gateway/GW/numer
        SIP/webrtc  : user/EXT
        """
        # Caller ID: outbound_caller_id z Odoo → numer wewnętrzny jako fallback
        cid_num  = self.outbound_caller_id or self.name
        cid_name = (
            f"{self.first_name or ''} {self.last_name or ''}".strip()
            or cid_num
        )
        cid_vars = (
            f'{{origination_caller_id_number={cid_num}'
            f',origination_caller_id_name={cid_name}}}'
        )

        if device.device_type == 'mobile':
            number  = device.mobile_number or self.name
            gateway = device.mobile_gateway or 'default'
            return f'{cid_vars}sofia/gateway/{gateway}/{number}'
        else:
            # SIP, WebRTC, softphone — user/EXT z CallerID
            sip_ext = device.linked_user_id.name if device.linked_user_id else self.name
            return f'{cid_vars}user/{sip_ext}'

    def action_sync_to_fs(self):
        """Synchronizuj użytkownika i jego urządzenia do bazy FreeSWITCH."""
        for rec in self:
            # Upsert użytkownika
            user_data = (
                rec.name,
                rec.first_name or '',
                rec.last_name or '',
                rec.email or None,
                rec.department or None,
                rec.sip_password or '',
                rec.vm_password or '0000',
                rec.status,
                rec.active,
                rec.busy_action or None,    rec.busy_target or None,
                rec.noanswer_action or None, rec.noanswer_target or None,
                int(rec.noanswer_timeout),
                rec.unreg_action or None,   rec.unreg_target or None,
                rec.outbound_caller_id or None,
            )

            if rec.fs_uuid:
                rec._fs_execute("""
                    UPDATE sip_users SET
                        extension=%(ext)s, first_name=%(fn)s, last_name=%(ln)s,
                        email=%(email)s, department=%(dept)s,
                        sip_password=%(pwd)s, vm_password=%(vm)s,
                        status=%(status)s, active=%(active)s,
                        busy_action=%(ba)s, busy_target=%(bt)s,
                        noanswer_action=%(na)s, noanswer_target=%(nt)s,
                        noanswer_timeout=%(nto)s,
                        unreg_action=%(ua)s, unreg_target=%(ut)s,
                        outbound_caller_id=%(ocid)s,
                        updated_at=NOW()
                    WHERE id=%(id)s::uuid
                """, dict(zip(
                    ['ext','fn','ln','email','dept','pwd','vm','status','active',
                     'ba','bt','na','nt','nto','ua','ut','ocid','id'],
                    list(user_data) + [rec.fs_uuid]
                )))
            else:
                rows = rec._fs_query("""
                    INSERT INTO sip_users
                        (extension, first_name, last_name, email, department,
                         sip_password, vm_password, status, active,
                         busy_action, busy_target,
                         noanswer_action, noanswer_target, noanswer_timeout,
                         unreg_action, unreg_target,
                         outbound_caller_id)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    RETURNING id::text
                """, user_data)
                if rows:
                    rec.fs_uuid = rows[0].get('id') or list(rows[0].values())[0]

            # Sync urządzeń + zapisz wyliczony dial_string
            for dev in rec.device_ids:
                dev.action_sync_to_fs()

            dial_string = rec._build_dial_string()
            if rec.fs_uuid:
                rec._fs_execute("""
                    UPDATE sip_users SET dial_string = %s, updated_at = NOW()
                    WHERE id = %s::uuid
                """, (dial_string, rec.fs_uuid))

        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title':   _('Użytkownik SIP'),
                'message': _('Zsynchronizowano z FreeSWITCH ✓'),
                'type':    'success',
            },
        }

    def action_view_cdrs(self):
        return {
            'type':      'ir.actions.act_window',
            'name':      _('Połączenia — %s') % self.display_name_full,
            'res_model': 'freeswitch.cdr',
            'view_mode': 'tree,form',
            'domain':    [
                '|',
                ('caller_id_num',  '=', self.name),
                ('destination_num', '=', self.name),
            ],
        }


# ── Model: Urządzenie SIP ─────────────────────────────────────────────────────

class FreeSwitchSipDevice(models.Model):
    _name        = 'freeswitch.sip.device'
    _description = 'FreeSWITCH — Urządzenie SIP użytkownika'
    _order       = 'sequence, device_type'
    _inherit     = ['freeswitch.db.mixin']
    _rec_name    = 'display_name_device'

    display_name_device = fields.Char(
        string='Nazwa urządzenia',
        compute='_compute_display_name_device',
        store=False,
    )

    @api.depends('device_type', 'label', 'mobile_number', 'linked_user_id.name',
                 'user_id.name', 'ring_strategy')
    def _compute_display_name_device(self):
        for rec in self:
            # Jeśli jest numer PSTN — zawsze pokazuj jako komórkę z numerem
            if rec.mobile_number:
                label = rec.label or 'Telefon'
                rec.display_name_device = f'📱 {label} ({rec.mobile_number})'

            # Konto SIP / WebRTC / softphone — pokaż numer wewnętrzny
            else:
                ext = rec.linked_user_id.name if rec.linked_user_id else (rec.user_id.name or '?')
                if rec.device_type == 'webrtc':
                    rec.display_name_device = f'🌐 WebRTC: {ext}'
                elif rec.device_type == 'softphone':
                    rec.display_name_device = f'💻 Softphone: {ext}'
                else:
                    rec.display_name_device = f'☎️  Konto SIP: {ext}'

    user_id     = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik',
        required=True, ondelete='cascade',
    )
    fs_uuid     = fields.Char('UUID FreeSWITCH', readonly=True, copy=False)
    sequence    = fields.Integer('Kolejność dzwonienia', default=10,
                                 help='Niższy numer = dzwoni pierwszy (lub jednocześnie).')
    device_type = fields.Selection(DEVICE_TYPES, string='Typ urządzenia',
                                   required=True, default='sip')
    label       = fields.Char('Etykieta',
                               help='Np. "Biuro", "Softphone", "Komórka służbowa"')
    active      = fields.Boolean('Aktywne', default=True)

    # ── Dane SIP (tylko dla kont SIP / WebRTC) ───────────────────────────────
    linked_user_id = fields.Many2one(
        'freeswitch.sip.user',
        string='Konto SIP (użytkownik)',
        domain="[('id', '!=', user_id)]",
        help='Wybierz innego użytkownika SIP, jeśli to urządzenie loguje się na jego konto. '
             'Puste = urządzenie używa własnego numeru i hasła właściciela.',
    )
    sip_domain   = fields.Char(
        'Domena SIP',
        help='Domena/IP serwera FreeSWITCH. Puste = pobierz z ustawień globalnych.',
    )
    codec_string = fields.Selection(
        CODEC_OPTIONS, string='Kodeki',
        default='G722,PCMU,PCMA',
    )
    dtmf_mode    = fields.Selection([
        ('rfc2833', 'RFC 2833 (zalecane)'),
        ('info',    'SIP INFO'),
        ('inband',  'Inband'),
    ], string='Tryb DTMF', default='rfc2833')
    nat_traverse = fields.Boolean('NAT (STUN/ICE)', default=False)
    transport    = fields.Selection([
        ('udp', 'UDP'), ('tcp', 'TCP'), ('tls', 'TLS'),
    ], default='udp', string='Transport')

    # ── Numer komórkowy / PSTN ───────────────────────────────────────────────
    mobile_number = fields.Char(
        'Numer PSTN/GSM',
        help='Numer zewnętrzny, np. +48501234567. Wymagany dla urządzeń mobilnych.',
    )
    mobile_gateway = fields.Char(
        'Gateway wychodzący',
        help='Nazwa gateway SIP-PSTN, przez który dzwonić na ten numer.',
    )

    # ── Opcje dzwonienia ─────────────────────────────────────────────────────
    ring_strategy = fields.Selection([
        ('simultaneous', 'Jednocześnie ze wszystkimi'),
        ('sequential',   'Po kolei (wg kolejności)'),
        ('exclusive',    'Tylko to urządzenie'),
    ], string='Strategia dzwonienia', default='simultaneous',
        help='Jednocześnie = dzwoni razem z innymi aktywnymi urządzeniami.\n'
             'Po kolei = dzwoni dopiero gdy poprzednie nie odpowie.\n'
             'Tylko to urządzenie = połączenia trafiają wyłącznie tutaj, pozostałe urządzenia są pomijane.')

    def _get_effective_sip_username(self):
        """Zwróć efektywny login SIP: z powiązanego użytkownika lub własny numer."""
        if self.linked_user_id:
            return self.linked_user_id.name
        return self.user_id.name

    def _get_effective_sip_password(self):
        """Zwróć efektywne hasło SIP: z powiązanego użytkownika lub własne."""
        if self.linked_user_id:
            return self.linked_user_id.sip_password or ''
        return self.user_id.sip_password or ''

    def _get_effective_sip_domain(self):
        """Zwróć domenę SIP: własną lub z ustawień globalnych."""
        if self.sip_domain:
            return self.sip_domain
        ICP = self.env['ir.config_parameter'].sudo()
        return ICP.get_param('freeswitch.sip_domain', 'sip.klinika.pl')

    def action_sync_to_fs(self):
        """Synchronizuj urządzenie do bazy FreeSWITCH."""
        rec = self
        data = (
            rec.user_id.fs_uuid,
            rec._get_effective_sip_username(),
            rec._get_effective_sip_password(),
            rec._get_effective_sip_domain() or None,
            rec.device_type,
            rec.label or None,
            rec.codec_string or 'G722,PCMU,PCMA',
            rec.dtmf_mode or 'rfc2833',
            rec.mobile_number or None,
            rec.mobile_gateway or None,
            rec.ring_strategy or 'simultaneous',
            rec.sequence,
            rec.active,
        )
        if rec.fs_uuid:
            rec._fs_execute("""
                UPDATE sip_devices SET
                    user_uuid=%(uu)s, sip_username=%(su)s, sip_password=%(sp)s,
                    sip_domain=%(sd)s, device_type=%(dt)s, label=%(lb)s,
                    codec_string=%(cs)s, dtmf_mode=%(dm)s,
                    mobile_number=%(mn)s, mobile_gateway=%(mg)s,
                    ring_strategy=%(rs)s, sequence=%(seq)s, active=%(act)s,
                    updated_at=NOW()
                WHERE id=%(id)s::uuid
            """, dict(zip(
                ['uu','su','sp','sd','dt','lb','cs','dm','mn','mg','rs','seq','act','id'],
                list(data) + [rec.fs_uuid]
            )))
        else:
            rows = rec._fs_query("""
                INSERT INTO sip_devices
                    (user_uuid, sip_username, sip_password, sip_domain,
                     device_type, label, codec_string, dtmf_mode,
                     mobile_number, mobile_gateway, ring_strategy, sequence, active)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                RETURNING id::text
            """, data)
            if rows:
                rec.fs_uuid = rows[0].get('id') or list(rows[0].values())[0]

    @api.constrains('device_type', 'mobile_number')
    def _check_mobile_number(self):
        for rec in self:
            if rec.device_type == 'mobile' and not rec.mobile_number:
                raise ValidationError(
                    _('Urządzenie mobilne wymaga podania numeru PSTN/GSM.')
                )

    @api.constrains('linked_user_id', 'mobile_number')
    def _check_linked_user_vs_mobile(self):
        for rec in self:
            if rec.linked_user_id and rec.mobile_number:
                raise ValidationError(
                    _('Nie można jednocześnie ustawić konta SIP i numeru PSTN/GSM. '
                      'Wybierz jedno z dwóch.')
                )

    @api.onchange('linked_user_id')
    def _onchange_linked_user_id(self):
        if self.linked_user_id and self.mobile_number:
            self.mobile_number = False
            self.mobile_gateway = False
            return {'warning': {
                'title': _('Wyczyszczono numer PSTN/GSM'),
                'message': _('Numer PSTN/GSM został usunięty, ponieważ wybrano konto SIP.'),
            }}

    @api.onchange('mobile_number')
    def _onchange_mobile_number(self):
        if self.mobile_number and self.linked_user_id:
            self.linked_user_id = False
            return {'warning': {
                'title': _('Wyczyszczono konto SIP'),
                'message': _('Konto SIP zostało usunięte, ponieważ podano numer PSTN/GSM.'),
            }}


# ── Model: Wpis kalendarza dostępności ───────────────────────────────────────

class FreeSwitchSipCalendar(models.Model):
    _name        = 'freeswitch.sip.calendar'
    _description = 'FreeSWITCH — Harmonogram dostępności użytkownika SIP'
    _order       = 'sequence'

    user_id    = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik',
        required=True, ondelete='cascade',
    )
    sequence   = fields.Integer('Kolejność', default=10)
    name       = fields.Char('Opis', default='Godziny pracy',
                              help='Np. "Poniedziałek–Piątek", "Sobota dyżur"')

    # Dni tygodnia
    day_mon = fields.Boolean('Pn', default=True)
    day_tue = fields.Boolean('Wt', default=True)
    day_wed = fields.Boolean('Śr', default=True)
    day_thu = fields.Boolean('Cz', default=True)
    day_fri = fields.Boolean('Pt', default=True)
    day_sat = fields.Boolean('Sob', default=False)
    day_sun = fields.Boolean('Nd',  default=False)

    time_start = fields.Char('Od',  default='08:00', required=True)
    time_end   = fields.Char('Do',  default='17:00', required=True)
    timezone   = fields.Char('Strefa czasowa', default='Europe/Warsaw')

    # Wyjątek: konkretna data (urlop, święto)
    is_exception = fields.Boolean(
        'Wyjątek (konkretna data)',
        help='Zaznacz jeśli ten wpis dotyczy jednego konkretnego dnia (np. święto).',
    )
    exception_date = fields.Date('Data wyjątku')
    exception_type = fields.Selection([
        ('available',   'Dostępny tego dnia'),
        ('unavailable', 'Niedostępny tego dnia'),
    ], string='Typ wyjątku', default='unavailable')

    @api.constrains('time_start', 'time_end')
    def _check_times(self):
        import re
        pattern = r'^\d{2}:\d{2}$'
        for rec in self:
            if rec.is_exception:
                continue
            if not re.match(pattern, rec.time_start or ''):
                raise ValidationError(_('Format czasu: HH:MM (np. 08:30)'))
            if not re.match(pattern, rec.time_end or ''):
                raise ValidationError(_('Format czasu: HH:MM (np. 17:00)'))

    @api.constrains('is_exception', 'exception_date')
    def _check_exception_date(self):
        for rec in self:
            if rec.is_exception and not rec.exception_date:
                raise ValidationError(
                    _('Dla wyjątku wymagana jest data.')
                )