# -*- coding: utf-8 -*-
# Kolejność importów jest ważna — mixin musi być przed modelami które go używają

# ── 1. Mixiny (najpierw, bo modele je dziedziczą) ────────────────────────────
from . import freeswitch_multicompany_mixin   # NOWY — mixin multi-company
from . import freeswitch_db                   # mixin DB + API (zaktualizowany)
from . import freeswitch_company_config        # NOWY — konfiguracja per firma

# ── 2. Modele główne ─────────────────────────────────────────────────────────
from . import sip_user
from . import inbound_route
from . import ivr_config
from . import ivr_menu_item
from . import fifo_config
from . import callcenter_queue
from . import callcenter_agent
from . import call_record
from . import freeswitch_sound
from . import flow_designer
from . import public_holiday
from . import res_config_settings             # pozostaje dla kompatybilności