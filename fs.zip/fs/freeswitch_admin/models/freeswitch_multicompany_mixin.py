# -*- coding: utf-8 -*-
"""
freeswitch_multicompany_mixin.py
================================
Mixin dodający obsługę multi-company do modeli FreeSWITCH.

Użycie w modelu:
    _inherit = [..., 'freeswitch.multicompany.mixin']
"""

from odoo import models, fields, api


class FreeSwitchMulticompanyMixin(models.AbstractModel):
    _name        = 'freeswitch.multicompany.mixin'
    _description = 'FreeSWITCH Multi-company Mixin'

    company_id = fields.Many2one(
        'res.company',
        string='Firma',
        required=True,
        index=True,
        default=lambda self: self.env.company,
        # Rekordy widoczne tylko dla firm, do których użytkownik ma dostęp
    )

    @api.model
    def _search(self, domain, offset=0, limit=None, order=None, access_rights_uid=None):
        """Automatycznie zawęź wyniki do firm aktywnych użytkownika."""
        domain = list(domain or [])
        # Odoo 17 multi-company: company_ids zawiera firmy dostępne dla usera
        if self._fields.get('company_id') and not any(
            leaf[0] == 'company_id' for leaf in domain if isinstance(leaf, (list, tuple))
        ):
            companies = self.env.companies
            if companies:
                domain = [('company_id', 'in', companies.ids)] + domain
        return super()._search(
            domain, offset=offset, limit=limit,
            order=order, access_rights_uid=access_rights_uid,
        )