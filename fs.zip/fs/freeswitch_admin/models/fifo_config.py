# -*- coding: utf-8 -*-
import json
import logging
from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)


class FreeSwitchFIFO(models.Model):
    _name        = 'freeswitch.fifo'
    _description = 'FreeSWITCH — Kolejka FIFO'
    _inherit     = ['mail.thread', 'mail.activity.mixin', 'freeswitch.db.mixin',
                    'freeswitch.multicompany.mixin']
    _order       = 'name'

    company_id = fields.Many2one(
        'res.company', string='Firma', required=True, index=True,
        default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('name_company_unique', 'UNIQUE(name, company_id)',
         'Nazwa kolejki FIFO musi być unikalna w ramach firmy!'),
    ]

    fs_uuid     = fields.Char('UUID FreeSWITCH', readonly=True, copy=False, index=True)
    name        = fields.Char('Nazwa kolejki (klucz)', required=True, tracking=True,
                               help='Np. fifo-mokotow-rejestracja')
    description = fields.Char('Opis', required=True, tracking=True)
    active      = fields.Boolean('Aktywna', default=True, tracking=True)

    # ── Parametry podstawowe ─────────────────────────────────────────────────
    importance  = fields.Integer('Priorytet kolejki', default=0)
    max_wait_sec = fields.Integer(
        'Maks. czas oczekiwania (s)', default=300,
        help='Po tym czasie caller zostanie przekierowany wg "Akcja po timeout".',
    )
    caller_priority = fields.Integer('Priorytet slotu callera (1-10)', default=5)

    # ── Strategia dzwonienia do agentów ──────────────────────────────────────
    RING_STRATEGIES = [
        ('ringall',        'Ring All — dzwoń do wszystkich jednocześnie'),
        ('progressive',    'Progressive — stopniowo dołączaj kolejnych agentów'),
    ]
    ring_strategy = fields.Selection(
        RING_STRATEGIES,
        string='Strategia dzwonienia',
        default='ringall',
        required=True,
        tracking=True,
        help=(
            'Ring All: dzwoni do wszystkich agentów jednocześnie od razu.\n'
            'Progressive: najpierw dzwoni do agenta 1 przez N sekund, '
            'potem dołącza agenta 2, itd. N = ring_progressive_sec.'
        ),
    )
    ring_progressive_sec = fields.Integer(
        'Czas dzwonienia przed dołączeniem kolejnego agenta (s)',
        default=15,
        help=(
            'Tylko dla strategii Progressive.\n'
            'Ile sekund dzwonić do bieżącej grupy agentów zanim dołączy kolejny.\n'
            'Np. 15 = po 15s bez odpowiedzi dołącza następny agent z listy.'
        ),
    )

    # ── Dźwięki ──────────────────────────────────────────────────────────────
    moh_sound_id = fields.Many2one(
        'freeswitch.sound', string='Muzyka oczekiwania (MOH)', ondelete='set null',
    )
    moh_sound_player = fields.Html(
        related='moh_sound_id.audio_player', string='Odsłuch MOH', sanitize=False,
    )
    announce_sound_id = fields.Many2one(
        'freeswitch.sound', string='Ogłoszenie pozycji (chime)', ondelete='set null',
        help='Plik audio odtwarzany co announce_freq sekund. Jeśli puste — ogłaszana '
             'jest tylko cyfra pozycji syntetycznie.',
    )
    announce_sound_player = fields.Html(
        related='announce_sound_id.audio_player', string='Odsłuch ogłoszenia', sanitize=False,
    )
    announce_freq = fields.Integer(
        'Częstotliwość ogłoszeń (s)', default=60,
        help='Co ile sekund ogłaszać pozycję w kolejce. 0 = wyłączone.',
    )
    orbit_announce_sound_id = fields.Many2one(
        'freeswitch.sound', string='Ogłoszenie orbit (timeout)', ondelete='set null',
    )
    orbit_announce_sound_player = fields.Html(
        related='orbit_announce_sound_id.audio_player',
        string='Odsłuch ogłoszenia orbit', sanitize=False,
    )

    # ── Wyjście callera ───────────────────────────────────────────────────────
    caller_exit_key = fields.Char('Klawisz wyjścia callera', default='')
    caller_exit_to_orbit = fields.Boolean('Wyjście klawiszem → orbit', default=False)

    # ── Akcja po timeout ──────────────────────────────────────────────────────
    TIMEOUT_TYPES = [
        ('ivr',         'Menu IVR'),
        ('fifo',        'Kolejka FIFO'),
        ('callcenter',  'Call Center'),
        ('user',        'Użytkownik SIP'),
        ('pstn',        'Numer zewnętrzny PSTN'),
        ('playback',    'Odtwórz plik audio'),
        ('voicemail',   'Poczta głosowa'),
        ('hangup',      'Rozłącz'),
    ]
    timeout_action_type = fields.Selection(TIMEOUT_TYPES, string='Akcja po timeout', tracking=True)
    timeout_ivr_id      = fields.Many2one('freeswitch.ivr',      string='Menu IVR (timeout)',      ondelete='set null')
    timeout_fifo_id     = fields.Many2one('freeswitch.fifo',     string='Kolejka FIFO (timeout)',  ondelete='set null')
    timeout_cc_id       = fields.Many2one('freeswitch.cc.queue', string='Call Center (timeout)',   ondelete='set null')
    timeout_user_id     = fields.Many2one('freeswitch.cc.agent', string='Agent SIP (timeout)',
                                          domain=[('active', '=', True)], ondelete='set null')
    timeout_pstn        = fields.Char('Numer PSTN (timeout)', help='Np. +48500123456')
    timeout_sound_id    = fields.Many2one('freeswitch.sound',    string='Plik audio (timeout)',    ondelete='set null')
    timeout_action      = fields.Char(
        'Akcja po timeout (wygenerowana)', compute='_compute_timeout_action',
        store=True, readonly=True,
    )

    @api.depends(
        'timeout_action_type', 'max_wait_sec',
        'timeout_ivr_id', 'timeout_fifo_id', 'timeout_cc_id',
        'timeout_user_id', 'timeout_pstn', 'timeout_sound_id',
    )
    def _compute_timeout_action(self):
        for rec in self:
            t = rec.timeout_action_type
            if not t or t == 'hangup':
                rec.timeout_action = 'hangup' if t == 'hangup' else ''
            elif t == 'ivr'         and rec.timeout_ivr_id:
                rec.timeout_action = f'transfer:{rec.timeout_ivr_id.name} XML default'
            elif t == 'fifo'        and rec.timeout_fifo_id:
                rec.timeout_action = f'transfer:{rec.timeout_fifo_id.name} XML default'
            elif t == 'callcenter'  and rec.timeout_cc_id:
                rec.timeout_action = f'transfer:{rec.timeout_cc_id.name} XML default'
            elif t == 'user'        and rec.timeout_user_id:
                rec.timeout_action = f'transfer:{rec.timeout_user_id.extension} XML default'
            elif t == 'pstn'        and rec.timeout_pstn:
                rec.timeout_action = f'transfer:{rec.timeout_pstn} XML default'
            elif t == 'playback'    and rec.timeout_sound_id:
                rec.timeout_action = f'playback:{rec.timeout_sound_id.fs_path or rec.timeout_sound_id.audio_fname}'
            elif t == 'voicemail':
                vm_ext = rec.env['ir.config_parameter'].sudo().get_param(
                    'freeswitch.voicemail_extension', 'voicemail')
                rec.timeout_action = f'transfer:{vm_ext} XML default'
            else:
                rec.timeout_action = ''

    # ── Nagrywanie ────────────────────────────────────────────────────────────
    record_template = fields.Char(
        'Szablon nagrania', default='',
        help='{uuid} = UUID połączenia. Np. /nagrania/{uuid}.wav. Puste = bez nagrywania.',
    )

    # ── Agenci ────────────────────────────────────────────────────────────────
    agent_ids   = fields.One2many('freeswitch.fifo.agent', 'fifo_id', string='Agenci')
    agent_count = fields.Integer('Liczba agentów', compute='_compute_agent_count')

    @api.depends('agent_ids')
    def _compute_agent_count(self):
        for rec in self:
            rec.agent_count = len(rec.agent_ids.filtered('active'))

    # ── Statystyki live (z FS) ────────────────────────────────────────────────
    callers_waiting  = fields.Integer('Oczekujących', default=0, readonly=True)
    agents_available = fields.Integer('Dostępnych agentów', default=0, readonly=True)

    def action_refresh_stats(self):
        for rec in self:
            try:
                result = rec._fs_api_call('GET', f'/fifo/stats?name={rec.name}')
                if result:
                    rec.callers_waiting  = result.get('callers_waiting', 0)
                    rec.agents_available = result.get('agents_available', 0)
            except Exception:
                pass

    # ── Sync do FS ────────────────────────────────────────────────────────────
    def action_sync_to_fs(self):
        """Zapisuje konfigurację kolejki FIFO do bazy FreeSWITCH (jeśli osobna baza)."""
        for rec in self:
            agents_json = rec._get_agents_json()
            sql = """
                INSERT INTO freeswitch_fifo
                    (fs_uuid, name, description, importance, max_wait_sec,
                     caller_priority, ring_strategy, ring_progressive_sec,
                     announce_freq, timeout_action, record_template, agents, active)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::text, %s)
                ON CONFLICT (fs_uuid) DO UPDATE SET
                    name                 = EXCLUDED.name,
                    description          = EXCLUDED.description,
                    importance           = EXCLUDED.importance,
                    max_wait_sec         = EXCLUDED.max_wait_sec,
                    caller_priority      = EXCLUDED.caller_priority,
                    ring_strategy        = EXCLUDED.ring_strategy,
                    ring_progressive_sec = EXCLUDED.ring_progressive_sec,
                    announce_freq        = EXCLUDED.announce_freq,
                    timeout_action       = EXCLUDED.timeout_action,
                    record_template      = EXCLUDED.record_template,
                    agents               = EXCLUDED.agents,
                    active               = EXCLUDED.active
            """
            params = (
                rec.fs_uuid or rec.name,
                rec.name, rec.description or rec.name,
                rec.importance or 0, rec.max_wait_sec or 300,
                rec.caller_priority or 5,
                rec.ring_strategy or 'ringall',
                rec.ring_progressive_sec or 15,
                rec.announce_freq or 0,
                rec.timeout_action or '',
                rec.record_template or '',
                agents_json, rec.active,
            )
            try:
                rec._fs_execute(sql, params)
                _logger.info('action_sync_to_fs OK: %s', rec.name)
            except Exception as e:
                _logger.warning('action_sync_to_fs error [%s]: %s', rec.name, e)

    def _get_agents_json(self):
        contacts = [a.contact for a in self.agent_ids if a.contact]
        return json.dumps(contacts)

    def _build_member_contact(self, agent):
        """Buduje string kontaktu membera (używane przez api.py sync)."""
        cfg     = self.env['freeswitch.company.config']._get_for_company(self.company_id)
        gateway = cfg.gateway or 'default'
        domain  = cfg.sip_domain or ''

        call_timeout = agent.call_timeout or 30
        member_wait  = agent.member_wait or 'nowait'

        mobile_number = mobile_gateway = ''
        if agent.sip_device_ids:
            for dev in agent.sip_device_ids.filtered(lambda d: d.active).sorted('sequence'):
                mn = getattr(dev, 'mobile_number', '')
                if mn:
                    mobile_number  = mn
                    mobile_gateway = getattr(dev, 'mobile_gateway', '') or gateway
                    break
        if not mobile_number and agent.cc_agent_id and agent.cc_agent_id.sip_user_id:
            for dev in agent.cc_agent_id.sip_user_id.device_ids.filtered(
                    lambda d: d.active).sorted('sequence'):
                mn = getattr(dev, 'mobile_number', '')
                if mn:
                    mobile_number  = mn
                    mobile_gateway = getattr(dev, 'mobile_gateway', '') or gateway
                    break

        is_pstn = bool(mobile_number)
        simo    = 1 if is_pstn else (agent.simo or 1)
        lag     = agent.lag or 0

        if is_pstn:
            contact = 'sofia/gateway/%s/%s' % (mobile_gateway or gateway, mobile_number)
        elif agent.contact:
            contact = agent.contact
        elif agent.extension:
            contact = 'user/%s@%s' % (agent.extension, domain)
        else:
            return None, simo, lag

        chan_vars = {'call_timeout': str(call_timeout), 'fifo_member_wait': member_wait}
        if is_pstn:
            chan_vars['ignore_early_media'] = 'true'
        if agent.group_confirm_key:
            chan_vars['group_confirm_key']          = agent.group_confirm_key
            cf = ''
            if agent.group_confirm_file:
                cf = agent.group_confirm_file.fs_path or (
                    '/etc/freeswitch/sounds/%s' % agent.group_confirm_file.audio_fname
                    if agent.group_confirm_file.audio_fname else '')
            chan_vars['group_confirm_file']          = cf or 'tone_stream://%(1000,0,440)'
            chan_vars['group_confirm_read_timeout']  = '5000'

        vars_str = ','.join('%s=%s' % kv for kv in chan_vars.items())
        return '{%s}%s' % (vars_str, contact), simo, lag

    def _sync_members_to_fs(self):
        for rec in self:
            try:
                rec._fs_api_call('POST', '/fifo/sync_members', data={'fifo_name': rec.name})
            except Exception as e:
                _logger.warning('FIFO sync_members FAILED: %s — %s', rec.name, e)


class FreeSwitchFIFOAgent(models.Model):
    _name        = 'freeswitch.fifo.agent'
    _description = 'FreeSWITCH — Agent kolejki FIFO'
    _order       = 'sequence, extension'

    fifo_id  = fields.Many2one('freeswitch.fifo', string='Kolejka FIFO',
                                ondelete='cascade', required=True)
    sequence = fields.Integer('Kolejność', default=10,
                               help='Kolejność w strategii Progressive: '
                                    'agent z sequence=10 dzwoni pierwszy, '
                                    'sequence=20 dołącza po ring_progressive_sec sekundach itd.')

    cc_agent_id = fields.Many2one(
        'freeswitch.cc.agent', string='Agent CC',
        domain=[('active', '=', True)], ondelete='set null',
    )
    cc_agent_sip_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik SIP agenta',
        related='cc_agent_id.sip_user_id', store=False, readonly=True,
    )
    sip_device_ids = fields.Many2many(
        'freeswitch.sip.device', 'fifo_agent_sip_device_rel', 'fifo_agent_id', 'device_id',
        string='Urządzenia agenta',
        domain="[('user_id', '=', cc_agent_sip_user_id), ('active', '=', True)]",
    )

    extension    = fields.Char('Numer wewnętrzny', required=True)
    contact      = fields.Char('Kontakt SIP', required=True)
    call_timeout = fields.Integer(
        'Timeout dzwonienia (s)', default=30,
        help='Ile sekund dzwonić do tego agenta zanim uzna się go za niedostępnego. '
             'Każdy agent może mieć inny timeout.',
    )

    # ── Parametry dzwonienia ──────────────────────────────────────────────────
    simo = fields.Integer(
        'Równoległe dzwonienia (simo)', default=1,
        help='Ile jednoczesnych połączeń — przydatne gdy agent ma wiele urządzeń SIP.\n'
             'Dla PSTN zawsze 1 (operator blokuje wielokrotne wywołania).',
    )
    lag = fields.Integer(
        'Czas wrapup (s)', default=0,
        help='Ile sekund odczekać po zakończeniu rozmowy przed przyjęciem kolejnej.',
    )
    member_wait = fields.Selection(
        [('nowait', 'nowait — rozłącz po odebraniu przez innego'),
         ('wait',   'wait — czekaj na kolejnego dzwoniącego')],
        string='Tryb agenta', default='nowait',
    )
    pop_order = fields.Char('Priorytety slotów', default='', placeholder='1,2')

    # ── Potwierdzenie odebrania (dla PSTN z pocztą głosową) ──────────────────
    group_confirm_file = fields.Many2one(
        'freeswitch.sound', string='Plik potwierdzenia', ondelete='set null',
        help='Grany agentowi po odebraniu — agent musi nacisnąć klawisz aby połączyć.\n'
             'Puste = sygnał 440Hz.',
    )
    group_confirm_key = fields.Char(
        'Klawisz potwierdzenia', default='1',
        help='DTMF który agent naciska po odebraniu (domyślnie "1").\n'
             'Puste = brak potwierdzenia (nie zalecane dla PSTN).',
    )

    # ── Wrapup ────────────────────────────────────────────────────────────────
    wrapup_sound_id = fields.Many2one('freeswitch.sound', string='Dźwięk wrapup', ondelete='set null')
    wrapup_key      = fields.Char('Klawisz zakończenia wrapup', default='')

    active = fields.Boolean('Aktywny', default=True)

    # ── Strategia FIFO — rotacja agentów ─────────────────────────────────────
    # Zapisywane przez action_fifo.lua po każdym odebranym połączeniu.
    # Lua sortuje agentów: ORDER BY last_answered_at ASC NULLS FIRST, sequence ASC
    # → agent który dawniej rozmawiał (lub nigdy) dzwoni pierwszy.
    last_answered_at = fields.Datetime(
        'Ostatnie odebranie',
        readonly=True,
        index=True,
        help=(
            'Kiedy ten agent ostatnio odebrał połączenie z tej kolejki.\n'
            'Aktualizowane automatycznie przez Lua (action_fifo.lua) po każdej rozmowie.\n'
            'Używane do rotacji FIFO: agent który dawniej rozmawiał (lub nigdy)\n'
            'trafia na początek kolejki dzwonienia przy następnym połączeniu.'
        ),
    )

    # ── Automatyczna synchronizacja po zapisaniu ──────────────────────────────

    def write(self, vals):
        res = super().write(vals)
        self.mapped('fifo_id')._sync_members_to_fs()
        return res

    @api.model_create_multi
    def create(self, vals_list):
        recs = super().create(vals_list)
        recs.mapped('fifo_id')._sync_members_to_fs()
        return recs

    def unlink(self):
        fifos = self.mapped('fifo_id')
        res   = super().unlink()
        fifos._sync_members_to_fs()
        return res

    # ── Onchange ──────────────────────────────────────────────────────────────

    @api.onchange('cc_agent_id')
    def _onchange_cc_agent_id(self):
        if not self.cc_agent_id:
            return
        self.extension    = self.cc_agent_id.extension    or ''
        self.call_timeout = self.cc_agent_id.call_timeout or 30
        devices = self.cc_agent_id.sip_device_ids.filtered(lambda d: d.active)
        self.sip_device_ids = [(6, 0, devices.ids)] if devices else False
        self._recompute_contact()

    @api.onchange('sip_device_ids')
    def _onchange_sip_device_ids(self):
        self._recompute_contact()

    @api.onchange('extension')
    def _onchange_extension(self):
        if self.extension and not self.cc_agent_id:
            domain = self.env['ir.config_parameter'].sudo().get_param(
                'freeswitch.sip_domain', 'sip.example.pl')
            self.contact = f'sofia/internal/{self.extension}@{domain}'

    def _recompute_contact(self):
        for rec in self:
            if not rec.cc_agent_id:
                continue
            if rec.sip_device_ids:
                devices = rec.sip_device_ids.filtered(lambda d: d.active).sorted('sequence')
                contact = rec.cc_agent_id._build_contact_from_devices(devices)
                rec.contact = contact or rec.cc_agent_id.contact or ''
            else:
                rec.contact = rec.cc_agent_id.contact or ''
            rec.extension = rec.cc_agent_id.extension or rec.extension