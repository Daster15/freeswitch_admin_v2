# -*- coding: utf-8 -*-
"""
callcenter_agent.py
===================
Modele agenta i tieru CallCenter.

Źródło prawdy = baza FreeSWITCH (tabele: agents, tiers).
Odoo zapisuje bezpośrednio do tych tabel przez _fs_cursor (freeswitch.db.mixin).
FreeSWITCH czyta konfigurację z bazy — zero xml_curl, zero provisioning w Lua.
"""
import logging
from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)

AGENT_STATUS = [
    ('Available',             'Dostępny'),
    ('Available (On Demand)', 'Dostępny na żądanie'),
    ('On Break',              'Przerwa'),
    ('Logged Out',            'Wylogowany'),
]

AGENT_STATE = [
    ('Waiting',   'Oczekuje'),
    ('Receiving', 'Odbiera'),
    ('Idle',      'Bezczynny'),
]



class FreeSwitchCCAgent(models.Model):
    _name        = 'freeswitch.cc.agent'
    _description = 'FreeSWITCH — Agent CallCenter'
    _inherit     = ['mail.thread', 'mail.activity.mixin', 'freeswitch.db.mixin',
                    'freeswitch.multicompany.mixin']
    _order       = 'name'

    company_id = fields.Many2one(
        'res.company', string='Firma', required=True, index=True,
        default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('name_company_unique', 'UNIQUE(name, company_id)',
         'Nazwa agenta musi być unikalna w ramach firmy!'),
    ]

    # ── Identyfikacja ────────────────────────────────────────────────────────
    name               = fields.Char('Nazwa agenta (klucz)', required=True, tracking=True,
                                      help='Klucz unikalny w mod_callcenter, np. agent-kowalska-anna')
    display_name_field = fields.Char('Imię i nazwisko')

    # ── Parametry mod_callcenter ─────────────────────────────────────────────
    agent_type           = fields.Selection(
        [('callback', 'Callback'), ('uuid-standby', 'UUID Standby')],
        string='Typ', default='callback', required=True,
    )
    call_timeout         = fields.Integer('Timeout połączenia (s)', default=20)
    wrap_up_time         = fields.Integer('Czas wrap-up (s)', default=0,
                                           help='Czas niedostępności po zakończeniu rozmowy.')
    max_no_answer        = fields.Integer('Maks. nieodebranych z rzędu', default=0,
                                           help='0 = bez limitu.')
    reject_delay_time    = fields.Integer('Opóźnienie po odrzuceniu (s)', default=0)
    busy_delay_time      = fields.Integer('Opóźnienie gdy zajęty (s)', default=0)
    no_answer_delay_time = fields.Integer('Opóźnienie po braku odpowiedzi (s)', default=0)

    # ── Powiązanie z SIP ─────────────────────────────────────────────────────
    sip_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Użytkownik SIP',
        ondelete='set null', tracking=True,
    )
    sip_device_ids = fields.Many2many(
        'freeswitch.sip.device',
        'cc_agent_sip_device_rel', 'agent_id', 'device_id',
        string='Urządzenia agenta',
        domain="[('user_id', '=', sip_user_id), ('active', '=', True)]",
    )
    extension = fields.Char('Numer wewnętrzny', required=True, tracking=True)
    contact   = fields.Char('Kontakt SIP', required=True)

    # ── Status / stan (Odoo = źródło prawdy dla statusów) ───────────────────
    status = fields.Selection(AGENT_STATUS, string='Status',
                               default='Logged Out', tracking=True)
    state  = fields.Selection(AGENT_STATE,  string='Stan',
                               default='Waiting', readonly=True)
    active = fields.Boolean('Aktywny', default=True, tracking=True)

    # ── Relacje ──────────────────────────────────────────────────────────────
    tier_ids    = fields.One2many('freeswitch.cc.tier', 'agent_id', string='Przypisania do kolejek')
    queue_count = fields.Integer('Kolejki', compute='_compute_queue_count')

    @api.depends('tier_ids')
    def _compute_queue_count(self):
        for rec in self:
            rec.queue_count = len(rec.tier_ids)

    # ── SIP helpers ──────────────────────────────────────────────────────────

    def _get_sip_domain(self):
        return self.env['ir.config_parameter'].sudo().get_param(
            'freeswitch.sip_domain', 'sip.example.pl'
        )

    def _build_contact_from_devices(self, devices):
        domain = self._get_sip_domain()

        def leg(dev):
            ext = dev.user_id.name
            if dev.device_type == 'mobile':
                gw  = dev.mobile_gateway or 'default'
                num = dev.mobile_number or ext
                return f'sofia/gateway/{gw}/{num}'
            sip_ext = dev.linked_user_id.name if dev.linked_user_id else ext
            return f'user/{sip_ext}'

        exclusive = devices.filtered(lambda d: d.ring_strategy == 'exclusive')[:1]
        if exclusive:
            return leg(exclusive)
        legs = [leg(d) for d in devices]
        if not legs:
            return ''
        sep = ':' if (devices[0].ring_strategy or 'simultaneous') == 'simultaneous' else '|'
        return sep.join(legs)

    def _recompute_contact(self):
        """Przelicz contact z urządzeń (UI onchange)."""
        if not self.sip_user_id:
            return
        self.extension = self.sip_user_id.name
        devices = self.sip_device_ids.filtered(lambda d: d.active).sorted('sequence')
        self.contact = (
            self._build_contact_from_devices(devices)
            or f'user/{self.extension}'
        )

    def _get_fs_contact(self):
        """
        Zwróć contact string do zapisu w tabeli agents FS.

        Logika wyboru kontaktu (w kolejności priorytetu):
        1. Urządzenia przypisane do agenta (cc_agent_sip_device_rel)
           - jeśli urządzenie ma mobile_number → sofia/gateway/GW/NUMER (PSTN)
           - jeśli device_type == 'mobile'     → sofia/gateway/GW/NUMER (PSTN)
           - w przeciwnym razie               → user/EXT (SIP)
        2. Fallback: pole contact agenta
        3. Ostateczny fallback: user/EXTENSION
        """
        self.ensure_one()
        domain = self._get_sip_domain()

        _logger.info('CC agent %s: _get_fs_contact  sip_user_id=%s  sip_device_ids=%s  contact=%s',
                     self.name, self.sip_user_id.id if self.sip_user_id else None,
                     self.sip_device_ids.ids, self.contact)

        # Pobierz urządzenia przypisane jawnie do agenta (cc_agent_sip_device_rel)
        devices = self.env['freeswitch.sip.device'].search([
            ('id', 'in', self.sip_device_ids.ids),
            ('active', '=', True),
        ], order='sequence')

        _logger.info('CC agent %s: jawne urządzenia=%d', self.name, len(devices))

        if not devices and self.sip_user_id:
            # Brak jawnie wybranych — weź WSZYSTKIE aktywne urządzenia użytkownika SIP
            devices = self.env['freeswitch.sip.device'].search([
                ('user_id', '=', self.sip_user_id.id),
                ('active', '=', True),
            ], order='sequence')
            _logger.info('CC agent %s: urządzenia z sip_user_id=%s: %d (typy: %s)',
                         self.name, self.sip_user_id.name, len(devices),
                         [(d.device_type, d.mobile_number or '-') for d in devices])

        if devices:
            # Jeśli jest urządzenie PSTN (mobile lub z mobile_number) — użyj go jako pierwsze
            # Agenci CC zazwyczaj mają jedno urządzenie; przy wielu budujemy dial string
            pstn_devices = devices.filtered(
                lambda d: d.device_type == 'mobile' or bool(d.mobile_number and d.mobile_number.strip())
            )
            sip_devices = devices - pstn_devices

            _logger.info('CC agent %s: PSTN=%d SIP=%d urządzeń',
                         self.name, len(pstn_devices), len(sip_devices))

            legs = []
            # PSTN najpierw
            for dev in pstn_devices:
                gw  = dev.mobile_gateway or self._get_fs_config().gateway or 'default'
                num = dev.mobile_number.strip()
                legs.append(f'sofia/gateway/{gw}/{num}')
                _logger.info('CC agent %s: PSTN leg gw=%s num=%s', self.name, gw, num)

            # SIP jeśli nie ma PSTN (lub mixed strategy)
            if not pstn_devices:
                for dev in sip_devices:
                    ext = dev.linked_user_id.name if dev.linked_user_id else (
                        dev.user_id.name if dev.user_id else self.extension)
                    sip_dom = dev.sip_domain or domain
                    legs.append(f'user/{ext}')
                    _logger.info('CC agent %s: SIP leg user/%s', self.name, ext)

            if legs:
                if len(legs) == 1:
                    return legs[0]
                sep = ':' if (devices[0].ring_strategy or 'simultaneous') == 'simultaneous' else '|'
                return sep.join(legs)

        # Fallback 1: pole contact agenta (ustawione ręcznie lub przez onchange)
        if self.contact and self.contact.strip():
            _logger.info('CC agent %s: fallback contact=%s', self.name, self.contact)
            return self.contact

        # Fallback 2: SIP z numerem wewnętrznym
        ext = self.extension or self.name
        _logger.info('CC agent %s: fallback SIP user/%s', self.name, ext)
        return f'user/{ext}'

    @api.onchange('sip_user_id')
    def _onchange_sip_user_id(self):
        self.sip_device_ids = [(5, 0, 0)]
        if not self.sip_user_id:
            return
        if not self.display_name_field:
            self.display_name_field = self.sip_user_id.display_name_full
        if not self.name:
            self.name = f'agent-{self.sip_user_id.name}'
        devices = self.sip_user_id.device_ids.filtered(lambda d: d.active)
        self.sip_device_ids = [(6, 0, devices.ids)]
        self._recompute_contact()

    @api.onchange('sip_device_ids')
    def _onchange_sip_device_ids(self):
        self._recompute_contact()

    @api.onchange('extension')
    def _onchange_extension(self):
        if self.extension and not self.sip_user_id:
            self.contact = f'user/{self.extension}'
            if not self.name:
                self.name = f'agent-{self.extension}'

    # ── Zapis do bazy FreeSWITCH ─────────────────────────────────────────────

    def _fs_agent_upsert(self):
        """
        Upsert agenta w tabeli `agents` bazy FreeSWITCH.
        Schemat: brak PK, unikalność po name.
        Używamy CTE (WITH) żeby UPDATE+INSERT działały w jednym zapytaniu/połączeniu.
        Kolumny runtime (last_bridge_*, calls_answered itp.) zarządza wyłącznie mod_callcenter.
        """
        for rec in self:
            fs_contact = rec._get_fs_contact()
            _logger.info('CC agent upsert FS: %s  contact=%s', rec.name, fs_contact)
            params = {
                'name':                 rec.name,
                'type':                 rec.agent_type,
                'contact':              fs_contact,
                'status':               rec.status or 'Logged Out',
                'max_no_answer':        rec.max_no_answer or 0,
                'wrap_up_time':         rec.wrap_up_time or 0,
                'reject_delay_time':    rec.reject_delay_time or 0,
                'busy_delay_time':      rec.busy_delay_time or 0,
                'no_answer_delay_time': rec.no_answer_delay_time or 0,
            }
            rec._fs_execute("""
                WITH upd AS (
                    UPDATE agents SET
                        type                 = %(type)s,
                        contact              = %(contact)s,
                        status               = %(status)s,
                        state                = 'Waiting',
                        max_no_answer        = %(max_no_answer)s,
                        wrap_up_time         = %(wrap_up_time)s,
                        reject_delay_time    = %(reject_delay_time)s,
                        busy_delay_time      = %(busy_delay_time)s,
                        no_answer_delay_time = %(no_answer_delay_time)s
                    WHERE name = %(name)s
                    RETURNING name
                )
                INSERT INTO agents (name, type, contact, status, state,
                    max_no_answer, wrap_up_time,
                    reject_delay_time, busy_delay_time, no_answer_delay_time)
                SELECT %(name)s, %(type)s, %(contact)s, %(status)s, 'Waiting',
                    %(max_no_answer)s, %(wrap_up_time)s,
                    %(reject_delay_time)s, %(busy_delay_time)s, %(no_answer_delay_time)s
                WHERE NOT EXISTS (SELECT 1 FROM upd)
            """, params)
            _logger.debug('CC agent upsert FS: %s (%s)', rec.name, rec.status)
            rec._fs_esl_reload_agent()

    def _fs_esl_reload_agent(self):
        """Powiadom mod_callcenter o zmianie agenta przez fs_cli."""
        import subprocess
        for cmd in [f'callcenter_config load agent {self.name}']:
            try:
                r = subprocess.run(['fs_cli', '-x', cmd],
                                   capture_output=True, text=True, timeout=5)
                _logger.info('CC agent fs_cli [%s] → %s', cmd, (r.stdout or '').strip()[:80])
                break
            except FileNotFoundError:
                break
            except Exception as e:
                _logger.debug('CC agent fs_cli błąd: %s', e)

    def _fs_agent_delete(self):
        """Usuń agenta z tabeli `agents` FreeSWITCH."""
        for rec in self:
            rec._fs_execute(
                "DELETE FROM agents WHERE name = %(name)s",
                {'name': rec.name},
            )
            _logger.debug('CC agent delete FS: %s', rec.name)

    # ── ORM hooks ────────────────────────────────────────────────────────────

    _FS_AGENT_FIELDS = {
        'name', 'agent_type', 'contact', 'extension',
        'status', 'wrap_up_time', 'max_no_answer',
        'reject_delay_time', 'busy_delay_time', 'no_answer_delay_time',
        'active',
    }

    def write(self, vals):
        res = super().write(vals)
        # Konfiguracja agenta jest serwowana przez xml_curl (main.py).
        # Przy zmianie statusu reload kolejek które agent obsługuje
        # żeby mod_callcenter pobrał nowy status przez xml_curl.
        if self._FS_AGENT_FIELDS & set(vals.keys()):
            try:
                self._fs_reload_queues_for_agents()
            except Exception as e:
                _logger.warning('CC agent reload błąd (niekrytyczny): %s', e)
        return res

    def create(self, vals_list):
        recs = super().create(vals_list)
        try:
            recs._fs_reload_queues_for_agents()
        except Exception as e:
            _logger.warning('CC agent create reload błąd (niekrytyczny): %s', e)
        return recs

    def unlink(self):
        try:
            self._fs_reload_queues_for_agents()
        except Exception as e:
            _logger.warning('CC agent unlink reload błąd (niekrytyczny): %s', e)
        return super().unlink()

    def _fs_reload_queues_for_agents(self):
        """Przeładuj kolejki powiązane z agentami przez fs_cli."""
        import subprocess
        queue_names = set()
        for rec in self:
            for tier in rec.tier_ids:
                if tier.queue_id and tier.queue_id.active:
                    qname = tier.queue_id._fs_queue_name()
                    queue_names.add(qname)
        if not queue_names:
            return
        for qname in queue_names:
            try:
                r = subprocess.run(
                    ['fs_cli', '-x', f'callcenter_config queue reload {qname}'],
                    capture_output=True, text=True, timeout=5,
                )
                _logger.info('CC agent reload queue %s → %s', qname,
                             (r.stdout or '').strip()[:80])
            except FileNotFoundError:
                break
            except Exception as e:
                _logger.debug('CC agent fs_cli błąd: %s', e)

    # ── Akcje statusu ────────────────────────────────────────────────────────

    def _change_status(self, new_status):
        for rec in self:
            _logger.info('CC agent %s: status %s → %s', rec.name, rec.status, new_status)
        # write() wywoła _fs_reload_queues_for_agents → xml_curl pobierze nowy status
        self.write({'status': new_status})

    def action_set_available(self):
        self._change_status('Available')

    def action_set_on_break(self):
        self._change_status('On Break')

    def action_set_logged_out(self):
        self._change_status('Logged Out')

    # ── Sync FS → Odoo (stany runtime) ──────────────────────────────────────

    def action_sync_from_fs(self):
        """Odczytaj aktualne status/state z tabeli agents w FS i zaktualizuj Odoo."""
        updated = 0
        for rec in self:
            try:
                rows = rec._fs_query(
                    "SELECT status, state FROM agents WHERE name = %(name)s",
                    {'name': rec.name},
                )
                if not rows:
                    continue
                row  = rows[0]
                vals = {}
                fs_status = row.get('status')
                fs_state  = row.get('state')
                if fs_status and fs_status != rec.status:
                    vals['status'] = fs_status
                if fs_state and fs_state != rec.state:
                    vals['state'] = fs_state
                if vals:
                    # Pomiń hook FS (dane idą z FS, nie do FS)
                    super(FreeSwitchCCAgent, rec).write(vals)
                    updated += 1
            except Exception as e:
                _logger.warning('CC agent sync_from_fs błąd dla %s: %s', rec.name, e)
        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title':   _('Sync z FreeSWITCH'),
                'message': _('Zaktualizowano %d agentów.') % updated,
                'type':    'success',
            }
        }

    def action_push_to_fs(self):
        """Ręczny reload kolejek powiązanych z agentem (xml_curl pobierze aktualną konfigurację)."""
        try:
            self._fs_reload_queues_for_agents()
        except Exception as e:
            _logger.warning('CC agent push reload błąd: %s', e)
        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title':   _('Agent CC'),
                'message': _('Kolejki agenta przeładowane — FreeSWITCH pobierze aktualną konfigurację ✓'),
                'type':    'success',
            }
        }


class FreeSwitchCCTier(models.Model):
    """Powiązanie agent ↔ kolejka z poziomem priorytetu.
    Każda zmiana → natychmiastowy UPSERT/DELETE w tabeli `tiers` bazy FS.
    """
    _name        = 'freeswitch.cc.tier'
    _description = 'FreeSWITCH — Tier agenta w kolejce CC'
    _inherit     = ['freeswitch.db.mixin']
    _order       = 'queue_id, level, position'

    queue_id = fields.Many2one('freeswitch.cc.queue', string='Kolejka',
                                required=True, ondelete='cascade')
    agent_id = fields.Many2one('freeswitch.cc.agent', string='Agent',
                                required=True, ondelete='cascade')
    level    = fields.Integer('Poziom (tier)', default=1,
                               help='1 = najwyższy priorytet. Agenci z niższym numerem obsługiwani pierwsi.')
    position = fields.Integer('Pozycja', default=1,
                               help='Kolejność w ramach tego samego poziomu.')

    _sql_constraints = [
        ('unique_queue_agent', 'UNIQUE(queue_id, agent_id)',
         'Agent może być przypisany do kolejki tylko raz.')
    ]

    # ── Zapis do bazy FreeSWITCH ─────────────────────────────────────────────

    def _fs_tier_upsert(self):
        for rec in self:
            if not rec.queue_id.name or not rec.agent_id.name:
                continue

            # Najpierw upewnij się że agent istnieje w tabeli agents
            # (tier wymaga że agent jest w agents — mod_callcenter)
            try:
                rec.agent_id._fs_agent_upsert()
            except Exception as e:
                _logger.warning('CC tier: agent upsert błąd dla %s: %s',
                                rec.agent_id.name, e)

            # Klucz kolejki w FS = name@sip_domain
            fs_queue = rec.queue_id._fs_queue_name()
            params = {
                'queue':    fs_queue,
                'agent':    rec.agent_id.name,
                'level':    rec.level or 1,
                'position': rec.position or 1,
            }
            rec._fs_execute("""
                WITH upd AS (
                    UPDATE tiers SET
                        level    = %(level)s,
                        position = %(position)s,
                        state    = 'Ready'
                    WHERE queue = %(queue)s AND agent = %(agent)s
                    RETURNING queue
                )
                INSERT INTO tiers (queue, agent, level, position, state)
                SELECT %(queue)s, %(agent)s, %(level)s, %(position)s, 'Ready'
                WHERE NOT EXISTS (SELECT 1 FROM upd)
            """, params)
            _logger.info('CC tier upsert FS: %s → %s (lvl=%d pos=%d)',
                         rec.agent_id.name, fs_queue, rec.level, rec.position)
            import subprocess
            for cmd in [f'callcenter_config load tier {fs_queue} {rec.agent_id.name}']:
                try:
                    r = subprocess.run(['fs_cli', '-x', cmd],
                                       capture_output=True, text=True, timeout=5)
                    _logger.info('CC tier fs_cli [%s] → %s', cmd, (r.stdout or '').strip()[:80])
                    break
                except FileNotFoundError:
                    break
                except Exception as e:
                    _logger.debug('CC tier fs_cli błąd: %s', e)

    def _fs_tier_delete(self):
        for rec in self:
            if not rec.queue_id.name or not rec.agent_id.name:
                continue
            fs_queue = rec.queue_id._fs_queue_name()
            rec._fs_execute(
                "DELETE FROM tiers WHERE queue = %(queue)s AND agent = %(agent)s",
                {'queue': fs_queue, 'agent': rec.agent_id.name},
            )
            _logger.info('CC tier delete FS: %s → %s', rec.agent_id.name, fs_queue)

    # ── ORM hooks ────────────────────────────────────────────────────────────

    def write(self, vals):
        res = super().write(vals)
        if {'level', 'position', 'queue_id', 'agent_id'} & set(vals.keys()):
            try:
                self._fs_reload_queue()
            except Exception as e:
                _logger.warning('CC tier reload błąd (niekrytyczny): %s', e)
        return res

    def create(self, vals_list):
        recs = super().create(vals_list)
        try:
            recs._fs_reload_queue()
        except Exception as e:
            _logger.warning('CC tier create reload błąd (niekrytyczny): %s', e)
        return recs

    def unlink(self):
        try:
            self._fs_reload_queue()
        except Exception as e:
            _logger.warning('CC tier unlink reload błąd (niekrytyczny): %s', e)
        return super().unlink()

    def _fs_reload_queue(self):
        """Przeładuj kolejkę przez fs_cli — xml_curl pobierze aktualną konfigurację."""
        import subprocess
        for rec in self:
            if not rec.queue_id or not rec.queue_id.active:
                continue
            qname = rec.queue_id._fs_queue_name()
            try:
                r = subprocess.run(
                    ['fs_cli', '-x', f'callcenter_config queue reload {qname}'],
                    capture_output=True, text=True, timeout=5,
                )
                _logger.info('CC tier reload queue %s → %s', qname,
                             (r.stdout or '').strip()[:80])
            except FileNotFoundError:
                break
            except Exception as e:
                _logger.debug('CC tier fs_cli błąd: %s', e)