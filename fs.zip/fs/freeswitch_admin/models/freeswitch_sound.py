# -*- coding: utf-8 -*-
import base64
import io
import logging
import os
import re
import subprocess
import tempfile

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

SOUND_CATEGORIES = [
    ('greeting',    'Powitanie'),
    ('ivr',         'Komunikat IVR'),
    ('hold',        'Muzyka oczekiwania'),
    ('queue',       'Ogłoszenie kolejki'),
    ('voicemail',   'Poczta głosowa'),
    ('playback',    'Odtwarzanie (Flow)'),
    ('other',       'Inne'),
]

AFTER_ACTIONS = [
    ('hangup',      'Rozłącz połączenie'),
    ('ivr',         'Przejdź do menu IVR'),
    ('callcenter',  'Przejdź do kolejki CallCenter'),
    ('user',        'Przekaż do użytkownika SIP'),
    ('pstn',        'Przekaż na numer zewnętrzny'),
    ('repeat',      'Powtórz nagranie'),
]

# ElevenLabs — modele syntezatora
ELEVENLABS_MODELS = [
    ('eleven_multilingual_v2',  'Multilingual v2 (najlepsza jakość, PL)'),
    ('eleven_turbo_v2_5',       'Turbo v2.5 (szybki, tani)'),
    ('eleven_turbo_v2',         'Turbo v2'),
    ('eleven_monolingual_v1',   'Monolingual v1 (tylko EN)'),
]


class FreeSwitchSound(models.Model):
    _name        = 'freeswitch.sound'
    _description = 'FreeSWITCH — Biblioteka dźwięków'
    _inherit     = ['mail.thread', 'mail.activity.mixin', 'freeswitch.multicompany.mixin']
    _order       = 'category, name'
    _rec_name    = 'name'

    # ── Multi-company ────────────────────────────────────────────────────
    company_id = fields.Many2one(
        'res.company',
        string='Firma',
        required=True,
        index=True,
        default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('name_company_unique', 'UNIQUE(name, company_id)',
         'Dźwięk o tej nazwie już istnieje w ramach tej firmy!'),
    ]

    # ── Podstawowe ───────────────────────────────────────────────────────
    name        = fields.Char('Nazwa', required=True, tracking=True)
    description = fields.Char('Opis')
    category    = fields.Selection(SOUND_CATEGORIES, string='Kategoria',
                                   default='ivr', required=True)
    active      = fields.Boolean('Aktywny', default=True, tracking=True)

    # ── Plik audio ───────────────────────────────────────────────────────
    audio_data  = fields.Binary('Plik audio', attachment=True)
    audio_fname = fields.Char('Nazwa pliku', default='sound.mp3')
    audio_mime  = fields.Char('Typ MIME', compute='_compute_mime', store=True)

    # Ścieżka na serwerze FreeSWITCH
    fs_path = fields.Char(
        'Ścieżka na serwerze FS', tracking=True,
        help='Ścieżka do pliku na serwerze FreeSWITCH, '
             'np. /etc/freeswitch/sounds/pl/powitanie.mp3',
    )

    # ── Player HTML (computed) ───────────────────────────────────────────
    audio_player = fields.Html('Player', compute='_compute_audio_player',
                               sanitize=False, store=False)

    # ── TTS — ElevenLabs ─────────────────────────────────────────────────
    tts_text    = fields.Text('Tekst do syntezowania')
    tts_status  = fields.Char('Status', readonly=True)

    el_voice_id   = fields.Char(
        'Voice ID',
        help='ID głosu z ElevenLabs. Kliknij "Pobierz listę głosów" aby wybrać.',
    )
    el_voice_name = fields.Char('Nazwa głosu', readonly=True)
    el_model_id   = fields.Selection(
        ELEVENLABS_MODELS, string='Model',
        default='eleven_multilingual_v2',
    )
    el_stability        = fields.Float('Stabilność',    default=0.5,
                                       help='0.0 – 1.0. Wyżej = bardziej stabilny, monotonny.')
    el_similarity_boost = fields.Float('Podobieństwo',  default=0.75,
                                       help='0.0 – 1.0. Wyżej = bliżej oryginału głosu.')
    el_style            = fields.Float('Ekspresja',     default=0.0,
                                       help='0.0 – 1.0. Wyżej = więcej ekspresji (tylko v2).')
    el_use_speaker_boost = fields.Boolean('Speaker Boost', default=True)

    # Dostępne głosy (JSON — ładowane przyciskiem)
    el_voices_html = fields.Html('Dostępne głosy', compute='_compute_el_voices_html',
                                 sanitize=False, store=False)

    # ── Statystyki ───────────────────────────────────────────────────────
    ivr_use_count = fields.Integer('Użyć w IVR', compute='_compute_ivr_use_count')

    # ── Akcja po odtworzeniu (dla kategorii 'playback') ──────────────────
    after_action  = fields.Selection(
        AFTER_ACTIONS, string='Akcja po odtworzeniu', default='hangup',
    )
    after_ivr_id  = fields.Many2one(
        'freeswitch.ivr', string='Docelowe menu IVR', ondelete='set null',
    )
    after_fifo_id = fields.Many2one(
        'freeswitch.fifo', string='Docelowa kolejka FIFO', ondelete='set null',
    )
    after_cc_id   = fields.Many2one(
        'freeswitch.cc.queue', string='Docelowa kolejka CC', ondelete='set null',
    )
    after_user_id = fields.Many2one(
        'freeswitch.sip.user', string='Docelowy użytkownik SIP', ondelete='set null',
    )
    after_pstn    = fields.Char('Numer zewnętrzny PSTN')
    after_target  = fields.Char(
        'Cel akcji', compute='_compute_after_target', store=True,
    )

    # ─────────────────────────────────────────────────────────────────────
    # COMPUTED
    # ─────────────────────────────────────────────────────────────────────
    @api.depends('audio_fname')
    def _compute_mime(self):
        for rec in self:
            fname = (rec.audio_fname or '').lower()
            if fname.endswith('.mp3'):
                rec.audio_mime = 'audio/mpeg'
            elif fname.endswith('.ogg'):
                rec.audio_mime = 'audio/ogg'
            else:
                rec.audio_mime = 'audio/wav'

    @api.depends('audio_data', 'audio_fname', 'audio_mime')
    def _compute_audio_player(self):
        for rec in self:
            if not rec.audio_data or not rec.id:
                rec.audio_player = (
                    '<div style="margin:4px 0 6px;padding:5px 10px;background:#f8f9fc;'
                    'border-radius:6px;border:1px dashed #d1d5db;color:#9ca3af;'
                    'font-size:12px;">🎵 Brak pliku audio</div>'
                )
                continue
            url = (
                f'/web/content?model=freeswitch.sound&id={rec.id}'
                f'&field=audio_data&filename={rec.audio_fname or "audio.mp3"}&download=false'
            )
            rec.audio_player = (
                f'<div style="margin:4px 0 6px;padding:6px 10px;background:#eff6ff;'
                f'border-radius:6px;border:1px solid #bfdbfe;display:flex;'
                f'align-items:center;gap:8px;min-width:0;">'
                f'<span style="font-size:13px;flex-shrink:0;">🎵</span>'
                f'<audio controls style="flex:1;min-width:0;height:28px;outline:none;">'
                f'<source src="{url}" type="{rec.audio_mime or "audio/mpeg"}"/>'
                f'</audio>'
                f'</div>'
            )

    def _compute_el_voices_html(self):
        """Wyświetl listę głosów załadowanych przez action_fetch_voices."""
        for rec in self:
            company_id = rec.company_id.id or self.env.company.id
            ICP = self.env['ir.config_parameter'].sudo()
            voices_json = ICP.get_param(
                f'freeswitch.el_voices_cache.{company_id}', ''
            ) or ICP.get_param('freeswitch.el_voices_cache', '')
            if not voices_json:
                rec.el_voices_html = (
                    '<div style="color:#9ca3af;font-size:12px;padding:8px;">'
                    'Kliknij <strong>Pobierz głosy</strong> aby załadować listę z ElevenLabs.</div>'
                )
                continue
            try:
                import json
                voices = json.loads(voices_json)
            except Exception:
                rec.el_voices_html = '<div style="color:#ef4444;">Błąd parsowania listy głosów.</div>'
                continue

            rows = ''
            for v in voices:
                selected = '✓ ' if v.get('voice_id') == rec.el_voice_id else ''
                rows += (
                    f'<tr style="cursor:pointer;" '
                    f'onclick="document.querySelector(\'[name=el_voice_id] input\').value=\'{v["voice_id"]}\'">'
                    f'<td style="padding:5px 10px;font-size:12px;color:#1e40af;font-weight:600;">{selected}</td>'
                    f'<td style="padding:5px 10px;font-size:13px;">{v.get("name","")}</td>'
                    f'<td style="padding:5px 10px;font-size:11px;color:#6b7280;">{v.get("category","")}</td>'
                    f'<td style="padding:5px 10px;font-size:11px;color:#9ca3af;font-family:monospace;">{v.get("voice_id","")}</td>'
                    f'</tr>'
                )
            rec.el_voices_html = f'''
<div style="max-height:240px;overflow-y:auto;border:1px solid #e5e7eb;border-radius:8px;">
  <table style="width:100%;border-collapse:collapse;">
    <thead>
      <tr style="background:#eff6ff;position:sticky;top:0;">
        <th style="padding:6px 10px;font-size:11px;color:#1e40af;text-align:left;width:24px;"></th>
        <th style="padding:6px 10px;font-size:11px;color:#1e40af;text-align:left;">Nazwa głosu</th>
        <th style="padding:6px 10px;font-size:11px;color:#1e40af;text-align:left;">Kategoria</th>
        <th style="padding:6px 10px;font-size:11px;color:#1e40af;text-align:left;">Voice ID</th>
      </tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>
</div>'''

    @api.depends('after_action', 'after_ivr_id', 'after_fifo_id',
                 'after_cc_id', 'after_user_id', 'after_pstn')
    def _compute_after_target(self):
        for rec in self:
            action = rec.after_action
            if action == 'ivr'          and rec.after_ivr_id:
                rec.after_target = rec.after_ivr_id.name
            elif action == 'fifo'       and rec.after_fifo_id:
                rec.after_target = rec.after_fifo_id.name
            elif action == 'callcenter' and rec.after_cc_id:
                rec.after_target = rec.after_cc_id.name
            elif action == 'user'       and rec.after_user_id:
                rec.after_target = rec.after_user_id.extension or rec.after_user_id.name
            elif action == 'pstn':
                rec.after_target = rec.after_pstn or ''
            else:
                rec.after_target = ''

    @api.onchange('after_action')
    def _onchange_after_action(self):
        self.after_ivr_id  = False
        self.after_fifo_id = False
        self.after_cc_id   = False
        self.after_user_id = False
        self.after_pstn    = ''

    def _compute_ivr_use_count(self):
        IVRItem = self.env['freeswitch.ivr.item']
        col_exists = 'sound_id' in IVRItem._fields
        if col_exists:
            try:
                self.env.cr.execute(
                    "SELECT 1 FROM information_schema.columns "
                    "WHERE table_name='freeswitch_ivr_item' AND column_name='sound_id' LIMIT 1"
                )
                col_exists = bool(self.env.cr.fetchone())
            except Exception:
                col_exists = False

        for rec in self:
            if col_exists:
                try:
                    rec.ivr_use_count = IVRItem.search_count([('sound_id', '=', rec.id)])
                except Exception:
                    rec.ivr_use_count = 0
            else:
                rec.ivr_use_count = 0

    # ─────────────────────────────────────────────────────────────────────
    # AKCJE
    # ─────────────────────────────────────────────────────────────────────
    def action_generate_tts(self):
        """Generuj plik audio z tekstu przez ElevenLabs."""
        self.ensure_one()
        if not self.tts_text:
            raise UserError(_('Wpisz tekst do syntezowania TTS.'))
        self._tts_elevenlabs()
        self._push_to_fs_server()
        # Przeładuj formularz aby player audio pojawił się natychmiast
        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'views': [(False, 'form')],
            'target': 'current',
            'context': {
                **self.env.context,
                'show_tts_success': True,
            },
        }

    def _get_fs_company_config(self):
        """Pobierz konfigurację FreeSWITCH dla firmy bieżącego rekordu."""
        company = self.company_id or self.env.company
        return self.env['freeswitch.company.config']._get_for_company(company)

    def _get_el_api_key(self):
        """Pobierz i wyczyść klucz API ElevenLabs.

        Kolejność szukania:
        1. freeswitch.company.config (Ustawienia per firma → zakładka ElevenLabs TTS)
        2. ir.config_parameter 'freeswitch.elevenlabs_api_key' (Ustawienia → FreeSWITCH)
        """
        raw = ''

        # 1) Per firma
        try:
            cfg = self._get_fs_company_config()
            raw = (cfg.elevenlabs_api_key or '').strip().strip('"\'').strip()
        except Exception:
            pass

        # 2) Globalny parametr systemowy
        if not raw:
            ICP = self.env['ir.config_parameter'].sudo()
            raw = (ICP.get_param('freeswitch.elevenlabs_api_key') or '').strip().strip('"\'').strip()

        _logger.info('ElevenLabs API key: clean_len=%d prefix=%s',
                     len(raw), raw[:8] if raw else '(empty)')

        if not raw:
            raise UserError(
                _('Brak klucza API ElevenLabs.\n'
                  'Ustaw go w jednym z miejsc:\n'
                  '• FreeSWITCH → Konfiguracja → Ustawienia per firma → zakładka ElevenLabs TTS\n'
                  '• Ustawienia → FreeSWITCH → blok ElevenLabs TTS'))
        return raw

    def _tts_elevenlabs(self):
        """ElevenLabs Text-to-Speech API — zwraca MP3."""
        try:
            import requests
        except ImportError:
            raise UserError(_('Brak biblioteki requests: pip install requests'))

        api_key  = self._get_el_api_key()
        voice_id = self.el_voice_id
        if not voice_id:
            raise UserError(
                _('Wybierz Voice ID.\n'
                  'Kliknij "Pobierz głosy" aby załadować dostępne głosy z ElevenLabs.'))

        model_id = self.el_model_id or 'eleven_multilingual_v2'
        url      = f'https://api.elevenlabs.io/v1/text-to-speech/{voice_id}'

        payload = {
            'text':     self.tts_text,
            'model_id': model_id,
            'voice_settings': {
                'stability':        max(0.0, min(1.0, self.el_stability)),
                'similarity_boost': max(0.0, min(1.0, self.el_similarity_boost)),
                'style':            max(0.0, min(1.0, self.el_style)),
                'use_speaker_boost': bool(self.el_use_speaker_boost),
            },
        }
        headers = {
            'xi-api-key':   api_key,
            'Content-Type': 'application/json',
            'Accept':       'audio/mpeg',
        }

        _logger.info('ElevenLabs TTS: voice=%s model=%s', voice_id, model_id)
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=60)
        except Exception as e:
            raise UserError(_('Błąd połączenia z ElevenLabs: %s') % str(e))

        if resp.status_code == 401:
            raise UserError(_('Nieprawidłowy klucz API ElevenLabs (401 Unauthorized).'))
        if resp.status_code == 422:
            raise UserError(_('Błąd walidacji ElevenLabs: %s') % resp.text)
        if not resp.ok:
            raise UserError(_('ElevenLabs API error %d: %s') % (resp.status_code, resp.text[:300]))

        audio_bytes = resp.content
        fname = self._safe_fname('.mp3')
        voice_label = self.el_voice_name or voice_id[:8]
        self.write({
            'audio_data':  base64.b64encode(audio_bytes),
            'audio_fname': fname,
            'audio_mime':  'audio/mpeg',
            'tts_status':  f'ElevenLabs ✓ | {voice_label} | {model_id} | {len(audio_bytes)//1024} KB',
        })

    def action_fetch_voices(self):
        """Pobierz listę dostępnych głosów z ElevenLabs i zapisz w cache per firma."""
        self.ensure_one()
        try:
            import requests, json
        except ImportError:
            raise UserError(_('Brak biblioteki requests.'))

        api_key = self._get_el_api_key()
        headers = {'xi-api-key': api_key}

        try:
            resp = requests.get('https://api.elevenlabs.io/v1/voices', headers=headers, timeout=20)
        except Exception as e:
            raise UserError(_('Błąd połączenia z ElevenLabs: %s') % str(e))

        if resp.status_code == 401:
            raise UserError(_('Nieprawidłowy klucz API ElevenLabs.'))
        if not resp.ok:
            raise UserError(_('ElevenLabs API error %d') % resp.status_code)

        data   = resp.json()
        voices = data.get('voices', [])
        simplified = [
            {
                'voice_id': v.get('voice_id', ''),
                'name':     v.get('name', ''),
                'category': v.get('category', ''),
            }
            for v in voices
        ]
        company_id = self.company_id.id or self.env.company.id
        ICP = self.env['ir.config_parameter'].sudo()
        ICP.set_param(f'freeswitch.el_voices_cache.{company_id}', json.dumps(simplified))

        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title':   _('ElevenLabs'),
                'message': _('Załadowano %d głosów ✓') % len(simplified),
                'type':    'success',
            },
        }

    def action_set_voice(self):
        """Pomocnicza akcja wywoływana z listy głosów — ustawia el_voice_id."""
        pass

    def action_test_elevenlabs_key(self):
        """Testuj połączenie z ElevenLabs — pełna diagnostyka klucza i odpowiedzi API."""
        self.ensure_one()
        try:
            import requests
        except ImportError:
            raise UserError(_('Brak biblioteki requests.'))

        ICP = self.env['ir.config_parameter'].sudo()
        diag_lines = ['=== DIAGNOSTYKA KLUCZA API ELEVENLABS ===', '']

        # Źródło A: freeswitch.company.config
        key_from_config = ''
        try:
            cfg = self._get_fs_company_config()
            raw_cfg = cfg.elevenlabs_api_key or ''
            key_from_config = raw_cfg.strip().strip('"\'').strip()
            diag_lines.append(f'[A] Ustawienia per firma:')
            diag_lines.append(f'    surowa długość:      {len(raw_cfg)} znaków')
            diag_lines.append(f'    oczyszczona długość: {len(key_from_config)} znaków')
            diag_lines.append(f'    pierwsze 12 znaków:  {key_from_config[:12]}...')
            diag_lines.append(f'    ostatnie 4 znaki:    ...{key_from_config[-4:] if key_from_config else ""}')
            hidden = [hex(ord(c)) for c in raw_cfg if ord(c) < 32 or ord(c) > 126]
            if hidden:
                diag_lines.append(f'    ⚠ NIEWIDZIALNE ZNAKI: {hidden[:10]}')
            else:
                diag_lines.append(f'    znaki specjalne: brak ✓')
        except Exception as e:
            diag_lines.append(f'[A] Ustawienia per firma: BŁĄD — {e}')

        # Źródło B: ir.config_parameter
        raw_icp = ICP.get_param('freeswitch.elevenlabs_api_key') or ''
        key_from_icp = raw_icp.strip().strip('"\'').strip()
        diag_lines.append('')
        diag_lines.append(f'[B] Globalny parametr systemowy:')
        diag_lines.append(f'    oczyszczona długość: {len(key_from_icp)} znaków')
        if key_from_icp:
            diag_lines.append(f'    pierwsze 12 znaków: {key_from_icp[:12]}...')
        else:
            diag_lines.append('    (pusty)')

        api_key = key_from_config or key_from_icp
        source  = '[A] per firma' if key_from_config else ('[B] globalny' if key_from_icp else 'BRAK')
        diag_lines.append('')
        diag_lines.append(f'Używany klucz ze źródła: {source}')
        diag_lines.append(f'Długość końcowa: {len(api_key)} znaków')
        diag_lines.append('')

        if not api_key:
            raise UserError('\n'.join(diag_lines) + '\n\nBRAK KLUCZA — nie można wykonać testu.')

        diag_lines.append('=== TEST POŁĄCZENIA Z API ===')
        try:
            resp = requests.get(
                'https://api.elevenlabs.io/v1/models',
                headers={'xi-api-key': api_key},
                timeout=10,
            )
            diag_lines.append(f'HTTP status: {resp.status_code}')
            diag_lines.append(f'Content-Type: {resp.headers.get("Content-Type", "?")}')
            body = resp.text[:500]
            diag_lines.append(f'Odpowiedź serwera:\n{body}')
        except Exception as e:
            raise UserError('\n'.join(diag_lines) + f'\n\nBłąd połączenia: {e}')

        _logger.info('ElevenLabs diag:\n%s', '\n'.join(diag_lines))

        if resp.status_code == 401:
            try:
                err_detail = resp.json().get('detail', {})
                err_msg = err_detail.get('message', resp.text[:200]) if isinstance(err_detail, dict) else str(err_detail)
            except Exception:
                err_msg = resp.text[:200]
            diag_lines.append('')
            diag_lines.append(f'POWÓD BŁĘDU 401: {err_msg}')
            raise UserError('\n'.join(diag_lines))

        if not resp.ok:
            raise UserError('\n'.join(diag_lines))

        try:
            models_list = resp.json()
            model_names = [m.get('model_id', '') for m in models_list if isinstance(m, dict)]
            models_info = ', '.join(model_names[:4]) or '?'
        except Exception:
            models_info = 'OK'

        account_info = f'Źródło klucza: {source}'
        try:
            r2 = requests.get(
                'https://api.elevenlabs.io/v1/user',
                headers={'xi-api-key': api_key},
                timeout=5,
            )
            if r2.ok:
                info = r2.json()
                sub  = info.get('subscription', {})
                account_info = (
                    f'Konto: {info.get("first_name","–")} | '
                    f'Plan: {sub.get("tier","?")} | '
                    f'Znaki: {sub.get("character_count","?")} / {sub.get("character_limit","?")} | '
                    f'Źródło: {source}'
                )
        except Exception:
            pass

        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title':   _('ElevenLabs — Połączenie OK ✓'),
                'message': _(f'Modele: {models_info}\n{account_info}'),
                'type':    'success',
                'sticky':  True,
            },
        }

    # ── Upload na serwer FS ───────────────────────────────────────────────
    def _push_to_fs_server(self):
        if not self.audio_data or not self.fs_path:
            return
        try:
            import requests
            cfg = self._get_fs_company_config()
            api_url = (cfg.api_url or '').rstrip('/') if hasattr(cfg, 'api_url') else ''
            api_key = cfg.odoo_api_key or ''
            if not api_url:
                return
            headers = {'X-API-Key': api_key} if api_key else {}
            audio_bytes = base64.b64decode(self.audio_data)
            files = {'file': (self.audio_fname, io.BytesIO(audio_bytes), self.audio_mime)}
            resp  = requests.post(
                f'{api_url}/sounds/upload', headers=headers,
                files=files, data={'path': self.fs_path}, timeout=30,
            )
            resp.raise_for_status()
            _logger.info('Sound uploaded to FS: %s', self.fs_path)
        except Exception as e:
            _logger.warning('Cannot push sound to FS: %s', e)

    def action_push_to_fs(self):
        self.ensure_one()
        if not self.audio_data:
            raise UserError(_('Brak pliku audio.'))
        if not self.fs_path:
            raise UserError(_('Podaj ścieżkę na serwerze FreeSWITCH.'))
        self._push_to_fs_server()
        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {'title': _('Upload'), 'message': _('Plik wysłany ✓'), 'type': 'success'},
        }

    # ── Konwersja audio → WAV 8kHz mono ─────────────────────────────────
    @staticmethod
    def _convert_to_wav_bytes(audio_bytes, src_fname):
        """
        Konwertuje bajty pliku audio (MP3/OGG/WAV) do WAV 8kHz mono.
        Zwraca (wav_bytes, 'audio/wav') lub (None, None) gdy konwersja niemożliwa.

        Narzędzia (w kolejności prób):
          1. SoX  — lekki, szybki, dedykowany do audio
                    apt install sox libsox-fmt-mp3
          2. ffmpeg — fallback gdy brak SoX
                    apt install ffmpeg
        """
        src_ext = os.path.splitext(src_fname or '')[1].lower() or '.mp3'
        if src_ext == '.wav':
            return audio_bytes, 'audio/wav'

        src_path = dst_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix=src_ext, delete=False) as src_f:
                src_f.write(audio_bytes)
                src_path = src_f.name
            dst_path = src_path[:-len(src_ext)] + '.wav'

            # ── Próba 1: SoX ──────────────────────────────────────────────
            # sox <src> -r 8000 -c 1 -e signed-integer -b 16 <dst>
            # libsox-fmt-mp3 wymagany do obsługi MP3
            try:
                result = subprocess.run(
                    ['sox', src_path,
                     '-r', '8000', '-c', '1',
                     '-e', 'signed-integer', '-b', '16',
                     dst_path],
                    capture_output=True, timeout=30,
                )
                if result.returncode == 0:
                    with open(dst_path, 'rb') as f:
                        wav_bytes = f.read()
                    _logger.info('SoX: %s → WAV 8kHz mono (%d bytes)', src_fname, len(wav_bytes))
                    return wav_bytes, 'audio/wav'
                else:
                    _logger.warning('SoX failed (rc=%d): %s',
                                    result.returncode,
                                    result.stderr.decode(errors='replace')[:200])
            except FileNotFoundError:
                _logger.info('SoX not found — trying ffmpeg')

            # ── Próba 2: ffmpeg ───────────────────────────────────────────
            try:
                result = subprocess.run(
                    ['ffmpeg', '-y', '-i', src_path,
                     '-ar', '8000', '-ac', '1',
                     '-acodec', 'pcm_s16le',
                     '-f', 'wav', dst_path],
                    capture_output=True, timeout=30,
                )
                if result.returncode == 0:
                    with open(dst_path, 'rb') as f:
                        wav_bytes = f.read()
                    _logger.info('ffmpeg: %s → WAV 8kHz mono (%d bytes)', src_fname, len(wav_bytes))
                    return wav_bytes, 'audio/wav'
                else:
                    _logger.warning('ffmpeg failed (rc=%d): %s',
                                    result.returncode,
                                    result.stderr.decode(errors='replace')[:200])
            except FileNotFoundError:
                _logger.warning('ffmpeg not found either — skipping conversion')

            return None, None

        except Exception as e:
            _logger.warning('Audio conversion error: %s', e)
            return None, None
        finally:
            for p in (src_path, dst_path):
                if p:
                    try:
                        os.unlink(p)
                    except Exception:
                        pass

    def _apply_wav_conversion(self, vals):
        """
        Jeśli vals zawiera audio_data i plik nie jest WAV —
        konwertuj do WAV 8kHz mono i zaktualizuj vals w miejscu.
        """
        audio_b64 = vals.get('audio_data')
        fname     = vals.get('audio_fname') or (self.audio_fname if self.id else 'sound.mp3')
        if not audio_b64 or not fname:
            return
        ext = os.path.splitext(fname)[1].lower()
        if ext == '.wav':
            return  # już WAV, nic do roboty
        try:
            audio_bytes = base64.b64decode(audio_b64)
        except Exception:
            return
        wav_bytes, mime = self._convert_to_wav_bytes(audio_bytes, fname)
        if wav_bytes:
            wav_fname = os.path.splitext(fname)[0] + '.wav'
            vals['audio_data']  = base64.b64encode(wav_bytes).decode()
            vals['audio_fname'] = wav_fname
            vals['audio_mime']  = 'audio/wav'
            _logger.info('Saved as WAV: %s → %s', fname, wav_fname)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            self._apply_wav_conversion(vals)
        return super().create(vals_list)

    def write(self, vals):
        if 'audio_data' in vals:
            self._apply_wav_conversion(vals)
        return super().write(vals)

    # ── Helpers ───────────────────────────────────────────────────────────
    def _safe_fname(self, ext='.mp3'):
        base = re.sub(r'[^a-zA-Z0-9_\-]', '_', self.name or 'sound')
        return f'{base}{ext}'

    @api.onchange('tts_text', 'name')
    def _onchange_tts_text(self):
        if self.name and not self.fs_path:
            try:
                cfg = self._get_fs_company_config()
                sounds_dir = cfg.sounds_dir or '/etc/freeswitch/sounds/pl'
            except Exception:
                sounds_dir = '/etc/freeswitch/sounds/pl'
            fname = re.sub(r'[^a-zA-Z0-9_\-]', '_', self.name)
            self.fs_path = f'{sounds_dir.rstrip("/")}/{fname}.mp3'

    @api.onchange('audio_data', 'audio_fname')
    def _onchange_audio_data(self):
        if self.audio_data and self.audio_fname:
            fname = (self.audio_fname or '').lower()
            if fname.endswith('.mp3'):
                self.audio_mime = 'audio/mpeg'
            elif fname.endswith('.ogg'):
                self.audio_mime = 'audio/ogg'
            else:
                self.audio_mime = 'audio/wav'

    @api.onchange('el_voice_id')
    def _onchange_el_voice_id(self):
        """Aktualizuj nazwę głosu przy wpisaniu Voice ID."""
        if not self.el_voice_id:
            self.el_voice_name = ''
            return
        try:
            import json
            company_id = self.company_id.id or self.env.company.id
            ICP = self.env['ir.config_parameter'].sudo()
            voices_json = ICP.get_param(
                f'freeswitch.el_voices_cache.{company_id}', ''
            ) or ICP.get_param('freeswitch.el_voices_cache', '')
            if voices_json:
                voices = json.loads(voices_json)
                match = next((v for v in voices if v['voice_id'] == self.el_voice_id), None)
                if match:
                    self.el_voice_name = match['name']
        except Exception:
            pass