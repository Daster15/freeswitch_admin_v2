# -*- coding: utf-8 -*-
import json
import logging
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

IVR_ACTIONS = [
    ('ivr',         'Zagnieżdżone menu IVR'),
    ('fifo',        'Kolejka FIFO'),
    ('callcenter',  'Kolejka CallCenter'),
    ('user',        'Użytkownik / Wewnętrzny'),
    ('pstn',        'Numer zewnętrzny PSTN'),
    ('playback',    'Odtwórz plik audio'),
    ('voicemail',   'Poczta głosowa'),
    ('hangup',      'Rozłącz'),
    ('repeat',      'Powtórz menu'),
]


class FreeSwitchIVR(models.Model):
    _name        = 'freeswitch.ivr'
    _description = 'FreeSWITCH — Konfiguracja IVR'
    _inherit     = ['mail.thread', 'mail.activity.mixin', 'freeswitch.db.mixin',
                    'freeswitch.multicompany.mixin']
    _order       = 'name'

    company_id = fields.Many2one(
        'res.company',
        string='Firma',
        required=True,
        index=True,
        default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('name_company_unique', 'UNIQUE(name, company_id)',
         'Nazwa IVR musi być unikalna w ramach firmy!'),
    ]

    fs_uuid      = fields.Char('UUID FreeSWITCH', readonly=True, copy=False, index=True)
    name         = fields.Char('Nazwa IVR (klucz)', required=True, tracking=True,
                               help='Unikalny klucz używany w dialplanie, np. ivr-mokotow-glowne')
    description  = fields.Char('Opis', required=True, tracking=True)
    greeting_id  = fields.Many2one(
        'freeswitch.sound', string='Plik audio (powitanie)',
        ondelete='set null', tracking=True,
    )
    greeting_player = fields.Html(
        related='greeting_id.audio_player',
        string='Odsłuch powitania', sanitize=False,
    )
    timeout_sec  = fields.Integer('Timeout (sekundy)', default=7, required=True)
    max_failures = fields.Integer('Maks. błędnych prób', default=3, required=True)
    active       = fields.Boolean('Aktywny', default=True, tracking=True)

    menu_item_ids = fields.One2many(
        'freeswitch.ivr.item', 'ivr_id', string='Opcje menu',
        copy=True,
    )
    item_count = fields.Integer('Liczba opcji', compute='_compute_item_count')

    # ── Akcja domyślna po wyczerpaniu prób ──────────────────────────────
    default_action  = fields.Selection(IVR_ACTIONS, string='Akcja po błędach', default='hangup')

    # Selektory dla akcji domyślnej
    default_ivr_id  = fields.Many2one('freeswitch.ivr',      string='Docelowe IVR',        ondelete='set null')
    default_fifo_id = fields.Many2one('freeswitch.fifo',     string='Docelowa kolejka FIFO', ondelete='set null')
    default_cc_id   = fields.Many2one('freeswitch.cc.queue', string='Docelowa kolejka CC',  ondelete='set null')
    default_user_id = fields.Many2one('freeswitch.cc.agent', string='Użytkownik SIP',
                                      domain=[('active', '=', True)], ondelete='set null')
    default_sound_id = fields.Many2one(
        'freeswitch.sound', string='Plik audio (odtwarzanie)',
        ondelete='set null',
    )
    default_sound_player = fields.Html(
        related='default_sound_id.audio_player',
        string='Odsłuch', sanitize=False,
    )
    default_pstn = fields.Char(string='Numer PSTN', help='np. +48221234567')

    # Obliczany cel do zapisu w FS (używany przez sync)
    default_target = fields.Char(
        string='Cel akcji domyślnej', compute='_compute_default_target', store=True,
    )

    @api.depends('menu_item_ids')
    def _compute_item_count(self):
        for rec in self:
            rec.item_count = len(rec.menu_item_ids)

    @api.depends('default_action', 'default_ivr_id', 'default_fifo_id',
                 'default_cc_id', 'default_user_id', 'default_sound_id', 'default_pstn')
    def _compute_default_target(self):
        for rec in self:
            action = rec.default_action
            if action == 'ivr'        and rec.default_ivr_id:
                rec.default_target = rec.default_ivr_id.name
            elif action == 'fifo'     and rec.default_fifo_id:
                rec.default_target = rec.default_fifo_id.name
            elif action == 'callcenter' and rec.default_cc_id:
                rec.default_target = rec.default_cc_id.name
            elif action == 'user'     and rec.default_user_id:
                rec.default_target = rec.default_user_id.extension
            elif action == 'playback' and rec.default_sound_id:
                rec.default_target = (
                    rec.default_sound_id.fs_path or rec.default_sound_id.audio_fname or ''
                )
            elif action == 'pstn':
                rec.default_target = rec.default_pstn or ''
            else:
                rec.default_target = ''

    # ── Onchange selektory → czyść przy zmianie akcji ────────────────────
    @api.onchange('default_action')
    def _onchange_default_action(self):
        self.default_ivr_id   = False
        self.default_fifo_id  = False
        self.default_cc_id    = False
        self.default_user_id  = False
        self.default_sound_id = False
        self.default_pstn     = ''

    # ── Sync ─────────────────────────────────────────────────────────────
    def _build_menu_items_json(self):
        items = []
        for item in sorted(self.menu_item_ids, key=lambda x: x.sequence):
            items.append({
                'digit':       item.digit,
                'description': item.description or '',
                'action':      item.action,
                'target':      item.target or '',
            })
        return json.dumps(items)

    def action_sync_to_fs(self):
        for rec in self:
            menu_json = rec._build_menu_items_json()
            if rec.fs_uuid:
                rec._fs_execute("""
                    UPDATE ivr_configs SET
                        name         = %s,
                        description  = %s,
                        greeting     = %s,
                        timeout_sec  = %s,
                        max_failures = %s,
                        menu_items   = %s::jsonb,
                        active       = %s,
                        updated_at   = NOW()
                    WHERE id = %s::uuid
                """, (rec.name, rec.description,
                      rec.greeting_id.fs_path or rec.greeting_id.audio_fname or None,
                      rec.timeout_sec, rec.max_failures,
                      menu_json, rec.active, rec.fs_uuid))
            else:
                rows = rec._fs_query("""
                    INSERT INTO ivr_configs
                        (name, description, greeting, timeout_sec, max_failures, menu_items, active)
                    VALUES (%s, %s, %s, %s, %s, %s::jsonb, %s)
                    RETURNING id::text
                """, (rec.name, rec.description,
                      rec.greeting_id.fs_path or rec.greeting_id.audio_fname or None,
                      rec.timeout_sec, rec.max_failures,
                      menu_json, rec.active))
                if rows:
                    rec.fs_uuid = rows[0].get('id') or list(rows[0].values())[0]

        return {
            'type':    'ir.actions.client',
            'tag':     'display_notification',
            'params': {
                'title':   _('IVR'),
                'message': _('Konfiguracja IVR zapisana ✓'),
                'type':    'success',
            }
        }

    def action_sync_from_fs(self):
        rows = self._fs_query("""
            SELECT id::text, name, description, greeting,
                   timeout_sec, max_failures, menu_items::text, active
            FROM ivr_configs ORDER BY name
        """)
        created = updated = 0
        for row in rows:
            greeting_path = row.get('greeting') or ''
            greeting_rec  = False
            if greeting_path:
                greeting_rec = self.env['freeswitch.sound'].search(
                    ['|', ('fs_path', '=', greeting_path),
                           ('audio_fname', '=', greeting_path.split('/')[-1])],
                    limit=1,
                )
            vals = {
                'fs_uuid':      row.get('id') or row.get('id::text'),
                'name':         row.get('name', ''),
                'description':  row.get('description') or row.get('name', ''),
                'greeting_id':  greeting_rec.id if greeting_rec else False,
                'timeout_sec':  row.get('timeout_sec', 7),
                'max_failures': row.get('max_failures', 3),
                'active':       row.get('active', True),
            }
            existing = self.search([('fs_uuid', '=', vals['fs_uuid'])])
            if existing:
                existing.write(vals)
                existing.menu_item_ids.unlink()
                rec = existing
                updated += 1
            else:
                rec = self.create(vals)
                created += 1

            items_json = row.get('menu_items') or '[]'
            try:
                items = json.loads(items_json)
                for seq, item in enumerate(items, 1):
                    action = item.get('action', 'hangup')
                    target = item.get('target', '')

                    # ── Odtwórz powiązania Many2one na podstawie target (string) ──
                    target_ivr_id   = False
                    target_fifo_id  = False
                    target_cc_id    = False
                    target_user_id  = False
                    target_sound_id = False

                    if target:
                        if action == 'ivr':
                            r = self.env['freeswitch.ivr'].search(
                                [('name', '=', target)], limit=1)
                            target_ivr_id = r.id if r else False

                        elif action == 'fifo':
                            r = self.env['freeswitch.fifo'].search(
                                [('name', '=', target)], limit=1)
                            target_fifo_id = r.id if r else False

                        elif action == 'callcenter':
                            r = self.env['freeswitch.cc.queue'].search(
                                [('name', '=', target)], limit=1)
                            target_cc_id = r.id if r else False

                        elif action == 'user':
                            r = self.env['freeswitch.sip.user'].search(
                                [('name', '=', target)], limit=1)
                            target_user_id = r.id if r else False

                        elif action == 'playback':
                            r = self.env['freeswitch.sound'].search(
                                ['|',
                                 ('fs_path', '=', target),
                                 ('audio_fname', '=', target.split('/')[-1])],
                                limit=1,
                            )
                            target_sound_id = r.id if r else False

                    self.env['freeswitch.ivr.item'].create({
                        'ivr_id':          rec.id,
                        'sequence':        seq * 10,
                        'digit':           str(item.get('digit', '')),
                        'description':     item.get('description', ''),
                        'action':          action,
                        'target':          target,
                        'target_ivr_id':   target_ivr_id,
                        'target_fifo_id':  target_fifo_id,
                        'target_cc_id':    target_cc_id,
                        'target_user_id':  target_user_id,
                        'target_sound_id': target_sound_id,
                    })
            except Exception:
                _logger.exception('Błąd parsowania menu_items dla IVR %s', rec.name)

        return {
            'type':    'ir.actions.client',
            'tag':     'display_notification',
            'params': {
                'title':   _('Import IVR'),
                'message': _('Zaimportowano: %d nowych, %d zaktualizowanych') % (created, updated),
                'type':    'success',
            }
        }