# -*- coding: utf-8 -*-
"""
freeswitch_company_config.py
============================
Konfiguracja FreeSWITCH per firma (multi-company).

Każda firma w Odoo może mieć własny serwer FreeSWITCH
z osobnym połączeniem DB, REST API, domeną SIP, bramką PSTN itp.

Zastępuje globalne ir.config_parameter z res.config.settings.
"""

import logging
import secrets

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class FreeSwitchPstnNumber(models.Model):
    """
    Pula numerów PSTN przypisanych do bramki (gateway) danej firmy.
    Tylko te numery będą dostępne przy tworzeniu tras DDI.
    """
    _name        = 'freeswitch.pstn.number'
    _description = 'FreeSWITCH — Numer PSTN (pula tenanta)'
    _rec_name    = 'display_name'
    _order       = 'number'

    config_id = fields.Many2one(
        'freeswitch.company.config',
        string='Konfiguracja firmy',
        required=True,
        ondelete='cascade',
        index=True,
    )
    company_id = fields.Many2one(
        'res.company',
        related='config_id.company_id',
        store=True,
        index=True,
        readonly=True,
    )
    number = fields.Char(
        string='Numer PSTN',
        required=True,
        help='Numer w formacie E.164, np. +48221234567',
    )
    description = fields.Char(
        string='Opis',
        help='Np. "Linia główna", "Infolinia"',
    )
    active = fields.Boolean(
        string='Aktywny',
        default=True,
    )
    # Computed — czy numer jest już przypisany do trasy DDI
    route_id = fields.Many2one(
        'freeswitch.route',
        string='Trasa DDI',
        compute='_compute_route_id',
        store=False,
    )

    display_name = fields.Char(
        string='Nazwa wyświetlana',
        compute='_compute_display_name',
        store=True,
    )

    _sql_constraints = [
        ('number_company_unique', 'UNIQUE(number, company_id)',
         'Numer PSTN musi być unikalny w ramach firmy!'),
    ]

    @api.depends('number', 'description')
    def _compute_display_name(self):
        for rec in self:
            if rec.description:
                rec.display_name = f'{rec.number} — {rec.description}'
            else:
                rec.display_name = rec.number or ''

    @api.depends('number', 'company_id')
    def _compute_route_id(self):
        for rec in self:
            route = self.env['freeswitch.route'].search([
                ('pstn_number_id', '=', rec.id),
            ], limit=1)
            rec.route_id = route


class FreeSwitchCompanyConfig(models.Model):
    _name        = 'freeswitch.company.config'
    _description = 'FreeSWITCH — Konfiguracja per firma'
    _rec_name    = 'company_id'

    company_id = fields.Many2one(
        'res.company',
        string='Firma',
        required=True,
        ondelete='cascade',
        index=True,
        default=lambda self: self.env.company,
    )

    # ── Połączenie z bazą FreeSWITCH ────────────────────────────────────
    use_same_db = fields.Boolean(
        string='Ta sama baza co Odoo',
        default=True,
        help='Zaznacz jeśli FreeSWITCH i Odoo korzystają z tej samej bazy PostgreSQL.',
    )
    db_host = fields.Char(
        string='Host PostgreSQL',
        default='127.0.0.1',
    )
    db_port = fields.Integer(
        string='Port',
        default=5432,
    )
    db_name = fields.Char(
        string='Nazwa bazy',
        default='freeswitch',
    )
    db_user = fields.Char(
        string='Użytkownik',
        default='freeswitch',
    )
    db_password = fields.Char(
        string='Hasło',
    )

    # ── REST API FreeSWITCH (FastAPI) ────────────────────────────────────
    api_url = fields.Char(
        string='URL REST API FreeSWITCH',
        default='http://127.0.0.1:8000/api/v1',
        help='Bazowy URL serwisu FastAPI FreeSWITCH.',
    )
    api_key = fields.Char(
        string='Klucz API (do FreeSWITCH)',
    )

    # ── REST API Odoo — klucz dla systemów zewnętrznych ──────────────────
    odoo_api_key = fields.Char(
        string='Klucz API Odoo (X-API-Key)',
        readonly=True,
        copy=False,
        help='Klucz generowany przez Odoo. '
             'Przekazywany w nagłówku X-API-Key przez systemy zewnętrzne.',
    )

    # ── Domena SIP ───────────────────────────────────────────────────────
    sip_domain = fields.Char(
        string='Domena SIP',
        default='sip.example.pl',
        help='Domena SIP do budowania kontaktów, np. sofia/internal/1001@domena.',
    )
    gateway = fields.Char(
        string='Gateway SIP (PSTN)',
        default='default',
        help='Nazwa bramki do połączeń PSTN.',
    )
    recordings_url = fields.Char(
        string='URL nagrań',
        default='http://127.0.0.1:8000/api/v1/recordings/file',
        help='Bazowy URL do pobierania plików nagrań.',
    )
    sounds_dir = fields.Char(
        string='Katalog dźwięków na serwerze FS',
        default='/etc/freeswitch/sounds/pl',
        help='Ścieżka bazowa do katalogu dźwięków na serwerze FreeSWITCH.',
    )

    # ── Pula numerów PSTN (DDI) ──────────────────────────────────────────
    pstn_number_ids = fields.One2many(
        'freeswitch.pstn.number',
        'config_id',
        string='Numery PSTN (DDI)',
        help='Lista numerów PSTN przypisanych do bramki tej firmy. '
             'Tylko te numery będą dostępne w konfiguracji tras DDI.',
    )

    # ── ElevenLabs TTS ───────────────────────────────────────────────────
    elevenlabs_api_key = fields.Char(
        string='ElevenLabs API Key',
        help='Klucz API z panelu ElevenLabs (xi-api-key).',
    )

    _sql_constraints = [
        ('company_unique', 'UNIQUE(company_id)',
         'Konfiguracja FreeSWITCH dla tej firmy już istnieje!'),
    ]

    # ── Generowanie klucza API ────────────────────────────────────────────
    def action_generate_api_key(self):
        """Wygeneruj nowy losowy klucz API dla systemów zewnętrznych."""
        self.ensure_one()
        self.odoo_api_key = secrets.token_urlsafe(32)
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title':   _('Klucz API'),
                'message': _('Nowy klucz API wygenerowany. Skopiuj go teraz — nie będzie ponownie wyświetlony.'),
                'type':    'warning',
                'sticky':  True,
            },
        }

    def action_revoke_api_key(self):
        """Unieważnij klucz API."""
        self.ensure_one()
        self.odoo_api_key = False
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title':   _('Klucz API'),
                'message': _('Klucz API został unieważniony.'),
                'type':    'success',
                'sticky':  False,
            },
        }

    # ── Test połączeń ─────────────────────────────────────────────────────
    def action_test_db_connection(self):
        self.ensure_one()
        try:
            mixin = self.env['freeswitch.db.mixin'].with_company(self.company_id)
            mixin.test_connection()
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title':   _('FreeSWITCH DB'),
                    'message': _('Połączenie z bazą PostgreSQL — OK ✓'),
                    'type':    'success',
                    'sticky':  False,
                },
            }
        except Exception as e:
            raise UserError(str(e))

    def action_test_api_connection(self):
        self.ensure_one()
        try:
            import requests
        except ImportError:
            raise UserError(_('Brak biblioteki requests. Zainstaluj: pip install requests'))
        url = (self.api_url or '').rstrip('/') + '/health'
        headers = {}
        if self.api_key:
            headers['X-API-Key'] = self.api_key
        try:
            resp = requests.get(url, headers=headers, timeout=5)
            resp.raise_for_status()
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title':   _('FreeSWITCH REST API'),
                    'message': _('Połączenie z REST API FreeSWITCH — OK ✓'),
                    'type':    'success',
                    'sticky':  False,
                },
            }
        except Exception as e:
            raise UserError(_('Błąd REST API: %s') % str(e))

    # ── Helper: pobierz config dla bieżącej firmy ─────────────────────────
    @api.model
    def _get_for_company(self, company=None):
        """
        Zwróć rekord konfiguracji dla podanej firmy (domyślnie env.company).
        Rzuca UserError jeśli brak konfiguracji.
        """
        company = company or self.env.company
        cfg = self.sudo().search([('company_id', '=', company.id)], limit=1)
        if not cfg:
            raise UserError(
                _('Brak konfiguracji FreeSWITCH dla firmy "%s". '
                  'Przejdź do: FreeSWITCH → Konfiguracja → Ustawienia per firma.')
                % company.name
            )
        return cfg