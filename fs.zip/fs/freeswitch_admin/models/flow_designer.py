# -*- coding: utf-8 -*-
"""
flow_designer.py
================
Model przepływu call-flow z dwukierunkową synchronizacją z modelami Odoo:
  - freeswitch.route     (DID node)
  - freeswitch.ivr       (IVR node)
  - freeswitch.fifo      (FIFO node)
  - freeswitch.cc.queue  (CallCenter node)
  - freeswitch.sip.user  (User/SIP node)
  - freeswitch.sound     (pliki audio / dźwięki)

Architektura:
  * Każdy węzeł może być "powiązany" z istniejącym rekordem (odoo_id w flow_data)
  * Zapis przepływu → tworzy lub aktualizuje powiązane rekordy
  * Połączenia węzłów (connections) → ustawiają route_type/route_target, menu IVR itp.
"""
import json
import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

# ── Mapowanie: typ węzła → model Odoo ────────────────────────────────────────
NODE_MODEL_MAP = {
    'did':        'freeswitch.route',
    'ivr':        'freeswitch.ivr',
    'timerule':   None,                # wbudowany w freeswitch.route (time_rule_ids)
    'fifo':       'freeswitch.fifo',
    'callcenter': 'freeswitch.cc.queue',
    'user':       'freeswitch.sip.user',
    'pstn':       None,                # nie ma osobnego modelu; to tylko target
    'voicemail':  'freeswitch.sip.user',  # alias — to ten sam SIP user
}


class FreeswitchFlow(models.Model):
    _name        = 'freeswitch.flow'
    _description = 'FreeSWITCH — Call Flow Designer'
    _inherit     = ['mail.thread', 'mail.activity.mixin']
    _rec_name    = 'name'
    _order       = 'write_date desc'

    name        = fields.Char(string='Nazwa przepływu', required=True,
                               default='Nowy przepływ')
    description = fields.Text(string='Opis')
    flow_data   = fields.Text(
        string='Dane przepływu (JSON)',
        default='{"nodes":[],"connections":[]}',
    )
    active         = fields.Boolean(string='Aktywny', default=True)
    node_count     = fields.Integer(string='Węzły',     compute='_compute_counts', store=False)
    connection_count = fields.Integer(string='Połączenia', compute='_compute_counts', store=False)
    last_exported  = fields.Datetime(string='Ostatni eksport')
    color          = fields.Integer(string='Kolor', default=0)

    @api.depends('flow_data')
    def _compute_counts(self):
        for rec in self:
            try:
                data = json.loads(rec.flow_data or '{}')
                rec.node_count       = len(data.get('nodes', []))
                rec.connection_count = len(data.get('connections', []))
            except Exception:
                rec.node_count = rec.connection_count = 0

    # ── Otwarcie designera ────────────────────────────────────────────────────
    def action_open_designer(self):
        self.ensure_one()
        return {
            'type':    'ir.actions.client',
            'tag':     'freeswitch_flow_designer',
            'name':    f'Flow Designer — {self.name}',
            'context': {'flow_id': self.id},
            'target':  'main',
        }

    # ── Podstawowy zapis/odczyt flow_data (prosty) ────────────────────────────
    def save_flow_data(self, flow_json):
        """Prosty zapis flow_data (bez syncu z modelami)."""
        self.ensure_one()
        self.write({'flow_data': json.dumps(flow_json, ensure_ascii=False)})
        return {
            'success': True,
            'node_count': self.node_count,
            'connection_count': self.connection_count,
        }

    def get_flow_data(self):
        self.ensure_one()
        try:
            return json.loads(self.flow_data or '{}')
        except Exception:
            return {'nodes': [], 'connections': []}

    # ─────────────────────────────────────────────────────────────────────────
    # GŁÓWNA METODA: załaduj dostępne rekordy dla selektorów w JS
    # ─────────────────────────────────────────────────────────────────────────
    def get_designer_data(self):
        """
        Zwraca słownik ze wszystkimi istniejącymi rekordami Odoo
        pogrupowanymi wg typów węzłów. Używane przez JS przy inicjalizacji
        designera do wypełnienia list rozwijanych w panelu właściwości.
        """
        # ensure_one() zastąpione ręczną obsługą — flow może nie istnieć (id=0)
        if not self or not self.id:
            flow_data = {'nodes': [], 'connections': []}
            flow_name = 'Nowy przepływ'
        else:
            self.ensure_one()
            try:
                flow_data = json.loads(self.flow_data or '{}')
                if 'nodes' not in flow_data:
                    flow_data = {'nodes': [], 'connections': []}
            except Exception:
                flow_data = {'nodes': [], 'connections': []}
            flow_name = self.name

        env = self.env

        def _records(model, fields_list, domain=None):
            domain = domain or [('active', '=', True)]
            try:
                recs = env[model].search(domain, order='name', limit=200)
                return recs.read(fields_list)
            except Exception as e:
                _logger.warning("get_designer_data: %s — %s", model, e)
                return []

        # Pliki audio — wspólna lista dla wszystkich typów węzłów
        sounds = _records(
            'freeswitch.sound',
            ['id', 'name', 'audio_fname', 'fs_path', 'category'],
            domain=[],
        )

        return {
            'flow_data': flow_data,
            'flow_name': flow_name,

            # Dostępne rekordy per typ węzła
            'records': {
                'did': _records(
                    'freeswitch.route',
                    ['id', 'name', 'pstn_number_id', 'description', 'route_type', 'route_target',
                     'active', 'use_time_rules'],
                ),
                'ivr': _records(
                    'freeswitch.ivr',
                    ['id', 'name', 'description', 'timeout_sec', 'max_failures',
                     'greeting_id', 'active'],
                ),
                'fifo': _records(
                    'freeswitch.fifo',
                    ['id', 'name', 'description', 'max_wait_sec',
                     'moh_sound_id', 'announce_freq', 'active'],
                ),
                'callcenter': _records(
                    'freeswitch.cc.queue',
                    ['id', 'name', 'description', 'strategy',
                     'max_wait_time', 'moh_sound_id', 'active'],
                ),
                'user': _records(
                    'freeswitch.sip.user',
                    ['id', 'name', 'display_name_full', 'first_name', 'last_name',
                     'email', 'department', 'noanswer_timeout', 'active'],
                ),
                'voicemail': _records(
                    'freeswitch.sip.user',
                    ['id', 'name', 'display_name_full', 'email', 'vm_password', 'active'],
                ),
            },

            # Pliki audio do wyboru w polach muzyki/powitania
            'sounds': sounds,

            # Strategie CallCenter (dla selecta w UI)
            'cc_strategies': [
                ('longest-idle-agent',        'Najdłużej bezczynny'),
                ('round-robin',               'Round-robin'),
                ('top-down',                  'Od góry listy'),
                ('agent-with-fewest-calls',   'Najmniej połączeń'),
                ('ring-all',                  'Dzwoń do wszystkich'),
                ('random',                    'Losowy'),
            ],

            # Agenci CC — wzbogaceni o pełne dane urządzeń SIP
            'agents': self._get_agents_with_devices(),
        }

    def save_and_sync_flow(self, flow_data):
        """Alias dla save_flow_with_sync — wywoływany z JS."""
        return self.save_flow_with_sync(flow_data)

    def _get_agents_with_devices(self):
        """
        Zwraca listę agentów CC z pełnymi danymi urządzeń SIP.
        Odoo read() zwraca Many2many jako same ID — tu wzbogacamy o nazwy i typy.
        """
        env = self.env
        try:
            agents = env['freeswitch.cc.agent'].search(
                [('active', '=', True)], order='name', limit=200
            ).read(['id', 'name', 'display_name_field', 'extension',
                    'contact', 'sip_device_ids', 'active'])
        except Exception:
            return []

        # Zbierz wszystkie ID urządzeń ze wszystkich agentów
        all_device_ids = []
        for a in agents:
            all_device_ids.extend(a.get('sip_device_ids') or [])
        all_device_ids = list(set(all_device_ids))

        # Pobierz pełne dane urządzeń jednym zapytaniem
        devices_by_id = {}
        if all_device_ids:
            try:
                devices = env['freeswitch.sip.device'].browse(all_device_ids).read(
                    ['id', 'display_name_device', 'device_type', 'ring_strategy',
                     'sequence', 'active']
                )
                devices_by_id = {d['id']: d for d in devices}
            except Exception:
                pass

        # Wzbogać agentów o pełne obiekty urządzeń
        for agent in agents:
            dev_ids = agent.get('sip_device_ids') or []
            agent['devices'] = [
                devices_by_id[did]
                for did in dev_ids
                if did in devices_by_id
            ]

        return agents

    # ─────────────────────────────────────────────────────────────────────────
    # GŁÓWNA METODA: zapisz przepływ + synchronizuj z modelami Odoo
    # ─────────────────────────────────────────────────────────────────────────
    def save_flow_with_sync(self, flow_data):
        """
        Zapisuje flow_data oraz tworzy/aktualizuje powiązane rekordy Odoo.

        Logika:
        1. Iteruj węzły → utwórz/zaktualizuj rekordy w odpowiednich modelach.
        2. Iteruj połączenia → ustaw route_type/route_target, opcje IVR itp.
        3. Zapisz zaktualizowane flow_data (z odoo_id dla nowych rekordów).
        """
        self.ensure_one()
        env = self.env

        nodes       = {n['id']: n for n in flow_data.get('nodes', [])}
        connections = flow_data.get('connections', [])

        # ── Krok 1: Utwórz / zaktualizuj rekordy węzłów ──────────────────────
        for node in nodes.values():
            ntype  = node.get('type')
            config = node.get('config', {})
            oid    = node.get('odoo_id')  # None = nowy rekord

            try:
                if ntype == 'did':
                    oid = self._sync_did_node(node, config, oid)
                elif ntype == 'ivr':
                    oid = self._sync_ivr_node(node, config, oid)
                elif ntype == 'fifo':
                    oid = self._sync_fifo_node(node, config, oid)
                elif ntype == 'callcenter':
                    oid = self._sync_callcenter_node(node, config, oid)
                elif ntype == 'user':
                    oid = self._sync_user_node(node, config, oid)
                elif ntype == 'audioplayer':
                    oid = self._sync_audioplayer_node(node, config, oid)
                elif ntype == 'voicemail':
                    oid = self._sync_voicemail_node(node, config, oid)
                # timerule i pstn nie mają własnego modelu
            except Exception as e:
                _logger.error("save_flow_with_sync: węzeł %s (%s) — %s",
                              node.get('id'), ntype, e)
              #  raise UserError(_(
              #      "Błąd zapisu węzła „%(label)s" (%(ntype)s):\n%(error)s",
               #     label=node.get('label', node.get('id')),
              #     ntype=ntype,
               #     error=str(e),
               # )) from e

            if oid:
                node['odoo_id'] = oid

        # ── Krok 2: Ustaw relacje z połączeń ─────────────────────────────────
        self._apply_connections(nodes, connections)

        # ── Krok 3: Zapisz zaktualizowane flow_data ───────────────────────────
        updated_flow = {
            'nodes':       list(nodes.values()),
            'connections': connections,
        }
        self.write({'flow_data': json.dumps(updated_flow, ensure_ascii=False)})

        return {
            'success':    True,
            'node_count': len(nodes),
            'conn_count': len(connections),
            'flow_data':  updated_flow,
        }

    # ─────────────────────────────────────────────────────────────────────────
    # Prywatne metody sync per typ węzła
    # ─────────────────────────────────────────────────────────────────────────

    def _sync_did_node(self, node, config, odoo_id):
        """Synchronizuj węzeł DID z modelem freeswitch.route."""
        Route      = self.env['freeswitch.route']
        PstnNumber = self.env['freeswitch.pstn.number']

        pstn_number_id = config.get('pstn_number_id')
        did_pattern    = config.get('did_pattern', '')

        # Jeśli podano pstn_number_id — użyj go; wpp. spróbuj znaleźć po numerze
        if not pstn_number_id and did_pattern:
            pstn_rec = PstnNumber.search([('number', '=', did_pattern)], limit=1)
            if pstn_rec:
                pstn_number_id = pstn_rec.id

        if not pstn_number_id:
            return odoo_id  # Brak numeru PSTN — pomijamy

        vals = {
            'pstn_number_id': pstn_number_id,
            'description':    config.get('description', did_pattern),
            'active':         True,
            # route_type i route_target ustawiane w _apply_connections
        }

        if odoo_id:
            rec = Route.browse(odoo_id)
            if rec.exists():
                rec.write(vals)
                return odoo_id
        # Próbuj znaleźć po pstn_number_id
        existing = Route.search([('pstn_number_id', '=', pstn_number_id)], limit=1)
        if existing:
            existing.write(vals)
            return existing.id
        # Nowy rekord
        vals['route_type']   = 'ivr'
        vals['route_target'] = '_pending_'
        new_rec = Route.create(vals)
        return new_rec.id

    def _sync_ivr_node(self, node, config, odoo_id):
        """Synchronizuj węzeł IVR z modelem freeswitch.ivr + freeswitch.ivr.item."""
        IVR = self.env['freeswitch.ivr']
        greeting_id = config.get('greeting_id') or self._find_sound_id(config.get('greeting', ''))
        vals = {
            'name':         config.get('name', ''),
            'description':  config.get('description', config.get('name', '')),
            'timeout_sec':  int(config.get('timeout', 7)),
            'max_failures': int(config.get('max_failures', 3)),
            'active':       True,
        }
        if greeting_id:
            vals['greeting_id'] = greeting_id

        if not vals['name']:
            return odoo_id

        # Utwórz lub zaktualizuj rekord IVR
        if odoo_id:
            rec = IVR.browse(odoo_id)
            if rec.exists():
                rec.write(vals)
            else:
                odoo_id = None
        if not odoo_id:
            existing = IVR.search([('name', '=', vals['name'])], limit=1)
            if existing:
                existing.write(vals)
                rec = existing
            else:
                rec = IVR.create(vals)
            odoo_id = rec.id

        # ── Synchronizuj pozycje menu (ivr.item) z menu_items konfigu ────────
        # Buduj mapę istniejących itemów wg cyfry
        IVRItem = self.env['freeswitch.ivr.item']
        existing_items = {it.digit: it for it in rec.menu_item_ids}
        menu_items = config.get('menu_items', [])
        seen_digits = set()

        for seq, mi in enumerate(menu_items, 1):
            digit = str(mi.get('digit', ''))
            if not digit:
                continue
            seen_digits.add(digit)
            desc = mi.get('description', f'Cyfra {digit}')
            item_vals = {
                'ivr_id':      rec.id,
                'sequence':    seq * 10,
                'digit':       digit,
                'description': desc,
                # action/target zostaną nadpisane przez _apply_connections gdy jest połączenie
            }
            if digit in existing_items:
                existing_items[digit].write({
                    'sequence':    item_vals['sequence'],
                    'description': item_vals['description'],
                })
            else:
                # Nowy item — potrzebujemy action, ustaw domyślne
                item_vals['action'] = 'hangup'
                item_vals['target'] = ''
                IVRItem.create(item_vals)

        # Usuń itemy których cyfry nie ma już w konfigu
        for digit, item in existing_items.items():
            if digit not in seen_digits:
                item.unlink()

        return odoo_id

    def _sync_fifo_node(self, node, config, odoo_id):
        """Synchronizuj węzeł FIFO z modelem freeswitch.fifo."""
        FIFO = self.env['freeswitch.fifo']

        # Klucze dźwięków — config JS używa moh_id / announce_id (int ID)
        moh_id      = config.get('moh_id') or None
        announce_id = config.get('announce_id') or None

        vals = {
            'name':          config.get('name', ''),
            'description':   config.get('description', config.get('name', '')),
            'max_wait_sec':  int(config.get('max_wait', 300)),
            'announce_freq': int(config.get('announce_freq', 60)),
            'importance':    int(config.get('importance', 0)),
            'active':        True,
        }
        vals['moh_sound_id']      = int(moh_id)      if moh_id      else False
        vals['announce_sound_id'] = int(announce_id) if announce_id else False

        timeout_action = config.get('timeout_action', '')
        if timeout_action:
            vals['timeout_action'] = timeout_action

        if not vals['name']:
            return odoo_id

        if odoo_id:
            rec = FIFO.browse(odoo_id)
            if not rec.exists():
                odoo_id = None
            else:
                rec.write(vals)
        if not odoo_id:
            existing = FIFO.search([("name", "=", vals["name"])], limit=1)
            if existing:
                existing.write(vals)
                rec = existing
            else:
                rec = FIFO.create(vals)
            odoo_id = rec.id
        else:
            rec = FIFO.browse(odoo_id)

        # ── Synchronizuj agentów ──────────────────────────────────────────────
        agents_cfg = config.get('agents', [])
        if isinstance(agents_cfg, list):
            rec.agent_ids.unlink()
            FIFOAgent = self.env['freeswitch.fifo.agent']
            SipDevice = self.env['freeswitch.sip.device']
            for a in agents_cfg:
                extension   = a.get('extension', '')
                contact     = a.get('contact', '')
                cc_agent_id = a.get('cc_agent_id') or False
                device_ids  = [int(d) for d in (a.get('device_ids') or []) if d]

                if cc_agent_id:
                    cc_agent_id = int(cc_agent_id)
                    cc_rec = self.env['freeswitch.cc.agent'].browse(cc_agent_id)
                    if cc_rec.exists():
                        extension = extension or cc_rec.extension or ''
                        if device_ids:
                            # Użyj wybranych urządzeń
                            devices = SipDevice.browse(device_ids).filtered(
                                lambda d: d.active
                            ).sorted('sequence')
                            contact = cc_rec._build_contact_from_devices(devices) or cc_rec.contact or ''
                        else:
                            # Brak wyboru → domyślnie tylko urządzenie SIP (device_type='sip')
                            sip_devices = cc_rec.sip_device_ids.filtered(
                                lambda d: d.active and d.device_type == 'sip'
                            ).sorted('sequence')
                            if sip_devices:
                                contact = cc_rec._build_contact_from_devices(sip_devices) or cc_rec.contact or ''
                            else:
                                contact = contact or cc_rec.contact or ''
                    else:
                        cc_agent_id = False

                if not extension or not contact:
                    continue

                agent_rec = FIFOAgent.create({
                    'fifo_id':    rec.id,
                    'cc_agent_id': cc_agent_id or False,
                    'extension':  extension,
                    'contact':    contact,
                    'sequence':   int(a.get('sequence', 10)),
                    'active':     bool(a.get('active', True)),
                })
                # Przypisz urządzenia do agenta FIFO (Many2many)
                if device_ids and cc_agent_id:
                    valid_devices = SipDevice.browse(device_ids).filtered(
                        lambda d: d.active and d.user_id and d.user_id.cc_agent_id.id == cc_agent_id
                    )
                    if valid_devices:
                        agent_rec.write({'sip_device_ids': [(6, 0, valid_devices.ids)]})

        return odoo_id

    def _sync_callcenter_node(self, node, config, odoo_id):
        """Synchronizuj węzeł CallCenter z modelem freeswitch.cc.queue."""
        CC = self.env['freeswitch.cc.queue']

        # moh_id w config to int ID rekordu freeswitch.sound
        moh_id = config.get('moh_id') or None

        vals = {
            'name':              config.get('name', ''),
            'description':       config.get('description', config.get('name', '')),
            'strategy':          config.get('strategy', 'longest-idle-agent'),
            'max_wait_time':     int(config.get('max_wait_time', 0)),
            'max_wait_no_agent': int(config.get('max_wait_no_agent', 120)),
            'record_template':   config.get('record_template', '/nagrania/{uuid}.wav'),
            'active':            True,
        }
        vals['moh_sound_id'] = int(moh_id) if moh_id else False

        if not vals['name']:
            return odoo_id

        if odoo_id:
            rec = CC.browse(odoo_id)
            if not rec.exists():
                odoo_id = None
            else:
                rec.write(vals)
        if not odoo_id:
            existing = CC.search([("name", "=", vals["name"])], limit=1)
            if existing:
                existing.write(vals)
                rec = existing
            else:
                rec = CC.create(vals)
            odoo_id = rec.id
        else:
            rec = CC.browse(odoo_id)

        # ── Synchronizuj tiery agentów ────────────────────────────────────────
        tiers_cfg = config.get('tiers', [])
        if isinstance(tiers_cfg, list):
            rec.tier_ids.unlink()
            CCTier = self.env['freeswitch.cc.tier']
            seen_agents = set()
            for t in tiers_cfg:
                agent_id = t.get('agent_id') or False
                if not agent_id:
                    continue
                agent_id = int(agent_id)
                # Constraint: agent tylko raz w kolejce
                if agent_id in seen_agents:
                    continue
                seen_agents.add(agent_id)
                cc_agent = self.env['freeswitch.cc.agent'].browse(agent_id)
                if not cc_agent.exists():
                    continue
                CCTier.create({
                    'queue_id': rec.id,
                    'agent_id': agent_id,
                    'level':    int(t.get('level', 1)),
                    'position': int(t.get('position', 1)),
                })

        return odoo_id

    def _sync_user_node(self, node, config, odoo_id):
        """Synchronizuj węzeł User SIP z modelem freeswitch.sip.user."""
        SipUser = self.env['freeswitch.sip.user']
        extension = config.get('extension', '')
        if not extension:
            return odoo_id

        vals = {
            'name':             extension,
            'noanswer_timeout': int(config.get('timeout', 30)),
            'active':           True,
        }
        # Jeśli mamy imię/nazwisko to ustaw (mogą być puste przy nowym)
        if config.get('first_name'):
            vals['first_name'] = config['first_name']
        if config.get('last_name'):
            vals['last_name'] = config['last_name']

        if odoo_id:
            rec = SipUser.browse(odoo_id)
            if rec.exists():
                rec.write(vals)
                return odoo_id
        existing = SipUser.search([('name', '=', extension)], limit=1)
        if existing:
            existing.write(vals)
            return existing.id
        # Tworzenie nowego SIP user wymaga imienia/nazwiska
        if not vals.get('first_name'):
            vals['first_name'] = extension
        if not vals.get('last_name'):
            vals['last_name'] = 'SIP'
        return SipUser.create(vals).id

    def _sync_audioplayer_node(self, node, config, odoo_id):
        """Synchronizuj węzeł AudioPlayer z modelem freeswitch.sound (kategoria playback)."""
        Sound = self.env['freeswitch.sound']
        sound_id = config.get('sound_id')
        if not sound_id:
            return odoo_id

        rec = Sound.browse(sound_id)
        if not rec.exists():
            return odoo_id

        # Ustaw kategorię i pola after_*
        vals = {
            'category':     'playback',
            'after_action': config.get('after_action', 'hangup'),
            'after_ivr_id':  False,
            'after_fifo_id': False,
            'after_cc_id':   False,
            'after_user_id': False,
            'after_pstn':    '',
        }
        target_id = config.get('after_target_id')
        action    = vals['after_action']
        if target_id:
            if action == 'ivr':         vals['after_ivr_id']  = target_id
            elif action == 'fifo':      vals['after_fifo_id'] = target_id
            elif action == 'callcenter':vals['after_cc_id']   = target_id
            elif action == 'user':      vals['after_user_id'] = target_id
        if action == 'pstn':
            vals['after_pstn'] = config.get('after_pstn', '')

        rec.write(vals)
        return sound_id  # odoo_id węzła audioplayer = id rekordu freeswitch.sound

    def _sync_voicemail_node(self, node, config, odoo_id):
        """
        Węzeł Voicemail — mapowany na freeswitch.sip.user.
        Mailbox = numer wewnętrzny użytkownika.
        """
        SipUser = self.env['freeswitch.sip.user']
        mailbox = config.get('mailbox', '')
        if not mailbox:
            return odoo_id

        vals = {
            'name':        mailbox,
            'vm_password': config.get('vm_pin', '0000'),
            'active':      True,
        }
        if config.get('email'):
            vals['email'] = config['email']

        if odoo_id:
            rec = SipUser.browse(odoo_id)
            if rec.exists():
                rec.write(vals)
                return odoo_id
        existing = SipUser.search([('name', '=', mailbox)], limit=1)
        if existing:
            existing.write(vals)
            return existing.id
        # Tworzenie nowego SIP user dla voicemail
        vals.update({'first_name': mailbox, 'last_name': 'Voicemail'})
        return SipUser.create(vals).id

    # ─────────────────────────────────────────────────────────────────────────
    # Zastosuj połączenia: ustaw route_type/route_target, opcje IVR
    # ─────────────────────────────────────────────────────────────────────────
    def _apply_connections(self, nodes, connections):
        """
        Przetwarza listę połączeń i ustawia relacje między rekordami Odoo:

        DID → cokolwiek:      route_type + route_target na freeswitch.route
        IVR port 1/2/3 → X:  freeswitch.ivr.item z digit=port, action=type, target=name
        timerule match → X:   route_type + route_target na freeswitch.route (DID parent)
        timerule no_match → X: fallback_type + fallback_target na freeswitch.route
        """
        # Budujemy mapę: node_id → (route_type, route_target, odoo_id)
        def _node_as_target(n):
            """Zwróć (route_type, route_target) dla danego węzła."""
            ntype  = n.get('type')
            config = n.get('config', {})
            oid    = n.get('odoo_id')
            if ntype == 'ivr':
                name = config.get('name', '')
                if not name and oid:
                    ivr = self.env['freeswitch.ivr'].browse(oid)
                    name = ivr.name if ivr.exists() else ''
                return 'ivr', name
            elif ntype == 'fifo':
                name = config.get('name', '')
                if not name and oid:
                    fifo = self.env['freeswitch.fifo'].browse(oid)
                    name = fifo.name if fifo.exists() else ''
                return 'fifo', name
            elif ntype == 'callcenter':
                name = config.get('name', '')
                if not name and oid:
                    cc = self.env['freeswitch.cc.queue'].browse(oid)
                    name = cc.name if cc.exists() else ''
                return 'callcenter', name
            elif ntype == 'user':
                ext = config.get('extension', '')
                if not ext and oid:
                    u = self.env['freeswitch.sip.user'].browse(oid)
                    ext = u.name if u.exists() else ''
                return 'user', ext
            elif ntype == 'pstn':
                return 'pstn', config.get('number', '')
            elif ntype == 'voicemail':
                mb = config.get('mailbox', '')
                if not mb and oid:
                    u = self.env['freeswitch.sip.user'].browse(oid)
                    mb = u.name if u.exists() else ''
                return 'voicemail', mb
            elif ntype == 'playback':
                return 'playback', config.get('sound_path', '')
            return None, None

        # Grupuj połączenia wg węzła źródłowego
        from collections import defaultdict
        out_conns = defaultdict(list)
        for c in connections:
            out_conns[c['fromNode']].append(c)

        Route = self.env['freeswitch.route']
        IVR   = self.env['freeswitch.ivr']

        for from_node_id, conns in out_conns.items():
            from_node = nodes.get(from_node_id)
            if not from_node:
                continue
            from_type = from_node.get('type')
            from_oid  = from_node.get('odoo_id')

            # ── DID node → ustaw route_type / route_target ────────────────
            if from_type == 'did' and from_oid:
                route_rec = Route.browse(from_oid)
                if not route_rec.exists():
                    continue

                # Połączenie "out" z DID → pierwszy target to main route
                # Połączenie "fallback" z DID → fallback
                main_conn     = next((c for c in conns if c['fromPort'] == 'out'), None)
                fallback_conn = next((c for c in conns if c['fromPort'] == 'fallback'), None)

                if main_conn:
                    to_node = nodes.get(main_conn['toNode'])
                    if to_node:
                        rtype, rtarget = _node_as_target(to_node)
                        if rtype and rtarget:
                            to_oid = to_node.get('odoo_id')
                            vals = {
                                'route_type':   rtype,
                                'route_target': rtarget,
                                'route_ivr_id':  False,
                                'route_fifo_id': False,
                                'route_cc_id':   False,
                                'route_user_id': False,
                            }
                            if to_oid:
                                if rtype == 'ivr':          vals['route_ivr_id']  = to_oid
                                elif rtype == 'fifo':       vals['route_fifo_id'] = to_oid
                                elif rtype == 'callcenter': vals['route_cc_id']   = to_oid
                                elif rtype == 'user':
                                    # route_user_id → freeswitch.cc.agent, ale węzeł user to sip.user
                                    # Szukamy agenta po extension
                                    agent = self.env['freeswitch.cc.agent'].search(
                                        [('extension', '=', rtarget)], limit=1)
                                    if agent:
                                        vals['route_user_id'] = agent.id
                            route_rec.write(vals)

                if fallback_conn:
                    to_node = nodes.get(fallback_conn['toNode'])
                    if to_node:
                        ftype, ftarget = _node_as_target(to_node)
                        if ftype and ftarget:
                            to_oid = to_node.get('odoo_id')
                            vals = {
                                'fallback_type':   ftype,
                                'fallback_target': ftarget,
                                'fallback_ivr_id':  False,
                                'fallback_fifo_id': False,
                                'fallback_cc_id':   False,
                            }
                            if to_oid:
                                if ftype == 'ivr':          vals['fallback_ivr_id']  = to_oid
                                elif ftype == 'fifo':       vals['fallback_fifo_id'] = to_oid
                                elif ftype == 'callcenter': vals['fallback_cc_id']   = to_oid
                            route_rec.write(vals)

            # ── IVR node → zaktualizuj akcje pozycji menu (ivr.item) ──────────
            elif from_type == 'ivr' and from_oid:
                ivr_rec = IVR.browse(from_oid)
                if not ivr_rec.exists():
                    continue

                digit_conns  = [c for c in conns if c['fromPort'] not in ('timeout', 'fail')]
                timeout_conn = next((c for c in conns if c['fromPort'] == 'timeout'), None)
                fail_conn    = next((c for c in conns if c['fromPort'] == 'fail'), None)

                IVRItem = self.env['freeswitch.ivr.item']
                items_by_digit = {it.digit: it for it in ivr_rec.menu_item_ids}

                for c in digit_conns:
                    digit   = c['fromPort']
                    to_node = nodes.get(c['toNode'])
                    if not to_node:
                        continue
                    action, target = _node_as_target(to_node)
                    if not action:
                        continue

                    to_label = to_node.get('label', '')
                    to_oid   = to_node.get('odoo_id')

                    # Buduj wartości — ustaw też pole Many2one dla ładnego widoku
                    item_vals = {
                        'action': action,
                        'target': target or '',
                        # Wyczyść wszystkie stare referencje
                        'target_ivr_id':   False,
                        'target_fifo_id':  False,
                        'target_cc_id':    False,
                        'target_user_id':  False,
                        'target_sound_id': False,
                    }
                    if to_oid:
                        if action == 'ivr':
                            item_vals['target_ivr_id']  = to_oid
                        elif action == 'fifo':
                            item_vals['target_fifo_id'] = to_oid
                        elif action == 'callcenter':
                            item_vals['target_cc_id']   = to_oid
                        # 'user' pomijamy — target_user_id wskazuje na cc.agent,
                        # a węzeł 'user' to freeswitch.sip.user — inny model

                    if digit in items_by_digit:
                        items_by_digit[digit].write(item_vals)
                    else:
                        IVRItem.create({
                            'ivr_id':      ivr_rec.id,
                            'sequence':    100,
                            'digit':       str(digit),
                            'description': f'Cyfra {digit} → {to_label}',
                            **item_vals,
                        })

                # Akcja domyślna (timeout / fail)
                for conn_item in [timeout_conn, fail_conn]:
                    if conn_item:
                        to_node = nodes.get(conn_item['toNode'])
                        if to_node:
                            action, target = _node_as_target(to_node)
                            if action:
                                def_vals = {'default_action': action, 'default_target': target or ''}
                                to_oid = to_node.get('odoo_id')
                                if to_oid:
                                    if action == 'ivr':          def_vals['default_ivr_id']  = to_oid
                                    elif action == 'fifo':       def_vals['default_fifo_id'] = to_oid
                                    elif action == 'callcenter': def_vals['default_cc_id']   = to_oid
                                    # 'user' pomijamy — default_user_id to cc.agent, nie sip.user
                                ivr_rec.write(def_vals)
                        break

            # ── audioplayer → zaktualizuj after_* gdy port 'done' jest połączony ─
            elif from_type == 'audioplayer' and from_oid:
                done_conn = next((c for c in conns if c['fromPort'] == 'done'), None)
                if done_conn:
                    to_node = nodes.get(done_conn['toNode'])
                    if to_node:
                        action, target = _node_as_target(to_node)
                        if action:
                            sound_rec = self.env['freeswitch.sound'].browse(from_oid)
                            if sound_rec.exists():
                                upd = {
                                    'after_action':  action,
                                    'after_ivr_id':  False,
                                    'after_fifo_id': False,
                                    'after_cc_id':   False,
                                }
                                to_oid = to_node.get('odoo_id')
                                if to_oid:
                                    if action == 'ivr':         upd['after_ivr_id']  = to_oid
                                    elif action == 'fifo':      upd['after_fifo_id'] = to_oid
                                    elif action == 'callcenter':upd['after_cc_id']   = to_oid
                                sound_rec.write(upd)

            # ── timerule → ustaw na route (DID node nadrzędny) ────────────
            elif from_type == 'timerule':
                # Znajdź DID, który łączy się Z timerule
                did_for_timer = None
                for c2 in connections:
                    if c2['toNode'] == from_node_id:
                        parent = nodes.get(c2['fromNode'])
                        if parent and parent.get('type') == 'did' and parent.get('odoo_id'):
                            did_for_timer = parent
                            break

                if did_for_timer:
                    route_rec = Route.browse(did_for_timer['odoo_id'])
                    if not route_rec.exists():
                        continue
                    # Ustaw reguły czasowe
                    timer_config = from_node.get('config', {})
                    route_rec.write({'use_time_rules': True})
                    # Utwórz/aktualizuj reguły czasowe
                    route_rec.time_rule_ids.unlink()
                    days_csv = timer_config.get('days', 'mon,tue,wed,thu,fri')
                    days_list = [d.strip() for d in days_csv.split(',')]
                    self.env['freeswitch.route.time_rule'].create({
                        'route_id':   route_rec.id,
                        'sequence':   10,
                        'name':       'Godziny pracy',
                        'day_mon':    'mon' in days_list,
                        'day_tue':    'tue' in days_list,
                        'day_wed':    'wed' in days_list,
                        'day_thu':    'thu' in days_list,
                        'day_fri':    'fri' in days_list,
                        'day_sat':    'sat' in days_list,
                        'day_sun':    'sun' in days_list,
                        'time_start': timer_config.get('time_start', '08:00'),
                        'time_end':   timer_config.get('time_end', '17:00'),
                        'timezone':   timer_config.get('timezone', 'Europe/Warsaw'),
                    })

                    # match → route, no_match → fallback
                    match_conn    = next((c for c in conns if c['fromPort'] == 'match'), None)
                    no_match_conn = next((c for c in conns if c['fromPort'] == 'no_match'), None)

                    if match_conn:
                        to_node = nodes.get(match_conn['toNode'])
                        if to_node:
                            rtype, rtarget = _node_as_target(to_node)
                            if rtype and rtarget:
                                route_rec.write({'route_type': rtype, 'route_target': rtarget})

                    if no_match_conn:
                        to_node = nodes.get(no_match_conn['toNode'])
                        if to_node:
                            ftype, ftarget = _node_as_target(to_node)
                            if ftype and ftarget:
                                route_rec.write({'fallback_type': ftype, 'fallback_target': ftarget})

    # ─────────────────────────────────────────────────────────────────────────
    # Helper: znajdź freeswitch.sound po nazwie / ścieżce
    # ─────────────────────────────────────────────────────────────────────────
    def _find_sound_id(self, path_or_name):
        if not path_or_name or path_or_name.startswith('local_stream://'):
            return False
        Sound = self.env['freeswitch.sound']
        rec = Sound.search(
            ['|', ('fs_path', '=', path_or_name),
             '|', ('audio_fname', '=', path_or_name),
                  ('name', '=', path_or_name)],
            limit=1,
        )
        return rec.id if rec else False

    # ─────────────────────────────────────────────────────────────────────────
    # Eksport JSON (z aktualną datą i wywołaniami API)
    # ─────────────────────────────────────────────────────────────────────────
    def get_export_json(self):
        self.ensure_one()
        data = self.get_flow_data()
        return {
            'version':    '2.0',
            'flow_name':  self.name,
            'exported_at': fields.Datetime.now().isoformat(),
            'nodes':       data.get('nodes', []),
            'connections': data.get('connections', []),
        }